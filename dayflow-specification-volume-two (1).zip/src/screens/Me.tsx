import { useClockFormat } from "../lib/time";
import { useMemo, useRef, useState } from "react";
import { Sparkles, Palette, LayoutGrid, Music, Bot, Flower2, DatabaseBackup, Settings as Cog, ClipboardCheck, Info, Search, Plus, Trash2, Download, Upload, Bell, MoonStar, Clock3, Type, ExternalLink } from "lucide-react";
import { useStore, useT, newId, type Intensity, type WidgetFont } from "../lib/store";
import { resolveDecor, type Family } from "../lib/calendar";
import { FAMILY } from "../lib/pattern";
import { WIDGETS, WIDGET_FONTS } from "../lib/widgets";
import { Card, Group, Honest, Row, ScreenHeader, Segmented, Toggle } from "../components/ui";
import { Motif, HeaderCrown, Corner, Divider, EmptyState , seasonIcon } from "../components/Decor";
import { RobotMini } from "../components/Companion";
import { Review } from "./Review";
import { Themes, useAllThemes } from "./Themes";
import { WidgetHub } from "./WidgetHub";
import { CITIES, prayerTimes, PRAYER_NAMES } from "../lib/prayer";
import { WidgetRenderer } from "../components/WidgetRenderer";
import { nativeBridge } from "../lib/nativeBridge";
import { ModelViewer } from "../components/ModelViewer";

export function Me({ sub, go }: { sub?: string; go: (tab: string, sub?: string) => void }) {
  const t = useT();
  const s = useStore();
  const back = () => go("me");
  const all = useAllThemes();
  const theme = all.find((x) => x.id === s.themeId);
  if (sub === "review") return <Review onBack={back} />;
  if (sub === "themes") return <Themes onBack={back} />;
  if (sub === "widgets") return <WidgetHub onBack={back} />;
  if (sub === "sounds") return <Sounds onBack={back} />;
  if (sub === "decor") return <DecorSettings onBack={back} />;
  if (sub === "companion") return <CompanionSettings onBack={back} />;
  if (sub === "backup") return <Backup onBack={back} />;
  if (sub === "settings") return <SettingsScreen onBack={back} />;
  if (sub === "notifs") return <NotifSettings onBack={back} />;
  if (sub === "alarmlook") return <AlarmLookScreen onBack={back} />;
  if (sub === "prayer") return <PrayerSettings onBack={back} />;
  if (sub === "widgetlook") return <WidgetLookScreen onBack={back} />;
  if (sub === "ledger") return <Ledger onBack={back} />;
  if (sub === "about") return <About onBack={back} />;
  return (
    <div className="pb-4">
      <ScreenHeader title={t("Me", "أنا")} />
      <Card className="mb-5 flex items-center gap-4 p-4">
        <RobotMini size={64} family={resolveDecor(new Date(), s.userDays).primary} />
        <div className="flex-1"><p className="font-bold">DAYFLOW</p><p className="text-xs muted">{t("Private · offline · on this device", "خاص · دون اتصال · على هذا الجهاز")}</p><p className="mt-1 text-xs accent">{theme ? (s.lang === "ar" ? theme.ar : theme.en) : ""}</p></div>
      </Card>
      <Group title={t("Insight", "رؤى")}>
        <Row icon={<Sparkles size={18} />} title={t("Review", "المراجعة")} hint={t("Daily, weekly and yearly — explainable", "يومي وأسبوعي وسنوي — وكل درجة ليها سبب")} onClick={() => go("me", "review")} />
        <Row icon={<Bot size={18} />} title={t("AI assistant & API keys", "مساعد الذكاء ومفاتيح API")} hint={t("GPT · Claude · Gemini · Groq · OpenRouter · local", "GPT · Claude · Gemini · Groq · OpenRouter · محلي")} onClick={() => go("ai")} />
      </Group>
      <Group title={t("Look & feel", "المظهر")}>
        <Row icon={<Palette size={18} />} title={t("Themes", "السمات")} hint={t(`${all.length} packs, studio, per-surface`, `${all.length} حزمة، استوديو، لكل واجهة`)} onClick={() => go("me", "themes")} />
        <Row icon={<Flower2 size={18} />} title={t("Seasons & decoration", "المواسم والزينة")} hint={t("Intensity, surfaces, personal days", "الشدة، الواجهات، الأيام الشخصية")} onClick={() => go("me", "decor")} />
        <Row icon={<LayoutGrid size={18} />} title={t("Widgets", "الودجات")} hint={t(`${WIDGETS.length} designs that change shape`, `${WIDGETS.length} تصميمًا متغير الشكل`)} onClick={() => go("me", "widgets")} />
        <Row icon={<Bell size={18} />} title={t("Notifications", "الإشعارات")} hint={t("Style, privacy, quiet hours, evening review", "الشكل والخصوصية والهدوء ومراجعة المسا")} onClick={() => go("me", "notifs")} />
        <Row icon={<MoonStar size={18} />} title={t("Alarm screen", "شاشة المنبه")} hint={t("Layout, seconds, gradient, ornament", "الشكل والثواني والتدرج والزخرفة")} onClick={() => go("me", "alarmlook")} />
        <Row icon={<Clock3 size={18} />} title={t("Prayer times & city", "مواقيت الصلاة والمدينة")} hint={t("Calculated on device — Cairo, Alexandria…", "حساب على الجهاز — القاهرة، إسكندرية…")} onClick={() => go("me", "prayer")} />
        <Row icon={<Type size={18} />} title={t("Widget fonts & ornaments", "خطوط وزخارف الودجات")} hint={t("Naskh · Kufi · Cairo · rounded · mono", "نسخ · كوفي · القاهرة · مستدير · ثابت")} onClick={() => go("me", "widgetlook")} />
        <Row icon={<Music size={18} />} title={t("Sounds", "الأصوات")} onClick={() => go("me", "sounds")} />
        <Row icon={<Bot size={18} />} title={t("Companion", "الرفيق")} hint={s.companion.enabled ? t("On", "مفعّل") : t("Disabled completely", "ملغي تمامًا")} right={<Toggle on={s.companion.enabled} onChange={(v) => s.set({ companion: { ...s.companion, enabled: v, hidden: false } })} label="companion" />} onClick={() => go("me", "companion")} />
      </Group>
      <Group title={t("Data & app", "البيانات والتطبيق")}>
        <Row icon={<DatabaseBackup size={18} />} title={t("Backup & restore", "النسخ الاحتياطي")} onClick={() => go("me", "backup")} />
        <Row icon={<Cog size={18} />} title={t("Settings", "الإعدادات")} onClick={() => go("me", "settings")} />
        <Row icon={<ClipboardCheck size={18} />} title={t("Verification ledger", "سجل التحقق")} hint={t("What's built and what isn't — honestly", "ما بُني وما لم يُبنَ — بصدق")} onClick={() => go("me", "ledger")} />
        <Row icon={<Info size={18} />} title={t("About & credits", "حول والاعتمادات")} onClick={() => go("me", "about")} />
      </Group>
    </div>
  );
}

function DecorSettings({ onBack }: { onBack: () => void }) {
  const t = useT(); const s = useStore();
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [name, setName] = useState(""); const [md, setMd] = useState(""); const [fam, setFam] = useState<Family>("birthday");
  const d = new Date(date + "T12:00");
  const stack = resolveDecor(d, s.userDays, 3, s.examSeason);
  const f = stack.primary;
  return (
    <div className="pb-4">
      <ScreenHeader title={t("Seasons & decoration", "المواسم والزينة")} onBack={onBack} />
      <p className="mb-2 text-xs font-semibold muted">{t("Intensity", "الشدة")}</p>
      <Segmented<Intensity> value={s.intensity} onChange={(v) => s.set({ intensity: v })} options={[{ id: "off", label: t("Off", "إيقاف") }, { id: "subtle", label: t("Subtle", "هادئ") }, { id: "rich", label: t("Rich", "غني") }, { id: "festival", label: t("Festival", "احتفالي") }]} />
      <Card className="my-3 p-3">
        <p className="mb-2 text-sm font-bold">{t("Floating decoration layer", "الزخارف العايمة تظهر فين؟")}</p>
        <Segmented value={s.decorLayer} onChange={(v) => s.set({ decorLayer: v })} options={[{ id: "behind", label: t("Behind content", "في الخلفية") }, { id: "above", label: t("Over content", "فوق المحتوى") }]} />
        <p className="mt-2 text-xs muted">{t("Decoration never blocks buttons or typing.", "الزينة مش بتمنع الضغط أو الكتابة، حتى لو فوق المحتوى.")}</p>
      </Card>
      <Group title={t("Where to decorate", "أين تظهر الزينة")}>
        {(["app", "notifications", "widgets", "icon", "companion"] as const).map((k) => <Row key={k} title={{ app: t("In the app", "داخل التطبيق"), notifications: t("Notifications", "الإشعارات"), widgets: t("Widgets", "الودجات"), icon: t("App icon", "أيقونة التطبيق"), companion: t("Companion outfit", "زي الرفيق") }[k]} right={<Toggle on={s.decorSurfaces[k]} onChange={(v) => s.set({ decorSurfaces: { ...s.decorSurfaces, [k]: v } })} label={k} />} />)}
      </Group>
      <h3 className="mb-2 mt-2 px-1 font-bold">{t("Preview any date", "معاينة أي تاريخ")}</h3>
      <input type="date" className="field mb-3" value={date} onChange={(e) => setDate(e.target.value)} />
      <div className="card relative overflow-hidden p-4" style={{ minHeight: 210 }}>
        <HeaderCrown family={f} height={50} />
        <Corner family={f} pos="bl" size={60} /><Corner family={f} pos="br" size={60} />
        <div className="relative mt-2 flex flex-wrap gap-1.5">{stack.layers.map((l, i) => <span key={i} className="chip"><Motif family={l.family} size={14} />{s.lang === "ar" ? l.ar : l.en}</span>)}</div>
        <Divider family={f} className="my-4" />
        <div className="flex justify-center gap-4">{stack.layers.map((l, i) => <Motif key={i} family={l.family} size={44} />)}</div>
      </div>
      <p className="mt-2 text-xs muted">{t("Order: occasion → season → weekday accent → personal day → climate. At most 3 ornament layers per screen.", "الترتيب: مناسبة ← موسم ← لمسة اليوم ← يوم شخصي ← المناخ. ٣ طبقات زخرفية كحد أقصى لكل شاشة.")}</p>
      <Group title={t("Ornament families", "عائلات الزخارف")}>
        <div className="grid grid-cols-5 gap-2 p-3">{(Object.keys(FAMILY) as Family[]).map((k) => <div key={k} className="flex flex-col items-center gap-1 text-center"><div className="grid h-12 w-12 place-items-center rounded-2xl" style={{ background: FAMILY[k].c3 }}><Motif family={k} size={34} /></div><span className="text-[9px] leading-tight muted">{s.lang === "ar" ? FAMILY[k].ar : FAMILY[k].en}</span></div>)}</div>
      </Group>
      <Group title={t("Personal days", "الأيام الشخصية")}>
        {s.userDays.map((u) => <Row key={u.id} icon={<Motif family={u.family} size={20} />} title={u.en} hint={u.date} right={<button onClick={() => s.set({ userDays: s.userDays.filter((x) => x.id !== u.id) })} className="muted" aria-label="delete"><Trash2 size={15} /></button>} />)}
        <form className="flex flex-wrap gap-2 p-3" onSubmit={(e) => { e.preventDefault(); if (name && md) { s.set({ userDays: [...s.userDays, { id: newId(), date: md.slice(5), en: name, ar: name, kind: fam === "birthday" ? "birthday" : "custom", family: fam }] }); setName(""); } }}>
          <input className="field flex-1" value={name} onChange={(e) => setName(e.target.value)} placeholder={t("e.g. My birthday", "مثال: عيد ميلادي")} />
          <input type="date" className="field w-40" value={md} onChange={(e) => setMd(e.target.value)} />
          <select className="field w-32" value={fam} onChange={(e) => setFam(e.target.value as Family)}>{(["birthday", "love", "spring", "islamic", "newyear"] as Family[]).map((k) => <option key={k} value={k}>{s.lang === "ar" ? FAMILY[k].ar : FAMILY[k].en}</option>)}</select>
          <button className="btn btn-primary"><Plus size={16} /></button>
        </form>
      </Group>
      <Honest>{t("All ornaments here are generated by DAYFLOW's pattern engine (exact geometry: star tilings, snowflakes, waves, lotus, lantern). Licensed photography and illustration packs are pending acquisition and appear only after their licenses pass the redistribution check.", "كل الزخارف هنا يولّدها محرك الأنماط في DAYFLOW (هندسة دقيقة: نجوم، بلورات ثلج، موج، لوتس، فانوس). حزم الصور والرسوم المرخّصة قيد الاقتناء ولن تظهر إلا بعد اجتياز تراخيصها فحص إعادة التوزيع.")}</Honest>
    </div>
  );
}

function Sounds({ onBack }: { onBack: () => void }) {
  const t = useT();
  const approved = ["Google Sound Library (CC-BY 4.0)", "AOSP platform sounds (per-file check)", "Kenney audio (CC0)", "OpenGameArt (CC0 only)", "Freesound (CC0 only)", "Internet Archive (public domain)", "Incompetech / FMA (CC-BY)"];
  const rejected = [["ZapSplat", t("no redistribution as a library", "لا يسمح بإعادة التوزيع كمكتبة")], ["Mixkit", t("license restricts standalone redistribution", "الترخيص يقيد إعادة التوزيع المستقل")], ["Envato / AudioJungle", t("marketplace license", "ترخيص سوق تجاري")], ["Samsung One UI tones", t("OEM tones can't be redistributed — use Device tones instead", "نغمات المصنّع لا يجوز توزيعها — استخدم نغمات الجهاز")], ["Pixabay audio", t("pending: clause must be quoted & pass extractability test", "معلّق: يجب اقتباس البند واجتياز اختبار الاستخراج")]];
  return (
    <div className="pb-4">
      <ScreenHeader title={t("Sounds", "الأصوات")} onBack={onBack} />
      <Card className="mb-4 p-4"><p className="font-bold">{t("Library reset", "إعادة ضبط المكتبة")}</p><p className="mt-1 text-sm muted">{t("Every previously bundled sound was removed. New tones are added file-by-file only after license, hash, loudness (alarms ≈ −16 LUFS, notifications ≈ −18 LUFS) and duration checks pass. Target: 160+ tones.", "حُذفت كل الأصوات المضمّنة سابقًا. تُضاف النغمات الجديدة ملفًا ملفًا بعد اجتياز فحص الترخيص والبصمة وشدة الصوت (المنبه ≈ −16 LUFS، الإشعارات ≈ −18 LUFS) والمدة. الهدف: ١٦٠+ نغمة.")}</p>
        <div className="mt-3 flex items-center gap-3"><span className="text-3xl font-bold">0</span><span className="text-xs muted">{t("bundled now · 160 target · acquisition pending (no network in this build)", "مضمّنة الآن · الهدف ١٦٠ · الاقتناء معلّق (لا شبكة في هذه البيئة)")}</span></div></Card>
      <Group title={t("Sources in the picker", "المصادر في المنتقي")}>
        <Row title={t("DAYFLOW library", "مكتبة DAYFLOW")} hint={t("Curated, license-verified", "منتقاة ومفحوصة الترخيص")} />
        <Row title={t("Device tones", "نغمات الجهاز")} hint={t("Your phone's own tones, including any your manufacturer provides. Stored as a reference, never copied.", "نغمات هاتفك، بما فيها نغمات الشركة المصنّعة. تُحفظ كمرجع ولا تُنسخ.")} />
        <Row title={t("My files", "ملفاتي")} hint={t("Import with the system picker", "استيراد عبر منتقي النظام")} />
        <Row title={t("Downloaded", "المنزّلة")} hint={t("From the Media Hub, with a trimmer", "من مركز الوسائط مع أداة قص")} />
      </Group>
      <Group title={t("Approved source pools", "المصادر المعتمدة")}>{approved.map((a) => <Row key={a} title={a} />)}</Group>
      <Group title={t("Rejected under the license gate", "مرفوضة وفق بوابة الترخيص")}>{rejected.map(([a, b]) => <Row key={a} title={a} hint={b} />)}</Group>
    </div>
  );
}

function CompanionSettings({ onBack }: { onBack: () => void }) {
  const t = useT(); const s = useStore(); const fam = resolveDecor(new Date(), s.userDays).primary;
  const moods: Array<[typeof s.companion.emotion, string, string]> = [["idle", "عادي", "Calm"], ["happy", "فرحان", "Happy"], ["sad", "زعلان", "Sad"], ["cold", "بردان", "Cold"], ["welcome", "أهلاً", "Welcome"], ["celebrate", "مبسوط", "Celebrate"], ["think", "بيفكر", "Thinking"], ["wink", "بيبصلك", "Wink"], ["sleep", "نايم", "Sleepy"]];
  const outfits: Array<[typeof s.companion.outfit, string, string]> = [["auto", "تلقائي موسمي", "Seasonal"], ["gold", "فانوس رمضان", "Ramadan lantern"], ["snow", "شال الشتا", "Winter scarf"], ["national", "شريط وطني", "National ribbon"], ["none", "بدون", "None"]];
  const sources = [
    ["RobotExpressive (CC0)", "three.js example model by Tomás Laulhé, modified by Don McCurdy", "https://threejs.org/examples/models/gltf/RobotExpressive/RobotExpressive.glb"],
    ["Quaternius robot packs (CC0)", "Animated robot and mech packs", "https://quaternius.com/"],
    ["Kenney (CC0)", "Blocky characters and robot kits", "https://kenney.nl/assets?q=robot"],
    ["Poly Pizza (CC0 / CC-BY per model)", "Search CC0 robots, check each license page", "https://poly.pizza/search/robot"],
    ["CGTrader robot (OWNER REVIEW)", "Not bundled: needs login and its license must pass the redistribution test", "https://www.cgtrader.com/free-3d-models/character/fantasy-character/robot-2bde3ccf-4311-47b8-b04e-468dcb873359"],
  ];
  return (
    <div className="pb-4">
      <ScreenHeader title={t("Companion", "الرفيق")} onBack={onBack} />
      <Card className="mb-4 grid place-items-center p-6"><RobotMini size={140} family={fam} mood={s.companion.emotion} /><p className="mt-2 text-xs muted">{t("Today's outfit", "زي النهاردة")}: {s.lang === "ar" ? FAMILY[fam].ar : FAMILY[fam].en} · {s.companion.emotion}</p></Card>
      <h3 className="mb-2 px-1 font-bold">{t("Real 3D models (CC0 / CC-BY, from the web)", "موديلات 3D حقيقية (CC0 / CC-BY من النت)")}</h3>
      <ModelViewer />
      <p className="mb-4 mt-1 px-1 text-[10px] leading-snug muted">{t("The Android app renders these GLB files with Filament (not WebGL). This preview uses three.js. Each model keeps its own licence and credit; upload your own file and the licence is yours to check. The CGTrader robot is still not used.", "تطبيق أندرويد بيعرض ملفات GLB دي بـFilament (مش WebGL). المعاينة دي بتستخدم three.js. كل موديل ليه ترخيصه ونسبه؛ ولو رفعت ملفك، الترخيص مسؤوليتك. روبوت CGTrader لسه مش مستخدم.")}</p>
      <Group title={t("Behaviour", "سلوكه")}>
        <Row title={t("Enable companion", "تفعيل الرفيق")} hint={t("Turn off to remove the companion completely (not just hide)", "أوقفه لإلغاء الرفيق نهائيًا (وليس مجرد إخفاء)")} right={<Toggle on={s.companion.enabled} onChange={(v) => s.set({ companion: { ...s.companion, enabled: v, hidden: false } })} label="enabled" />} />
        <Row title={t("Temporarily hide", "إخفاء مؤقت")} hint={t("Keeps a restore pill & optional notification", "يترك زر إرجاع أو إشعار لإعادته")} right={<Toggle on={s.companion.hidden} onChange={(v) => s.set({ companion: { ...s.companion, hidden: v } })} label="hidden" />} />
        <Row title={t("Reminder messages", "رسائل التذكير")} hint={t("A small bubble right above its head, in Egyptian Arabic", "فقاعة صغيرة فوق دماغه بالمصري")} right={<Toggle on={s.companion.bubbles} onChange={(v) => s.set({ companion: { ...s.companion, bubbles: v } })} label="bubbles" />} />
        <Row title={t("Return from a notification", "يرجع من إشعار")} hint={t("When hidden, a real notification brings it back (needs permission)", "لما يختفي، إشعار حقيقي يرجّعه (محتاج إذن)")} right={<Toggle on={s.companion.notify} onChange={async (v) => { if (v && "Notification" in window && Notification.permission === "default") { try { await Notification.requestPermission(); } catch { /* denied */ } } s.set({ companion: { ...s.companion, notify: v } }); }} label="notify" />} />
        <Row title={t("Mood sound", "صوت المزاج")} hint={t("Only when you tap it — never automatic", "بس لما تضغط عليه — مش تلقائي")} right={<Toggle on={s.companion.sound} onChange={(v) => s.set({ companion: { ...s.companion, sound: v } })} label="sound" />} />
        <div className="p-4"><label className="text-sm">{t("Size", "الحجم")}<input type="range" min={0.7} max={1.5} step={0.05} value={s.companion.size} onChange={(e) => s.set({ companion: { ...s.companion, size: +e.target.value } })} className="mt-2 w-full" style={{ accentColor: "var(--accent)" }} /></label></div>
        <div className="p-4"><label className="text-sm">{t("Opacity", "الشفافية")}<input type="range" min={0.35} max={1} step={0.05} value={s.companion.opacity} onChange={(e) => s.set({ companion: { ...s.companion, opacity: +e.target.value } })} className="mt-2 w-full" style={{ accentColor: "var(--accent)" }} /></label></div>
      </Group>
      <button onClick={() => s.set({ companion: { ...s.companion, hidden: false, bubbles: true, emotion: "welcome" } })} className="btn btn-soft mb-4 w-full"><Bell size={14} />{t("Show a reminder bubble now", "اعرض فقاعة تذكير دلوقتي")}</button>
      <Group title={t("Emotions", "الأحاسيس")}>
        <div className="flex flex-wrap gap-1.5 p-3">{moods.map(([id, ar, en]) => <button key={id} className="chip text-[11px]" aria-pressed={s.companion.emotion === id} onClick={() => s.set({ companion: { ...s.companion, emotion: id } })}>{s.lang === "ar" ? ar : en}</button>)}</div>
      </Group>
      <Group title={t("Outfits", "الملابس والزينة")}>
        <div className="flex flex-wrap gap-1.5 p-3">{outfits.map(([id, ar, en]) => <button key={id} className="chip text-[11px]" aria-pressed={s.companion.outfit === id} onClick={() => s.set({ companion: { ...s.companion, outfit: id } })}>{s.lang === "ar" ? ar : en}</button>)}</div>
      </Group>
      <Group title={t("Floating over other apps", "فوق التطبيقات التانية")}>
        <Row title={t("Android overlay", "نافذة أندرويد العائمة")} hint={t("SYSTEM_ALERT_WINDOW + foreground service. Wired in android/ — tap inside the APK to grant overlay permission.", "SYSTEM_ALERT_WINDOW + خدمة أمامية. جاهزة في مجلد android/ — اضغط جوه الـAPK لتشغيلها.")} right={<span className="chip px-1.5 py-0 text-[9px]">Android</span>} onClick={() => nativeBridge.startCompanionOverlay({ enabled: s.companion.enabled, size: s.companion.size, opacity: s.companion.opacity })?.then((r) => { if (r && !r.hasPermission) nativeBridge.requestOverlayPermission(); })} />
        <Row title={t("Browser floating window", "نافذة المتصفح العائمة")} hint={t("Tap the robot → More → “Float over other apps”. Chrome's Document Picture-in-Picture keeps it on top while you use other apps.", "اضغط الروبوت ← المزيد ← «اعرضه فوق أي تطبيق». نافذة Chrome تفضل فوق وانت بتستخدم تطبيقات تانية.")} right={<span className="chip px-1.5 py-0 text-[9px]">Chrome</span>} />
      </Group>
      <Group title={t("3D robot models (sources, not bundled)", "نماذج روبوت 3D (مصادر، غير مضمّنة)")}>
        {sources.map(([name, desc, url]) => <a key={name} href={url} target="_blank" rel="noreferrer" className="flex items-center gap-2 px-4 py-3"><span className="flex-1"><span className="block text-[13px] font-semibold">{name}</span><span className="block text-[11px] leading-snug muted">{desc}</span></span><ExternalLink size={14} className="muted" /></a>)}
      </Group>
      <Honest>{t("This preview draws an articulated 2D robot with real joint physics. The Android app renders a GLB with Filament. No 3D file is bundled: the CGTrader robot needs a login and its license must pass the redistribution test first; the CC0 fallbacks above are listed for the owner to download and verify. A browser cannot draw over other apps without the PiP window.", "المعاينة دي بترسم روبوت ثنائي الأبعاد بمفاصل فيزيائية حقيقية. تطبيق أندرويد بيعرض GLB عبر Filament. مفيش ملف 3D مضمّن: روبوت CGTrader محتاج تسجيل دخول وترخيصه لازم يعدي اختبار إعادة التوزيع؛ بدائل CC0 فوق للتنزيل والتحقق. المتصفح مش يقدر يرسم فوق تطبيقات تانية غير بنافذة PiP.")}</Honest>
    </div>
  );
}

function NotifSettings({ onBack }: { onBack: () => void }) {
  const t = useT(); const s = useStore(); const [tested, setTested] = useState("");
  const test = async () => {
    if (!("Notification" in window)) { setTested(t("This browser has no notifications.", "المتصفح ده مفيهوش إشعارات.")); return; }
    const perm = Notification.permission === "granted" ? "granted" : await Notification.requestPermission();
    if (perm !== "granted") { setTested(t("Permission denied in the browser settings.", "الإذن مرفوض من إعدادات المتصفح.")); return; }
    new Notification("DAYFLOW — " + t("notification test", "اختبار الإشعارات"), { body: s.notif.preview ? t("Alarm “Work days” at 06:30 — in 8 hours", "منبه «أيام الشغل» ٦:٣٠ — فاضل ٨ ساعات") : t("A reminder is ready", "عندك تذكير"), tag: "dayflow-test", icon: seasonIcon(resolveDecor(new Date(), s.userDays).primary) });
    setTested(t("Sent. Check your notification tray.", "اتبعت. بص في الإشعارات."));
  };
  return (
    <div className="pb-4">
      <ScreenHeader title={t("Notifications", "الإشعارات")} onBack={onBack} />
      <Group title={t("Look", "الشكل")}>
        <div className="p-3"><Segmented value={s.notif.style} onChange={(v) => s.set({ notif: { ...s.notif, style: v } })} options={[{ id: "minimal", label: t("Minimal", "بسيط") }, { id: "detailed", label: t("Detailed", "بالتفاصيل") }, { id: "occasion", label: t("Occasion", "بالمناسبة") }]} /></div>
        <Row title={t("Show content in the notification", "إظهار المحتوى في الإشعار")} hint={t("Turn off to hide task names on the lock screen", "أوقفه لإخفاء أسماء المهام على شاشة القفل")} right={<Toggle on={s.notif.preview} onChange={(v) => s.set({ notif: { ...s.notif, preview: v } })} label="preview" />} />
        <Row title={t("Sound", "الصوت")} right={<Toggle on={s.notif.sound} onChange={(v) => s.set({ notif: { ...s.notif, sound: v } })} label="sound" />} />
        <Row title={t("Vibration", "اهتزاز")} right={<Toggle on={s.notif.vibrate} onChange={(v) => s.set({ notif: { ...s.notif, vibrate: v } })} label="vibrate" />} />
        <Row title={t("Quiet hours", "ساعات الهدوء")} hint={t("No reviews or non-alarm reminders after 23:00", "مفيش مراجعات أو تذكيرات بعد ١١ مساءً")} right={<Toggle on={s.notif.quiet} onChange={(v) => s.set({ notif: { ...s.notif, quiet: v } })} label="quiet" />} />
      </Group>
      <Group title={t("Review reminders", "تذكيرات المراجعة")}>
        <Row title={t("Evening daily review", "مراجعة المسا")} hint={t("Default 21:30", "الافتراضي ٩:٣٠ م")} right={<input type="time" value={s.notif.dailyReview} onChange={(e) => s.set({ notif: { ...s.notif, dailyReview: e.target.value } })} className="field w-28 py-1" />} />
        <Row title={t("Weekly review (Friday evening)", "المراجعة الأسبوعية (جمعة بالليل)")} right={<Toggle on={s.notif.weeklyReview} onChange={(v) => s.set({ notif: { ...s.notif, weeklyReview: v } })} label="weekly" />} />
      </Group>
      <button onClick={test} className="btn btn-primary w-full"><Bell size={15} />{t("Send a real test notification", "ابعت إشعار تجربة حقيقي")}</button>
      {tested && <p className="mt-2 text-center text-xs accent">{tested}</p>}
      <div className="mt-3"><Honest>{t("Browser notifications are real and permission-based. Scheduled background reminders need the Android notification system (not built in this preview). Interactive buttons (Complete / Snooze / Open) are Android-only.", "إشعارات المتصفح حقيقية وبتطلب إذن. التذكيرات المجدولة في الخلفية محتاجة نظام إشعارات أندرويد (مش مبني في المعاينة). الأزرار التفاعلية (تم / غفوة / افتح) لأندرويد فقط.")}</Honest></div>
    </div>
  );
}

function AlarmLookScreen({ onBack }: { onBack: () => void }) {
  const t = useT(); const s = useStore(); const fam = resolveDecor(new Date(), s.userDays).primary; const f = FAMILY[fam];
  const layouts: Array<[typeof s.alarmLook.layout, string, string]> = [["ornate", "مزخرف", "Ornate"], ["midnight", "ليل", "Midnight"], ["minimal", "بسيط", "Minimal"], ["glass", "زجاج", "Glass"]];
  return (
    <div className="pb-4">
      <ScreenHeader title={t("Alarm screen", "شاشة المنبه")} onBack={onBack} />
      <div className="card relative mb-4 grid min-h-[260px] place-items-center overflow-hidden p-6 text-white" style={{ background: s.alarmLook.gradient ? `linear-gradient(170deg, ${f.c2}, #0b0f1a)` : "#0b0f1a", border: "none", borderRadius: "var(--r)" }}>
        {s.alarmLook.layout === "ornate" && <div className="absolute inset-0" style={{ backgroundImage: `url("data:image/svg+xml,${encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" width="60" height="60"><circle cx="30" cy="30" r="16" fill="none" stroke="${f.c1}" stroke-opacity=".35"/></svg>`)}")` }} />}
        <div className="relative text-center"><p className="text-[10px] uppercase tracking-[.3em] opacity-60">{t("Alarm", "منبه")}</p><p className="mt-2 text-6xl font-extralight tabular-nums">{s.alarmLook.layout === "minimal" ? "06:30" : "٠٦:٣٠"}{s.alarmLook.showSeconds && <span className="text-2xl">:٠٠</span>}</p><p className="mt-2 text-sm opacity-80">{t("Work days · gentle wake", "أيام الشغل · استيقاظ لطيف")}</p>{s.alarmLook.weatherLine && <p className="mt-1 text-xs opacity-60">{t("18° · clear", "١٨° · صافي")}</p>}
          {s.alarmLook.layout === "glass" && <div className="mt-4 rounded-2xl bg-white/15 px-5 py-2 text-sm backdrop-blur">{t("Snooze 10 min", "غفوة ١٠ دقايق")}</div>}</div>
      </div>
      <Group title={t("Layout", "الشكل")}><div className="flex flex-wrap gap-1.5 p-3">{layouts.map(([id, ar, en]) => <button key={id} className="chip text-[11px]" aria-pressed={s.alarmLook.layout === id} onClick={() => s.set({ alarmLook: { ...s.alarmLook, layout: id } })}>{s.lang === "ar" ? ar : en}</button>)}</div></Group>
      <Group>
        <Row title={t("Show seconds", "إظهار الثواني")} right={<Toggle on={s.alarmLook.showSeconds} onChange={(v) => s.set({ alarmLook: { ...s.alarmLook, showSeconds: v } })} label="seconds" />} />
        <Row title={t("Seasonal gradient", "تدرج موسمي")} hint={t("Uses today's DecorResolver colours", "بيستخدم ألوان زينة النهاردة")} right={<Toggle on={s.alarmLook.gradient} onChange={(v) => s.set({ alarmLook: { ...s.alarmLook, gradient: v } })} label="gradient" />} />
        <Row title={t("Gentle weather line", "سطر الجو")} hint={t("Only if you add a weather source; off means nothing is fetched", "بس لو ضفت مصدر جوية؛ إيقافه يعني مفيش جلب بيانات")} right={<Toggle on={s.alarmLook.weatherLine} onChange={(v) => s.set({ alarmLook: { ...s.alarmLook, weatherLine: v } })} label="weather" />} />
      </Group>
      <Honest>{t("This is a live preview of the layout tokens. On Android the ringing screen is native Kotlin, works on the lock screen and with the screen off.", "دي معاينة حية لشكل الشاشة. على أندرويد شاشة الرنين أصلية بـKotlin، بتشتغل على شاشة القفل والشاشة مقفولة.")}</Honest>
    </div>
  );
}

function PrayerSettings({ onBack }: { onBack: () => void }) {
  const clockFormat = useClockFormat();
  const t = useT(); const s = useStore(); const city = CITIES[s.cityIndex] || CITIES[0]; const p = prayerTimes(city, new Date());
  return (
    <div className="pb-4">
      <ScreenHeader title={t("Prayer times", "مواقيت الصلاة")} subtitle={s.lang === "ar" ? city.cityAr : city.city} onBack={onBack} />
      <Card className="mb-4 p-4">
        <div className="mb-3 flex items-center justify-between"><div><p className="text-xs muted">{t("Next prayer", "الصلاة القادمة")}</p><p className="text-2xl font-bold">{s.lang === "ar" ? p.next?.nameAr : p.next?.name} · {clockFormat(p.next?.time || "")}</p><p className="text-xs muted">{t(`in ${Math.floor((p.next?.inMin || 0) / 60)}h ${(p.next?.inMin || 0) % 60}m`, `فاضل ${Math.floor((p.next?.inMin || 0) / 60)} ساعة و${(p.next?.inMin || 0) % 60} دقيقة`)}</p></div><Motif family="islamic" size={44} /></div>
        <div className="grid grid-cols-2 gap-1.5">{PRAYER_NAMES.map(([k, en, ar, icon]) => <div key={k} className="flex items-center justify-between rounded-lg px-2 py-1.5" style={{ background: p.next?.name === k ? "var(--soft)" : "transparent" }}><span className="text-xs">{icon} {s.lang === "ar" ? ar : en}</span><b className="text-xs tabular-nums">{clockFormat(p[k as "fajr"])}</b></div>)}</div>
      </Card>
      <Group title={t("City", "المدينة")}>
        <div className="grid grid-cols-2 gap-1.5 p-3">{CITIES.map((c, i) => <button key={c.city} className="chip justify-start text-[11px]" aria-pressed={s.cityIndex === i} onClick={() => s.set({ cityIndex: i })}>{s.lang === "ar" ? c.cityAr : c.city}</button>)}</div>
      </Group>
      <Honest>{t("Times are calculated on this device (Egyptian General Survey Authority: Fajr 19.5°, Isha 17.5°, standard Asr). No location or network is used. Daylight-saving differences can shift a time by an hour; the Android app reads the system time zone.", "المواقيت بتتحسب على الجهاز (الهيئة المصرية العامة للمساحة: الفجر ١٩٫٥°، العشاء ١٧٫٥°، العصر المذهب القياسي). مفيش استخدام للموقع أو النت. فرق التوقيت الصيفي قد يحرّك الوقت ساعة؛ تطبيق أندرويد بيقرأ توقيت النظام.")}</Honest>
    </div>
  );
}

function WidgetLookScreen({ onBack }: { onBack: () => void }) {
  const t = useT(); const s = useStore(); const def = WIDGETS.find((w) => w.id === "clock-minimal-digital")!; const prayer = WIDGETS.find((w) => w.id === "utility-prayer-schedule") || WIDGETS.find((w) => w.arche === "prayer")!;
  return (
    <div className="pb-4">
      <ScreenHeader title={t("Widget fonts & ornaments", "خطوط وزخارف الودجات")} onBack={onBack} />
      <Group title={t("Font", "الخط")}>
        <div className="flex flex-wrap gap-1.5 p-3">{(Object.keys(WIDGET_FONTS) as Array<keyof typeof WIDGET_FONTS>).map((k) => <button key={k} className="chip text-[11px]" aria-pressed={s.widgetFont === k} onClick={() => s.set({ widgetFont: k as WidgetFont })}>{WIDGET_FONTS[k].ar} / {WIDGET_FONTS[k].en}</button>)}</div>
      </Group>
      <div className="wallpaper mb-4 flex flex-wrap justify-center gap-4 rounded-3xl p-4">
        <WidgetRenderer def={def} form="2x2" style="oneui" cell={64} />
        <WidgetRenderer def={prayer} form="2x2" style="paper" cell={64} />
      </div>
      <p className="text-xs muted">{t("Every widget in the catalog uses this setting. Arabic fonts come from your device — no font file is downloaded, so nothing breaks offline. Ornaments follow the season and intensity under Me → Seasons.", "كل الودجات بتستخدم الإعداد ده. خطوط العربي من جهازك — مفيش خط بينزل، فمفيش حاجة تبوظ أوفلاين. الزخارف بتتبع الموسم والشدة من: أنا ← المواسم.")}</p>
      <Honest>{t("Widgets on Android can't truly blur. Glass styles emulate it with layered translucency, noise and a scrim. Fonts beyond the system set need licensed OFL files in the APK — pending the license check.", "ودجات أندرويد مش بتعمل تمويه حقيقي. أنماط الزجاج بتحاكيه بطبقات وشفافية ونويز. الخطوط الإضافية محتاجة ملفات OFL مرخّصة في الـAPK — مستنية فحص الترخيص.")}</Honest>
    </div>
  );
}

function Backup({ onBack }: { onBack: () => void }) {
  const t = useT(); const s = useStore(); const ref = useRef<HTMLInputElement>(null); const [msg, setMsg] = useState("");
  const exp = () => { const raw = localStorage.getItem("dayflow-v2") || "{}"; const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([raw], { type: "application/json" })); a.download = `dayflow-backup-${new Date().toISOString().slice(0, 10)}.json`; a.click(); };
  const imp = async (f: File) => { try { const j = JSON.parse(await f.text()); if (!j.state || typeof j.state !== "object") throw 0; localStorage.setItem("dayflow-v2", JSON.stringify(j)); setMsg(t("Restored. Reloading…", "تمت الاستعادة. إعادة التحميل…")); setTimeout(() => location.reload(), 700); } catch { setMsg(t("Not a valid DAYFLOW backup.", "ليست نسخة احتياطية صالحة.")); } };
  return (
    <div className="pb-4">
      <ScreenHeader title={t("Backup & restore", "النسخ الاحتياطي")} onBack={onBack} />
      <div className="space-y-3">
        <button className="btn btn-primary w-full" onClick={exp}><Download size={16} />{t("Export backup (includes themes)", "تصدير نسخة (تشمل السمات)")}</button>
        <button className="btn btn-soft w-full" onClick={() => ref.current?.click()}><Upload size={16} />{t("Restore from file", "استعادة من ملف")}</button>
        <input ref={ref} type="file" accept="application/json" className="hidden" onChange={(e) => e.target.files?.[0] && imp(e.target.files[0])} />
        {msg && <p className="text-sm accent">{msg}</p>}
        <button className="btn btn-ghost w-full text-red-500" onClick={() => { if (confirm(t("Erase all DAYFLOW data on this device?", "مسح كل بيانات DAYFLOW على هذا الجهاز؟"))) { localStorage.removeItem("dayflow-v2"); location.reload(); } }}><Trash2 size={16} />{t("Erase all data", "مسح كل البيانات")}</button>
        <p className="text-xs muted">{t(`Stored only in this browser. ${s.tasks.length} tasks, ${s.notes.length} notes, ${s.alarms.length} alarms.`, `مخزّنة في هذا المتصفح فقط. ${s.tasks.length} مهام، ${s.notes.length} ملاحظات، ${s.alarms.length} منبهات.`)}</p>
      </div>
    </div>
  );
}

function SettingsScreen({ onBack }: { onBack: () => void }) {
  const t = useT(); const s = useStore(); const [q, setQ] = useState("");
  const rows = [
    { g: t("General", "عام"), k: "lang", title: t("Language", "اللغة"), right: <Segmented value={s.lang} onChange={(v) => s.set({ lang: v })} options={[{ id: "en", label: "EN" }, { id: "ar", label: "ع" }]} /> },
    { g: t("General", "عام"), k: "clock", title: t("12-hour clock", "الساعة بنظام ١٢ ساعة"), hint: t("Display only; saved schedules stay unchanged", "عرض ص/م بس، مواعيدك المحفوظة مش بتتغير"), right: <Toggle on={s.hour12} onChange={(v) => s.set({ hour12: v })} label={t("12-hour clock", "الساعة بنظام ١٢ ساعة")} /> },
    { g: t("General", "عام"), k: "power", title: t("Power mode", "الوضع المتقدم"), hint: t("Show advanced options everywhere", "إظهار الخيارات المتقدمة في كل مكان"), right: <Toggle on={s.powerMode} onChange={(v) => s.set({ powerMode: v })} label="power" /> },
    { g: t("Accessibility", "إمكانية الوصول"), k: "motion", title: t("Reduce motion", "تقليل الحركة"), hint: t("Static decor and a calm companion pose", "زينة ثابتة ووضعية هادئة للرفيق"), right: <Toggle on={s.reduceMotion} onChange={(v) => s.set({ reduceMotion: v })} label="motion" /> },
    { g: t("Review", "المراجعة"), k: "tone", title: t("Coach tone", "نبرة المدرب"), right: <select className="field w-32 py-1" value={s.reviewTone} onChange={(e) => s.set({ reviewTone: e.target.value as "gentle" })}><option value="gentle">{t("Gentle", "لطيف")}</option><option value="balanced">{t("Balanced", "متوازن")}</option><option value="direct">{t("Direct", "مباشر")}</option></select> },
    { g: t("Review", "المراجعة"), k: "spiritual", title: t("Spiritual routine", "الورد الروحي"), hint: t("Opt-in dimension", "بُعد اختياري"), right: <Toggle on={s.spiritual} onChange={(v) => s.set({ spiritual: v })} label="spiritual" /> },
    { g: t("Review", "المراجعة"), k: "sample", title: t("Use sample data", "استخدام بيانات تجريبية"), hint: t("A labelled demo year so reviews have something to explain", "سنة تجريبية موسومة لتوضيح المراجعات"), right: <Toggle on={s.sampleData} onChange={(v) => s.set({ sampleData: v })} label="sample" /> },
    { g: t("Calendar", "التقويم"), k: "exam", title: t("Exam season decor", "زينة موسم الامتحانات"), right: <Toggle on={s.examSeason} onChange={(v) => s.set({ examSeason: v })} label="exam" /> },
    { g: t("Media Hub", "مركز الوسائط"), k: "clip", title: t("Detect copied links", "اكتشاف الروابط المنسوخة"), hint: t("Only while the app is open", "فقط أثناء فتح التطبيق"), right: <Toggle on={s.clipboardWatch} onChange={(v) => s.set({ clipboardWatch: v })} label="clipboard" /> },
  ];
  const vis = rows.filter((r) => !q || (r.title + (r.hint || "") + r.g).toLowerCase().includes(q.toLowerCase()));
  const groups = [...new Set(vis.map((r) => r.g))];
  return (
    <div className="pb-4">
      <ScreenHeader title={t("Settings", "الإعدادات")} onBack={onBack} />
      <div className="relative mb-4"><Search size={16} className="muted absolute start-3 top-1/2 -translate-y-1/2" /><input value={q} onChange={(e) => setQ(e.target.value)} className="field ps-9" placeholder={t("Search settings", "ابحث في الإعدادات")} /></div>
      {groups.map((g) => <Group key={g} title={g}>{vis.filter((r) => r.g === g).map((r) => <Row key={r.k} title={r.title} hint={r.hint} right={r.right} />)}</Group>)}
      {!vis.length && <EmptyState family="friday" title={t("No matching settings", "لا إعدادات مطابقة")} />}
    </div>
  );
}

type Status = "Built" | "Unit-tested" | "Built-and-run-on-CI" | "Verified-on-device" | "Unverified";
function Ledger({ onBack }: { onBack: () => void }) {
  const t = useT();
  const today = new Date().toISOString().slice(0, 10);
  const rows: Array<[string, Status, string]> = useMemo(() => [
    ["Six-tab shell (Today · Calendar · Alarms · Tools · AI · Me), quick-create, AR/EN + RTL", "Built", "Production build + SSR render of every route"],
    ["Three calendars, occasions, DecorResolver (budget 3)", "Built", "Ramadan/Friday/Winter stack verified"],
    ["69 theme packs + Gallery + Studio + WCAG check", "Built", "All 69 pass AA contrast script"],
    ["137 widget designs + form resolver + 10 styles + fonts", "Built", "793 design×size renders, 0 failures"],
    ["Prayer times on device (Egyptian method) + 5 prayer widgets", "Built", "Cairo 2026-11: 04:47 · 06:17 · 11:39 · 14:40 · 17:01 · 18:21"],
    ["Habits manager: name, days, type, target, reminder, details, colour", "Built", "Creates, edits, 28-day grid; feeds Review consistency"],
    ["Review Tier 1 + Tier-2 guard demo", "Built", "365-day sample script; formal tests not run"],
    ["22 AI providers, 81 curated models + live catalogs", "Built", "OpenRouter sk-or-v1- detected as OpenRouter, never OpenAI"],
    ["Real chat streaming + faint reasoning block + app actions", "Built", "Code paths for OpenAI-compatible, Anthropic, Gemini; not run with a real key in this environment"],
    ["Robot: Egyptian reminders pinned above it, 9 moods, hide + notification, quick AI panel", "Built", "Browser preview; local intent engine returns real actions"],
    ["Floating over other apps", "Built", "Chrome Document Picture-in-Picture; Android overlay Unverified"],
    ["Media Hub real previews (oEmbed) + real direct download", "Built", "YouTube title fetched; CC0 file 1,128,375 B fetched"],
    ["3D robot preview (three.js) with 3 public models + own GLB", "Built", "RobotExpressive (CC0), CesiumMan (CC-BY 4.0), Fox (CC0) URLs verified 200"],
    ["Native alarm engine, device tones, native widgets, Filament companion, download engine", "Unverified", "No Android toolchain or APK in this environment"],
    ["Sound library (≥160 tones)", "Unverified", "0 bundled — acquisition pending"],
    ["GitHub Actions workflows", "Unverified", "Not authored in this deliverable"],
    ["On-device LLM (Tier 2)", "Unverified", "No runtime; Arabic quality not evaluated"],
  ], []);
  const color: Record<Status, string> = { "Built": "#3e63dd", "Unit-tested": "#2fa36b", "Built-and-run-on-CI": "#2fa36b", "Verified-on-device": "#1a7f37", "Unverified": "#b26a00" };
  return (
    <div className="pb-4">
      <ScreenHeader title={t("Verification ledger", "سجل التحقق")} subtitle={today} onBack={onBack} />
      <p className="mb-3 text-sm muted">{t("Nothing here is marked verified without evidence. This is a web preview of the DAYFLOW UI layer.", "لا شيء هنا موسوم كمتحقَّق بدون دليل. هذه معاينة ويب لطبقة واجهة DAYFLOW.")}</p>
      <Card className="divide-y divide-[var(--line)]">{rows.map(([f, st, ev]) => <div key={f} className="flex items-start gap-3 px-4 py-3"><div className="flex-1"><p className="text-sm font-medium">{f}</p><p className="text-[11px] muted">{ev}</p></div><span className="flex-none rounded-full px-2 py-0.5 text-[10px] font-bold text-white" style={{ background: color[st] }}>{st}</span></div>)}</Card>
    </div>
  );
}

function About({ onBack }: { onBack: () => void }) {
  const t = useT();
  return (
    <div className="pb-4">
      <ScreenHeader title={t("About & credits", "حول والاعتمادات")} onBack={onBack} />
      <Group title={t("Open-source used here", "مكتبات مفتوحة المصدر مستخدمة")}>
        {[["React", "MIT"], ["Vite", "MIT"], ["Tailwind CSS v4", "MIT"], ["Zustand", "MIT"], ["Lucide icons", "ISC"]].map(([a, b]) => <Row key={a} title={a} right={<span className="chip text-[10px]">{b}</span>} />)}
      </Group>
      <Group title={t("Honest limits", "حدود صريحة")}>
        {[
          t("Android owns the widget picker; DAYFLOW provides its full catalog inside the app.", "أندرويد يملك منتقي الودجات؛ DAYFLOW يوفر كتالوجه الكامل داخل التطبيق."),
          t("Widgets can't truly blur; glass is emulated.", "الودجات لا تستطيع التمويه فعليًا؛ الزجاج محاكى."),
          t("Overlays don't show on the lock screen; some OEMs restrict background services.", "النوافذ العائمة لا تظهر على شاشة القفل؛ وبعض الشركات تقيد الخدمات الخلفية."),
          t("Main screens are rendered by the system WebView in the Android app.", "الشاشات الرئيسية تُعرض عبر WebView النظام في تطبيق أندرويد."),
          t("The Media Hub isn't allowed on Google Play; a Play-safe flavor omits it. Its binaries carry GPL obligations.", "مركز الوسائط غير مسموح على Google Play؛ نسخة Play تحذفه. وملفاته تحمل التزامات GPL."),
          t("Site extractors break when sites change; use “Update engine”.", "مستخرجات المواقع تتعطل عند تغيّر المواقع؛ استخدم «تحديث المحرك»."),
          t("Samsung tones are never bundled; your device's own tones are listed instead.", "نغمات سامسونج لا تُضمَّن أبدًا؛ تُعرض نغمات جهازك بدلًا منها."),
        ].map((x, i) => <Row key={i} title={x} />)}
      </Group>
      <p className="text-center text-xs muted">DAYFLOW · {t("UI preview build", "نسخة معاينة الواجهة")}</p>
    </div>
  );
}
