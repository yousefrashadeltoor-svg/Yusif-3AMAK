import { useClockFormat } from "../lib/time";
import { useEffect, useMemo, useState } from "react";
import { Search, ListChecks, Repeat, Timer, Droplet, StickyNote, Link2, Hourglass, Ruler, CircleDot, CalendarRange, BookHeart, Pill, MoonStar, QrCode, GraduationCap, Dumbbell, Plus, Trash2, Pin, Check, Play, Pause, RotateCcw, BookOpen, Image as ImageIcon, Wind, AlignLeft, Watch, Download, Flag } from "lucide-react";
import { QRStudio } from "./QRStudio";
import { useStore, useT, fmtNum, newId } from "../lib/store";
import { dayKey, hijri, coptic, HIJRI_MONTHS, COPTIC_MONTHS } from "../lib/calendar";
import { fmtBytes } from "../lib/media";
import { Card, ScreenHeader, Segmented, Ring } from "../components/ui";
import { EmptyState, Motif, useDecor, Particles } from "../components/Decor";
import { MediaHub } from "./MediaHub";
import { Habits } from "./Habits";

const TOOLS = [
  ["tasks", ListChecks, "Tasks", "المهام"], ["habits", Repeat, "Habits", "العادات"], ["focus", Timer, "Focus", "التركيز"], ["study", GraduationCap, "Study", "الدراسة"],
  ["workout", Dumbbell, "Workout", "التمارين"], ["water", Droplet, "Water", "الماء"], ["notes", StickyNote, "Notes", "الملاحظات"], ["media", Link2, "Media Hub", "مركز الوسائط"],
  ["countdowns", Hourglass, "Countdowns", "العد التنازلي"], ["convert", Ruler, "Converters", "المحولات"], ["tasbih", CircleDot, "Tasbih & Khatma", "التسبيح والختمة"], ["datecalc", CalendarRange, "Date calculator", "حاسبة التاريخ"],
  ["journal", BookHeart, "Journal & mood", "اليوميات والمزاج"], ["meds", Pill, "Medication", "الأدوية"], ["bedside", MoonStar, "Bedside clock", "ساعة السرير"], ["qr", QrCode, "QR generator", "صانع QR"],
  ["imgtools", ImageIcon, "Image converter", "محول وضغط الصور"], ["breath", Wind, "Breathing", "تمارين التنفس"], ["texttools", AlignLeft, "Text & counter", "عدّاد النصوص"], ["stopwatch", Watch, "Stopwatch", "ساعة إيقاف"],
] as const;

export function Tools({ sub, go }: { sub?: string; go: (tab: string, sub?: string) => void }) {
  const t = useT();
  const lang = useStore((s) => s.lang);
  const [q, setQ] = useState("");
  const back = () => go("tools");
  if (sub) {
    const meta = TOOLS.find((x) => x[0] === sub);
    const title = meta ? (lang === "ar" ? meta[3] : meta[2]) : "";
    if (sub === "media") return <MediaHub onBack={back} />;
    if (sub === "bedside") return <Bedside onBack={back} />;
    if (sub === "habits") return <Habits />;
    return (
      <div className="pb-4">
        <ScreenHeader title={title} onBack={back} />
        {sub === "tasks" && <TasksTool />}
        {sub === "habits" && <Habits />}
        {(sub === "focus" || sub === "study") && <FocusTool study={sub === "study"} />}
        {sub === "workout" && <WorkoutTool />}
        {sub === "water" && <WaterTool />}
        {sub === "notes" && <NotesTool />}
        {sub === "countdowns" && <CountdownTool />}
        {sub === "convert" && <ConvertTool />}
        {sub === "tasbih" && <TasbihTool />}
        {sub === "datecalc" && <DateCalc />}
        {sub === "journal" && <JournalTool />}
        {sub === "meds" && <MedsTool />}
        {sub === "qr" && <QRStudio />}
        {sub === "imgtools" && <ImageTool />}
        {sub === "breath" && <BreathTool />}
        {sub === "texttools" && <TextTool />}
        {sub === "stopwatch" && <StopwatchTool />}
      </div>
    );
  }
  const list = TOOLS.filter((x) => !q || (x[2] + " " + x[3]).toLowerCase().includes(q.toLowerCase()));
  return (
    <div className="pb-4">
      <ScreenHeader title={t("Tools", "الأدوات")} />
      <div className="relative mb-4">
        <Search size={16} className="muted absolute start-3 top-1/2 -translate-y-1/2" />
        <input value={q} onChange={(e) => setQ(e.target.value)} className="field ps-9" placeholder={t("Search tools", "ابحث في الأدوات")} />
      </div>
      <div className="grid grid-cols-3 gap-3 sm:grid-cols-4">
        {list.map(([id, I, en, ar]) => (
          <Card key={id} onClick={() => go("tools", id)} className="flex aspect-square flex-col items-center justify-center gap-2 p-2 text-center">
            <span className="grid h-11 w-11 place-items-center rounded-2xl" style={{ background: "var(--soft)", color: "var(--accent)" }}><I size={22} /></span>
            <span className="text-xs font-semibold leading-tight">{lang === "ar" ? ar : en}</span>
          </Card>
        ))}
      </div>
    </div>
  );
}

function TasksTool() {
  const t = useT(); const s = useStore();
  const [view, setView] = useState<"list" | "matrix" | "kanban">("list");
  const [txt, setTxt] = useState(""); const [urgent, setUrgent] = useState(false); const [important, setImportant] = useState(true);
  const [date, setDate] = useState(dayKey(new Date())); const [dueTime, setDueTime] = useState("");
  const decor = useDecor();
  return (
    <>
      <Segmented value={view} onChange={setView} options={[{ id: "list", label: t("List", "قائمة") }, { id: "matrix", label: t("Matrix", "المصفوفة") }, { id: "kanban", label: "Kanban" }]} />
      <form onSubmit={(e) => { e.preventDefault(); if (txt.trim() && date) { s.addTask(txt.trim(), date, urgent, important, dueTime || undefined); setTxt(""); } }} className="my-3 space-y-2">
        <div className="flex gap-2"><input value={txt} onChange={(e) => setTxt(e.target.value)} className="field" placeholder={t("New task", "مهمة جديدة")} /><button className="btn btn-primary"><Plus size={18} /></button></div>
        <div className="flex gap-2"><label className="min-w-0 flex-1 text-xs muted">{t("Date", "اليوم")}<input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="field mt-1" required /></label><label className="min-w-0 flex-1 text-xs muted">{t("Time (optional)", "الساعة (اختياري)")}<input type="time" value={dueTime} onChange={(e) => setDueTime(e.target.value)} className="field mt-1" /></label></div>
        <div className="flex gap-2"><button type="button" className="chip" aria-pressed={urgent} onClick={() => setUrgent(!urgent)}>{t("Urgent", "عاجل")}</button><button type="button" className="chip" aria-pressed={important} onClick={() => setImportant(!important)}>{t("Important", "مهم")}</button></div>
      </form>
      {view === "list" && (s.tasks.length ? <Card className="divide-y divide-[var(--line)]">{s.tasks.map((x) => (
        <div key={x.id} className="flex items-center gap-3 px-4 py-3">
          <button onClick={() => s.toggleTask(x.id)} className="grid h-6 w-6 flex-none place-items-center rounded-lg border-2" style={{ borderColor: "var(--accent)", background: x.done ? "var(--accent)" : "transparent", color: "var(--on-accent)" }} aria-label={x.title}>{x.done && <Check size={14} />}</button>
          <div className="min-w-0 flex-1"><p className={x.done ? "muted line-through" : ""}>{x.title}</p><p className="text-[11px] muted">{x.date}{x.dueTime ? ` · ${x.dueTime}` : ""}{x.urgent ? " · " + t("urgent", "عاجل") : ""}{x.important ? " · " + t("important", "مهم") : ""}</p></div>
          <button onClick={() => s.removeTask(x.id)} className="muted" aria-label={t("Delete", "حذف")}><Trash2 size={16} /></button>
        </div>))}</Card> : <EmptyState family={decor.primary} title={t("No tasks", "لا مهام")} />)}
      {view === "matrix" && <div className="grid grid-cols-2 gap-2">{([[true, true, t("Do now", "نفّذ الآن"), "#e5484d"], [false, true, t("Schedule", "جدول"), "#3e63dd"], [true, false, t("Delegate", "فوّض"), "#f5a623"], [false, false, t("Drop", "احذف"), "#8b8d98"]] as const).map(([u, im, l, c]) => (
        <Card key={l} className="min-h-36 p-3"><p className="mb-2 text-xs font-bold" style={{ color: c }}>{l}</p>{s.tasks.filter((x) => x.urgent === u && x.important === im && !x.done).map((x) => <button key={x.id} onClick={() => s.toggleTask(x.id)} className="block w-full truncate py-1 text-start text-sm">○ {x.title}</button>)}</Card>))}</div>}
      {view === "kanban" && <div className="grid grid-cols-3 gap-2">{(["todo", "doing", "done"] as const).map((k) => (
        <div key={k} className="rounded-2xl p-2" style={{ background: "var(--soft)" }}><p className="mb-2 px-1 text-xs font-bold">{{ todo: t("To do", "للتنفيذ"), doing: t("Doing", "جارٍ"), done: t("Done", "تم") }[k]}</p>
          {s.tasks.filter((x) => x.status === k).map((x) => <div key={x.id} className="card mb-2 p-2 text-xs"><p className="mb-1.5">{x.title}</p><div className="flex gap-1">{(["todo", "doing", "done"] as const).filter((z) => z !== k).map((z) => <button key={z} onClick={() => s.updateTask(x.id, { status: z })} className="rounded-md px-1.5 py-0.5 text-[10px]" style={{ background: "var(--soft)" }}>→ {{ todo: t("To do", "للتنفيذ"), doing: t("Doing", "جارٍ"), done: t("Done", "تم") }[z]}</button>)}</div></div>)}
        </div>))}</div>}
    </>
  );
}

function FocusTool({ study }: { study?: boolean }) {
  const t = useT(); const lang = useStore((s) => s.lang);
  const [len, setLen] = useState(25); const [left, setLeft] = useState(25 * 60); const [run, setRun] = useState(false); const [subject, setSubject] = useState("");
  useEffect(() => { if (!run) return; const i = setInterval(() => setLeft((x) => { if (x <= 1) { setRun(false); navigator.vibrate?.(300); return 0; } return x - 1; }), 1000); return () => clearInterval(i); }, [run]);
  const mm = String(Math.floor(left / 60)).padStart(2, "0"), ss = String(left % 60).padStart(2, "0");
  return (
    <div className="flex flex-col items-center pt-4">
      {study && <input value={subject} onChange={(e) => setSubject(e.target.value)} className="field mb-4" placeholder={t("Subject (e.g. Physics)", "المادة (مثل الفيزياء)")} />}
      <Ring value={1 - left / (len * 60)} size={240} stroke={12}><div className="text-center"><p className="text-5xl font-light tabular-nums">{fmtNum(`${mm}:${ss}`, lang)}</p><p className="text-sm muted">{study ? subject || t("Study", "دراسة") : t("Focus", "تركيز")}</p></div></Ring>
      <div className="mt-6 flex gap-2">{[15, 25, 45, 60].map((m) => <button key={m} className="chip" aria-pressed={len === m} onClick={() => { setLen(m); setLeft(m * 60); setRun(false); }}>{fmtNum(m, lang)}′</button>)}</div>
      <div className="mt-6 flex gap-3"><button className="btn btn-primary px-8" onClick={() => setRun(!run)}>{run ? <Pause size={18} /> : <Play size={18} />}{run ? t("Pause", "إيقاف") : t("Start", "ابدأ")}</button><button className="btn btn-ghost" onClick={() => { setLeft(len * 60); setRun(false); }} aria-label="reset"><RotateCcw size={18} /></button></div>
      <p className="mt-6 max-w-xs text-center text-xs muted">{t("On Android, focus sessions show as a progress notification (Live Update on Android 16 where supported).", "على أندرويد تظهر جلسات التركيز كإشعار تقدم (تحديث مباشر على أندرويد ١٦ حيث يتوفر).")}</p>
    </div>
  );
}

function WorkoutTool() {
  const t = useT(); const lang = useStore((s) => s.lang);
  const [log, setLog] = useState<Array<{ n: string; m: number }>>(() => JSON.parse(localStorage.getItem("df-workout-" + dayKey(new Date())) || "[]"));
  const [n, setN] = useState(""); const [m, setM] = useState(20);
  useEffect(() => { localStorage.setItem("df-workout-" + dayKey(new Date()), JSON.stringify(log)); }, [log]);
  const total = log.reduce((a, b) => a + b.m, 0);
  return (<>
    <Card className="mb-3 flex items-center gap-4 p-4"><Ring value={total / 30} size={70}><b>{fmtNum(total, lang)}′</b></Ring><div><p className="font-semibold">{t("Today", "اليوم")}</p><p className="text-sm muted">{t("Goal 30 min", "الهدف ٣٠ دقيقة")}</p></div></Card>
    <form onSubmit={(e) => { e.preventDefault(); if (n.trim()) { setLog([...log, { n: n.trim(), m }]); setN(""); } }} className="mb-3 flex gap-2"><input className="field" value={n} onChange={(e) => setN(e.target.value)} placeholder={t("Activity (walk, gym…)", "النشاط (مشي، جيم…)")} /><input type="number" className="field w-20" value={m} onChange={(e) => setM(+e.target.value)} /><button className="btn btn-primary"><Plus size={18} /></button></form>
    {log.map((x, i) => <div key={i} className="flex justify-between border-b border-[var(--line)] py-2 text-sm"><span>{x.n}</span><span className="muted">{fmtNum(x.m, lang)} {t("min", "د")}</span></div>)}
  </>);
}

function WaterTool() {
  const t = useT(); const s = useStore(); const w = s.water[dayKey(new Date())] || 0;
  return (<div className="flex flex-col items-center pt-4">
    <Ring value={w / s.waterGoal} size={220} stroke={14} color="#3aa0ff"><div className="text-center"><Droplet className="mx-auto" color="#3aa0ff" /><p className="text-4xl font-bold">{fmtNum((w / 1000).toFixed(2), s.lang)}</p><p className="muted text-sm">/ {fmtNum(s.waterGoal / 1000, s.lang)} L</p></div></Ring>
    <div className="mt-6 grid w-full grid-cols-3 gap-2">{[150, 250, 500].map((ml) => <button key={ml} className="btn btn-soft" onClick={() => s.addWater(ml)}>+{fmtNum(ml, s.lang)} ml</button>)}</div>
    <button className="btn btn-ghost mt-2 w-full" onClick={() => s.addWater(-250)}>{t("Undo 250 ml", "تراجع ٢٥٠ مل")}</button>
    <label className="mt-4 flex w-full items-center justify-between text-sm">{t("Daily goal (ml)", "الهدف اليومي (مل)")}<input type="number" step={250} className="field w-28" value={s.waterGoal} onChange={(e) => s.set({ waterGoal: Math.max(500, +e.target.value) })} /></label>
  </div>);
}

function NotesTool() {
  const t = useT(); const s = useStore(); const [txt, setTxt] = useState(""); const decor = useDecor();
  const notes = [...s.notes].sort((a, b) => +b.pinned - +a.pinned || b.at - a.at);
  return (<>
    <form onSubmit={(e) => { e.preventDefault(); if (txt.trim()) { s.addNote(txt.trim()); setTxt(""); } }} className="mb-3"><textarea value={txt} onChange={(e) => setTxt(e.target.value)} className="field min-h-20" placeholder={t("Write a note…", "اكتب ملاحظة…")} /><button className="btn btn-primary mt-2 w-full">{t("Save note", "حفظ")}</button></form>
    {!notes.length && <EmptyState family={decor.primary} title={t("No notes", "لا ملاحظات")} />}
    <div className="columns-2 gap-3">{notes.map((n) => <Card key={n.id} className="mb-3 break-inside-avoid p-3"><p className="whitespace-pre-wrap text-sm">{n.text}</p><div className="mt-2 flex justify-end gap-2"><button onClick={() => s.togglePin(n.id)} className={n.pinned ? "accent" : "muted"} aria-label="pin"><Pin size={14} /></button><button onClick={() => s.removeNote(n.id)} className="muted" aria-label="delete"><Trash2 size={14} /></button></div></Card>)}</div>
  </>);
}

function CountdownTool() {
  const t = useT(); const s = useStore(); const [title, setTitle] = useState(""); const [date, setDate] = useState("");
  return (<>
    <form onSubmit={(e) => { e.preventDefault(); if (title && date) { s.set({ countdowns: [...s.countdowns, { id: newId(), title, date }] }); setTitle(""); setDate(""); } }} className="mb-3 flex gap-2"><input className="field" value={title} onChange={(e) => setTitle(e.target.value)} placeholder={t("Event", "الحدث")} /><input type="date" className="field w-40" value={date} onChange={(e) => setDate(e.target.value)} /><button className="btn btn-primary"><Plus size={18} /></button></form>
    <div className="grid grid-cols-2 gap-3">{s.countdowns.map((c) => { const d = Math.ceil((new Date(c.date).getTime() - Date.now()) / 864e5); return <Card key={c.id} className="p-4"><p className="text-4xl font-bold accent">{fmtNum(d, s.lang)}</p><p className="text-xs muted">{t("days", "يوم")}</p><p className="mt-1 font-semibold">{c.title}</p><button onClick={() => s.set({ countdowns: s.countdowns.filter((x) => x.id !== c.id) })} className="mt-1 text-xs muted">{t("Remove", "إزالة")}</button></Card>; })}</div>
  </>);
}

const UNITS: Record<string, Record<string, number>> = {
  length: { m: 1, km: 1000, cm: 0.01, mm: 0.001, mi: 1609.344, ft: 0.3048, in: 0.0254 },
  weight: { kg: 1, g: 0.001, lb: 0.45359237, oz: 0.0283495, ton: 1000 },
  volume: { L: 1, ml: 0.001, gal: 3.78541, cup: 0.24 },
  area: { "m²": 1, "km²": 1e6, feddan: 4200.83, acre: 4046.86, "ft²": 0.092903 },
};
function ConvertTool() {
  const t = useT(); const lang = useStore((s) => s.lang);
  const [kind, setKind] = useState("length"); const [v, setV] = useState(1); const u = Object.keys(UNITS[kind]); const [a, setA] = useState("km"); const [b, setB] = useState("m");
  const [c, setC] = useState(25);
  useEffect(() => { setA(Object.keys(UNITS[kind])[1]); setB(Object.keys(UNITS[kind])[0]); }, [kind]);
  const out = UNITS[kind][a] && UNITS[kind][b] ? (v * UNITS[kind][a]) / UNITS[kind][b] : 0;
  return (<>
    <div className="scroll-hide mb-3 flex gap-1.5 overflow-x-auto">{Object.keys(UNITS).map((k) => <button key={k} className="chip" aria-pressed={kind === k} onClick={() => setKind(k)}>{t(k, { length: "الطول", weight: "الوزن", volume: "الحجم", area: "المساحة" }[k]!)}</button>)}</div>
    <Card className="space-y-3 p-4">
      <div className="flex gap-2"><input type="number" className="field" value={v} onChange={(e) => setV(+e.target.value)} /><select className="field w-28" value={a} onChange={(e) => setA(e.target.value)}>{u.map((x) => <option key={x}>{x}</option>)}</select></div>
      <div className="flex items-center gap-2"><p className="field text-xl font-bold">{fmtNum(+out.toPrecision(8), lang)}</p><select className="field w-28" value={b} onChange={(e) => setB(e.target.value)}>{u.map((x) => <option key={x}>{x}</option>)}</select></div>
    </Card>
    <Card className="mt-3 p-4"><p className="mb-2 text-sm font-semibold">{t("Temperature", "درجة الحرارة")}</p><div className="flex items-center gap-2"><input type="number" className="field" value={c} onChange={(e) => setC(+e.target.value)} /><span>°C =</span><b className="text-lg">{fmtNum((c * 9 / 5 + 32).toFixed(1), lang)} °F</b></div></Card>
    <p className="mt-3 text-xs muted">{t("Currency is intentionally not included: DAYFLOW works offline and has no exchange rates.", "العملات غير مدرجة عمدًا: يعمل DAYFLOW دون اتصال ولا يملك أسعار صرف.")}</p>
  </>);
}

function TasbihTool() {
  const t = useT(); const s = useStore(); const [target, setTarget] = useState(33);
  return (<div className="flex flex-col items-center">
    <button onClick={() => { s.set({ tasbih: s.tasbih + 1 }); if ((s.tasbih + 1) % target === 0) navigator.vibrate?.(120); }} className="card mt-2 grid h-60 w-60 place-items-center rounded-full active:scale-95" style={{ borderRadius: "999px" }} aria-label={t("Count", "عد")}>
      <Ring value={(s.tasbih % target) / target} size={220} stroke={10}><div className="text-center"><p className="text-6xl font-light">{fmtNum(s.tasbih, s.lang)}</p><p className="text-xs muted">{t("tap anywhere", "اضغط للعد")}</p></div></Ring>
    </button>
    <div className="mt-5 flex gap-2">{[33, 99, 100].map((n) => <button key={n} className="chip" aria-pressed={target === n} onClick={() => setTarget(n)}>{fmtNum(n, s.lang)}</button>)}<button className="chip" onClick={() => s.set({ tasbih: 0 })}><RotateCcw size={13} /></button></div>
    <Card className="mt-6 w-full p-4"><div className="flex items-center gap-2"><BookOpen size={18} className="accent" /><p className="flex-1 font-semibold">{t("Khatma tracker", "متتبع الختمة")}</p><span className="text-sm muted">{fmtNum(s.khatma, s.lang)} / ٣٠</span></div>
      <div className="mt-3 grid grid-cols-10 gap-1">{Array.from({ length: 30 }, (_, i) => <button key={i} onClick={() => s.set({ khatma: i + 1 === s.khatma ? i : i + 1 })} className="aspect-square rounded-md text-[10px] font-semibold" style={{ background: i < s.khatma ? "var(--accent)" : "var(--line)", color: i < s.khatma ? "var(--on-accent)" : undefined }}>{fmtNum(i + 1, s.lang)}</button>)}</div>
      <p className="mt-2 text-xs muted">{t("Tracks juz' numbers only — no Quran text is bundled.", "يتتبع أرقام الأجزاء فقط — لا يتضمن نص القرآن.")}</p></Card>
  </div>);
}

function DateCalc() {
  const t = useT(); const lang = useStore((s) => s.lang);
  const [a, setA] = useState(dayKey(new Date())); const [b, setB] = useState(dayKey(new Date(Date.now() + 30 * 864e5))); const [add, setAdd] = useState(40);
  const diff = Math.round((new Date(b).getTime() - new Date(a).getTime()) / 864e5);
  const plus = new Date(new Date(a).getTime() + add * 864e5);
  const h = hijri(new Date(a)), c = coptic(new Date(a));
  return (<div className="space-y-3">
    <Card className="p-4"><p className="mb-2 text-sm font-semibold">{t("Between two dates", "بين تاريخين")}</p><div className="flex gap-2"><input type="date" className="field" value={a} onChange={(e) => setA(e.target.value)} /><input type="date" className="field" value={b} onChange={(e) => setB(e.target.value)} /></div><p className="mt-3 text-3xl font-bold accent">{fmtNum(diff, lang)} <span className="text-base muted">{t("days", "يوم")} ≈ {fmtNum((diff / 7).toFixed(1), lang)} {t("weeks", "أسبوع")}</span></p></Card>
    <Card className="p-4"><p className="mb-2 text-sm font-semibold">{t("Add days", "إضافة أيام")}</p><input type="number" className="field" value={add} onChange={(e) => setAdd(+e.target.value)} /><p className="mt-2 font-semibold">{plus.toLocaleDateString(lang === "ar" ? "ar-EG" : "en-GB", { weekday: "long", day: "numeric", month: "long", year: "numeric" })}</p></Card>
    <Card className="p-4"><p className="mb-1 text-sm font-semibold">{t("Convert first date", "تحويل التاريخ الأول")}</p><p>{fmtNum(h.d, lang)} {HIJRI_MONTHS[lang][h.m - 1]} {fmtNum(h.y, lang)} {t("AH", "هـ")}</p><p>{fmtNum(c.d, lang)} {COPTIC_MONTHS[lang][c.m - 1]} {fmtNum(c.y, lang)} {t("AM", "ش")}</p></Card>
  </div>);
}

function JournalTool() {
  const t = useT(); const s = useStore(); const [mood, setMood] = useState(3); const [txt, setTxt] = useState("");
  const faces = ["😞", "😕", "😐", "🙂", "😄"];
  return (<>
    <Card className="mb-3 p-4"><p className="mb-2 text-sm font-semibold">{t("How are you today?", "كيف حالك اليوم؟")}</p><div className="mb-3 flex justify-between">{faces.map((f, i) => <button key={i} onClick={() => setMood(i + 1)} className="grid h-12 w-12 place-items-center rounded-full text-2xl transition-transform" style={{ background: mood === i + 1 ? "var(--soft)" : "transparent", transform: mood === i + 1 ? "scale(1.15)" : "none" }} aria-label={`mood ${i + 1}`}>{f}</button>)}</div>
      <textarea className="field min-h-24" value={txt} onChange={(e) => setTxt(e.target.value)} placeholder={t("A few words (private, on this device)", "بضع كلمات (خاصة على هذا الجهاز)")} />
      <button className="btn btn-primary mt-2 w-full" onClick={() => { s.set({ journal: [{ id: newId(), date: dayKey(new Date()), mood, text: txt }, ...s.journal] }); setTxt(""); }}>{t("Save entry", "حفظ")}</button></Card>
    <div className="mb-3 flex gap-1">{Array.from({ length: 30 }, (_, i) => { const d = new Date(); d.setDate(d.getDate() - 29 + i); const e = s.journal.find((j) => j.date === dayKey(d)); return <span key={i} className="h-6 flex-1 rounded" style={{ background: e ? `color-mix(in oklch, var(--accent) ${e.mood * 20}%, var(--line))` : "var(--line)" }} />; })}</div>
    {s.journal.map((j) => <Card key={j.id} className="mb-2 p-3"><p className="text-xs muted">{j.date} {faces[j.mood - 1]}</p><p className="text-sm">{j.text}</p></Card>)}
    <p className="text-xs muted">{t("Mood feeds the Review only if you allow it in Settings.", "يُستخدم المزاج في المراجعة فقط إن سمحت بذلك في الإعدادات.")}</p>
  </>);
}

function MedsTool() {
  const t = useT(); const s = useStore(); const [name, setName] = useState(""); const [time, setTime] = useState("09:00"); const today = dayKey(new Date());
  return (<>
    <form onSubmit={(e) => { e.preventDefault(); if (name.trim()) { s.set({ meds: [...s.meds, { id: newId(), name: name.trim(), times: [time], taken: {} }] }); setName(""); } }} className="mb-3 flex gap-2"><input className="field" value={name} onChange={(e) => setName(e.target.value)} placeholder={t("Medication or supplement", "دواء أو مكمل")} /><input type="time" className="field w-28" value={time} onChange={(e) => setTime(e.target.value)} /><button className="btn btn-primary"><Plus size={18} /></button></form>
    {s.meds.map((m) => <Card key={m.id} className="mb-2 flex items-center gap-3 p-3"><Pill size={18} className="accent" /><div className="flex-1"><p className="font-semibold">{m.name}</p><p className="text-xs muted">{m.times.join(", ")}</p></div>{m.times.map((tm) => { const on = (m.taken[today] || []).includes(tm); return <button key={tm} className="chip" aria-pressed={on} onClick={() => s.set({ meds: s.meds.map((x) => x.id === m.id ? { ...x, taken: { ...x.taken, [today]: on ? (x.taken[today] || []).filter((y) => y !== tm) : [...(x.taken[today] || []), tm] } } : x) })}>{on ? t("Taken", "أُخذ") : tm}</button>; })}<button onClick={() => s.set({ meds: s.meds.filter((x) => x.id !== m.id) })} className="muted" aria-label="delete"><Trash2 size={15} /></button></Card>)}
    <p className="mt-3 text-xs muted">{t("Informational reminders only. This is not medical advice.", "تذكيرات معلوماتية فقط وليست نصيحة طبية.")}</p>
  </>);
}

function Bedside({ onBack }: { onBack: () => void }) {
  const clockFormat = useClockFormat();
  const t = useT(); const s = useStore(); const decor = useDecor();
  const [now, setNow] = useState(new Date());
  useEffect(() => { const i = setInterval(() => setNow(new Date()), 1000); return () => clearInterval(i); }, []);
  const shift = useMemo(() => ({ x: (now.getMinutes() % 5) * 6 - 12, y: (Math.floor(now.getMinutes() / 5) % 4) * 6 - 9 }), [now.getMinutes()]); // eslint-disable-line
  return (
    <div className="fixed inset-0 z-[70] flex flex-col items-center justify-center bg-black text-white" onClick={onBack} role="dialog" aria-label={t("Bedside clock — tap to exit", "ساعة السرير — اضغط للخروج")}>
      <Particles family={decor.primary} intensity="subtle" />
      <div style={{ transform: `translate(${shift.x}px, ${shift.y}px)`, opacity: 0.75, transition: "transform 2s" }} className="text-center">
        <Motif family={decor.primary} size={40} mono="#ffffff55" className="mx-auto mb-2" />
        <p className="text-[22vw] font-extralight leading-none tabular-nums sm:text-[9rem]">{clockFormat(now)}</p>
        <p className="mt-2 text-sm opacity-60">{now.toLocaleDateString(s.lang === "ar" ? "ar-EG" : "en-GB", { weekday: "long", day: "numeric", month: "long" })}</p>
      </div>
      <p className="absolute bottom-6 text-xs opacity-30">{t("Burn-in safe: position shifts every minute · tap to exit", "آمن من الاحتراق: يتحرك كل دقيقة · اضغط للخروج")}</p>
    </div>
  );
}

function ImageTool() {
  const t = useT(); const lang = useStore((s) => s.lang);
  const [file, setFile] = useState<File | null>(null);
  const [fmt, setFmt] = useState<"image/webp" | "image/jpeg" | "image/png">("image/webp");
  const [quality, setQuality] = useState(0.85);
  const [maxW, setMaxW] = useState(1600);
  const [out, setOut] = useState<{ url: string; size: number; w: number; h: number } | null>(null);

  useEffect(() => {
    if (!file) { setOut(null); return; }
    let cancelled = false;
    const img = new Image();
    const srcUrl = URL.createObjectURL(file);
    img.onload = () => {
      const scale = img.width > maxW ? maxW / img.width : 1;
      const w = Math.max(1, Math.round(img.width * scale)), h = Math.max(1, Math.round(img.height * scale));
      const c = document.createElement("canvas"); c.width = w; c.height = h;
      c.getContext("2d")!.drawImage(img, 0, 0, w, h);
      c.toBlob((blob) => {
        URL.revokeObjectURL(srcUrl);
        if (!blob || cancelled) return;
        setOut({ url: URL.createObjectURL(blob), size: blob.size, w, h });
      }, fmt, quality);
    };
    img.src = srcUrl;
    return () => { cancelled = true; };
  }, [file, fmt, quality, maxW]);

  const ext = fmt === "image/png" ? "png" : fmt === "image/jpeg" ? "jpg" : "webp";
  return (
    <div className="space-y-3">
      <Card className="p-4 space-y-3">
        <label className="btn btn-primary w-full"><ImageIcon size={16} />{t("Choose an image", "اختار صورة")}<input type="file" accept="image/*" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) setFile(f); }} /></label>
        <div className="flex flex-wrap gap-1.5">{([["image/webp", "WebP"], ["image/jpeg", "JPG"], ["image/png", "PNG"]] as const).map(([m, l]) => <button key={m} className="chip" aria-pressed={fmt === m} onClick={() => setFmt(m)}>{l}</button>)}</div>
        <label className="block text-xs">{t("Quality", "الجودة")}: {fmtNum(Math.round(quality * 100), lang)}%<input type="range" min={0.2} max={1} step={0.05} value={quality} onChange={(e) => setQuality(+e.target.value)} className="mt-1 w-full" style={{ accentColor: "var(--accent)" }} /></label>
        <label className="block text-xs">{t("Max width (px)", "أقصى عرض (بكسل)")}: {fmtNum(maxW, lang)}<input type="range" min={400} max={3840} step={100} value={maxW} onChange={(e) => setMaxW(+e.target.value)} className="mt-1 w-full" style={{ accentColor: "var(--accent)" }} /></label>
      </Card>
      {file && out && <Card className="p-4">
        <img src={out.url} alt="" className="mx-auto max-h-52 rounded-xl object-contain" />
        <p className="mt-2 text-center text-xs muted">{fmtBytes(file.size)} → <b className="accent">{fmtBytes(out.size)}</b> · {fmtNum(out.w, lang)}×{fmtNum(out.h, lang)}</p>
        <a href={out.url} download={(file.name.replace(/\.[^.]+$/, "") || "image") + "." + ext} className="btn btn-primary mt-3 w-full"><Download size={16} />{t("Save converted image", "حفظ الصورة المحولة")}</a>
      </Card>}
    </div>
  );
}

function BreathTool() {
  const t = useT(); const lang = useStore((s) => s.lang);
  const [mode, setMode] = useState<"478" | "box">("478");
  const [run, setRun] = useState(false);
  const [sec, setSec] = useState(0);
  const seq = mode === "478" ? [{ en: "Inhale", ar: "شهيق", s: 4 }, { en: "Hold", ar: "احبس النفس", s: 7 }, { en: "Exhale", ar: "زفير", s: 8 }] : [{ en: "Inhale", ar: "شهيق", s: 4 }, { en: "Hold", ar: "احبس", s: 4 }, { en: "Exhale", ar: "زفير", s: 4 }, { en: "Hold", ar: "احبس", s: 4 }];
  const total = seq.reduce((a, b) => a + b.s, 0);
  useEffect(() => { if (!run) return; const i = setInterval(() => setSec((x) => (x + 1) % total), 1000); return () => clearInterval(i); }, [run, total]);
  let acc = 0, cur = seq[0], rem = seq[0].s;
  for (const p of seq) { if (sec < acc + p.s) { cur = p; rem = acc + p.s - sec; break; } acc += p.s; }
  const big = cur.en === "Inhale" || (cur.en === "Hold" && sec > 3 && sec < 11);
  return (
    <div className="flex flex-col items-center pt-4">
      <Segmented value={mode} onChange={(v) => { setMode(v); setSec(0); }} options={[{ id: "478", label: "4-7-8" }, { id: "box", label: t("Box 4×4", "مربع ٤×٤") }]} />
      <div className="my-10 grid h-52 w-52 place-items-center rounded-full transition-transform duration-1000" style={{ background: "var(--soft)", border: "4px solid var(--accent)", transform: run && big ? "scale(1.16)" : "scale(.9)" }}>
        <div className="text-center"><p className="text-xl font-bold">{lang === "ar" ? cur.ar : cur.en}</p><p className="text-4xl font-light tabular-nums">{fmtNum(rem, lang)}</p></div>
      </div>
      <button className="btn btn-primary px-8" onClick={() => setRun(!run)}>{run ? <Pause size={17} /> : <Play size={17} />}{run ? t("Pause", "إيقاف") : t("Start", "ابدأ")}</button>
    </div>
  );
}

function TextTool() {
  const t = useT(); const lang = useStore((s) => s.lang);
  const [txt, setTxt] = useState("");
  const words = txt.trim() ? txt.trim().split(/\s+/).length : 0;
  const chars = txt.length;
  const lines = txt ? txt.split("\n").length : 0;
  return (
    <div className="space-y-3">
      <textarea className="field min-h-44" value={txt} onChange={(e) => setTxt(e.target.value)} placeholder={t("Paste or write text here…", "الصق أو اكتب نص هنا…")} />
      <div className="grid grid-cols-3 gap-2">
        {[[t("Words", "كلمات"), words], [t("Chars", "حروف"), chars], [t("Lines", "سطور"), lines]].map(([l, v]) => <Card key={String(l)} className="p-3 text-center"><p className="text-2xl font-bold accent">{fmtNum(v as number, lang)}</p><p className="text-xs muted">{l}</p></Card>)}
      </div>
      <div className="flex flex-wrap gap-2">
        <button className="chip" onClick={() => setTxt(txt.replace(/[\u064B-\u065F\u0670]/g, ""))}>{t("Strip Arabic diacritics", "إزالة التشكيل")}</button>
        <button className="chip" onClick={() => setTxt(txt.replace(/[ \t]+/g, " ").replace(/\n{3,}/g, "\n\n").trim())}>{t("Clean extra spaces", "تنظيف المسافات")}</button>
        <button className="chip" onClick={() => setTxt("")}>{t("Clear", "مسح")}</button>
      </div>
    </div>
  );
}

function StopwatchTool() {
  const t = useT(); const lang = useStore((s) => s.lang);
  const [run, setRun] = useState(false);
  const [ms, setMs] = useState(0);
  const [laps, setLaps] = useState<number[]>([]);
  useEffect(() => { if (!run) return; const start = Date.now() - ms; const i = setInterval(() => setMs(Date.now() - start), 50); return () => clearInterval(i); }, [run]); // eslint-disable-line
  const fmt = (n: number) => `${String(Math.floor(n / 60000)).padStart(2, "0")}:${String(Math.floor(n / 1000) % 60).padStart(2, "0")}.${String(Math.floor((n % 1000) / 10)).padStart(2, "0")}`;
  return (
    <div className="flex flex-col items-center pt-4">
      <p className="font-mono text-5xl font-light tabular-nums">{fmtNum(fmt(ms), lang)}</p>
      <div className="mt-6 flex gap-3">
        <button className="btn btn-primary px-6" onClick={() => setRun(!run)}>{run ? <Pause size={17} /> : <Play size={17} />}{run ? t("Pause", "إيقاف") : t("Start", "ابدأ")}</button>
        <button className="btn btn-soft" onClick={() => setLaps([ms, ...laps])} disabled={!ms}><Flag size={16} />{t("Lap", "لفة")}</button>
        <button className="btn btn-ghost" onClick={() => { setRun(false); setMs(0); setLaps([]); }} aria-label="reset"><RotateCcw size={16} /></button>
      </div>
      {laps.length > 0 && <Card className="mt-5 w-full divide-y divide-[var(--line)]">{laps.map((l, i) => <div key={i} className="flex justify-between px-4 py-2 text-sm"><span className="muted">#{fmtNum(laps.length - i, lang)}</span><b className="font-mono">{fmtNum(fmt(l), lang)}</b></div>)}</Card>}
    </div>
  );
}
