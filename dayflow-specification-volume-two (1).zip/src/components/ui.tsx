import { ChevronLeft, ChevronRight, X } from "lucide-react";
import { useEffect, type ReactNode } from "react";
import { useLang } from "../lib/store";

export function Card({ children, className = "", onClick, style }: { children: ReactNode; className?: string; onClick?: () => void; style?: React.CSSProperties }) {
  const a11y = onClick ? { role: "button", tabIndex: 0, onKeyDown: (e: React.KeyboardEvent) => { if (e.target === e.currentTarget && (e.key === "Enter" || e.key === " ")) { e.preventDefault(); onClick(); } } } : {};
  return <div onClick={onClick} style={style} {...a11y} className={`card ${onClick ? "cursor-pointer text-start w-full active:scale-[.99]" : ""} ${className}`}>{children}</div>;
}

export function Toggle({ on, onChange, label }: { on: boolean; onChange: (v: boolean) => void; label: string }) {
  return <button role="switch" aria-checked={on} aria-label={label} className="switch" onClick={(e) => { e.stopPropagation(); onChange(!on); }} />;
}

export function Row({ icon, title, hint, right, onClick }: { icon?: ReactNode; title: string; hint?: string; right?: ReactNode; onClick?: () => void }) {
  const lang = useLang();
  const Chev = lang === "ar" ? ChevronLeft : ChevronRight;
  const a11y = onClick ? { role: "button", tabIndex: 0, onKeyDown: (e: React.KeyboardEvent) => { if (e.target === e.currentTarget && (e.key === "Enter" || e.key === " ")) { e.preventDefault(); onClick(); } } } : {};
  return (
    <div onClick={onClick} {...a11y} className={`flex w-full items-center gap-3 px-4 py-3 text-start ${onClick ? "cursor-pointer" : ""}`}>
      {icon && <span className="grid h-9 w-9 flex-none place-items-center rounded-xl" style={{ background: "var(--soft)", color: "var(--accent)" }}>{icon}</span>}
      <span className="min-w-0 flex-1">
        <span className="block text-[.95rem] font-medium">{title}</span>
        {hint && <span className="muted block text-xs leading-snug">{hint}</span>}
      </span>
      {right ?? (onClick && <Chev size={18} className="muted" />)}
    </div>
  );
}

export function Group({ title, children }: { title?: string; children: ReactNode }) {
  return (
    <section className="mb-5">
      {title && <h3 className="muted mb-2 px-1 text-xs font-semibold uppercase tracking-wider">{title}</h3>}
      <div className="card divide-y" style={{ ["--tw-divide-opacity" as string]: 1 }}>
        <div className="divide-y divide-[var(--line)]">{children}</div>
      </div>
    </section>
  );
}

export function ScreenHeader({ title, onBack, right, subtitle }: { title: string; onBack?: () => void; right?: ReactNode; subtitle?: string }) {
  const lang = useLang();
  const Back = lang === "ar" ? ChevronRight : ChevronLeft;
  return (
    <header className="sticky top-0 z-20 -mx-4 mb-3 flex items-center gap-2 px-4 pb-2 pt-3" style={{ background: "color-mix(in oklch, var(--bg) 82%, transparent)", backdropFilter: "blur(14px)" }}>
      {onBack && <button onClick={onBack} aria-label="Back" className="-ms-2 grid h-10 w-10 place-items-center rounded-full"><Back size={22} /></button>}
      <div className="min-w-0 flex-1">
        <h1 className="truncate text-xl font-bold tracking-tight">{title}</h1>
        {subtitle && <p className="muted truncate text-xs">{subtitle}</p>}
      </div>
      {right}
    </header>
  );
}

export function Sheet({ open, onClose, title, children, wide }: { open: boolean; onClose: () => void; title?: string; children: ReactNode; wide?: boolean }) {
  useEffect(() => {
    if (!open) return;
    const k = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", k);
    return () => window.removeEventListener("keydown", k);
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-[60] flex items-end justify-center sm:items-center" role="dialog" aria-modal="true" aria-label={title}>
      <div className="absolute inset-0 bg-black/40 fade-in" onClick={onClose} />
      <div className={`card sheet relative max-h-[88vh] w-full overflow-y-auto rounded-b-none p-5 sm:rounded-b-[var(--r)] ${wide ? "sm:max-w-2xl" : "sm:max-w-md"}`} style={{ background: "var(--surface)", backdropFilter: "none" }}>
        <div className="mx-auto mb-3 h-1 w-10 rounded-full sm:hidden" style={{ background: "var(--line)" }} />
        {title && (
          <div className="mb-4 flex items-center justify-between">
            <h2 className="text-lg font-bold">{title}</h2>
            <button onClick={onClose} aria-label="Close" className="grid h-8 w-8 place-items-center rounded-full btn-soft"><X size={16} /></button>
          </div>
        )}
        {children}
      </div>
    </div>
  );
}

export function Ring({ value, size = 64, stroke = 7, color = "var(--accent)", track = "var(--line)", children }: { value: number; size?: number; stroke?: number; color?: string; track?: string; children?: ReactNode }) {
  const r = (size - stroke) / 2, c = 2 * Math.PI * r;
  return (
    <div className="relative grid place-items-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90" aria-hidden>
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke={track} strokeWidth={stroke} />
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke={color} strokeWidth={stroke} strokeLinecap="round" strokeDasharray={c} strokeDashoffset={c * (1 - Math.max(0, Math.min(1, value)))} style={{ transition: "stroke-dashoffset var(--dur) var(--ease)" }} />
      </svg>
      <div className="absolute inset-0 grid place-items-center">{children}</div>
    </div>
  );
}

export function Segmented<T extends string>({ value, options, onChange }: { value: T; options: Array<{ id: T; label: string }>; onChange: (v: T) => void }) {
  return (
    <div className="flex gap-1 rounded-full p-1" style={{ background: "var(--soft)" }} role="tablist">
      {options.map((o) => (
        <button key={o.id} role="tab" aria-selected={value === o.id} onClick={() => onChange(o.id)}
          className="flex-1 rounded-full px-3 py-1.5 text-sm font-semibold transition-all"
          style={value === o.id ? { background: "var(--surface)", boxShadow: "0 1px 4px rgba(0,0,0,.12)" } : { opacity: 0.7 }}>
          {o.label}
        </button>
      ))}
    </div>
  );
}

export function Honest({ children }: { children: ReactNode }) {
  return <div className="rounded-xl border border-dashed px-3 py-2 text-xs leading-relaxed muted" style={{ borderColor: "var(--line)" }}>{children}</div>;
}
