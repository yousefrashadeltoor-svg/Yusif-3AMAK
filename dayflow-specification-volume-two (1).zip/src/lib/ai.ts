// Real AI client. Calls the provider the user chose, from the browser, with the user's own key.
// No proxy server, no key ever leaves the device except to the chosen provider.
import { type Api, type ModelInfo, providerById, detectProvider, PROVIDERS, isChatModelId, modelLogoSlug } from "./providers";
import { dayKey } from "./calendar";

export interface ApiKeyEntry { id: string; provider: Api; key: string; label: string; addedAt: number; baseOverride?: string; liveModels?: LiveModel[]; modelsFetchedAt?: number }
export interface LiveModel { id: string; name: string; ctx: number; prompt: number; completion: number; free: boolean; modality?: string; supportsImage?: boolean; supportsDoc?: boolean }
export interface Attachment { name: string; mime: string; size: number; isImage: boolean; dataUrl?: string; text?: string }
export interface SourceRef { kind: "app" | "attachment" | "web"; title: string; origin: "available" | "cited"; url?: string }
export interface AiMsg { role: "user" | "assistant" | "system"; content: string; reasoning?: string; model?: string; at?: number; err?: boolean; attachments?: Attachment[] }
export interface Conversation { id: string; title: string; msgs: AiMsg[]; keyId?: string; model?: string; at: number }

export function keyHint(k: string) {
  const t = k.trim();
  if (!t) return "";
  return t.length <= 10 ? "•".repeat(t.length) : t.slice(0, 6) + "…" + t.slice(-4);
}

/** Verifies a key with the provider's own free endpoint where one exists. */
export async function verifyKey(entry: ApiKeyEntry): Promise<{ ok: boolean; detail: string; models?: LiveModel[] }> {
  const p = providerById(entry.provider);
  const base = (entry.baseOverride || p.base).replace(/\/$/, "");
  try {
    if (entry.provider === "openrouter") {
      const r = await fetch(base + "/models", { headers: { Authorization: "Bearer " + entry.key } });
      if (!r.ok) return { ok: false, detail: `HTTP ${r.status}: ${(await r.text()).slice(0, 140)}` };
      const j = await r.json();
      const models: LiveModel[] = (j.data || [])
        .filter((m: { id: string }) => isChatModelId(m.id))
        .map((m: Record<string, unknown>) => {
          const pr = (m.pricing || {}) as Record<string, string>;
          const arch = (m.architecture || {}) as { modality?: string; input_modalities?: string[] };
          const inp = arch.input_modalities || [];
          return {
            id: m.id as string, name: m.name as string, ctx: (m.context_length as number) || 0,
            prompt: +(pr.prompt || 0), completion: +(pr.completion || 0), free: +(pr.prompt || 0) === 0,
            modality: arch.modality || "",
            supportsImage: inp.includes("image") || /vision|vl|4o|gemini|claude-3|claude-sonnet-4|claude-opus-4|pixtral|llama-4/i.test(m.id as string),
            supportsDoc: inp.includes("file") || /claude|gemini|gpt-4o|gpt-4\.1|gpt-5/i.test(m.id as string),
          };
        });
      return { ok: true, detail: `${models.length} models · ${models.filter((m) => m.free).length} free`, models };
    }
    if (entry.provider === "gemini") {
      const r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models?key=${encodeURIComponent(entry.key)}`);
      if (!r.ok) return { ok: false, detail: `HTTP ${r.status}` };
      const j = await r.json();
      const models: LiveModel[] = (j.models || [])
        .filter((m: { name: string; supportedGenerationMethods?: string[] }) => m.supportedGenerationMethods?.includes("generateContent") && isChatModelId(m.name))
        .map((m: { name: string; displayName: string; inputTokenLimit: number }) => ({
          id: m.name.replace("models/", ""), name: m.displayName, ctx: m.inputTokenLimit || 0,
          prompt: 0, completion: 0, free: true, supportsImage: true, supportsDoc: true,
        }));
      return { ok: true, detail: `${models.length} Gemini models`, models };
    }
    if (p.kind === "openai" || p.kind === "anthropic") {
      const isA = p.kind === "anthropic";
      const r = await fetch(base + (isA ? "/messages" : "/models"), isA ? {
        method: "POST",
        headers: { "content-type": "application/json", "x-api-key": entry.key, "anthropic-version": "2023-06-01", "anthropic-dangerous-direct-browser-access": "true" },
        body: JSON.stringify({ model: p.models[0].id, max_tokens: 1, messages: [{ role: "user", content: "hi" }] }),
      } : { headers: { Authorization: "Bearer " + entry.key } });
      if (isA) {
        if (r.status === 401 || r.status === 403) return { ok: false, detail: `HTTP ${r.status} — key rejected` };
        return { ok: true, detail: r.ok ? "Key accepted" : `Reachable (HTTP ${r.status})` };
      }
      if (!r.ok) return { ok: false, detail: `HTTP ${r.status}: ${(await r.text()).slice(0, 140)}` };
      const j = await r.json();
      const models: LiveModel[] = (j.data || [])
        .filter((m: { id: string }) => isChatModelId(m.id))
        .map((m: { id: string; context_window?: number; context_length?: number }) => ({
          id: m.id, name: m.id, ctx: m.context_length || m.context_window || 0,
          prompt: 0, completion: 0, free: entry.provider === "groq",
          supportsImage: /vision|vl|4o|4\.1|gpt-5|pixtral|llama-4|scout|maverick|gemini/i.test(m.id),
          supportsDoc: /4o|4\.1|gpt-5|claude|gemini/i.test(m.id),
        }));
      return { ok: true, detail: models.length ? `${models.length} chat models` : "Key accepted", models: models.length ? models : undefined };
    }
    return { ok: true, detail: "Saved (not verifiable without a request)" };
  } catch (e) {
    return { ok: false, detail: (e as Error).message + " — check the URL / CORS / connection" };
  }
}

/** Pick the safest reliable chat model (never a TTS/terms-gated model). */
export function defaultModelFor(provider: Api, live?: LiveModel[]): string {
  const p = providerById(provider);
  if (!live?.length) return p.models[0]?.id || "";
  for (const curated of p.models) {
    if (live.some((l) => l.id === curated.id)) return curated.id;
  }
  const safe = live.find((m) => isChatModelId(m.id) && !/orpheus|whisper|guard|tts/i.test(m.id));
  return safe?.id || p.models[0]?.id || live[0].id;
}

const APP_SYSTEM = `You are "Dayflow AI", the assistant inside the DAYFLOW app.
Brand facts: DAYFLOW is a calm, offline-first planner. Tabs: Today, Calendar, Alarms, Tools, AI, Me.
It has 3 calendars (Gregorian, Hijri Umm al-Qura, Coptic), Egyptian + Islamic occasions, a seasonal decoration engine,
69 theme packs, 140+ size-morphing widgets, prayer times calculated on device (Egyptian method), a deterministic Review engine with 11 dimensions and "why this score" evidence,
habits with days/types/targets, water/focus/notes/countdowns/journal/meds/tasbih/converters/image-converter/QR, a floating physical robot companion + 3D models,
and a Media Hub that fetches public previews & direct files in browser (native yt-dlp/FFmpeg engine in the Android project).
Honesty rules: never claim a native Android feature works inside a browser preview. Never invent data, prices or licenses.
Answer in the user's language. If the user writes Arabic, reply in warm EGYPTIAN COLLOQUIAL Arabic (not MSA).
You can act in the app. Dates are important: today, in the user's LOCAL time zone, is supplied below.
Convert phrases like "بكرة", "بعد بكرة", "بعد ٣ أيام", and named weekdays into an absolute YYYY-MM-DD in the user's local calendar. Never change a requested future date to today. For one-off alarms use date YYYY-MM-DD and days ""; for recurring alarms use only days (0=Sunday, 6=Saturday) and do not invent a date. For tasks include date YYYY-MM-DD and optional time HH:mm. For a habit that starts later include its start date. If a day, hour, or AM/PM is unclear, ASK THE USER; never assume today, tomorrow, or a weekday schedule. A future date already requested in an earlier turn remains in force when the user answers a follow-up question.
Only report an action completed after it has actually been recorded. To propose an action, append ONE fenced block like:
\`\`\`dayflow
{"actions":[{"intent":"addAlarm","date":"2027-06-15","time":"06:30","days":"","label":"الصبح"},{"intent":"addTask","title":"مكالمة","date":"2027-06-15","time":"18:00"}]}
\`\`\`
Allowed intents: addAlarm(time HH:mm, date for one-off OR days csv for repetition, label), addTask(title, date YYYY-MM-DD, optional time HH:mm), addHabit(name, days, optional date to begin), addWater(ml), open(tab, sub).
If a required field is missing, DO NOT act — ask the user a short question first.
When the user asks about the app, use the brand facts above and be precise. Keep replies short unless asked for detail.`;

export interface ChatCallbacks {
  onReasoning?: (delta: string) => void;
  onText?: (delta: string) => void;
  signal?: AbortSignal;
}

function modelSupportsReasoningParam(provider: Api, model: string): boolean {
  if (provider === "openrouter") return /r1|reasoner|thinking|o1|o3|o4|grok-4|qwq/i.test(model);
  if (provider === "deepseek") return /reasoner|r1/i.test(model);
  return false;
}

function toOpenAiContent(m: AiMsg): string | Array<Record<string, unknown>> {
  const atts = m.attachments || [];
  if (!atts.length) return m.content;
  const parts: Array<Record<string, unknown>> = [];
  let text = m.content;
  for (const a of atts) {
    if (a.isImage && a.dataUrl) parts.push({ type: "image_url", image_url: { url: a.dataUrl } });
    else if (a.text) text += `\n\n[File: ${a.name}]\n${a.text}`;
  }
  parts.unshift({ type: "text", text });
  return parts;
}

function toAnthropicContent(m: AiMsg): string | Array<Record<string, unknown>> {
  const atts = m.attachments || [];
  if (!atts.length) return m.content;
  const parts: Array<Record<string, unknown>> = [];
  let text = m.content;
  for (const a of atts) {
    if (a.isImage && a.dataUrl) {
      const b64 = a.dataUrl.split(",")[1] || "";
      parts.push({ type: "image", source: { type: "base64", media_type: a.mime || "image/png", data: b64 } });
    } else if (a.mime === "application/pdf" && a.dataUrl) {
      const b64 = a.dataUrl.split(",")[1] || "";
      parts.push({ type: "document", source: { type: "base64", media_type: "application/pdf", data: b64 } });
    } else if (a.text) text += `\n\n[File: ${a.name}]\n${a.text}`;
  }
  parts.push({ type: "text", text });
  return parts;
}

function toGeminiParts(m: AiMsg): Array<Record<string, unknown>> {
  const atts = m.attachments || [];
  const parts: Array<Record<string, unknown>> = [];
  let text = m.content;
  for (const a of atts) {
    if ((a.isImage || a.mime === "application/pdf") && a.dataUrl) {
      const b64 = a.dataUrl.split(",")[1] || "";
      parts.push({ inlineData: { mimeType: a.mime || "image/png", data: b64 } });
    } else if (a.text) text += `\n\n[File: ${a.name}]\n${a.text}`;
  }
  parts.unshift({ text });
  return parts;
}

/** Streams a chat completion. Supports OpenAI-compatible, Anthropic and Google Gemini, including attachments. */
export async function streamChat(opts: { entry: ApiKeyEntry; model: string; messages: AiMsg[]; temperature?: number; reasoning?: boolean }, cb: ChatCallbacks): Promise<string> {
  const p = providerById(opts.entry.provider);
  const base = (opts.entry.baseOverride || p.base).replace(/\/$/, "");
  const now = new Date();
  const sys = `${APP_SYSTEM}\nCurrent device-local date: ${dayKey(now)}; local time: ${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}; weekday (0=Sunday): ${now.getDay()}; time zone: ${Intl.DateTimeFormat().resolvedOptions().timeZone}.`;
  const rawHist = opts.messages.filter((m) => m.role !== "system");

  if (p.kind === "anthropic") {
    const r = await fetch(base + "/messages", {
      method: "POST", signal: cb.signal,
      headers: { "content-type": "application/json", "x-api-key": opts.entry.key, "anthropic-version": "2023-06-01", "anthropic-dangerous-direct-browser-access": "true" },
      body: JSON.stringify({ model: opts.model, max_tokens: 1600, system: sys, stream: true, messages: rawHist.map((m) => ({ role: m.role, content: toAnthropicContent(m) })), ...(opts.reasoning && /claude-3-7|claude-sonnet-4|claude-opus-4/i.test(opts.model) ? { thinking: { type: "enabled", budget_tokens: 1024 } } : {}) }),
    });
    if (!r.ok) throw new Error(`HTTP ${r.status}: ${(await r.text()).slice(0, 320)}`);
    return readSSE(r, cb, (j, emit) => {
      const d = j.delta || {};
      if (d.type === "thinking_delta" && d.thinking) emit("reason", d.thinking);
      else if (d.type === "text_delta" && d.text) emit("text", d.text);
    });
  }

  if (p.kind === "gemini") {
    const url = base + `/models/${encodeURIComponent(opts.model)}:streamGenerateContent?alt=sse&key=${encodeURIComponent(opts.entry.key)}`;
    const r = await fetch(url, {
      method: "POST", signal: cb.signal, headers: { "content-type": "application/json" },
      body: JSON.stringify({ systemInstruction: { parts: [{ text: sys }] }, contents: rawHist.map((m) => ({ role: m.role === "assistant" ? "model" : "user", parts: toGeminiParts(m) })), generationConfig: { temperature: opts.temperature ?? 0.7 } }),
    });
    if (!r.ok) throw new Error(`HTTP ${r.status}: ${(await r.text()).slice(0, 320)}`);
    return readSSE(r, cb, (j, emit) => {
      const parts: any[] = j.candidates?.[0]?.content?.parts || [];
      for (const pt of parts) { if (pt.thought) { if (pt.text) emit("reason", pt.text); } else if (pt.text) emit("text", pt.text); }
    });
  }

  // OpenAI-compatible (OpenAI, OpenRouter, Groq, Mistral, DeepSeek, xAI, Cohere, local…)
  const headers: Record<string, string> = { "content-type": "application/json", Authorization: "Bearer " + opts.entry.key };
  if (opts.entry.provider === "openrouter") { headers["HTTP-Referer"] = location.origin; headers["X-Title"] = "DAYFLOW"; }
  const body: Record<string, unknown> = {
    model: opts.model,
    messages: [{ role: "system", content: sys }, ...rawHist.map((m) => ({ role: m.role, content: toOpenAiContent(m) }))],
    stream: true,
    temperature: opts.temperature ?? 0.7,
  };
  if (opts.reasoning && modelSupportsReasoningParam(opts.entry.provider, opts.model)) {
    body.reasoning = { effort: "medium" };
    body.include_reasoning = true;
  }
  const r = await fetch(base + "/chat/completions", { method: "POST", signal: cb.signal, headers, body: JSON.stringify(body) });
  if (!r.ok) throw new Error(`HTTP ${r.status}: ${(await r.text()).slice(0, 320)}`);
  return readSSE(r, cb, (j, emit) => {
    const d = j.choices?.[0]?.delta || {};
    if (d.reasoning) emit("reason", d.reasoning);
    if (d.reasoning_content) emit("reason", d.reasoning_content);
    if (d.reasoning_details) for (const rd of (d.reasoning_details as any[])) if (rd.text) emit("reason", rd.text);
    if (d.content) emit("text", typeof d.content === "string" ? d.content : "");
  });
}

async function readSSE(res: Response, cb: ChatCallbacks, handle: (json: any, emit: (t: "text" | "reason", s: string) => void) => void) {
  const reader = res.body?.getReader();
  if (!reader) throw new Error("No stream in this browser");
  const dec = new TextDecoder();
  let buf = "", full = "";
  const emit = (t: "text" | "reason", s: string) => {
    if (!s) return;
    if (t === "text") { full += s; cb.onText?.(s); }
    else cb.onReasoning?.(s);
  };
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    buf += dec.decode(value, { stream: true });
    const lines = buf.split("\n"); buf = lines.pop() || "";
    for (const line of lines) {
      const l = line.trim();
      if (!l || l.startsWith(":") || l.startsWith("event:")) continue;
      if (!l.startsWith("data:")) continue;
      const data = l.slice(5).trim();
      if (data === "[DONE]") continue;
      try { handle(JSON.parse(data), emit); } catch { /* keep-alive or partial */ }
    }
  }
  return full;
}

/** Extract + strip the dayflow action block. */
export function parseActions(text: string): { clean: string; actions: Array<{ intent: string; [k: string]: string }> } {
  const m = text.match(/```dayflow\s*([\s\S]*?)```/i);
  if (!m) return { clean: text, actions: [] };
  let actions: Array<{ intent: string; [k: string]: string }> = [];
  try { actions = (JSON.parse(m[1]).actions || []).filter((a: { intent?: string }) => a && a.intent); } catch { actions = []; }
  return { clean: text.replace(m[0], "").trim(), actions };
}

/** Real model list, merging the curated catalog with any live list (OpenRouter/Gemini/Groq/OpenAI). */
export function modelList(provider: Api, live?: LiveModel[]): ModelInfo[] {
  const p = providerById(provider);
  const base = p.models.map((m) => ({ ...m, logo: m.logo || modelLogoSlug(m.id, p.logo) }));
  if (live?.length) {
    const seen = new Set(base.map((m) => m.id));
    for (const lm of live.slice(0, 450)) {
      if (!isChatModelId(lm.id)) continue;
      if (seen.has(lm.id)) {
        const existing = base.find((x) => x.id === lm.id);
        if (existing) {
          if (lm.supportsImage !== undefined) existing.supportsImage = lm.supportsImage;
          if (lm.supportsDoc !== undefined) existing.supportsDoc = lm.supportsDoc;
          if (lm.free && !existing.tier.includes("free")) existing.tier = ["free", ...existing.tier];
        }
        continue;
      }
      seen.add(lm.id);
      const tiers: ModelInfo["tier"] = lm.free ? ["free", "open"] : lm.prompt > 0 && lm.prompt <= 0.0000005 ? ["cheap", "balanced"] : lm.prompt >= 0.000005 ? ["premium"] : ["balanced"];
      if (/r1|reasoner|thinking|qwq|o1|o3|o4/i.test(lm.id)) tiers.push("reasoning");
      if (/coder|codestral|devstral/i.test(lm.id)) tiers.push("coding");
      if (/flash|instant|mini|nano|haiku|turbo/i.test(lm.id)) tiers.push("fast");
      if (lm.supportsImage) tiers.push("vision");
      base.push({
        id: lm.id, name: lm.name.replace(/^[^:]+:\s*/, ""), tier: tiers, ctx: lm.ctx,
        logo: modelLogoSlug(lm.id, p.logo),
        supportsImage: !!lm.supportsImage, supportsDoc: !!lm.supportsDoc,
      });
    }
  }
  return base;
}

export const providerCount = PROVIDERS.length;
export const detectedLabel = (k: string) => { const p = detectProvider(k); return p ? providerById(p).name : null; };
