import { dayKey, fromKey } from "./calendar";

export type DateIntent =
  | { kind: "none" }
  | { kind: "date"; date: string; phrase: string }
  | { kind: "repeat"; days: number[]; phrase: string; startDate?: string }
  | { kind: "ambiguous"; reason: string };

export type TimeIntent =
  | { kind: "none" }
  | { kind: "time"; time: string; phrase: string; date?: string; relative?: boolean }
  | { kind: "ambiguous"; reason: string };

const DAYS: Array<[RegExp, number]> = [
  [/(?:^|[^\p{L}])و?(?:الاحد|sunday|sun)(?=$|[^\p{L}])/iu, 0],
  [/(?:^|[^\p{L}])و?(?:الاثنين|الاتنين|اتنين|اثنين|monday|mon)(?=$|[^\p{L}])/iu, 1],
  [/(?:^|[^\p{L}])و?(?:التلات|التلاتاء|تلات|الثلاثاء|tuesday|tue)(?=$|[^\p{L}])/iu, 2],
  [/(?:^|[^\p{L}])و?(?:الاربعاء|اربعاء|wednesday|wed)(?=$|[^\p{L}])/iu, 3],
  [/(?:^|[^\p{L}])و?(?:الخميس|خميس|thursday|thu)(?=$|[^\p{L}])/iu, 4],
  [/(?:^|[^\p{L}])و?(?:الجمعة|الجمعه|جمعة|friday|fri)(?=$|[^\p{L}])/iu, 5],
  [/(?:^|[^\p{L}])و?(?:السبت|سبت|saturday|sat)(?=$|[^\p{L}])/iu, 6],
];
const MONTH_NAMES = ["يناير", "فبراير", "مارس", "ابريل", "مايو", "يونيو", "يوليو", "اغسطس", "سبتمبر", "اكتوبر", "نوفمبر", "ديسمبر"];
const MONTHS_EN = ["january", "february", "march", "april", "may", "june", "july", "august", "september", "october", "november", "december"];

export function normalizeDateWords(value: string): string {
  return value
    .replace(/[٠-٩]/g, (c) => String("٠١٢٣٤٥٦٧٨٩".indexOf(c)))
    .replace(/[۰-۹]/g, (c) => String("۰۱۲۳۴۵۶۷۸۹".indexOf(c)))
    .replace(/[\u064B-\u065F\u0670\u0640]/g, "")
    .replace(/[إأآٱ]/g, "ا").replace(/ى/g, "ي")
    .toLowerCase();
}

export function isValidDay(value: unknown): value is string {
  if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const d = fromKey(value);
  return Number.isFinite(+d) && dayKey(d) === value;
}

export const isValidTime = (value: unknown): value is string => typeof value === "string" && /^([01]\d|2[0-3]):[0-5]\d$/.test(value);

export function contextualRequest(previous: string, reply: string): string {
  if (!previous) return reply;
  const freshCommand = /^(?:اعمل|اعملي|ضيف|اضف|اكتب|حط|سجل|انشئ|create|add|set|schedule)\s+(?:منبه|مهمة|تاسك|عادة|task|alarm|habit)/i.test(normalizeDateWords(reply.trim()));
  return freshCommand ? reply : `${previous} ${reply}`;
}

const calendarDay = (now: Date, offset: number): string => dayKey(new Date(now.getFullYear(), now.getMonth(), now.getDate() + offset));

export function parseDateIntent(input: string, now = new Date()): DateIntent {
  const q = normalizeDateWords(input);
  const start = q.match(/(?:ابتداء\s+من|بداية\s+من|بدايه\s+من|من|starting(?:\s+on)?)\s+(بعد\s+بكر[هةا]|بكر[هةا]|غدا|tomorrow|\d{4}[-/]\d{1,2}[-/]\d{1,2}|\d{1,2}[/.]\d{1,2}[/.]\d{4})/i);
  if (start && /(?:كل يوم|كل\s+(?:يوم\s+)?(?:الاتنين|الاثنين|اتنين|التلات|الثلاثاء|الخميس|الجمعة|السبت)|every\s+(?:day|monday|tuesday|wednesday|thursday|friday|saturday|sunday)|يوميا|daily)/i.test(q)) {
    const recur = parseDateIntent(q.replace(start[0], ""), now);
    const first = parseDateIntent(start[1], now);
    if (recur.kind === "repeat" && first.kind === "date") return { ...recur, startDate: first.date };
    return { kind: "ambiguous", reason: "حدد تاريخ بداية التكرار بالضبط، مثل 15/06/2027." };
  }
  const explicit = q.match(/(?<!\d)(\d{4})[-/]([01]?\d)[-/]([0-3]?\d)(?!\d)/);
  if (explicit) {
    const value = `${explicit[1]}-${explicit[2].padStart(2, "0")}-${explicit[3].padStart(2, "0")}`;
    return isValidDay(value) ? { kind: "date", date: value, phrase: explicit[0] } : { kind: "ambiguous", reason: "تاريخ غير صالح؛ اكتب التاريخ بصيغة سنة-شهر-يوم." };
  }
  const dmy = q.match(/(?<!\d)([0-3]?\d)[/.]([01]?\d)[/.](\d{4})(?!\d)/);
  if (dmy) {
    const value = `${dmy[3]}-${dmy[2].padStart(2, "0")}-${dmy[1].padStart(2, "0")}`;
    return isValidDay(value) ? { kind: "date", date: value, phrase: dmy[0] } : { kind: "ambiguous", reason: "التاريخ ده مش صالح؛ اكتب اليوم والشهر والسنة." };
  }
  const namedMonth = q.match(/(?<!\d)(\d{1,2})\s+(يناير|فبراير|مارس|ابريل|مايو|يونيو|يوليو|اغسطس|سبتمبر|اكتوبر|نوفمبر|ديسمبر|january|february|march|april|may|june|july|august|september|october|november|december)\s+(\d{4})(?!\d)/i);
  if (namedMonth) {
    const month = Math.max(MONTH_NAMES.indexOf(namedMonth[2]), MONTHS_EN.indexOf(namedMonth[2])) + 1;
    const value = `${namedMonth[3]}-${String(month).padStart(2, "0")}-${namedMonth[1].padStart(2, "0")}`;
    return isValidDay(value) ? { kind: "date", date: value, phrase: namedMonth[0] } : { kind: "ambiguous", reason: "التاريخ ده مش صالح؛ اكتب اليوم والشهر والسنة." };
  }
  if (/(?<!\d)\d{1,2}\s+(?:يناير|فبراير|مارس|ابريل|مايو|يونيو|يوليو|اغسطس|سبتمبر|اكتوبر|نوفمبر|ديسمبر|january|february|march|april|may|june|july|august|september|october|november|december)(?!\p{L})/iu.test(q)) return { kind: "ambiguous", reason: "قولّي السنة كمان عشان ما أحددش يوم غلط." };

  const isRepeat = /(?:كل يوم|يوميا|every day|\bdaily\b|كل\s+(?:الاحد|الاتنين|الاثنين|اتنين|اثنين|التلات|تلات|الثلاثاء|الاربعاء|اربعاء|الخميس|خميس|الجمعة|جمعة|السبت|سبت)|every\s+(?:monday|tuesday|wednesday|thursday|friday|saturday|sunday)|كل اسبوع)/i.test(q);
  const names: number[] = [];
  for (const [regex, n] of DAYS) if (regex.test(q)) names.push(n);
  const weekdays = [...new Set(names)].sort();
  if (isRepeat && weekdays.length) return { kind: "repeat", days: weekdays, phrase: "أيام متكررة" };
  if (isRepeat && (/كل يوم|يوميا|every day|daily/.test(q))) return { kind: "repeat", days: [0, 1, 2, 3, 4, 5, 6], phrase: "كل يوم" };
  if (isRepeat) return { kind: "ambiguous", reason: "حدّد أيام التكرار، زي كل يوم اتنين أو كل يوم." };

  const after = q.match(/(?:بعد|in)\s+(?:(\d{1,3})\s+(يوم|ايام|اسبوع|اسابيع|days?|weeks?)|(يومين|اسبوعين|اسبوع|يوم)(?!\p{L}))/iu);
  if (after) {
    const word = after[3] || "", n = after[1] ? Number(after[1]) : /يومين|اسبوعين/.test(word) ? 2 : 1;
    if (!Number.isFinite(n) || n <= 0 || n > 365) return { kind: "ambiguous", reason: "حدّد بعد كام يوم بالظبط." };
    const weeks = /اسبوع|weeks?/i.test(after[2] || word);
    return { kind: "date", date: calendarDay(now, n * (weeks ? 7 : 1)), phrase: after[0] };
  }
  if (/(?:بعد\s+(?:بكر[هةا]|غد)|day after tomorrow)/i.test(q)) return { kind: "date", date: calendarDay(now, 2), phrase: "بعد بكرة" };
  if (/(?:بكر[هةا]|غدا|tomorrow)/i.test(q)) return { kind: "date", date: calendarDay(now, 1), phrase: "بكرة" };
  if (/(?:النهارده|النهاردة|اليوم|today)/i.test(q)) return { kind: "date", date: dayKey(now), phrase: "النهاردة" };

  if (weekdays.length > 1) return { kind: "ambiguous", reason: "أنهي يوم بالظبط؟ لو متكرر قول كل يوم اتنين وخميس." };
  if (/(?:بعد الجاي|بعد القادم|week after next|مش\s+بكر(?![\s\S]*بعد\s+بكر))/i.test(q)) return { kind: "ambiguous", reason: "حدّد التاريخ المقصود باليوم والشهر والسنة عشان ما أختارش أسبوع غلط." };
  if (weekdays.length === 1) {
    const target = weekdays[0];
    const weekday = q.match(/(?:الاحد|الاثنين|الاتنين|التلات|التلاتاء|الثلاثاء|الاربعاء|الخميس|الجمعة|الجمعه|السبت|sunday|monday|tuesday|wednesday|thursday|friday|saturday)/i)?.[0] || "";
    const nextWeek = /(?:الاسبوع\s+(?:الجاي|اللي جاي|القادم)|next week)/i.test(q);
    const delta = nextWeek
      ? 7 - (now.getDay() + 1) % 7 + (target + 1) % 7
      : (target - now.getDay() + 7) % 7 || (/الجاي|القادم|next/i.test(q) ? 7 : 0);
    return { kind: "date", date: calendarDay(now, delta), phrase: weekday };
  }
  if (/(?:الشهر\s+(?:الجاي|اللي جاي|القادم|المقبل)|next month|الاسبوع\s+(?:الجاي|اللي جاي|القادم|المقبل)|next week)/i.test(q)) return { kind: "ambiguous", reason: "حدّد اليوم المطلوب في الشهر أو الأسبوع الجاي." };
  if (/(?<!\d)\d{1,2}[/.]\d{1,2}(?![/.\d])/.test(q)) return { kind: "ambiguous", reason: "اكتب السنة مع اليوم والشهر، مثل 15/06/2027." };
  if (/(?:يوم|day)\s+\d{1,2}(?![\d:/.])/.test(q)) return { kind: "ambiguous", reason: "قولّي الشهر والسنة كمان عشان أسجّلها في اليوم الصح." };
  const relativeTime = parseTimeIntent(q, now);
  if (relativeTime.kind === "time" && relativeTime.relative) return { kind: "none" };
  if (/(?:بعد\s+(?!الضهر|الظهر)|الجاي|القادم|المقبل|لاحقا|لاحق|later\b|next\b|future\b|upcoming\b)/i.test(q)) return { kind: "ambiguous", reason: "قولّي التاريخ المقصود بشكل واضح، زي بكرة أو 15/06/2027." };
  return { kind: "none" };
}

export function parseTimeIntent(input: string, now = new Date()): TimeIntent {
  const q = normalizeDateWords(input).replace(/\d{4}[-/]\d{1,2}[-/]\d{1,2}/g, " ").replace(/\d{1,2}[/.]\d{1,2}[/.]\d{4}/g, " ");
  const later = q.match(/(?:بعد|in)\s+(?:(\d{1,3}|ساعتين|ساعتان|ساعة|نص|نصف)\s*(ساعات|ساعة|ساعه|دقايق|دقائق|دقيقة|دقيقه|hours?|minutes?)|(ساعتين|ساعتان))/i);
  if (later) {
    const unit = later[2] || later[3] || "";
    const amount = /ساعتين|ساعتان/.test(later[1] || later[3] || "") ? 2 : /نص|نصف/.test(later[1] || "") ? 0.5 : /ساعة|ساعه/.test(later[1] || "") ? 1 : Number(later[1]);
    const minutes = Math.round(amount * (/دقايق|دقائق|دقيقة|دقيقه|minutes?/i.test(unit) ? 1 : 60));
    if (minutes <= 0 || minutes > 7 * 1440) return { kind: "ambiguous", reason: "حدد فاضل كام ساعة أو دقيقة بالظبط." };
    const target = new Date(now.getTime() + minutes * 60000);
    return { kind: "time", time: `${String(target.getHours()).padStart(2, "0")}:${String(target.getMinutes()).padStart(2, "0")}`, date: dayKey(target), relative: true, phrase: later[0] };
  }
  const match = q.match(/(?<!\d)(\d{1,2}):([0-5]\d)(?!\d)/) || q.match(/(?:الساعه|ساعة|الساعة|at)\s*(\d{1,2})(?!\d)(?:\s*(ونص|وربع))?/) || q.match(/(?<!\d)(\d{1,2})(?=\s*(?:الصبح|صباح|الفجر|مسا|مساء|بالليل|الليل|العصر|الظهر|\bam\b|\bpm\b))/);
  if (!match) return { kind: "none" };
  let hour = Number(match[1]);
  const minute = match[2] && /^\d+$/.test(match[2]) ? Number(match[2]) : match[2] === "ونص" ? 30 : match[2] === "وربع" ? 15 : 0;
  if (hour > 23) return { kind: "ambiguous", reason: "الساعة لازم تكون بين 00 و23." };
  const period = q.slice(match.index! + match[0].length).match(/^\s*(?:الصبح|صباحا|صباح|الفجر|فجرا|مسا|مساء|مساءا|بالليل|الليل|بعد الضهر|العصر|الظهر|ضهرا|am\b|pm\b|ص\b|م\b)/i)?.[0]?.trim() ||
    q.match(/(?:الصبح|صباحا|صباح|الفجر|فجرا|مسا|مساء|بالليل|الليل|بعد الضهر|العصر|الظهر|ضهرا|\bam\b|\bpm\b)/i)?.[0] || "";
  if (/^(?:مسا|مساء|مساءا|pm|بعد الضهر|العصر)$/.test(period)) { if (hour < 12) hour += 12; }
  else if (/^(?:بالليل|الليل)$/.test(period)) { if (hour === 12) hour = 0; else if (hour >= 5 && hour < 12) hour += 12; }
  else if (/^(?:الصبح|صباحا|صباح|الفجر|فجرا|am|ص)$/.test(period)) { if (hour === 12) hour = 0; }
  else if (hour < 13 && !/^0\d:/.test(match[0]) && !/24\s*(?:hour|ساعه)/i.test(q)) return { kind: "ambiguous", reason: "الساعة دي صباح ولا مساء؟ اكتب مثلاً ٧ الصبح أو ٧ بالليل." };
  return { kind: "time", time: `${String(hour).padStart(2, "0")}:${String(minute).padStart(2, "0")}`, phrase: match[0] };
}

export function futureAt(date: string, time: string, now = new Date()) {
  if (!isValidDay(date) || !isValidTime(time)) return false;
  const [h, m] = time.split(":").map(Number);
  const at = fromKey(date); at.setHours(h, m, 0, 0);
  return at > now;
}