// Capacitor JS-to-Native bridge (no-op in browser, invokes real Kotlin plugins in Android APK).
export interface DayflowNative {
  scheduleAlarm(opts: { id: string; time: string; date?: string; days: number[]; label: string; soundUri?: string; vibrate: boolean; snooze: number }): Promise<void>;
  cancelAlarm(opts: { id: string }): Promise<void>;
  getDeviceTones(): Promise<{ tones: Array<{ title: string; uri: string; type: string }> }>;
  pinWidget(opts: { designId: string; style: string; w: number; h: number }): Promise<{ pinned: boolean }>;
  openWidgetHub(): Promise<void>;
  startCompanionOverlay(opts: { enabled: boolean; size: number; opacity: number; modelId?: string }): Promise<{ hasPermission: boolean }>;
  requestOverlayPermission(): Promise<void>;
  enqueueDownload(opts: { url: string; name: string; preset?: string }): Promise<void>;
  syncState(opts: { json: string }): Promise<void>;
}

function plugin(): Partial<DayflowNative> | null {
  if (typeof window === "undefined") return null;
  const cap = (window as unknown as { Capacitor?: { isNativePlatform?: () => boolean; Plugins?: { DayflowBridge?: Partial<DayflowNative> } } }).Capacitor;
  if (!cap?.isNativePlatform?.()) return null;
  return cap.Plugins?.DayflowBridge || null;
}

export const isAndroidApk = () => !!plugin();

export const nativeBridge = {
  scheduleAlarm: (opts: Parameters<DayflowNative["scheduleAlarm"]>[0]) => plugin()?.scheduleAlarm?.(opts),
  cancelAlarm: (opts: Parameters<DayflowNative["cancelAlarm"]>[0]) => plugin()?.cancelAlarm?.(opts),
  getDeviceTones: () => plugin()?.getDeviceTones?.(),
  pinWidget: (opts: Parameters<DayflowNative["pinWidget"]>[0]) => plugin()?.pinWidget?.(opts),
  openWidgetHub: () => plugin()?.openWidgetHub?.(),
  startCompanionOverlay: (opts: Parameters<DayflowNative["startCompanionOverlay"]>[0]) => plugin()?.startCompanionOverlay?.(opts),
  requestOverlayPermission: () => plugin()?.requestOverlayPermission?.(),
  enqueueDownload: (opts: Parameters<DayflowNative["enqueueDownload"]>[0]) => plugin()?.enqueueDownload?.(opts),
  syncState: (json: string) => plugin()?.syncState?.({ json }),
};
