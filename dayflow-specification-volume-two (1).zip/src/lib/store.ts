import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";
import type { UserDay } from "./calendar";
import { dayKey } from "./calendar";
import type { ThemePack } from "./themes";
import type { WStyle } from "./widgets";
import type { ApiKeyEntry, Conversation } from "./ai";
import type { Mood } from "./soul";
import { futureAt, isValidDay, isValidTime, parseDateIntent, parseTimeIntent, type DateIntent } from "./temporal";
import { nativeBridge } from "./nativeBridge";

export type Lang = "en" | "ar";
export type Intensity = "off" | "subtle" | "rich" | "festival";
export type SoundSource = "library" | "device" | "files" | "downloaded";
export type HabitType = "build" | "quit" | "count" | "timer";
export interface Alarm { id: string; time: string; date?: string; days: number[]; label: string; enabled: boolean; sound: { source: SoundSource; title: string }; vibrate: boolean; snooze: number; gentle: boolean }
export interface Task { id: string; title: string; date: string; dueTime?: string; done: boolean; urgent: boolean; important: boolean; status: "todo" | "doing" | "done"; createdAt: number }
export interface Note { id: string; text: string; pinned: boolean; at: number }
export interface Habit { id: string; en: string; ar?: string; log: string[]; type?: HabitType; days?: number[]; startDate?: string; target?: number; unit?: string; details?: string; emoji?: string; color?: string; reminder?: string; createdAt?: number }
export interface Placed { id: string; designId: string; w: number; h: number; style: WStyle; tapOpens: boolean }
export interface Journal { id: string; date: string; mood: number; text: string }
export interface Countdown { id: string; title: string; date: string }
export interface Med { id: string; name: string; times: string[]; taken: Record<string, string[]> }

export type WidgetFont = "sans" | "naskh" | "kufi" | "cairo" | "rounded" | "mono";
export interface NotifPrefs { preview: boolean; style: "minimal" | "detailed" | "occasion"; sound: boolean; vibrate: boolean; quiet: boolean; dailyReview: string; weeklyReview: boolean }
export interface AlarmLook { layout: "midnight" | "minimal" | "ornate" | "glass"; showSeconds: boolean; gradient: boolean; weatherLine: boolean }
export interface RobotPrefs { enabled: boolean; hidden: boolean; notify: boolean; bubbles: boolean; emotion: Mood; sound: boolean; size: number; opacity: number; outfit: "auto" | "gold" | "snow" | "national" | "none"; modelId?: string }

const uid = () => Math.random().toString(36).slice(2, 10);
const today = () => dayKey(new Date());
const serverStorage: Storage = {
  length: 0, clear() {}, key() { return null; }, getItem() { return null; }, setItem() {}, removeItem() {},
};

interface S {
  lang: Lang; themeId: string; customThemes: ThemePack[]; favThemes: string[];
  surfaceTheme: { widgets?: string; alarm?: string; companion?: string };
  intensity: Intensity; decorSurfaces: Record<"app" | "notifications" | "widgets" | "icon" | "companion", boolean>;
  powerMode: boolean; reduceMotion: boolean; reviewTone: "gentle" | "balanced" | "direct"; spiritual: boolean; examSeason: boolean;
  sampleData: boolean; feedback: Record<string, number>;
  hour12: boolean; decorLayer: "behind" | "above"; aiShareContext: boolean;
  companion: RobotPrefs;
  alarms: Alarm[]; tasks: Task[]; notes: Note[]; habits: Habit[]; water: Record<string, number>; waterGoal: number;
  userDays: UserDay[]; placed: Placed[]; journal: Journal[]; countdowns: Countdown[]; meds: Med[];
  tasbih: number; khatma: number; clipboardWatch: boolean; mediaNoticeSeen: boolean;
  apiKeys: ApiKeyEntry[]; activeKeyId: string | null; activeModel: string; aiReasoning: boolean; convos: Conversation[];
  notif: NotifPrefs; alarmLook: AlarmLook; widgetFont: WidgetFont; cityIndex: number; autoTimeTheme: boolean; ambientPhoto: boolean; periodThemes: Partial<Record<string, string>>;
  set: (p: Partial<S>) => void;
  addAlarm: (a: Omit<Alarm, "id">) => string; updateAlarm: (id: string, p: Partial<Alarm>) => void; removeAlarm: (id: string) => void;
  addTask: (title: string, date?: string, urgent?: boolean, important?: boolean, dueTime?: string) => string; toggleTask: (id: string) => void; updateTask: (id: string, p: Partial<Task>) => void; removeTask: (id: string) => void;
  addNote: (text: string) => void; removeNote: (id: string) => void; togglePin: (id: string) => void;
  toggleHabit: (id: string, day?: string) => void; addHabit: (h: Omit<Habit, "id" | "log">) => string; updateHabit: (id: string, p: Partial<Habit>) => void; removeHabit: (id: string) => void;
  addWater: (ml: number) => void;
  placeWidget: (designId: string, w: number, h: number, style: WStyle) => void; updatePlaced: (id: string, p: Partial<Placed>) => void; removePlaced: (id: string) => void;
  addKey: (e: ApiKeyEntry) => void; removeKey: (id: string) => void; updateKey: (id: string, p: Partial<ApiKeyEntry>) => void;
  saveConvo: (c: Conversation) => void; deleteConvo: (id: string) => void;
}

export const useStore = create<S>()(
  persist(
    (set) => ({
      lang: typeof navigator !== "undefined" && navigator.language?.startsWith("ar") ? "ar" : "en",
      themeId: "paper-white", customThemes: [], favThemes: [], surfaceTheme: {},
      intensity: "subtle", decorSurfaces: { app: true, notifications: true, widgets: true, icon: false, companion: true },
      powerMode: false, reduceMotion: false, reviewTone: "balanced", spiritual: false, examSeason: false,
      sampleData: false, feedback: {}, hour12: false, decorLayer: "behind", aiShareContext: false,
      companion: { enabled: true, hidden: false, notify: false, bubbles: true, emotion: "idle", sound: false, size: 1, opacity: 1, outfit: "auto" },
      alarms: [], tasks: [], notes: [], habits: [], water: {}, waterGoal: 2500,
      userDays: [], placed: [], journal: [], countdowns: [], meds: [],
      tasbih: 0, khatma: 0, clipboardWatch: false, mediaNoticeSeen: false,
      apiKeys: [], activeKeyId: null, activeModel: "", aiReasoning: true, convos: [],
      notif: { preview: true, style: "detailed", sound: true, vibrate: true, quiet: false, dailyReview: "21:30", weeklyReview: false },
      alarmLook: { layout: "ornate", showSeconds: false, gradient: true, weatherLine: false },
      widgetFont: "sans", cityIndex: 0, autoTimeTheme: true, ambientPhoto: true, periodThemes: {},
      set: (p) => set(p),
      addAlarm: (a) => { const id = uid(); set((s) => ({ alarms: [...s.alarms, { ...a, id }] })); return id; },
      updateAlarm: (id, p) => set((s) => ({ alarms: s.alarms.map((a) => (a.id === id ? { ...a, ...p } : a)) })),
      removeAlarm: (id) => set((s) => ({ alarms: s.alarms.filter((a) => a.id !== id) })),
      addTask: (title, date = today(), urgent = false, important = true, dueTime) => { const id = uid(); set((s) => ({ tasks: [{ id, title, date, dueTime, done: false, urgent, important, status: "todo", createdAt: Date.now() }, ...s.tasks] })); return id; },
      toggleTask: (id) => set((s) => ({ tasks: s.tasks.map((t) => (t.id === id ? { ...t, done: !t.done, status: !t.done ? "done" : "todo" } : t)) })),
      updateTask: (id, p) => set((s) => ({ tasks: s.tasks.map((t) => (t.id === id ? { ...t, ...p, done: p.status ? p.status === "done" : p.done ?? t.done } : t)) })),
      removeTask: (id) => set((s) => ({ tasks: s.tasks.filter((t) => t.id !== id) })),
      addNote: (text) => set((s) => ({ notes: [{ id: uid(), text, pinned: false, at: Date.now() }, ...s.notes] })),
      removeNote: (id) => set((s) => ({ notes: s.notes.filter((n) => n.id !== id) })),
      togglePin: (id) => set((s) => ({ notes: s.notes.map((n) => (n.id === id ? { ...n, pinned: !n.pinned } : n)) })),
      toggleHabit: (id, day = today()) => set((s) => ({ habits: s.habits.map((h) => (h.id === id && (!h.startDate || day >= h.startDate) ? { ...h, log: h.log.includes(day) ? h.log.filter((d) => d !== day) : [...h.log, day] } : h)) })),
      addHabit: (h) => { const id = uid(); set((s) => ({ habits: [...s.habits, { ...h, id, log: [], createdAt: Date.now() }] })); return id; },
      updateHabit: (id, p) => set((s) => ({ habits: s.habits.map((h) => (h.id === id ? { ...h, ...p } : h)) })),
      removeHabit: (id) => set((s) => ({ habits: s.habits.filter((h) => h.id !== id) })),
      addWater: (ml) => set((s) => ({ water: { ...s.water, [today()]: Math.max(0, (s.water[today()] || 0) + ml) } })),
      placeWidget: (designId, w, h, style) => set((s) => ({ placed: [...s.placed, { id: uid(), designId, w, h, style, tapOpens: false }] })),
      updatePlaced: (id, p) => set((s) => ({ placed: s.placed.map((x) => (x.id === id ? { ...x, ...p } : x)) })),
      removePlaced: (id) => set((s) => ({ placed: s.placed.filter((x) => x.id !== id) })),
      addKey: (e) => set((s) => ({ apiKeys: [...s.apiKeys.filter((k) => k.id !== e.id), e], activeKeyId: s.activeKeyId || e.id, activeModel: s.activeKeyId ? s.activeModel : (e.liveModels?.[0]?.id || "") })),
      removeKey: (id) => set((s) => ({ apiKeys: s.apiKeys.filter((k) => k.id !== id), activeKeyId: s.activeKeyId === id ? (s.apiKeys.find((k) => k.id !== id)?.id ?? null) : s.activeKeyId })),
      updateKey: (id, p) => set((s) => ({ apiKeys: s.apiKeys.map((k) => (k.id === id ? { ...k, ...p } : k)) })),
      saveConvo: (c) => set((s) => ({ convos: [c, ...s.convos.filter((x) => x.id !== c.id)].slice(0, 60) })),
      deleteConvo: (id) => set((s) => ({ convos: s.convos.filter((c) => c.id !== id) })),
    }),
    { name: "dayflow-v2", version: 3, migrate: (state) => state as S, storage: createJSONStorage(() => typeof window === "undefined" ? serverStorage : window.localStorage) }
  )
);

export const newId = uid;

export function useT() {
  const lang = useStore((s) => s.lang);
  return (en: string, ar: string) => (lang === "ar" ? ar : en);
}
export const useLang = () => useStore((s) => s.lang);

export function fmtNum(n: number | string, lang: Lang) {
  return lang === "ar" ? String(n).replace(/\d/g, (d) => "٠١٢٣٤٥٦٧٨٩"[+d]) : String(n);
}

export function nextAlarmTime(alarms: Alarm[], from = new Date()): { alarm: Alarm; at: Date } | null {
  let best: { alarm: Alarm; at: Date } | null = null;
  for (const a of alarms) {
    if (!a.enabled || !isValidTime(a.time)) continue;
    const [h, m] = a.time.split(":").map(Number);
    if (a.date && !isValidDay(a.date)) continue;
    if (a.date && !a.days.length) {
      const oneOff = new Date(`${a.date}T00:00:00`);
      oneOff.setHours(h, m, 0, 0);
      if (oneOff > from && (!best || oneOff < best.at)) best = { alarm: a, at: oneOff };
      continue;
    }
    const anchor = a.date && a.days.length && a.date > dayKey(from) ? new Date(`${a.date}T00:00:00`) : from;
    for (let i = 0; i < 8; i++) {
      const d = new Date(anchor.getFullYear(), anchor.getMonth(), anchor.getDate() + i, h, m);
      if (d <= from) continue;
      if (a.date && dayKey(d) < a.date) continue;
      if (a.days.length && !a.days.includes(d.getDay())) continue;
      if (!best || d < best.at) best = { alarm: a, at: d };
      break;
    }
  }
  return best;
}

export interface ActionOutcome { done: string[]; issues: string[] }

/** Validate dates from both the user's words and model output before changing any stored records. */
export function applyActionsDetailed(actions: Array<{ intent: string; [k: string]: string }>, open: (tab: string, sub?: string) => void, request = "", now = new Date()): ActionOutcome {
  const s = useStore.getState();
  const done: string[] = [];
  const issues: string[] = [];
  const requestedDate = parseDateIntent(request, now);
  const requestedTime = parseTimeIntent(request, now);
  const hasSchedule = (intent: string) => ["addAlarm", "addTask", "addHabit"].includes(intent);
  for (const a of actions) {
    if (hasSchedule(a.intent) && requestedDate.kind === "ambiguous") { issues.push(requestedDate.reason); continue; }
    if (hasSchedule(a.intent) && requestedTime.kind === "ambiguous") { issues.push(requestedTime.reason); continue; }
    if (requestedDate.kind === "date" && requestedTime.kind === "time" && requestedTime.relative && requestedTime.date !== requestedDate.date) { issues.push("قصدك بعد المدة دي من دلوقتي، ولا في اليوم اللي حددته؟ وضّح المعاد."); continue; }
    const modelDate = a.date ? parseDateIntent(a.date, now) : { kind: "none" } as DateIntent;
    if (hasSchedule(a.intent) && a.date && modelDate.kind !== "date") { issues.push("التاريخ اللي رجع من المساعد مش واضح. قولّي اليوم والشهر والسنة."); continue; }
    const targetDate = requestedDate.kind === "date" ? requestedDate.date : requestedDate.kind === "repeat" ? requestedDate.startDate : requestedTime.kind === "time" && requestedTime.relative ? requestedTime.date : !request && modelDate.kind === "date" ? modelDate.date : undefined;
    const proposedTime = requestedTime.kind === "time" ? requestedTime.time : a.time;
    if (a.intent === "addTask") {
      if (requestedDate.kind === "repeat") { issues.push("المهام المتكررة مش متاحة هنا؛ حدّد تاريخ المهمة أو اعملها عادة."); continue; }
      if (!a.title?.trim() || a.title.length > 500) { issues.push("قولّي اسم المهمة عشان أسجلها."); continue; }
      const taskDate = targetDate || dayKey(now);
      const dueTime = requestedTime.kind === "time" ? requestedTime.time : !request ? a.time || undefined : undefined;
      if (!isValidDay(taskDate) || (dueTime && !isValidTime(dueTime))) { issues.push("حدّد تاريخ ووقت صحيحين للمهمة."); continue; }
      if (taskDate < dayKey(now) || (dueTime && !futureAt(taskDate, dueTime, now))) { issues.push("ميعاد المهمة ده فات؛ اختار يوم أو ساعة لسه جايين."); continue; }
      s.addTask(a.title.trim(), taskDate, false, true, dueTime);
      done.push(`task · ${taskDate}${dueTime ? ` ${dueTime}` : ""}`);
    } else if (a.intent === "addAlarm") {
      const repeat = requestedDate.kind === "repeat";
      const days = repeat ? requestedDate.days : targetDate ? [] : a.days ? a.days.split(",").map(Number) : [];
      if (!isValidTime(proposedTime) || (request && requestedTime.kind === "none")) { issues.push("عايز المنبّه الساعة كام؟ قولّي الوقت بصيغة واضحة، زي ٧ الصبح أو ١٩:٠٠."); continue; }
      if (days.length > 7 || days.some((n) => !Number.isInteger(n) || n < 0 || n > 6)) { issues.push("أيام المنبّه مش واضحة؛ حدّد الأيام تاني."); continue; }
      if (!targetDate && !repeat && (request || !days.length)) { issues.push("المنبّه ده أنهي يوم؟ قولّي النهاردة أو بكرة أو أيام التكرار."); continue; }
      if (targetDate && !repeat && !futureAt(targetDate, proposedTime, now)) { issues.push("وقت المنبّه ده فات. حدّد يوم وساعة في المستقبل."); continue; }
      const alarm: Omit<Alarm, "id"> = { time: proposedTime, date: targetDate, days, label: a.label || "منبّه من DAYFLOW", enabled: true, sound: { source: "device", title: "Default alarm (device)" }, vibrate: true, snooze: 10, gentle: true };
      const id = s.addAlarm(alarm);
      void nativeBridge.scheduleAlarm({ id, date: targetDate, time: proposedTime, days, label: alarm.label, vibrate: alarm.vibrate, snooze: alarm.snooze })?.catch(() => {});
      done.push(`alarm · ${targetDate || `weekly ${days.join(",")}`} ${proposedTime}`);
    } else if (a.intent === "addHabit") {
      const days = requestedDate.kind === "repeat" ? requestedDate.days : a.days?.split(",").map(Number).filter((n) => Number.isInteger(n) && n >= 0 && n <= 6) || [];
      if (!a.name?.trim() || !days.length) { issues.push("قولّي اسم العادة والأيام اللي هتعملها فيها."); continue; }
      if (targetDate && targetDate < dayKey(now)) { issues.push("تاريخ بداية العادة فات؛ حدّد يوم جاي."); continue; }
      s.addHabit({ en: a.name.trim(), type: "build", days: [...new Set(days)], startDate: targetDate });
      done.push(`habit${targetDate ? ` · ${targetDate}` : ""}`);
    } else if (a.intent === "addWater" && (!request || requestedDate.kind === "none")) {
      const ml = Number(a.ml || 250);
      if (!Number.isFinite(ml) || ml <= 0 || ml > 5000) { issues.push("كمية المياه مش صحيحة."); continue; }
      s.addWater(ml); done.push("water");
    } else if (a.intent === "open" && ["today", "calendar", "alarms", "tools", "me", "ai"].includes(a.tab)) { open(a.tab, a.sub); done.push("open"); }
    else if (a.intent === "addNote" && a.text?.trim() && requestedDate.kind === "none") { s.addNote(a.text.trim()); done.push("note"); }
    else if (requestedDate.kind !== "none" && ["addWater", "addNote"].includes(a.intent)) issues.push("الميزة دي بتتسجل دلوقتي بس. لو عايزها في يوم جاي، أعملهالك مهمة أو تذكير؟");
  }
  return { done, issues: [...new Set(issues)] };
}

export function applyActions(actions: Array<{ intent: string; [k: string]: string }>, open: (tab: string, sub?: string) => void, request = "", now = new Date()): string[] {
  return applyActionsDetailed(actions, open, request, now).done;
}
