package app.dayflow.android

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Intent
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import com.getcapacitor.JSArray
import com.getcapacitor.JSObject
import com.getcapacitor.Plugin
import com.getcapacitor.PluginCall
import com.getcapacitor.PluginMethod
import com.getcapacitor.annotation.CapacitorPlugin
import app.dayflow.android.alarm.AlarmScheduler
import app.dayflow.android.companion.CompanionOverlayService
import app.dayflow.android.media.DownloadForegroundService
import app.dayflow.android.widgets.PrayerWidgetProvider
import app.dayflow.android.widgets.ClockWidgetProvider
import app.dayflow.android.widgets.TasksWidgetProvider
import app.dayflow.android.widgets.WidgetHubActivity

@CapacitorPlugin(name = "DayflowBridge")
class DayflowBridgePlugin : Plugin() {

    @PluginMethod
    fun scheduleAlarm(call: PluginCall) {
        val id = call.getString("id") ?: return call.reject("missing id")
        val time = call.getString("time") ?: return call.reject("missing time")
        val date = call.getString("date")
        val label = call.getString("label") ?: ""
        val soundUri = call.getString("soundUri")
        val vibrate = call.getBoolean("vibrate") ?: true
        val snooze = call.getInt("snooze") ?: 10
        val daysArr = call.getArray("days") ?: JSArray()
        val days = (0 until daysArr.length()).map { daysArr.getInt(it) }
        if (!AlarmScheduler.schedule(context, id, time, days, label, soundUri, vibrate, snooze, date)) {
            return call.reject("Invalid or past alarm date/time")
        }
        call.resolve()
    }

    @PluginMethod
    fun cancelAlarm(call: PluginCall) {
        val id = call.getString("id") ?: return call.reject("missing id")
        AlarmScheduler.cancel(context, id)
        call.resolve()
    }

    @PluginMethod
    fun getDeviceTones(call: PluginCall) {
        val arr = JSArray()
        listOf(
            RingtoneManager.TYPE_ALARM to "alarm",
            RingtoneManager.TYPE_NOTIFICATION to "notification",
            RingtoneManager.TYPE_RINGTONE to "ringtone"
        ).forEach { (type, kind) ->
            val rm = RingtoneManager(context).apply { setType(type) }
            val cursor = rm.cursor
            while (cursor.moveToNext()) {
                val idx = cursor.position
                val title = cursor.getString(RingtoneManager.TITLE_COLUMN_INDEX)
                val uri = rm.getRingtoneUri(idx)?.toString() ?: ""
                arr.put(JSObject().put("title", title).put("uri", uri).put("type", kind))
            }
        }
        call.resolve(JSObject().put("tones", arr))
    }

    @PluginMethod
    fun pinWidget(call: PluginCall) {
        val designId = call.getString("designId") ?: "clock-minimal-digital"
        val mgr = AppWidgetManager.getInstance(context)
        val provider = when {
            designId.contains("prayer") -> ComponentName(context, PrayerWidgetProvider::class.java)
            designId.contains("task") -> ComponentName(context, TasksWidgetProvider::class.java)
            else -> ComponentName(context, ClockWidgetProvider::class.java)
        }
        val ok = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && mgr.isRequestPinAppWidgetSupported) {
            mgr.requestPinAppWidget(provider, null, null)
        } else false
        call.resolve(JSObject().put("pinned", ok))
    }

    @PluginMethod
    fun openWidgetHub(call: PluginCall) {
        val i = Intent(context, WidgetHubActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(i)
        call.resolve()
    }

    @PluginMethod
    fun startCompanionOverlay(call: PluginCall) {
        val enabled = call.getBoolean("enabled") ?: true
        val canDraw = Settings.canDrawOverlays(context)
        if (!enabled) {
            context.stopService(Intent(context, CompanionOverlayService::class.java))
            call.resolve(JSObject().put("hasPermission", canDraw))
            return
        }
        if (canDraw) {
            val i = Intent(context, CompanionOverlayService::class.java)
                .putExtra("size", (call.getDouble("size") ?: 1.0).toFloat())
                .putExtra("opacity", (call.getDouble("opacity") ?: 1.0).toFloat())
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(i) else context.startService(i)
        }
        call.resolve(JSObject().put("hasPermission", canDraw))
    }

    @PluginMethod
    fun requestOverlayPermission(call: PluginCall) {
        val i = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(i)
        call.resolve()
    }

    @PluginMethod
    fun enqueueDownload(call: PluginCall) {
        if (!BuildConfig.MEDIA_HUB_ENABLED) return call.reject("Media Hub disabled in Play flavor")
        val url = call.getString("url") ?: return call.reject("missing url")
        val name = call.getString("name") ?: "download"
        val i = Intent(context, DownloadForegroundService::class.java).putExtra("url", url).putExtra("name", name)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(i) else context.startService(i)
        call.resolve()
    }

    @PluginMethod
    fun syncState(call: PluginCall) {
        val json = call.getString("json") ?: "{}"
        context.getSharedPreferences("dayflow_native_state", 0).edit().putString("snapshot", json).apply()
        call.resolve()
    }
}
