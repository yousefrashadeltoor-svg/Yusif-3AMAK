package app.dayflow.android.widgets

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.os.Bundle
import android.widget.RemoteViews
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import app.dayflow.android.MainActivity
import app.dayflow.android.R
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.min

object WidgetFormResolver {
    fun resolve(minWidthDp: Int, minHeightDp: Int): String = when {
        minWidthDp >= 240 && minHeightDp >= 240 -> "4x4"
        minWidthDp >= 240 && minHeightDp >= 120 -> "4x2"
        minWidthDp >= 240 -> "4x1"
        minWidthDp >= 120 && minHeightDp >= 120 -> "2x2"
        minWidthDp >= 120 -> "2x1"
        else -> "1x1"
    }
}

object WidgetRenderer {
    // Memory-budgeted bitmap renderer for RemoteViews (respects Android binder transaction cap)
    fun render(ctx: Context, appWidgetId: Int, design: String, minW: Int, minH: Int): RemoteViews {
        val form = WidgetFormResolver.resolve(minW, minH)
        val bmpW = min(720, (minW * 2).coerceAtLeast(180))
        val bmpH = min(720, (minH * 2).coerceAtLeast(140))
        val bmp = Bitmap.createBitmap(bmpW, bmpH, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#EEF4F2") }
        c.drawRoundRect(RectF(0f, 0f, bmpW.toFloat(), bmpH.toFloat()), 36f, 36f, bgPaint)

        val pMain = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#1D1C1A")
            textSize = (bmpH * 0.24f).coerceIn(24f, 84f)
            typeface = Typeface.DEFAULT_BOLD
        }
        val pAccent = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#2F6F5E")
            textSize = (bmpH * 0.13f).coerceIn(18f, 34f)
        }
        val time = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
        when {
            design.contains("prayer") -> {
                c.drawText("🕌 مواقيت الصلاة · $form", 28f, bmpH * 0.28f, pAccent)
                c.drawText("الفجر 04:47  ·  المغرب 17:01", 28f, bmpH * 0.68f, pMain.apply { textSize = (bmpH * 0.14f).coerceIn(20f, 36f) })
            }
            design.contains("task") -> {
                c.drawText("مهام النهاردة ($form)", 28f, bmpH * 0.28f, pAccent)
                c.drawText("افتح التطبيق لإضافة مهام", 28f, bmpH * 0.68f, pMain.apply { textSize = (bmpH * 0.14f).coerceIn(20f, 36f) })
            }
            else -> {
                c.drawText(time, 28f, bmpH * 0.56f, pMain)
                c.drawText("DAYFLOW · $form", 28f, bmpH * 0.82f, pAccent)
            }
        }

        val rv = RemoteViews(ctx.packageName, R.layout.widget_bitmap_host)
        rv.setImageViewBitmap(R.id.widget_bitmap, bmp)
        rv.setTextViewText(R.id.widget_title, "DAYFLOW · $design")
        val open = PendingIntent.getActivity(ctx, appWidgetId, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        rv.setOnClickPendingIntent(R.id.widget_root, open)
        return rv
    }
}

open class BaseDayflowWidgetProvider(private val defaultDesign: String) : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        val prefs = context.getSharedPreferences("dayflow_widgets", 0)
        for (id in appWidgetIds) {
            val design = prefs.getString("design_$id", defaultDesign) ?: defaultDesign
            val opts = appWidgetManager.getAppWidgetOptions(id)
            val w = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 140)
            val h = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 110)
            appWidgetManager.updateAppWidget(id, WidgetRenderer.render(context, id, design, w, h))
        }
    }

    override fun onAppWidgetOptionsChanged(context: Context, appWidgetManager: AppWidgetManager, appWidgetId: Int, newOptions: Bundle) {
        val design = context.getSharedPreferences("dayflow_widgets", 0).getString("design_$appWidgetId", defaultDesign) ?: defaultDesign
        val w = newOptions.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 140)
        val h = newOptions.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 110)
        appWidgetManager.updateAppWidget(appWidgetId, WidgetRenderer.render(context, appWidgetId, design, w, h))
    }
}

class GatewaySmallWidgetProvider : BaseDayflowWidgetProvider("clock-minimal-digital")
class GatewayMediumWidgetProvider : BaseDayflowWidgetProvider("utility-prayer-schedule")
class GatewayLargeWidgetProvider : BaseDayflowWidgetProvider("tasks-checklist")
class PrayerWidgetProvider : BaseDayflowWidgetProvider("utility-prayer-schedule")
class ClockWidgetProvider : BaseDayflowWidgetProvider("clock-minimal-digital")
class TasksWidgetProvider : BaseDayflowWidgetProvider("tasks-checklist")

class WidgetHubActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setResult(RESULT_CANCELED)
        val appWidgetId = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
        val designs = listOf(
            "clock-minimal-digital" to "ساعة رقمية بسيطة",
            "utility-prayer-schedule" to "مواقيت الصلاة",
            "utility-next-prayer" to "الصلاة القادمة",
            "tasks-checklist" to "قائمة المهام",
            "habits-water-drop" to "قطرة الماء",
            "calendar-tri-calendar-date-card" to "التقاويم الثلاثة"
        )
        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize()) {
                    Column(Modifier.padding(16.dp)) {
                        Text("DAYFLOW · Widget Hub", style = MaterialTheme.typography.headlineSmall)
                        Spacer(Modifier.height(12.dp))
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(designs) { (id, label) ->
                                Card(Modifier.fillMaxWidth().clickable {
                                    if (appWidgetId != AppWidgetManager.INVALID_APPWIDGET_ID) {
                                        getSharedPreferences("dayflow_widgets", 0).edit().putString("design_$appWidgetId", id).apply()
                                        val mgr = AppWidgetManager.getInstance(this@WidgetHubActivity)
                                        mgr.updateAppWidget(appWidgetId, WidgetRenderer.render(this@WidgetHubActivity, appWidgetId, id, 180, 140))
                                        setResult(RESULT_OK, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId))
                                    }
                                    finish()
                                }) {
                                    Column(Modifier.padding(16.dp)) {
                                        Text(label, style = MaterialTheme.typography.titleMedium)
                                        Text(id, style = MaterialTheme.typography.bodySmall)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
