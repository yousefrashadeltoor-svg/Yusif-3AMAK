package app.dayflow.android.notifications

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import app.dayflow.android.R

object DayflowNotifications {
    const val CH_ALARMS = "dayflow_alarms"
    const val CH_REMINDERS = "dayflow_reminders"
    const val CH_COMPANION = "dayflow_companion"
    const val CH_DOWNLOADS = "dayflow_downloads"

    fun ensureChannels(ctx: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannels(listOf(
            NotificationChannel(CH_ALARMS, ctx.getString(R.string.channel_alarms), NotificationManager.IMPORTANCE_HIGH),
            NotificationChannel(CH_REMINDERS, ctx.getString(R.string.channel_reminders), NotificationManager.IMPORTANCE_DEFAULT),
            NotificationChannel(CH_COMPANION, ctx.getString(R.string.channel_companion), NotificationManager.IMPORTANCE_MIN),
            NotificationChannel(CH_DOWNLOADS, ctx.getString(R.string.channel_downloads), NotificationManager.IMPORTANCE_LOW)
        ))
    }
}
