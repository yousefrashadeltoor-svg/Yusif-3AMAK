package app.dayflow.android.media

import android.app.Service
import android.content.Intent
import android.os.Bundle
import android.os.IBinder
import androidx.activity.ComponentActivity
import androidx.core.app.NotificationCompat
import app.dayflow.android.MainActivity
import app.dayflow.android.notifications.DayflowNotifications

class DownloadForegroundService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        DayflowNotifications.ensureChannels(this)
        val name = intent?.getStringExtra("name") ?: "Media"
        val notif = NotificationCompat.Builder(this, DayflowNotifications.CH_DOWNLOADS)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("DAYFLOW · تنزيل")
            .setContentText(name)
            .setProgress(100, 0, true)
            .build()
        startForeground(88, notif)
        return START_NOT_STICKY
    }
}

class ShareReceiverActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val shared = intent?.getStringExtra(Intent.EXTRA_TEXT)
        val main = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            if (!shared.isNullOrBlank()) putExtra("shared_url", shared)
        }
        startActivity(main)
        finish()
    }
}
