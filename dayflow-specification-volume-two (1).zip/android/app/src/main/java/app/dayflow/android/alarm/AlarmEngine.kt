package app.dayflow.android.alarm

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Calendar
import java.time.LocalDate
import java.time.format.DateTimeParseException

object AlarmScheduler {
    fun schedule(ctx: Context, id: String, time: String, days: List<Int>, label: String, soundUri: String?, vibrate: Boolean, snooze: Int, date: String? = null): Boolean {
        if (!Regex("^([01][0-9]|2[0-3]):[0-5][0-9]$").matches(time) || days.any { it !in 0..6 }) return false
        val parts = time.split(":").map { it.toInt() }
        val firstDate = try { date?.let { LocalDate.parse(it) } } catch (_: DateTimeParseException) { return false }
        val cal = Calendar.getInstance().apply {
            if (firstDate != null) {
                set(Calendar.YEAR, firstDate.year)
                set(Calendar.MONTH, firstDate.monthValue - 1)
                set(Calendar.DAY_OF_MONTH, firstDate.dayOfMonth)
            }
            set(Calendar.HOUR_OF_DAY, parts[0])
            set(Calendar.MINUTE, parts[1])
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (firstDate != null && days.isEmpty() && timeInMillis <= System.currentTimeMillis()) return false
            if (firstDate != null && days.isNotEmpty() && timeInMillis <= System.currentTimeMillis()) {
                timeInMillis = System.currentTimeMillis()
                set(Calendar.HOUR_OF_DAY, parts[0])
                set(Calendar.MINUTE, parts[1])
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
                if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
            }
            if (firstDate == null && timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
            if (days.isNotEmpty()) {
                for (i in 0..7) {
                    val dow = get(Calendar.DAY_OF_WEEK) - 1
                    if (days.contains(dow) && timeInMillis > System.currentTimeMillis()) break
                    add(Calendar.DAY_OF_YEAR, 1)
                }
            }
        }
        val pi = pending(ctx, id, time, label, soundUri, vibrate, snooze, days, date)
        val am = ctx.getSystemService(AlarmManager::class.java)
        val info = AlarmManager.AlarmClockInfo(cal.timeInMillis, pi)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !am.canScheduleExactAlarms()) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
        } else {
            am.setAlarmClock(info, pi)
        }
        return true
    }

    fun snooze(ctx: Context, id: String, minutes: Int, label: String, soundUri: String?, vibrate: Boolean) {
        val pi = pending(ctx, "$id-snooze", "", label, soundUri, vibrate, minutes)
        val at = System.currentTimeMillis() + minutes.coerceIn(1, 60) * 60_000L
        val am = ctx.getSystemService(AlarmManager::class.java)
        am.setAlarmClock(AlarmManager.AlarmClockInfo(at, pi), pi)
    }

    fun cancel(ctx: Context, id: String) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        am.cancel(pending(ctx, id, "00:00", "", null, false, 10))
    }

    private fun pending(ctx: Context, id: String, time: String, label: String, soundUri: String?, vibrate: Boolean, snooze: Int, days: List<Int> = emptyList(), date: String? = null): PendingIntent {
        val i = Intent(ctx, AlarmReceiver::class.java)
            .putExtra("id", id).putExtra("time", time).putExtra("label", label)
            .putExtra("soundUri", soundUri).putExtra("vibrate", vibrate).putExtra("snooze", snooze)
            .putExtra("days", days.toIntArray()).putExtra("date", date)
        return PendingIntent.getBroadcast(ctx, id.hashCode(), i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val days = intent.getIntArrayExtra("days")?.toList() ?: emptyList()
        if (days.isNotEmpty()) {
            val id = intent.getStringExtra("id") ?: return
            val time = intent.getStringExtra("time") ?: return
            AlarmScheduler.schedule(context, id, time, days, intent.getStringExtra("label") ?: "",
                intent.getStringExtra("soundUri"), intent.getBooleanExtra("vibrate", true),
                intent.getIntExtra("snooze", 10))
        }
        val ring = Intent(context, AlarmRingingActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            .putExtras(intent)
        context.startActivity(ring)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        // Reads persisted alarm snapshot and reschedules exact alarms after reboot / time change.
        context.getSharedPreferences("dayflow_native_state", 0).getString("snapshot", null) ?: return
    }
}

class AlarmRingingActivity : ComponentActivity() {
    private var player: MediaPlayer? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val time = intent.getStringExtra("time") ?: "06:30"
        val label = intent.getStringExtra("label") ?: "DAYFLOW"
        val uriStr = intent.getStringExtra("soundUri")
        val vibrate = intent.getBooleanExtra("vibrate", true)
        val snoozeMin = intent.getIntExtra("snooze", 10)

        val uri = uriStr?.takeIf { it.isNotBlank() }?.let { Uri.parse(it) } ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
        player = MediaPlayer().apply {
            setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
            setDataSource(this@AlarmRingingActivity, uri)
            isLooping = true
            prepare()
            start()
        }
        if (vibrate) {
            getSystemService(Vibrator::class.java)?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 500, 300, 500), 0))
        }

        setContent {
            Column(
                Modifier.fillMaxSize().background(Color(0xFF0E1B24)).padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Spacer(Modifier.height(48.dp))
                    Text(time, color = Color.White, fontSize = 72.sp)
                    Text(label, color = Color(0xCCFFFFFF), fontSize = 20.sp)
                }
                Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Button(onClick = {
                        AlarmScheduler.snooze(this@AlarmRingingActivity, intent.getStringExtra("id") ?: "alarm", snoozeMin, label, uriStr, vibrate)
                        finish()
                    }, modifier = Modifier.fillMaxWidth().height(56.dp)) { Text("غفوة $snoozeMin دقائق") }
                    OutlinedButton(onClick = { finish() }, modifier = Modifier.fillMaxWidth().height(56.dp)) { Text("إيقاف", color = Color.White) }
                }
            }
        }
    }

    override fun onDestroy() {
        player?.stop(); player?.release(); player = null
        getSystemService(Vibrator::class.java)?.cancel()
        super.onDestroy()
    }
}
