package app.dayflow.android

import android.os.Bundle
import com.getcapacitor.BridgeActivity
import app.dayflow.android.notifications.DayflowNotifications

class MainActivity : BridgeActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        registerPlugin(DayflowBridgePlugin::class.java)
        super.onCreate(savedInstanceState)
        DayflowNotifications.ensureChannels(this)
    }
}
