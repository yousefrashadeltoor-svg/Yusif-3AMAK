package app.dayflow.android.companion

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.graphics.*
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.view.*
import android.widget.FrameLayout
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.app.NotificationCompat
import app.dayflow.android.MainActivity
import app.dayflow.android.R
import app.dayflow.android.notifications.DayflowNotifications
import kotlin.math.abs

class CompanionOverlayService : Service() {
    private var wm: WindowManager? = null
    private var container: FrameLayout? = null
    private var params: WindowManager.LayoutParams? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        DayflowNotifications.ensureChannels(this)
        startForeground(77, buildNotif())
        if (container == null) showOverlay()
        return START_STICKY
    }

    private fun buildNotif(): Notification {
        val open = PendingIntent.getActivity(this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(this, 2, Intent(this, CompanionOverlayService::class.java).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, DayflowNotifications.CH_COMPANION)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("رفيق DAYFLOW")
            .setContentText("شغال فوق التطبيقات — اضغط لفتح التطبيق")
            .setContentIntent(open)
            .addAction(0, "إخفاء", stop)
            .setOngoing(true)
            .build()
    }

    private fun showOverlay() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 40; y = 320 }

        container = FrameLayout(this).apply {
            val badge = TextView(context).apply {
                text = "🤖"
                textSize = 36f
                setPadding(18, 18, 18, 18)
            }
            addView(badge)
            var downX = 0f; var downY = 0f; var startX = 0; var startY = 0
            setOnTouchListener { _, ev ->
                val p = params ?: return@setOnTouchListener false
                when (ev.action) {
                    MotionEvent.ACTION_DOWN -> { downX = ev.rawX; downY = ev.rawY; startX = p.x; startY = p.y; true }
                    MotionEvent.ACTION_MOVE -> { p.x = startX + (ev.rawX - downX).toInt(); p.y = startY + (ev.rawY - downY).toInt(); wm?.updateViewLayout(this, p); true }
                    MotionEvent.ACTION_UP -> {
                        if (abs(ev.rawX - downX) < 18 && abs(ev.rawY - downY) < 18) {
                            startActivity(Intent(context, CompanionPanelActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                        }
                        true
                    }
                    else -> false
                }
            }
        }
        wm?.addView(container, params)
    }

    override fun onDestroy() {
        container?.let { wm?.removeView(it) }
        container = null
        super.onDestroy()
    }
}

class CompanionPanelActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxWidth().padding(16.dp), shape = MaterialTheme.shapes.large) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("رفيق DAYFLOW", style = MaterialTheme.typography.titleMedium)
                        Text("اللوحة السريعة الأصلية (مرتبطة بالتطبيق)")
                        Button(onClick = {
                            startActivity(Intent(this@CompanionPanelActivity, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                            finish()
                        }, modifier = Modifier.fillMaxWidth()) { Text("افتح DAYFLOW") }
                        OutlinedButton(onClick = { finish() }, modifier = Modifier.fillMaxWidth()) { Text("إغلاق") }
                    }
                }
            }
        }
    }
}
