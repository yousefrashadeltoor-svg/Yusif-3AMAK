# DAYFLOW Style Bible (v0.1, draft)

## Ornament families (procedural, `src/lib/pattern.ts`)
| Family | Geometry | Palette (c1 / c2 / c3) |
|---|---|---|
| Ramadan | crescent + fanous polygons, 8-fold tiles | #d4a237 / #1f4e5f / #f3dfa2 |
| Islamic | {8} star rosette, interlaced octagon | #1e7a5f / #c9a24a / #e8f1ea |
| Winter | 6-arm snowflake, two branch tiers | #7fb2d9 / #2f5a80 / #e8f3fb |
| Spring / Nile | lotus petals (quadratic), sine waves | see `FAMILY` |
| National | tri-colour ribbon curve (red/white/black) | #ce1126 / #c09300 / #f5f5f5 |
| Coptic | cross + rotated squares | #8b5a2b / #b8860b / #f6ecdc |

## Rules
- At most 3 ornament layers per screen. Particles: ≤ 60 (≤ 20 on devices with ≤ 4 cores), animated with transform and opacity only, and none under reduced motion.
- Intensity levels: Off / **Subtle (default)** / Rich / Festival.
- Text on artwork always sits on a gradient scrim. Directional ornaments are mirrored in RTL.
- Photography is **not yet used**. Every photo must pass Gate 1 (the extractability test) and the grading LUT per season family before it ships.

## Don'ts
No hand-drawn amateur art, no AI imagery without documented provenance, no hotlinked images.
