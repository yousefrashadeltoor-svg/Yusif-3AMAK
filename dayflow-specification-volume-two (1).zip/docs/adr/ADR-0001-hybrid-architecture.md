# ADR-0001 — Hybrid architecture

**Status:** Accepted (UI layer delivered; native layer not yet built)

## Decision
- **Kotlin-native, never a WebView:** alarms and the ringing screen, notifications, widgets and the Widget Hub, the QS tile, the companion overlay (Filament) and its panel, the Media Hub engine and its services, share receivers, the Dream, shortcuts, boot recovery, and the Review workers.
- **React/TypeScript (Vite) inside a Capacitor host:** Today, Calendar, Alarms list, Tools, Me, Theme Studio, galleries and Review visualisations. In the Android app these screens are rendered by the **system WebView**.
- **Shared pure-TS engines** (`src/lib/*`) are written to be mirrored in Kotlin. Golden-vector JSON fixtures are planned so both implementations can be checked against each other.

## Budgets (escape hatch)
Cold start ≤ 1.2 s, p95 frame ≤ 16 ms on scroll, input latency ≤ 50 ms on the reference mid-range device. If the WebView misses these, the offending screens move to Jetpack Compose, and the TS core is kept through a headless JS engine or a Kotlin mirror. No migration is done in advance.

## Minimum WebView
Chromium 111+ (for `color-mix()`, `:has()`, View Transitions). Older versions degrade gracefully: view transitions are skipped and colours fall back to static tokens.
