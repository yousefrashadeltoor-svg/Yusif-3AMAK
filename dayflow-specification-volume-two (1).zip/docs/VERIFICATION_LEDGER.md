# DAYFLOW — Verification Ledger (v2.1)

Scope: the React/TypeScript UI layer delivered as a static web build. The Kotlin/Android layer and CI remain unbuilt here.

| Feature | Status | Evidence |
|---|---|---|
| Six-tab shell, quick-create, AR/EN, RTL | Built | `npm run build`; SSR render of every route passed |
| 3 calendars + occasions + DecorResolver | Built | Script: Ramadan/Friday/Winter on 2026-02-20 |
| 69 theme packs + Studio | Built | All pass AA contrast (two accents corrected) |
| 137 widgets + forms + 10 styles + 6 fonts | Built | 793 design×size renders, 0 failures |
| Prayer times (Egyptian method) on device | Built | Cairo: 04:47 / 06:17 / 11:39 / 14:40 / 17:01 / 18:21; depression angles corrected |
| Habits with days/types/targets/reminders | Built | Form + 28-day grid + Review consistency |
| Review Tier 1 + Tier-2 guard | Built | 365-day smoke; property tests **not run** |
| 22 AI providers, 81 curated models, live catalogs | Built | Key detection script (OpenRouter ≠ OpenAI) |
| Streaming chat + reasoning block + actions | Built (not run with a real key here) | OpenAI-compatible / Anthropic / Gemini code paths |
| Robot reminders (Egyptian), 9 moods, hide/notification, quick AI | Built | Local intent engine returns real alarm/task actions |
| Float over other apps | Built for Chrome PiP; Android **Unverified** | Document Picture-in-Picture |
| Media real preview | Built | YouTube oEmbed returned real title/author/thumbnail; MDN CC0 file HEAD returned video/mp4, 1,128,375 B |
| Media native download engine | Unverified | Not built; no speed figures |
| 3D viewer | Built | RobotExpressive (CC0), CesiumMan (CC-BY 4.0), Fox (CC0) fetched 200 from official public URLs |
| Native alarms, device tones, widgets, Filament, overlay | Unverified | Needs Android build/device |
| Sound library ≥160 | Unverified | 0 bundled |
| CI workflows | Unverified | Not authored |
| On-device language model | Unverified | No runtime |

Security note: API keys are kept in this browser's `localStorage` and sent only to the chosen provider. There is no DAYFLOW server.
