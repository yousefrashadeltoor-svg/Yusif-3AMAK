# Building the DAYFLOW Android APK

## العربية
1. ارفع المستودع إلى GitHub.
2. افتح تبويب **Actions** وشغّل **DAYFLOW CI** أو **DAYFLOW Release APK**.
3. لتحويل التطبيق محليًا على جهازك:
   - ثبّت Node 22 وJDK 17 وAndroid SDK (API 35).
   - شغّل:
     ```bash
     npm ci
     npm run build
     npx cap sync android
     cd android && ./gradlew assembleFullDebug
     ```
4. لنسخة Google Play الآمنة بدون محرك التنزيل:
   ```bash
   cd android && ./gradlew assemblePlaySafeRelease -PnoMediaHub
   ```

## English
1. Push the repository to GitHub and run **DAYFLOW CI** from the Actions tab.
2. Locally with Node 22, JDK 17 and Android SDK 35:
   ```bash
   npm ci && npm run build && npx cap sync android
   cd android && ./gradlew assembleFullDebug
   ```
3. For the Play-safe flavor (omits Media Hub binaries): `cd android && ./gradlew assemblePlaySafeRelease -PnoMediaHub`.
