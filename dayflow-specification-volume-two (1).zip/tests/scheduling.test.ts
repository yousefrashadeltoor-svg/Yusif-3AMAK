import { beforeEach, describe, expect, it } from "vitest";
import { dayKey } from "../src/lib/calendar";
import { applyActionsDetailed, nextAlarmTime, useStore } from "../src/lib/store";
import { contextualRequest, isValidDay, parseDateIntent, parseTimeIntent } from "../src/lib/temporal";
import { miniBrain } from "../src/lib/soul";
import { parseActions } from "../src/lib/ai";

const now = new Date(2027, 4, 10, 14, 30); // Monday
const go = () => {};

beforeEach(() => {
  useStore.getState().set({ alarms: [], tasks: [], habits: [] });
});

describe("Egyptian local date and time parsing", () => {
  it.each([
    ["بكرة", "2027-05-11"],
    ["بعد بكرة", "2027-05-12"],
    ["بعد ٣ أيام", "2027-05-13"],
    ["بعد أسبوعين", "2027-05-24"],
    ["الجمعة الجاية", "2027-05-14"],
    ["الجمعة الأسبوع الجاي", "2027-05-21"],
    ["15/06/2027", "2027-06-15"],
    ["2027-06-15", "2027-06-15"],
    ["١٥ نوفمبر ٢٠٢٧", "2027-11-15"],
    ["tomorrow", "2027-05-11"],
  ])("resolves %s to %s", (input, expected) => {
    expect(parseDateIntent(input, now)).toMatchObject({ kind: "date", date: expected });
  });

  it("keeps a recurring Monday separate from a one-off date", () => {
    expect(parseDateIntent("كل يوم اتنين", now)).toEqual({ kind: "repeat", days: [1], phrase: "أيام متكررة" });
    expect(parseDateIntent("كل يوم اتنين وخميس", now)).toMatchObject({ kind: "repeat", days: [1, 4] });
    expect(parseDateIntent("الجمعة الجاية", now).kind).toBe("date");
    expect(parseDateIntent("كل يوم اتنين من 15/06/2027", now)).toMatchObject({ kind: "repeat", days: [1], startDate: "2027-06-15" });
  });

  it("rejects invalid or ambiguous calendar dates instead of rolling them over", () => {
    expect(isValidDay("2027-02-30")).toBe(false);
    expect(parseDateIntent("30/02/2027", now).kind).toBe("ambiguous");
    expect(parseDateIntent("15/06", now).kind).toBe("ambiguous");
    expect(parseDateIntent("الأسبوع الجاي", now).kind).toBe("ambiguous");
    expect(parseDateIntent("الأسبوع المقبل", now).kind).toBe("ambiguous");
  });

  it.each([
    ["الساعة ٧ بالليل", "19:00"],
    ["الساعة ٧ الصبح", "07:00"],
    ["الساعة ١٢ بالليل", "00:00"],
    ["بكرة ٦:٣٠ مساء", "18:30"],
    ["tomorrow at 9 pm", "21:00"],
    ["07:30", "07:30"],
  ])("resolves %s to %s", (input, expected) => {
    expect(parseTimeIntent(input)).toMatchObject({ kind: "time", time: expected });
  });
  it("asks for AM/PM rather than guessing", () => expect(parseTimeIntent("الساعة ٧").kind).toBe("ambiguous"));
  it("handles relative hours and minutes, including crossing midnight", () => {
    expect(parseDateIntent("بعد ساعتين", now).kind).toBe("none");
    expect(parseTimeIntent("بعد ساعتين", now)).toMatchObject({ kind: "time", date: "2027-05-10", time: "16:30" });
    expect(parseTimeIntent("بعد ٢٠ دقيقة", now)).toMatchObject({ kind: "time", date: "2027-05-10", time: "14:50" });
    expect(parseTimeIntent("بعد ساعتين", new Date(2027, 4, 10, 23, 30))).toMatchObject({ kind: "time", date: "2027-05-11", time: "01:30" });
  });
});

describe("AI action execution", () => {
  it("saves tomorrow's task on tomorrow, with the specified hour", () => {
    const out = applyActionsDetailed([{ intent: "addTask", title: "تسليم التقرير", date: "2027-05-10", time: "07:00" }], go,
      "ضيف مهمة تسليم التقرير بكرة الساعة ٧ بالليل", now);
    expect(out.issues).toEqual([]);
    expect(useStore.getState().tasks[0]).toMatchObject({ title: "تسليم التقرير", date: "2027-05-11", dueTime: "19:00" });
  });

  it("never silently invents a future day if the user didn't ask for one", () => {
    applyActionsDetailed([{ intent: "addTask", title: "قراءة", date: "2027-05-12" }], go, "ضيف مهمة قراءة", now);
    expect(useStore.getState().tasks[0].date).toBe(dayKey(now));
  });

  it("saves one-off next-Friday alarm with no repeating days", () => {
    const out = applyActionsDetailed([{ intent: "addAlarm", time: "07:00", days: "0,1,2,3,4", label: "الدكتور" }], go,
      "اعمل منبه الجمعة الجاية الساعة ٧ مساء", now);
    expect(out.issues).toEqual([]);
    expect(useStore.getState().alarms[0]).toMatchObject({ date: "2027-05-14", time: "19:00", days: [] });
    expect(dayKey(nextAlarmTime(useStore.getState().alarms, now)!.at)).toBe("2027-05-14");
    expect(nextAlarmTime(useStore.getState().alarms, new Date(2027, 4, 15))).toBeNull();
  });

  it("repeats only the weekdays the user explicitly chose", () => {
    applyActionsDetailed([{ intent: "addAlarm", time: "07:00", days: "0,1,2,3,4" }], go,
      "اعمل منبه كل يوم اتنين الساعة ٧ الصبح", now);
    expect(useStore.getState().alarms[0]).toMatchObject({ days: [1], time: "07:00" });
    expect(dayKey(nextAlarmTime(useStore.getState().alarms, now)!.at)).toBe("2027-05-17");
  });

  it("respects a future start date even when a recurring alarm begins more than a week away", () => {
    applyActionsDetailed([{ intent: "addAlarm", time: "07:00", days: "0,1,2,3,4" }], go,
      "اعمل منبه كل يوم اتنين من 15/06/2027 الساعة ٧ الصبح", now);
    expect(useStore.getState().alarms[0]).toMatchObject({ date: "2027-06-15", days: [1] });
    expect(dayKey(nextAlarmTime(useStore.getState().alarms, now)!.at)).toBe("2027-06-21");
  });

  it("does not save a past date, an unspecified day or an ambiguous hour", () => {
    const cases = [
      ["اعمل منبه 08:00", { intent: "addAlarm", time: "08:00", days: "0,1,2,3,4" }],
      ["اعمل منبه النهاردة الساعة ٧ الصبح", { intent: "addAlarm", time: "07:00", days: "" }],
      ["اعمل منبه بكرة الساعة ٧", { intent: "addAlarm", time: "07:00", days: "" }],
      ["ضيف مهمة التقرير الأسبوع الجاي", { intent: "addTask", title: "التقرير" }],
      ["ضيف مهمة الاجتماع 2027-05-09 الساعة 16:00", { intent: "addTask", title: "الاجتماع", date: "2027-05-09", time: "16:00" }],
    ] as const;
    for (const [source, action] of cases) expect(applyActionsDetailed([action], go, source, now).issues.length).toBeGreaterThan(0);
    expect(useStore.getState().alarms).toHaveLength(0);
    expect(useStore.getState().tasks).toHaveLength(0);
  });

  it("keeps a later habit inactive until its requested start date", () => {
    applyActionsDetailed([{ intent: "addHabit", name: "مشي", days: "0,1,2,3,4,5,6" }], go,
      "ضيف عادة مشي تبدأ بعد ٣ أيام", now);
    const h = useStore.getState().habits[0];
    expect(h.startDate).toBe("2027-05-13");
    useStore.getState().toggleHabit(h.id, "2027-05-10");
    expect(useStore.getState().habits[0].log).toEqual([]);
    useStore.getState().toggleHabit(h.id, "2027-05-13");
    expect(useStore.getState().habits[0].log).toEqual(["2027-05-13"]);
  });

  it("schedules a relative-time alarm after midnight for the next day", () => {
    const late = new Date(2027, 4, 10, 23, 30);
    const out = applyActionsDetailed([{ intent: "addAlarm", time: "07:00", days: "0,1,2,3,4" }], go,
      "صحيني بعد ساعتين", late);
    expect(out.issues).toEqual([]);
    expect(useStore.getState().alarms[0]).toMatchObject({ date: "2027-05-11", time: "01:30", days: [] });
    expect(nextAlarmTime(useStore.getState().alarms, late)?.at.getHours()).toBe(1);
  });

  it("handles a fenced provider action with the date from the actual request", () => {
    const parsed = parseActions("Okay\n```dayflow\n{\"actions\":[{\"intent\":\"addTask\",\"title\":\"اجتماع\"}]}\n```");
    expect(parsed.actions).toHaveLength(1);
    applyActionsDetailed(parsed.actions, go, "ضيف مهمة اجتماع بعد بكرة الساعة ١٩:٣٠", now);
    expect(useStore.getState().tasks[0]).toMatchObject({ date: "2027-05-12", dueTime: "19:30" });
  });
});

describe("offline Egyptian assistant", () => {
  const ctx = { alarms: [], tasks: [], habitsCount: 0, water: 0 };
  it("creates an explicit future task, not a task for today", () => {
    const reply = miniBrain("ضيف مهمة تسليم التقرير بعد ٣ أيام الساعة ٧ بالليل", ctx, "ar", now);
    expect(reply.actions?.[0]).toMatchObject({ intent: "addTask", date: "2027-05-13", time: "19:00" });
  });
  it("asks for missing time rather than defaulting a future alarm", () => {
    expect(miniBrain("اعمل منبه بكرة", ctx, "ar", now).actions).toBeUndefined();
    expect(miniBrain("اعمل منبه بكرة", ctx, "ar", now).needs).toContain("time");
  });
  it("keeps the future day from the first turn when given an hour in a follow-up", () => {
    const combined = miniBrain("اعمل منبه بكرة الساعة ٧ بالليل", ctx, "ar", now);
    expect(combined.actions?.[0]).toMatchObject({ date: "2027-05-11", time: "19:00", days: "" });
  });
  it("also keeps an earlier hour when the next turn supplies the future day", () => {
    const request = contextualRequest("اعمل منبه الساعة ٦ الصبح", "بعد بكرة");
    const reply = miniBrain(request, ctx, "ar", now);
    expect(reply.actions?.[0]).toMatchObject({ date: "2027-05-12", time: "06:00", days: "" });
  });
  it("schedules a future task after a relative number of hours", () => {
    const reply = miniBrain("ضيف مهمة مراجعة المشروع بعد ساعتين", ctx, "ar", now);
    expect(reply.actions?.[0]).toMatchObject({ date: "2027-05-10", time: "16:30" });
  });
});