import { expect, test } from "@playwright/test";

test("offline AI preserves a requested future task and one-off alarm through the UI", async ({ page }) => {
  await page.clock.install({ time: new Date(2027, 4, 10, 14, 30) });
  await page.addInitScript(() => {
    localStorage.setItem("dayflow-v2", JSON.stringify({ version: 3, state: {
      lang: "ar", autoTimeTheme: false, companion: {
        enabled: false, hidden: true, notify: false, bubbles: false, emotion: "idle",
        sound: false, size: 1, opacity: 1, outfit: "auto",
      },
    } }));
  });
  await page.goto("http://127.0.0.1:5173/#/ai");
  await page.getByRole("textbox", { name: "رسالة" }).fill("ضيف مهمة تسليم التقرير بكرة الساعة ٧ بالليل");
  await page.getByRole("button", { name: "إرسال" }).click();
  await expect(page.getByText(/2027-05-11/).first()).toBeVisible();
  const task = await page.evaluate(() => JSON.parse(localStorage.getItem("dayflow-v2")!).state.tasks[0]);
  expect(task).toMatchObject({ date: "2027-05-11", dueTime: "19:00" });

  await page.getByRole("textbox", { name: "رسالة" }).fill("اعمل منبه الجمعة الجاية الساعة ٧ مساء");
  await page.getByRole("button", { name: "إرسال" }).click();
  await expect(page.getByText(/2027-05-14/).first()).toBeVisible();
  const alarm = await page.evaluate(() => JSON.parse(localStorage.getItem("dayflow-v2")!).state.alarms[0]);
  expect(alarm).toMatchObject({ date: "2027-05-14", time: "19:00", days: [] });
  await page.getByRole("textbox", { name: "رسالة" }).fill("اعمل منبه الساعة ٦ الصبح");
  await page.getByRole("button", { name: "إرسال" }).click();
  await expect(page.getByText(/أنهي يوم/)).toBeVisible();
  await page.getByRole("textbox", { name: "رسالة" }).fill("بعد بكرة");
  await page.getByRole("button", { name: "إرسال" }).click();
  const afterTomorrow = await page.evaluate(() => JSON.parse(localStorage.getItem("dayflow-v2")!).state.alarms[0]);
  expect(afterTomorrow).toMatchObject({ date: "2027-05-12", time: "06:00", days: [] });
  await page.goto("http://127.0.0.1:5173/#/alarms");
  await expect(page.getByText(/١٤ مايو ٢٠٢٧/).first()).toBeVisible();
});