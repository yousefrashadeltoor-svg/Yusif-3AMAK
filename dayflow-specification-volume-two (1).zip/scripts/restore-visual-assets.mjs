// Restores existing licensed visual sources; no runtime downloads for app artwork.
import fs from 'node:fs/promises';
import crypto from 'node:crypto';
import sharp from 'sharp';
const photos = {
 'dawn.jpg': ['9/99/Sunset_Over_the_Nile_from_Kyobe_Safari_Lodge.jpg','CC0'],
 'noon.jpg': ['c/c0/Field%2C_corn%2C_Liechtenstein%2C_Mountains%2C_Alps%2C_Vaduz%2C_sky%2C_clouds%2C_landscape.jpg','Public domain'],
 'asr.jpg': ['9/9a/Desert_landscape_at_dusk_with_sagebrush_and_distant_mountain_01.jpg','CC0'],
 'maghrib.jpg': ['5/59/Alexandre-Gabriel_Decamps_-_Sunset%2C_Tombs_Near_Cairo_-_Walters_378.jpg','Public domain'],
 'night.jpg': ['d/d0/Stars_and_Milky_Way_over_%C3%85byfjorden_1.jpg','CC0'],
 'snow.jpg': ['2/21/Snowflake_macro_%28Unsplash%29.jpg','CC0'],
 'autumn-tree.jpg': ['8/8f/Autumn_tree%2C_Valea_Morilor_park.jpg','CC0'],
};
const art = {'fanous.jpg':'5/5d/Fanous.jpg','cairo-night.jpg':'4/44/Cairo_by_night.jpg'};
const emoji = {maple:'1f341',fallen:'1f342',wind:'1f343',snow:'2744',star:'2b50',sparkle:'2728',crescent:'1f31b',blossom:'1f338',tulip:'1f337',wave:'1f30a',balloon:'1f388',confetti:'1f38a',heart:'2764_fe0f',lotus:'1fab7',dove:'1f54a_fe0f',herb:'1f33f',snowman:'26c4',gift:'1f381',books:'1f4da'};
const records=[];
async function fetchAsset(path,url,license,source,transform) {
 try { await fs.access(path); console.log('Present',path); return; } catch {}
 await fs.mkdir(path.substring(0,path.lastIndexOf('/')),{recursive:true});
 for(let attempt=0;attempt<4;attempt++){
  try {
   const r=await fetch(url,{signal:AbortSignal.timeout(25000),headers:{'User-Agent':'DAYFLOW asset restoration'}});
   if(!r.ok) throw new Error(`HTTP ${r.status}`);
   const sourceBytes=Buffer.from(await r.arrayBuffer());
   const bytes=transform?await transform(sourceBytes):sourceBytes;
   await fs.writeFile(path,bytes);
   records.push({path,url,source,license,retrieved:new Date().toISOString(),sourceSha256:crypto.createHash('sha256').update(sourceBytes).digest('hex'),sha256:crypto.createHash('sha256').update(bytes).digest('hex'),bytes:bytes.length});
   console.log('Fetched',path,bytes.length);return;
  }catch(e){if(attempt===3)throw e;await new Promise(r=>setTimeout(r,6000));}
 }
}
for(const [name,[source,license]] of Object.entries(photos)){
 const file=source.split('/').pop();
 const url=name==='autumn-tree.jpg' ? `https://upload.wikimedia.org/wikipedia/commons/${source}` : `https://upload.wikimedia.org/wikipedia/commons/thumb/${source}/1280px-${file}`;
 await fetchAsset(`src/assets/photos/${name}`,url,license,`https://commons.wikimedia.org/wiki/File:${file}`,b=>sharp(b).resize(1000,null,{withoutEnlargement:true}).jpeg({quality:70}).toBuffer());
}
for(const [name,source] of Object.entries(art)) await fetchAsset(`src/assets/art/${name}`,`https://upload.wikimedia.org/wikipedia/commons/${source}`,'Public domain',`https://commons.wikimedia.org/wiki/File:${source.split('/').pop()}`);
await Promise.all(Object.entries(emoji).map(async([name,code])=>{
 const url=`https://fonts.gstatic.com/s/e/notoemoji/latest/${code}/512.webp`;
 await fetchAsset(`src/assets/decor/${name}.png`,url,'CC-BY-4.0','https://googlefonts.github.io/noto-emoji-animation/',async b=>{
  // A mid-animation frame avoids a blank opening frame (maple leaf in particular).
  const meta=await sharp(b,{animated:true}).metadata();const pages=meta.pages||1;
  return sharp(b,{page:Math.floor(pages/2),pages:1}).resize(160,160,{fit:'contain'}).png({palette:true}).toBuffer();
 });
}));
await fs.mkdir('docs/art',{recursive:true});
await fs.writeFile('docs/art/RESTORED_ASSETS.json',JSON.stringify(records,null,2));
