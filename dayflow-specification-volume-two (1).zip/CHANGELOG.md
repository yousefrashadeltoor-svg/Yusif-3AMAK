# Changelog

## 2.0.0-ui-preview
- **Removed:** the entire previously bundled sound library, with its manifest entries, seeds and credits (V2-4.1). There are 0 bundled tones until licensed acquisition is done.
- **Added (UI layer):** five-tab shell, three calendars, occasions, DecorResolver, procedural ornament engine, 69 theme packs with Gallery and Studio, 132-design widget catalog with size forms, Review Engine Tier 1, Tier-2 guard, articulated companion (web mirror), Media Hub logic (fixture only), and tools: tasks (list, matrix, kanban), habits, focus/study, workout, water, notes, countdowns, converters, tasbih and khatma, date calculator, journal, medication, bedside clock.
- **Not included:** the Kotlin native layer, GitHub Actions workflows and licensed assets. See `docs/VERIFICATION_LEDGER.md`.

## 2.1.0-ui-preview
- **AI tab:** 22 providers (OpenAI, Anthropic, Google, Groq, OpenRouter, Mistral, DeepSeek, xAI, Cohere, Together, Fireworks, Perplexity, Cerebras, DeepInfra, Novita, Hyperbolic, SambaNova, NVIDIA, Ollama, LM Studio, Azure, custom), 81 curated models plus live catalogs. Real prefix detection, official LobeHub logos with letter fallback, real key verification, grouped model picker with free/cheap/premium/open/reasoning/vision tags and live OpenRouter prices. Streaming chat with a faint reasoning block, saved chats, and structured app actions.
- **Companion:** Egyptian-dialect reminders pinned directly above the head, nine moods, hide + real notification restore, expanded quick panel with an AI tab, seasonal outfits, and a Chrome picture-in-picture window that floats over other apps.
- **Media Hub:** removed all simulated metadata, formats and progress. Real public previews via oEmbed, real direct-file downloads with byte progress, honest native-engine boundary.
- **Habits:** full manager (name, days, type, target, unit, reminder, details, colour) feeding Review consistency.
- **Prayer:** on-device astronomical calculation, Cairo/Alexandria/Luxor/Aswan/Suez/Sharm/Makkah/Madinah/Dubai/London, five prayer widgets, Today strip.
- **Widgets:** 137 designs, 793 form renders tested, widget font selector, Arabic ornament backgrounds.
- **Customisation:** notification style/privacy/quiet/test, alarm-screen layouts, widget fonts. Previous bundled sounds remain at zero.
