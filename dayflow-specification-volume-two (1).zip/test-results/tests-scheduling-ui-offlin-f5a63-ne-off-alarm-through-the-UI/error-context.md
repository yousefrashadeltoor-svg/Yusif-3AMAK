# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: tests/scheduling-ui.spec.ts >> offline AI preserves a requested future task and one-off alarm through the UI
- Location: tests/scheduling-ui.spec.ts:3:1

# Error details

```
Error: expect(received).toMatchObject(expected)

- Expected  - 2
+ Received  + 2

  Object {
-   "date": "2027-05-12",
+   "date": "2027-05-14",
    "days": Array [],
-   "time": "06:00",
+   "time": "19:00",
  }
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - main [ref=e4]:
    - generic [ref=e5]:
      - generic [ref=e6]:
        - button "المحادثات" [ref=e7] [cursor=pointer]
        - button "محرك DAYFLOW المحلي محرك مصري · أوفلاين" [ref=e12] [cursor=pointer]:
          - generic [ref=e13]:
            - generic [ref=e14]: محرك DAYFLOW المحلي
            - generic [ref=e16]: محرك مصري · أوفلاين
        - button "مفاتيح API" [ref=e19] [cursor=pointer]
      - generic [ref=e23]:
        - generic [ref=e24]: ضيف مهمة تسليم التقرير بكرة الساعة ٧ بالليل
        - generic [ref=e26]:
          - generic [ref=e27]: هسجّل «تس م التقرير» ليوم 2027-05-11 الساعة 19:00، مش للنهاردة.
          - paragraph [ref=e28]: dayflow-local
        - generic [ref=e29]: اعمل منبه الجمعة الجاية الساعة ٧ مساء
        - generic [ref=e31]:
          - generic [ref=e32]: تمام، منبّه 19:00 يوم 2027-05-14 هيتسجّل دلوقتي. تقدر تشوفه في المنبّهات.
          - paragraph [ref=e33]: dayflow-local
        - generic [ref=e34]: اعمل منبه الساعة ٦ الصبح
        - generic [ref=e36]:
          - generic [ref=e37]: تمام، المنبّه ده أنهي يوم؟ النهاردة ولا بكرة ولا كل يوم معين؟
          - paragraph [ref=e38]: dayflow-local
        - generic [ref=e39]: بعد بكرة
        - generic [ref=e41]:
          - generic [ref=e42]: تمام، منبّه 06:00 يوم 2027-05-12 هيتسجّل دلوقتي. تقدر تشوفه في المنبّهات.
          - paragraph [ref=e43]: dayflow-local
        - generic [ref=e44]: اتعمل منبه · 2027-05-12 06:00
      - generic [ref=e48]:
        - generic [ref=e49]:
          - button "إرفاق ملف (أقصى ٢ ميجا)" [ref=e50] [cursor=pointer]
          - textbox "رسالة" [ref=e53]:
            - /placeholder: اسأل أي حاجة…
          - button "إرسال" [active] [ref=e54] [cursor=pointer]
        - paragraph [ref=e58]: محرك مصري محلي · فوري · بدون نت
  - button "اعمل جديد" [ref=e59] [cursor=pointer]
  - navigation "الرئيسية" [ref=e61]:
    - generic [ref=e62]:
      - button "النهاردة" [ref=e63] [cursor=pointer]
      - button "التقويم" [ref=e71] [cursor=pointer]
      - button "المنبهات" [ref=e75] [cursor=pointer]
      - button "أدوات" [ref=e84] [cursor=pointer]
      - button "الذكاء" [ref=e91] [cursor=pointer]
      - button "أنا" [ref=e96] [cursor=pointer]
```

# Test source

```ts
  1  | import { expect, test } from "@playwright/test";
  2  | 
  3  | test("offline AI preserves a requested future task and one-off alarm through the UI", async ({ page }) => {
  4  |   await page.clock.install({ time: new Date(2027, 4, 10, 14, 30) });
  5  |   await page.addInitScript(() => {
  6  |     localStorage.setItem("dayflow-v2", JSON.stringify({ version: 3, state: {
  7  |       lang: "ar", autoTimeTheme: false, companion: {
  8  |         enabled: false, hidden: true, notify: false, bubbles: false, emotion: "idle",
  9  |         sound: false, size: 1, opacity: 1, outfit: "auto",
  10 |       },
  11 |     } }));
  12 |   });
  13 |   await page.goto("http://127.0.0.1:5173/#/ai");
  14 |   await page.getByRole("textbox", { name: "رسالة" }).fill("ضيف مهمة تسليم التقرير بكرة الساعة ٧ بالليل");
  15 |   await page.getByRole("button", { name: "إرسال" }).click();
  16 |   await expect(page.getByText(/2027-05-11/).first()).toBeVisible();
  17 |   const task = await page.evaluate(() => JSON.parse(localStorage.getItem("dayflow-v2")!).state.tasks[0]);
  18 |   expect(task).toMatchObject({ date: "2027-05-11", dueTime: "19:00" });
  19 | 
  20 |   await page.getByRole("textbox", { name: "رسالة" }).fill("اعمل منبه الجمعة الجاية الساعة ٧ مساء");
  21 |   await page.getByRole("button", { name: "إرسال" }).click();
  22 |   await expect(page.getByText(/2027-05-14/).first()).toBeVisible();
  23 |   const alarm = await page.evaluate(() => JSON.parse(localStorage.getItem("dayflow-v2")!).state.alarms[0]);
  24 |   expect(alarm).toMatchObject({ date: "2027-05-14", time: "19:00", days: [] });
  25 |   await page.getByRole("textbox", { name: "رسالة" }).fill("اعمل منبه الساعة ٦ الصبح");
  26 |   await page.getByRole("button", { name: "إرسال" }).click();
  27 |   await expect(page.getByText(/أنهي يوم/)).toBeVisible();
  28 |   await page.getByRole("textbox", { name: "رسالة" }).fill("بعد بكرة");
  29 |   await page.getByRole("button", { name: "إرسال" }).click();
  30 |   const afterTomorrow = await page.evaluate(() => JSON.parse(localStorage.getItem("dayflow-v2")!).state.alarms[0]);
> 31 |   expect(afterTomorrow).toMatchObject({ date: "2027-05-12", time: "06:00", days: [] });
     |                         ^ Error: expect(received).toMatchObject(expected)
  32 |   await page.goto("http://127.0.0.1:5173/#/alarms");
  33 |   await expect(page.getByText(/١٤ مايو ٢٠٢٧/).first()).toBeVisible();
  34 | });
```