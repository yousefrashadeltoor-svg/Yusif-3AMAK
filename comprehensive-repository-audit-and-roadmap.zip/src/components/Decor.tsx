import { useMemo } from "react";
import type { Family } from "../lib/calendar";
import { resolveDecor } from "../lib/calendar";
import { FAMILY, motif, mulberry32, tileDataUri } from "../lib/pattern";
import { useStore } from "../lib/store";
import { DECOR_ART } from "../lib/ambience";

import arabesqueUrl from "../assets/art/arabesque.svg";
import rubElHizbUrl from "../assets/art/rub-el-hizb.svg";
import lotusRoundelUrl from "../assets/art/lotus-roundel.svg";
import snowflakeUrl from "../assets/art/snowflake.svg";
import ornamentAcUrl from "../assets/art/ornament-ac.svg";
import ornamentLoopUrl from "../assets/art/ornament-loop.svg";
import ornamentTugscUrl from "../assets/art/ornament-tugsc.svg";
import flowerOrnamentUrl from "../assets/art/flower-ornament.svg";
import fanousPhoto from "../assets/art/fanous.jpg";
import cairoNightPhoto from "../assets/art/cairo-night.jpg";

const BUDGET = { off: 0, subtle: 2, rich: 3, festival: 3 } as const;

export function useDecor(date: Date = new Date()) {
  const userDays = useStore((s) => s.userDays);
  const intensity = useStore((s) => s.intensity);
  const exam = useStore((s) => s.examSeason);
  const key = date.toDateString();
  return useMemo(() => ({ ...resolveDecor(date, userDays, Math.max(1, BUDGET[intensity]), exam), intensity }), [key, userDays, intensity, exam]); // eslint-disable-line
}

/** Curated Public Domain / CC0 Wikimedia ornament per season family. */
export const CURATED_SVG: Partial<Record<Family, string>> = {
  ramadan: rubElHizbUrl,
  islamic: arabesqueUrl,
  friday: rubElHizbUrl,
  eid: ornamentAcUrl,
  winter: snowflakeUrl,
  spring: flowerOrnamentUrl,
  nile: lotusRoundelUrl,
  summer: ornamentTugscUrl,
  autumn: ornamentLoopUrl,
  coptic: ornamentAcUrl,
  newyear: ornamentTugscUrl,
  birthday: flowerOrnamentUrl,
};

export function seasonPhoto(family: Family): string | null {
  if (family === "ramadan" || family === "eid") return fanousPhoto;
  if (family === "nile" || family === "islamic" || family === "national" || family === "friday") return cairoNightPhoto;
  return null;
}

/** Curated ornament rendered as a tinted CSS mask (for monochrome/white/seasonal ink) or crisp fallback SVG. */
export function Motif({ family, size = 48, className = "", mono }: { family: Family; size?: number; className?: string; mono?: string }) {
  const st = FAMILY[family];
  const curated = CURATED_SVG[family];
  if (curated) {
    const color = mono || st.c1;
    return (
      <span
        aria-hidden
        className={`inline-block flex-none ${className}`}
        style={{
          width: size,
          height: size,
          backgroundColor: color,
          WebkitMaskImage: `url("${curated}")`,
          maskImage: `url("${curated}")`,
          WebkitMaskRepeat: "no-repeat",
          maskRepeat: "no-repeat",
          WebkitMaskPosition: "center",
          maskPosition: "center",
          WebkitMaskSize: "contain",
          maskSize: "contain",
        }}
      />
    );
  }
  const m = motif(family, 50, 50, 90);
  return (
    <svg viewBox="0 0 100 100" width={size} height={size} className={className} aria-hidden>
      {m.fill.map((d, i) => <path key={"f" + i} d={d} fill={mono || (i % 2 ? st.c2 : st.c1)} fillOpacity={0.9} />)}
      {m.stroke.map((d, i) => <path key={"s" + i} d={d} fill="none" stroke={mono || (i % 2 ? st.c1 : st.c2)} strokeWidth={family === "national" ? 7 : 3} strokeLinecap="round" strokeLinejoin="round" />)}
      {family === "national" && !mono && <>
        <path d={m.stroke[0]} fill="none" stroke="#fff" strokeWidth={4} transform="translate(0,7)" />
        <path d={m.stroke[0]} fill="none" stroke="#111" strokeWidth={6} transform="translate(0,13)" />
      </>}
    </svg>
  );
}

/** AppBar / hero crown using curated PD/CC0 SVG frieze. */
export function HeaderCrown({ family, height = 64, className = "" }: { family: Family; height?: number; className?: string }) {
  const st = FAMILY[family];
  const centerSize = Math.round(height * 0.72);
  const sideSize = Math.round(height * 0.36);
  return (
    <div className={`relative flex items-center justify-center gap-4 overflow-hidden px-4 ${className}`} style={{ height }} aria-hidden>
      <span className="h-px flex-1 opacity-60" style={{ background: `linear-gradient(90deg, transparent, ${st.c3})` }} />
      <Motif family={family} size={sideSize} mono={st.c3} className="opacity-55" />
      <Motif family={family} size={centerSize} mono={st.c3} className="opacity-95" />
      <Motif family={family} size={sideSize} mono={st.c3} className="opacity-55" />
      <span className="h-px flex-1 opacity-60" style={{ background: `linear-gradient(90deg, ${st.c3}, transparent)` }} />
    </div>
  );
}

export function Corner({ family, pos = "tl", size = 64, opacity = 0.55 }: { family: Family; pos?: "tl" | "tr" | "bl" | "br"; size?: number; opacity?: number }) {
  const st = FAMILY[family];
  const curated = CURATED_SVG[family] || ornamentAcUrl;
  const tf = { tl: "", tr: "scale(-1,1)", bl: "scale(1,-1)", br: "scale(-1,-1)" }[pos];
  const place = { tl: "top-1 start-1", tr: "top-1 end-1", bl: "bottom-1 start-1", br: "bottom-1 end-1" }[pos];
  return (
    <span className={`pointer-events-none absolute ${place}`} style={{ opacity, transform: tf }} aria-hidden>
      <Motif family={family} size={size} mono={st.c3} />
      {!curated && null}
    </span>
  );
}

export function Divider({ family, className = "" }: { family: Family; className?: string }) {
  const st = FAMILY[family];
  return (
    <div className={`flex items-center gap-3 ${className}`} aria-hidden>
      <span className="h-px flex-1" style={{ background: `linear-gradient(90deg, transparent, ${st.c1})` }} />
      <Motif family={family} size={22} />
      <span className="h-px flex-1" style={{ background: `linear-gradient(90deg, ${st.c1}, transparent)` }} />
    </div>
  );
}

export function Particles({ family, intensity }: { family: Family; intensity: string }) {
  const lowEnd = typeof navigator !== "undefined" && (navigator.hardwareConcurrency || 8) <= 4;
  const n = { off: 0, subtle: 9, rich: 20, festival: 34 }[intensity as "off"] ?? 0;
  const count = Math.min(lowEnd ? 14 : 48, n);
  const art = DECOR_ART[family];
  const items = useMemo(() => {
    const r = mulberry32(family.length * 97 + count);
    return Array.from({ length: count }, (_, i) => ({ left: r() * 100, delay: -r() * 22, dur: 13 + r() * 15, size: 18 + r() * 22, dx: (r() - 0.5) * 140, o: 0.55 + r() * 0.4, src: art.fall[i % art.fall.length] }));
  }, [family, count, art]);
  if (!count) return null;
  const cls = art.motion === "fall" ? "decor-fall" : art.motion === "float" ? "decor-float" : "decor-drift";
  return (
    <>
      {art.backdrop && family === "autumn" && <div className="decor-tree" aria-hidden><img src={art.backdrop} alt="" /></div>}
      <div className="pointer-events-none fixed inset-0 z-[1] overflow-hidden" aria-hidden style={{ perspective: 600 }}>
        {items.map((p, i) => (
          <img key={i} src={p.src} alt="" draggable={false} className={`decor-sprite ${cls}`}
            style={{ left: (family === "autumn" ? 55 + p.left * 0.45 : p.left) + "%", width: p.size, height: p.size, animationDuration: p.dur + "s", animationDelay: p.delay + "s", ["--dx" as string]: p.dx + "px", ["--o" as string]: p.o }} />
        ))}
      </div>
    </>
  );
}

/** Realistic seasonal art piece (static) — used on widgets, alarm, notifications and the companion. */
export function SeasonArt({ family, size = 34, className = "", style }: { family: Family; size?: number; className?: string; style?: React.CSSProperties }) {
  const src = DECOR_ART[family]?.corner;
  if (!src) return null;
  return <img src={src} alt="" aria-hidden draggable={false} className={`decor-static ${className}`} style={{ width: size, height: size, ...style }} />;
}

/** Data URL of the season art for native/web notification icons. */
export const seasonIcon = (family: Family) => DECOR_ART[family]?.corner || DECOR_ART.islamic.corner!;

export function PatternLayer({ family, color }: { family: Family; color?: string }) {
  return <div className="pointer-events-none absolute inset-0" style={{ backgroundImage: tileDataUri(family, color || FAMILY[family].c1, 0.22, 64) }} aria-hidden />;
}

export function EmptyState({ family, title, hint, action }: { family: Family; title: string; hint?: string; action?: React.ReactNode }) {
  const st = FAMILY[family];
  return (
    <div className="flex flex-col items-center px-6 py-8 text-center fade-in">
      <div className="relative mb-3 grid h-28 w-28 place-items-center rounded-full" style={{ background: `radial-gradient(circle, ${st.c3}99, transparent 70%)` }}>
        <Motif family={family} size={74} className="float-y" />
      </div>
      <p className="font-semibold">{title}</p>
      {hint && <p className="muted mt-1 text-sm">{hint}</p>}
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}

export function familyGradient(f: Family) {
  const s = FAMILY[f];
  return `linear-gradient(135deg, ${s.c2}, ${s.c1})`;
}
