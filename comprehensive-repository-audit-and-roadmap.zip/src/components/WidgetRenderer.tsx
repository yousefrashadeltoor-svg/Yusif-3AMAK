import { useClockFormat, clockParts } from "../lib/time";
import { useEffect, useMemo, useState } from "react";
import { Check, Plus, Mic, Link2, Droplet, Timer, AlarmClock, StickyNote, Play, Pause, Minus } from "lucide-react";
import type { WidgetDef, Form, WStyle } from "../lib/widgets";
import { formSize } from "../lib/widgets";
import { useStore, nextAlarmTime, fmtNum } from "../lib/store";
import { dayKey, hijri, coptic, HIJRI_MONTHS, COPTIC_MONTHS, upcomingOccasions, resolveDecor, occasionsOn } from "../lib/calendar";
import { FAMILY, tileDataUri } from "../lib/pattern";
import { Motif, SeasonArt } from "./Decor";
import { RobotMini } from "./Companion";
import { sampleHistory, reviewAll, DIMS } from "../lib/review";
import { prayerTimes, CITIES, PRAYER_NAMES } from "../lib/prayer";
import { WIDGET_FONTS } from "../lib/widgets";

export function useNow(ms = 1000) {
  const [n, setN] = useState(() => new Date());
  useEffect(() => { const t = setInterval(() => setN(new Date()), ms); return () => clearInterval(t); }, [ms]);
  return n;
}

let reviewCache: { scores: number[]; dims: number[] } | null = null;
function reviewData() {
  if (!reviewCache) {
    const h = sampleHistory(120);
    const r = reviewAll(h);
    reviewCache = { scores: r.map((x) => x.score), dims: DIMS.map((d) => { const v = r.slice(-7).map((x) => x.dims.find((y) => y.id === d.id)!.score).filter((x): x is number => x !== null); return v.length ? v.reduce((a, b) => a + b, 0) / v.length : 50; }) };
  }
  return reviewCache;
}

const pad = (n: number) => String(n).padStart(2, "0");

export function WidgetRenderer({ def, form, style, cell = 76, gap = 10, live = true }: { def: WidgetDef; form: Form; style: WStyle; cell?: number; gap?: number; live?: boolean }) {
  const clockFormat = useClockFormat();
  const [w, h] = formSize(form);
  const W = w * cell + (w - 1) * gap, H = h * cell + (h - 1) * gap;
  const now = useNow(live ? 1000 : 60000);
  const lang = useStore((s) => s.lang);
  const s = useStore();
  const decor = useMemo(() => resolveDecor(now, s.userDays, 2), [now.toDateString(), s.userDays]); // eslint-disable-line
  const prayer = useMemo(() => prayerTimes(CITIES[s.cityIndex] || CITIES[0], now), [now.getMinutes(), now.getDate(), s.cityIndex]); // eslint-disable-line
  const fam = decor.primary;
  const st = FAMILY[fam];
  const L = (en: string, ar: string) => (lang === "ar" ? ar : en);
  const N = (n: number | string) => fmtNum(n, lang);
  const todayKey = dayKey(now);
  const tasks = s.tasks.filter((t) => t.date === todayKey);
  const done = tasks.filter((t) => t.done).length;
  const next = nextAlarmTime(s.alarms, now);
  const water = s.water[todayKey] || 0;
  const hj = hijri(now), cp = coptic(now);
  const dayProg = (now.getHours() * 60 + now.getMinutes()) / 1440;
  const time = clockParts(now, s.hour12, lang).time;
  const dateStr = now.toLocaleDateString(lang === "ar" ? "ar-EG" : "en-GB", { weekday: "long", day: "numeric", month: "long" });
  const small = w === 1 && h === 1, wide = h === 1 && w > 1, big = w >= 4 && h >= 4;
  const v = def.variant;

  const seasonalVars = style === "seasonal" ? { ["--s1" as string]: st.c2, ["--s2" as string]: st.c1 } : {};
  const dark = style === "neon" || style === "amoled" || style === "outline" || style === "seasonal";
  const acc = dark ? (style === "seasonal" ? st.c3 : "var(--accent)") : "var(--accent)";
  const sub = { opacity: 0.62 } as React.CSSProperties;
  const stop = (fn: () => void) => (e: React.MouseEvent) => { e.stopPropagation(); fn(); };

  const ringEl = (val: number, label: string, size: number) => {
    const r = size / 2 - 7, c = 2 * Math.PI * r;
    return (
      <div className="relative grid place-items-center" style={{ width: size, height: size }}>
        <svg width={size} height={size} className="-rotate-90"><circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="currentColor" strokeOpacity=".14" strokeWidth="7" /><circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke={acc} strokeWidth="7" strokeLinecap="round" strokeDasharray={c} strokeDashoffset={c * (1 - Math.min(1, val))} /></svg>
        <span className="absolute font-bold" style={{ fontSize: size * 0.22 }}>{label}</span>
      </div>
    );
  };

  const analog = (size: number) => {
    const hA = ((now.getHours() % 12) + now.getMinutes() / 60) * 30, mA = now.getMinutes() * 6, sA = now.getSeconds() * 6;
    const lux = v === 8, skel = v === 7, min = v === 9 || v === 11;
    return (
      <svg width={size} height={size} viewBox="0 0 100 100">
        <circle cx="50" cy="50" r="47" fill={lux ? "#14110c" : "none"} stroke={lux ? "#c9a24a" : "currentColor"} strokeOpacity={lux ? 1 : 0.18} strokeWidth={lux ? 2.5 : 1.5} />
        {skel && <><circle cx="50" cy="50" r="34" fill="none" stroke="currentColor" strokeOpacity=".15" /><circle cx="50" cy="50" r="22" fill="none" stroke="currentColor" strokeOpacity=".1" strokeDasharray="2 2" /></>}
        {v === 11 && <circle cx="50" cy="50" r="40" fill="none" stroke={acc} strokeOpacity=".4" strokeDasharray="1 5" />}
        {Array.from({ length: 12 }, (_, i) => {
          const a = (i * 30 * Math.PI) / 180; const r1 = i % 3 === 0 ? 37 : 41;
          return min && i % 3 ? null : <line key={i} x1={50 + r1 * Math.sin(a)} y1={50 - r1 * Math.cos(a)} x2={50 + 44 * Math.sin(a)} y2={50 - 44 * Math.cos(a)} stroke={lux ? "#c9a24a" : "currentColor"} strokeWidth={i % 3 === 0 ? 2.4 : 1.2} strokeLinecap="round" />;
        })}
        {v === 6 && [12, 3, 6, 9].map((n, i) => <text key={n} x={50 + 29 * Math.sin((i * Math.PI) / 2)} y={50 - 29 * Math.cos((i * Math.PI) / 2) + 4} textAnchor="middle" fontSize="10" fontWeight="600" fill="currentColor">{N(n)}</text>)}
        <line x1="50" y1="50" x2={50 + 24 * Math.sin((hA * Math.PI) / 180)} y2={50 - 24 * Math.cos((hA * Math.PI) / 180)} stroke={lux ? "#e8d29a" : "currentColor"} strokeWidth="4" strokeLinecap="round" />
        <line x1="50" y1="50" x2={50 + 35 * Math.sin((mA * Math.PI) / 180)} y2={50 - 35 * Math.cos((mA * Math.PI) / 180)} stroke={lux ? "#e8d29a" : "currentColor"} strokeWidth="2.6" strokeLinecap="round" />
        {!small && <line x1="50" y1="50" x2={50 + 39 * Math.sin((sA * Math.PI) / 180)} y2={50 - 39 * Math.cos((sA * Math.PI) / 180)} stroke={acc} strokeWidth="1.2" strokeLinecap="round" />}
        <circle cx="50" cy="50" r="2.6" fill={acc} />
      </svg>
    );
  };

  const body = (() => {
    switch (def.arche) {
      case "digital": {
        const font = v === 1 ? { fontWeight: 900, letterSpacing: "-.04em" } : v === 4 ? { fontFamily: "ui-monospace,monospace", letterSpacing: ".08em" } : v === 15 ? { fontWeight: 200 } : { fontWeight: 600 };
        if (def.id.includes("stopwatch")) return <Stopwatch L={L} small={small} acc={acc} />;
        if (v === 5 && !small) {
          const words = lang === "ar" ? [`الساعة ${N(now.getHours())}`, `و${N(now.getMinutes())} دقيقة`] : [`${now.getHours() % 12 || 12} o'clock`, `and ${now.getMinutes()} minutes`];
          return <div className="flex h-full flex-col justify-center p-4"><div className="text-2xl font-black leading-tight">{words[0]}</div><div className="text-lg leading-tight" style={sub}>{words[1]}</div></div>;
        }
        if (small) return <div className="grid h-full place-items-center"><div className="text-center leading-none" style={font}><div className="text-3xl">{N(s.hour12 ? now.getHours() % 12 || 12 : pad(now.getHours()))}</div><div className="text-3xl" style={{ color: acc }}>{pad(now.getMinutes())}</div></div></div>;
        return (
          <div className="flex h-full flex-col justify-center p-4">
            <div style={{ ...font, fontSize: Math.min(H * (wide ? 0.5 : 0.3), W * 0.24) }} className="leading-none">{N(time)}{s.hour12 && <small className="ms-1 text-[10px]">{clockParts(now, true, lang).suffix}</small>}</div>
            <div className="mt-1 truncate text-sm" style={sub}>{dateStr}</div>
            {h >= 2 && w >= 2 && next && <div className="mt-2 flex items-center gap-1 text-xs font-semibold" style={{ color: acc }}><AlarmClock size={13} /> {clockFormat(next.alarm.time)}</div>}
            {w >= 4 && h >= 2 && <div className="mt-1 text-xs" style={sub}>{N(hj.d)} {HIJRI_MONTHS[lang][hj.m - 1]} · {N(cp.d)} {COPTIC_MONTHS[lang][cp.m - 1]}</div>}
            {big && <div className="mt-4 space-y-2">{tasks.slice(0, 5).map((t) => <div key={t.id} className="flex items-center gap-2 text-sm"><span className="h-2 w-2 rounded-full" style={{ background: t.done ? "currentColor" : acc, opacity: t.done ? 0.3 : 1 }} /><span className={t.done ? "line-through opacity-50" : ""}>{t.title}</span></div>)}</div>}
          </div>
        );
      }
      case "analog": {
        const size = Math.min(W, H) - (small ? 12 : 24);
        if (h >= 2 && w >= 4) return <div className="flex h-full items-center gap-4 p-4">{analog(Math.min(H - 24, W / 2))}<div><div className="text-3xl font-bold">{N(time)}{s.hour12 && <small className="ms-1 text-[10px]">{clockParts(now, true, lang).suffix}</small>}</div><div className="text-sm" style={sub}>{dateStr}</div>{big && <div className="mt-3 text-xs" style={sub}>{N(hj.d)} {HIJRI_MONTHS[lang][hj.m - 1]}</div>}</div></div>;
        return <div className="grid h-full place-items-center">{analog(size)}</div>;
      }
      case "flip": {
        const digits = v === 13 ? [pad(now.getDate()), now.toLocaleDateString(lang === "ar" ? "ar-EG" : "en", { month: "short" })] : [pad(s.hour12 ? now.getHours() % 12 || 12 : now.getHours()), pad(now.getMinutes())];
        return (
          <div className="flex h-full items-center justify-center gap-2 p-3">
            {(small ? [digits[0]] : digits).map((d, i) => (
              <div key={i} className="relative grid place-items-center rounded-lg font-black" style={{ background: dark ? "#ffffff14" : "#00000010", width: small ? "80%" : (W - 40) / 2, height: H - 26, fontSize: Math.min(H * 0.5, W * 0.2) }}>
                {N(d)}<span className="absolute inset-x-0 top-1/2 h-px" style={{ background: "currentColor", opacity: 0.15 }} />
              </div>
            ))}
          </div>
        );
      }
      case "sunarc": {
        const p = Math.max(0, Math.min(1, (now.getHours() + now.getMinutes() / 60 - 6) / 12));
        const x = 10 + 80 * p, y = 50 - Math.sin(p * Math.PI) * 38;
        return <div className="flex h-full flex-col p-3"><svg viewBox="0 0 100 56" className="w-full flex-1"><path d="M10 50 Q50 -26 90 50" fill="none" stroke="currentColor" strokeOpacity=".25" strokeDasharray="2 3" /><line x1="4" y1="50" x2="96" y2="50" stroke="currentColor" strokeOpacity=".2" /><circle cx={x} cy={y} r="5" fill={st.c1} /></svg>{!small && <div className="flex justify-between text-xs" style={sub}><span>≈06:00</span><b style={{ color: "inherit", opacity: 1 }}>{N(time)}</b><span>≈18:00</span></div>}{h >= 2 && <div className="mt-1 text-[10px]" style={sub}>{L("Approximate — location-free", "تقريبي — بدون موقع")}</div>}</div>;
      }
      case "world": {
        const zones = [["Africa/Cairo", L("Cairo", "القاهرة")], ["Asia/Riyadh", L("Makkah", "مكة")], ["Europe/London", L("London", "لندن")], ["America/New_York", L("New York", "نيويورك")]];
        const n = small ? 1 : wide ? 2 : big ? 4 : 2;
        return <div className={`grid h-full gap-2 p-3 ${wide ? "grid-cols-2" : ""}`}>{zones.slice(0, n).map(([z, name]) => <div key={z} className="flex flex-col justify-center"><div className="text-xs" style={sub}>{name}</div><div className="text-xl font-bold">{N(now.toLocaleTimeString(lang === "ar" ? "ar-EG" : "en-GB", { timeZone: z, hour: "2-digit", minute: "2-digit", hour12: s.hour12 }))}</div></div>)}</div>;
      }
      case "ring": case "dial": {
        let val = dayProg, label = Math.round(dayProg * 100) + "%", cap = L("Day", "اليوم");
        if (def.cat === "tasks" || def.id.includes("priorit")) { val = tasks.length ? done / tasks.length : 0; label = `${done}/${tasks.length}`; cap = L("Tasks", "المهام"); }
        if (def.cat === "review" || def.id.includes("health")) { const sc = reviewData().scores.at(-1)!; val = sc / 100; label = String(sc); cap = L("Score", "النتيجة"); }
        if (def.cat === "habits") { val = Math.min(1, 25 / 30); label = "25′"; cap = L("Workout", "تمرين"); }
        if (def.cat === "alarms" || def.id.includes("sleep")) { const mins = next ? (next.at.getTime() - now.getTime()) / 60000 : 0; val = Math.min(1, mins / 720); label = next ? `${Math.floor(mins / 60)}h` : "—"; cap = L("to alarm", "للمنبه"); }
        if (def.cat === "focus" || def.id.includes("timer")) return <FocusRing small={small} acc={acc} L={L} />;
        if (def.cat === "occasions") { const up = upcomingOccasions(now, 1)[0]; const d = up ? Math.round((up.date.getTime() - now.getTime()) / 864e5) : 0; val = 1 - Math.min(1, d / 60); label = N(d) + L("d", "ي"); cap = up ? (lang === "ar" ? up.o.ar : up.o.en) : ""; }
        const size = Math.min(W, H) - (small ? 14 : 30);
        if (def.arche === "dial") {
          const a = Math.PI * val;
          return <div className="flex h-full flex-col items-center justify-center p-3"><svg viewBox="0 0 100 56" style={{ width: Math.min(W - 20, (H - 20) * 1.8) }}><path d="M8 50 A42 42 0 0 1 92 50" fill="none" stroke="currentColor" strokeOpacity=".14" strokeWidth="8" strokeLinecap="round" /><path d={`M8 50 A42 42 0 0 1 ${50 - 42 * Math.cos(a)} ${50 - 42 * Math.sin(a)}`} fill="none" stroke={acc} strokeWidth="8" strokeLinecap="round" /><text x="50" y="47" textAnchor="middle" fontSize="15" fontWeight="700" fill="currentColor">{label}</text></svg>{!small && <div className="text-xs" style={sub}>{cap}</div>}</div>;
        }
        if (w >= 4) return <div className="flex h-full items-center gap-4 p-4">{ringEl(val, label, Math.min(H - 30, 120))}<div className="min-w-0"><div className="text-lg font-bold">{def[lang]}</div><div className="truncate text-sm" style={sub}>{cap}</div>{big && <div className="mt-3 space-y-1.5">{tasks.slice(0, 4).map((t) => <div key={t.id} className="text-sm">{t.done ? "✓ " : "· "}{t.title}</div>)}</div>}</div></div>;
        return <div className="flex h-full flex-col items-center justify-center">{ringEl(val, label, wide ? H - 20 : size)}{h >= 2 && <div className="mt-1 max-w-full truncate px-2 text-xs" style={sub}>{cap}</div>}</div>;
      }
      case "checklist": {
        const items = def.cat === "alarms" ? s.alarms.map((a) => ({ id: a.id, t: a.time + " · " + a.label, d: a.enabled, f: () => s.updateAlarm(a.id, { enabled: !a.enabled }) }))
          : tasks.map((t) => ({ id: t.id, t: t.title, d: t.done, f: () => s.toggleTask(t.id) }));
        const n = small ? 0 : h === 1 ? (w >= 4 ? 2 : 1) : h === 2 ? 3 : 8;
        if (small) return <div className="grid h-full place-items-center"><div className="text-center"><div className="text-2xl font-bold">{N(items.filter((i) => !i.d).length)}</div><div className="text-[10px]" style={sub}>{L("open", "متبقية")}</div></div></div>;
        return (
          <div className="flex h-full flex-col p-3">
            {h >= 2 && <div className="mb-1.5 flex items-center justify-between text-xs font-bold"><span>{def[lang]}</span><span style={{ color: acc }}>{N(items.filter((i) => i.d).length)}/{N(items.length)}</span></div>}
            <div className={`flex-1 ${h === 1 && w >= 4 ? "flex gap-3" : "space-y-1.5"}`}>
              {items.slice(0, n).map((i) => (
                <button key={i.id} onClick={stop(i.f)} className="flex w-full min-w-0 items-center gap-2 text-start text-sm" aria-pressed={i.d}>
                  <span className="grid h-5 w-5 flex-none place-items-center rounded-md border-2" style={{ borderColor: acc, background: i.d ? acc : "transparent", color: "#fff" }}>{i.d && <Check size={12} strokeWidth={3} />}</span>
                  <span className={`truncate ${i.d ? "line-through opacity-50" : ""}`}>{i.t}</span>
                </button>
              ))}
              {!items.length && <div className="text-sm" style={sub}>{L("All clear", "لا شيء متبقٍ")}</div>}
            </div>
          </div>
        );
      }
      case "list": {
        const occ = def.cat === "occasions" || def.id.includes("agenda") || def.cat === "calendar";
        const rows = occ ? upcomingOccasions(now, 8).map((u) => ({ k: u.o.id + u.date, a: lang === "ar" ? u.o.ar : u.o.en, b: u.date.toLocaleDateString(lang === "ar" ? "ar-EG" : "en-GB", { day: "numeric", month: "short" }), f: u.o.family }))
          : tasks.map((t) => ({ k: t.id, a: t.title, b: t.done ? "✓" : "", f: fam }));
        const n = small ? 1 : h === 1 ? 1 : h === 2 ? 3 : 8;
        return (
          <div className="flex h-full flex-col p-3">
            {!small && h >= 2 && <div className="mb-2 text-xs font-bold">{def[lang]}</div>}
            <div className="space-y-2">{rows.slice(0, n).map((r) => <div key={r.k} className="flex items-center gap-2"><Motif family={r.f} size={small ? 26 : 20} /><span className={`min-w-0 flex-1 truncate ${small ? "text-[10px]" : "text-sm"}`}>{r.a}</span>{!small && <span className="text-xs" style={sub}>{N(r.b)}</span>}</div>)}</div>
            {!rows.length && <div className="text-sm" style={sub}>{L("Nothing here", "لا يوجد شيء")}</div>}
          </div>
        );
      }
      case "month": {
        const first = new Date(now.getFullYear(), now.getMonth(), 1);
        const days = new Date(now.getFullYear(), now.getMonth() + 1, 0).getDate();
        const offset = first.getDay();
        const hijriMode = v === 8, copticMode = v === 9;
        return (
          <div className="flex h-full flex-col p-3" style={v === 1 ? { backgroundImage: tileDataUri(fam, st.c1, 0.2, 40) } : undefined}>
            <div className="mb-1 flex items-baseline justify-between text-xs font-bold"><span>{hijriMode ? HIJRI_MONTHS[lang][hj.m - 1] : copticMode ? COPTIC_MONTHS[lang][cp.m - 1] : now.toLocaleDateString(lang === "ar" ? "ar-EG" : "en", { month: "long" })}</span><span style={sub}>{N(hijriMode ? hj.y : copticMode ? cp.y : now.getFullYear())}</span></div>
            <div className="grid flex-1 grid-cols-7 gap-px text-center" style={{ fontSize: big ? 13 : 9 }}>
              {Array.from({ length: offset }, (_, i) => <span key={"e" + i} />)}
              {Array.from({ length: days }, (_, i) => {
                const d = new Date(now.getFullYear(), now.getMonth(), i + 1);
                const o = occasionsOn(d)[0];
                const isT = i + 1 === now.getDate();
                const label = hijriMode ? hijri(d).d : copticMode ? coptic(d).d : i + 1;
                return <span key={i} className="relative grid place-items-center rounded" style={isT ? { background: acc, color: dark ? "#000" : "#fff", fontWeight: 700 } : undefined}>{N(label)}{o && !isT && <span className="absolute bottom-0 h-1 w-1 rounded-full" style={{ background: FAMILY[o.family].c1 }} />}</span>;
              })}
            </div>
          </div>
        );
      }
      case "week": {
        const n = small ? 3 : 7;
        const start = new Date(now); start.setDate(now.getDate() - (small ? 1 : now.getDay()));
        return <div className="flex h-full items-stretch gap-1 p-3">{Array.from({ length: n }, (_, i) => { const d = new Date(start); d.setDate(start.getDate() + i); const isT = d.toDateString() === now.toDateString(); const o = occasionsOn(d)[0]; const has = s.alarms.some((a) => a.enabled && a.days.includes(d.getDay())); return <div key={i} className="flex flex-1 flex-col items-center justify-center rounded-lg" style={isT ? { background: acc, color: dark ? "#000" : "#fff" } : { background: "#8881" }}><span className="text-[9px] opacity-70">{d.toLocaleDateString(lang === "ar" ? "ar-EG" : "en", { weekday: "narrow" })}</span><span className="text-sm font-bold">{N(d.getDate())}</span>{h >= 2 && <span className="mt-1 h-1.5 w-1.5 rounded-full" style={{ background: o ? FAMILY[o.family].c1 : has ? "currentColor" : "transparent", opacity: o ? 1 : 0.4 }} />}</div>; })}</div>;
      }
      case "heatmap": case "mosaic": {
        const sc = reviewData().scores;
        const cols = small ? 5 : w * 6, rows = small ? 5 : h * 3 + (h > 2 ? 2 : 0);
        const cells = sc.slice(-cols * rows);
        const habitMode = def.id.includes("habit-grid");
        return <div className="flex h-full flex-col p-3">{!small && h >= 2 && <div className="mb-1.5 text-xs font-bold">{def[lang]}</div>}{habitMode && !small ? <div className="space-y-1.5">{s.habits.slice(0, h * 2).map((hb) => <div key={hb.id} className="flex items-center gap-2"><button onClick={stop(() => s.toggleHabit(hb.id))} className="h-5 w-5 flex-none rounded-md border-2" style={{ borderColor: acc, background: hb.log.includes(todayKey) ? acc : "transparent" }} aria-label={hb.en} /><span className="truncate text-xs">{hb.en}</span></div>)}</div> : <div className="grid flex-1 gap-[3px]" style={{ gridTemplateColumns: `repeat(${cols}, 1fr)` }}>{cells.map((x, i) => <span key={i} className={def.arche === "mosaic" ? "rounded-full" : "rounded-[3px]"} style={{ background: acc, opacity: 0.12 + (x / 100) * 0.88 }} />)}</div>}</div>;
      }
      case "timeline": {
        const blocks = [[6.5, 7.5, st.c1], [9, 12, "var(--accent)"], [13, 14, st.c2], [15, 17, "var(--accent)"], [20, 21, st.c1]] as Array<[number, number, string]>;
        const vertical = def.en.includes("vertical") || (h > w / 2 && h >= 2);
        if (vertical) return <div className="relative h-full p-3">{blocks.map(([a, b, c], i) => <div key={i} className="absolute inset-x-8 rounded-md px-2 text-[10px] text-white" style={{ top: `${(a / 24) * 100}%`, height: `${((b - a) / 24) * 100}%`, background: c, minHeight: 4 }}>{h >= 4 && ["Fajr walk", "Deep work", "Lunch", "Study", "Family"][i]}</div>)}<div className="absolute inset-x-3 h-0.5" style={{ top: `${dayProg * 100}%`, background: "red" }} /></div>;
        return <div className="flex h-full flex-col justify-center gap-2 p-3">{!small && <div className="flex justify-between text-xs"><b>{def[lang]}</b><span style={sub}>{N(time)}</span></div>}<div className="relative h-5 rounded-full" style={{ background: "#8882" }}>{blocks.map(([a, b, c], i) => <span key={i} className="absolute inset-y-0 rounded-full" style={{ insetInlineStart: `${(a / 24) * 100}%`, width: `${((b - a) / 24) * 100}%`, background: c }} />)}<span className="absolute -inset-y-1 w-0.5 bg-red-500" style={{ insetInlineStart: `${dayProg * 100}%` }} /></div>{h >= 2 && <div className="text-xs" style={sub}>{L("Next: Study at 15:00", "التالي: دراسة ١٥:٠٠")}</div>}</div>;
      }
      case "hero": {
        const up = upcomingOccasions(now, 1)[0];
        const f2 = def.id.includes("friday") ? "friday" : def.id.includes("nile") ? "nile" : def.id.includes("national") ? "national" : def.id.includes("eid") ? "eid" : up?.o.family ?? fam;
        const s2 = FAMILY[f2];
        return (
          <div className="relative h-full overflow-hidden p-3 text-white" style={{ background: `linear-gradient(140deg, ${s2.c2}, ${s2.c1})` }}>
            <div className="absolute inset-0" style={{ backgroundImage: tileDataUri(f2, "#ffffff", 0.25, 44) }} />
            <div className="absolute -bottom-3 -end-3 opacity-90"><Motif family={f2} size={Math.min(W, H) * (small ? 0.8 : 0.7)} mono="#ffffffcc" /></div>
            {!small && <div className="relative"><div className="text-[10px] uppercase tracking-wider opacity-80">{f2 === "friday" ? L("Jumu'ah Mubarak", "جمعة مباركة") : L("Coming up", "قريبًا")}</div><div className="mt-0.5 text-base font-bold leading-tight">{up ? (lang === "ar" ? up.o.ar : up.o.en) : ""}</div>{h >= 2 && up && <div className="text-xs opacity-80">{up.date.toLocaleDateString(lang === "ar" ? "ar-EG" : "en-GB", { day: "numeric", month: "long" })}</div>}</div>}
          </div>
        );
      }
      case "countdown": {
        let target = next?.at, label = L("Next alarm", "المنبه التالي");
        if (def.cat === "occasions" || def.cat === "focus" || def.cat === "utility") { const up = upcomingOccasions(now, 1)[0]; target = up?.date; label = up ? (lang === "ar" ? up.o.ar : up.o.en) : ""; }
        if (def.id.includes("bedtime")) { target = new Date(now.getFullYear(), now.getMonth(), now.getDate() + (now.getHours() >= 23 ? 1 : 0), 23, 0); label = L("Bedtime", "وقت النوم"); }
        const ms = target ? target.getTime() - now.getTime() : 0;
        const dd = Math.floor(ms / 864e5), hh = Math.floor((ms % 864e5) / 36e5), mm = Math.floor((ms % 36e5) / 6e4);
        const txt = !target ? "—" : dd > 0 ? `${N(dd)}${L("d", "ي")} ${N(hh)}${L("h", "س")}` : `${N(hh)}:${N(pad(mm))}`;
        return <div className={`flex h-full ${wide ? "flex-row items-center justify-between" : "flex-col justify-center"} p-3`}><div className="min-w-0">{!small && <div className="truncate text-xs" style={sub}>{label}</div>}<div className="font-bold leading-none" style={{ fontSize: small ? 20 : Math.min(H * 0.35, 42) }}>{txt}</div></div>{h >= 2 && next && def.cat === "alarms" && <div className="mt-2 text-xs" style={{ color: acc }}>{clockFormat(next.alarm.time)} · {next.alarm.label}</div>}</div>;
      }
      case "drop": {
        const r = Math.min(1, water / s.waterGoal);
        const bottle = def.id.includes("bottle");
        const shape = bottle ? "M38 8h24v10l8 10v62a6 6 0 0 1-6 6H36a6 6 0 0 1-6-6V28l8-10z" : "M50 6C50 6 18 46 18 66a32 32 0 0 0 64 0C82 46 50 6 50 6z";
        const sz = small ? Math.min(W, H) - 14 : Math.min(H - 20, W / (w >= 2 ? 2.2 : 1));
        const vis = <svg viewBox="0 0 100 100" width={sz} height={sz}><defs><clipPath id={"dc" + def.id}><path d={shape} /></clipPath></defs><path d={shape} fill="#3aa0ff22" stroke="#3aa0ff" strokeWidth="3" /><g clipPath={`url(#dc${def.id})`}><rect x="0" y={100 - r * 96} width="100" height="100" fill="#3aa0ff" /><path d={`M0 ${100 - r * 96} q12 -6 25 0 t25 0 t25 0 t25 0 v8 H0z`} fill="#6cc0ff" /></g></svg>;
        if (small) return <div className="grid h-full place-items-center">{vis}</div>;
        return <div className="flex h-full items-center gap-3 p-3">{vis}<div className="min-w-0 flex-1"><div className="text-lg font-bold">{N((water / 1000).toFixed(2))} L</div><div className="text-xs" style={sub}>/ {N(s.waterGoal / 1000)} L</div><div className="mt-2 flex gap-1.5"><button onClick={stop(() => s.addWater(250))} className="flex items-center gap-1 rounded-full px-2.5 py-1 text-xs font-bold text-white" style={{ background: "#3aa0ff" }}><Plus size={12} />250</button>{w >= 4 && <button onClick={stop(() => s.addWater(500))} className="rounded-full px-2.5 py-1 text-xs font-bold text-white" style={{ background: "#3aa0ff" }}>+500</button>}<button onClick={stop(() => s.addWater(-250))} className="grid h-6 w-6 place-items-center rounded-full" style={{ background: "#3aa0ff22" }} aria-label="undo"><Minus size={12} /></button></div>{big && <div className="mt-4 flex h-16 items-end gap-1">{[0.6, 0.8, 1, 0.7, 0.9, 0.5, r].map((x, i) => <span key={i} className="flex-1 rounded-t" style={{ height: x * 100 + "%", background: "#3aa0ff", opacity: i === 6 ? 1 : 0.45 }} />)}</div>}</div></div>;
      }
      case "note": {
        const n = s.notes.find((x) => x.pinned) || s.notes[0];
        const hand = def.id.includes("handwritten");
        const prompt = def.id.includes("journal");
        return <div className="relative h-full p-3" style={{ background: v === 6 ? "#fff3a8" : undefined, color: v === 6 ? "#3a3200" : undefined, backgroundImage: "repeating-linear-gradient(0deg, transparent 0 19px, #0001 19px 20px)" }}><StickyNote size={14} style={sub} /><p className="mt-1 leading-5" style={{ fontFamily: hand ? "'Segoe Print','Bradley Hand',cursive" : undefined, fontSize: h >= 2 ? 14 : 12 }}>{prompt ? L("What made today meaningful?", "ما الذي جعل اليوم ذا معنى؟") : n?.text ?? L("No notes yet", "لا ملاحظات بعد")}</p></div>;
      }
      case "matrix": {
        const q = [[true, true, L("Do", "نفّذ")], [false, true, L("Plan", "خطط")], [true, false, L("Delegate", "فوّض")], [false, false, L("Drop", "احذف")]] as const;
        return <div className="grid h-full grid-cols-2 gap-1.5 p-2">{q.map(([u, im, lab], i) => { const list = s.tasks.filter((t) => t.urgent === u && t.important === im && !t.done); return <div key={i} className="overflow-hidden rounded-lg p-1.5" style={{ background: ["#e5484d22", "#3e63dd22", "#f5a62322", "#8882"][i] }}><div className="text-[10px] font-bold">{lab} · {N(list.length)}</div>{h >= 4 && list.slice(0, 3).map((t) => <button key={t.id} onClick={stop(() => s.toggleTask(t.id))} className="block w-full truncate text-start text-[11px]">○ {t.title}</button>)}</div>; })}</div>;
      }
      case "kanban": {
        const cols = [["todo", L("To do", "للتنفيذ")], ["doing", L("Doing", "قيد التنفيذ")], ["done", L("Done", "تم")]] as const;
        return <div className="flex h-full gap-1.5 p-2">{cols.map(([k, lab]) => <div key={k} className="flex-1 overflow-hidden rounded-lg p-1.5" style={{ background: "#8881" }}><div className="mb-1 text-[10px] font-bold">{lab} {N(s.tasks.filter((t) => t.status === k).length)}</div>{s.tasks.filter((t) => t.status === k).slice(0, h >= 4 ? 5 : 2).map((t) => <div key={t.id} className="mb-1 truncate rounded px-1 py-0.5 text-[10px]" style={{ background: dark ? "#fff1" : "#fff8" }}>{t.title}</div>)}</div>)}</div>;
      }
      case "spark": {
        const sc = reviewData().scores.slice(-(small ? 7 : w * 7));
        const max = 100, pts = sc.map((x, i) => `${(i / (sc.length - 1)) * 100},${40 - (x / max) * 36}`).join(" ");
        const delta = sc.at(-1)! - sc[0];
        return <div className="flex h-full flex-col p-3">{!small && <div className="flex justify-between text-xs"><b>{def[lang]}</b><span style={{ color: delta >= 0 ? "#2fa36b" : "#e5484d" }}>{delta >= 0 ? "▲" : "▼"} {N(Math.abs(delta))}</span></div>}<svg viewBox="0 0 100 42" preserveAspectRatio="none" className="w-full flex-1"><polyline points={pts} fill="none" stroke={acc} strokeWidth="2" vectorEffect="non-scaling-stroke" /><polygon points={`0,42 ${pts} 100,42`} fill={acc} opacity=".12" /></svg></div>;
      }
      case "donut": {
        const parts = [[35, "var(--accent)", L("Work", "عمل")], [20, st.c1, L("Study", "دراسة")], [15, st.c2, L("Health", "صحة")], [30, "#8888", L("Family", "عائلة")]] as const;
        let acc0 = 0; const r = 15.9;
        return <div className="flex h-full items-center gap-3 p-3"><svg viewBox="0 0 42 42" style={{ width: Math.min(H, W) - 24 }} className="-rotate-90">{parts.map(([p, c], i) => { const el = <circle key={i} cx="21" cy="21" r={r} fill="none" stroke={c} strokeWidth="6" strokeDasharray={`${p} ${100 - p}`} strokeDashoffset={-acc0} />; acc0 += p; return el; })}</svg>{w >= 2 && !wide && <div className="space-y-1 text-xs">{parts.map(([p, c, l]) => <div key={l} className="flex items-center gap-1.5"><span className="h-2 w-2 rounded-full" style={{ background: c }} />{l} {N(p)}%</div>)}</div>}</div>;
      }
      case "radar": {
        const d = reviewData().dims.slice(0, 8);
        const pts = d.map((x, i) => { const a = (i / d.length) * 2 * Math.PI - Math.PI / 2; return `${50 + Math.cos(a) * x * 0.4},${50 + Math.sin(a) * x * 0.4}`; }).join(" ");
        return <div className="grid h-full place-items-center p-2"><svg viewBox="0 0 100 100" style={{ width: Math.min(W, H) - 16 }}>{[40, 26, 13].map((r) => <polygon key={r} points={d.map((_, i) => { const a = (i / d.length) * 2 * Math.PI - Math.PI / 2; return `${50 + Math.cos(a) * r},${50 + Math.sin(a) * r}`; }).join(" ")} fill="none" stroke="currentColor" strokeOpacity=".15" />)}<polygon points={pts} fill={acc} fillOpacity=".3" stroke={acc} strokeWidth="1.5" />{big && DIMS.slice(0, 8).map((dm, i) => { const a = (i / 8) * 2 * Math.PI - Math.PI / 2; return <text key={dm.id} x={50 + Math.cos(a) * 47} y={50 + Math.sin(a) * 47 + 2} fontSize="4" textAnchor="middle" fill="currentColor">{lang === "ar" ? dm.ar : dm.en}</text>; })}</svg></div>;
      }
      case "bars": {
        const vals = def.id.includes("cups") ? Array.from({ length: 8 }, (_, i) => (i < Math.round(water / 250) ? 1 : 0.15)) : reviewData().dims.slice(0, small ? 3 : w * 2).map((x) => x / 100);
        return <div className="flex h-full flex-col p-3">{!small && h >= 2 && <div className="mb-1 text-xs font-bold">{def[lang]}</div>}<div className="flex flex-1 items-end gap-1">{vals.map((x, i) => <span key={i} className="flex-1 rounded-t-md" style={{ height: Math.max(8, x * 100) + "%", background: def.id.includes("cups") ? "#3aa0ff" : acc, opacity: def.id.includes("cups") ? 1 : 0.5 + x * 0.5 }} />)}</div>{def.id.includes("cups") && <button onClick={stop(() => s.addWater(250))} className="mt-1.5 rounded-full py-0.5 text-[11px] font-bold text-white" style={{ background: "#3aa0ff" }}>+ {L("cup", "كوب")}</button>}</div>;
      }
      case "battery": return <BatteryW small={small} acc={acc} L={L} N={N} />;
      case "counter": {
        const isT = def.id.includes("tasbih");
        const val = isT ? s.tasbih : def.id.includes("streak") ? 12 : 248;
        return <button disabled={!isT} onClick={stop(() => isT && s.set({ tasbih: s.tasbih + 1 }))} className="flex h-full w-full flex-col items-center justify-center p-2"><div className="font-black leading-none" style={{ fontSize: Math.min(H * 0.4, 48), color: acc }}>{N(val)}</div>{!small && <div className="mt-1 text-xs" style={sub}>{isT ? L("Tap to count", "اضغط للعد") : def[lang]}</div>}</button>;
      }
      case "compass": return <div className="flex h-full flex-col items-center justify-center p-2"><svg viewBox="0 0 100 100" style={{ width: Math.min(W, H) - (small ? 12 : 34) }}><circle cx="50" cy="50" r="45" fill="none" stroke="currentColor" strokeOpacity=".2" /><text x="50" y="14" textAnchor="middle" fontSize="9" fill="currentColor">N</text><g transform="rotate(136 50 50)"><path d="M50 12 L56 50 L50 46 L44 50Z" fill={acc} /></g></svg>{!small && <div className="text-[10px]" style={sub}>{L("Cairo · 136° (sensor opt-in)", "القاهرة · ١٣٦° (المستشعر اختياري)")}</div>}</div>;
      case "download": return <div className="flex h-full flex-col items-center justify-center gap-1 p-3 text-center"><Link2 size={small ? 22 : 18} style={{ color: acc }} />{!small && <div className="text-xs font-semibold">{L("No active downloads", "لا تنزيلات نشطة")}</div>}{h >= 2 && <div className="text-[10px]" style={sub}>{L("Downloads run in the native Android engine", "التنزيل يعمل في محرك أندرويد الأصلي")}</div>}</div>;
      case "portrait": return <div className="flex h-full items-center justify-center gap-2 p-2"><RobotMini size={Math.min(H, W / (w >= 4 ? 2 : 1)) - 16} family={fam} />{w >= 2 && !small && <div className="min-w-0 text-xs">{def.id.includes("tip") ? L("Tip: drink a glass of water before your next focus block.", "نصيحة: اشرب كوب ماء قبل جلسة التركيز التالية.") : def.id.includes("mood") ? L("Feeling upbeat ✦", "مزاج رائق ✦") : FAMILY[fam][lang === "ar" ? "ar" : "en"]}</div>}</div>;
      case "quick": {
        const acts = def.id.includes("paste") ? [[Link2, L("Paste", "لصق")]] : def.id.includes("voice") ? [[Mic, L("Record", "تسجيل")]] : [[Plus, L("Task", "مهمة")], [AlarmClock, L("Alarm", "منبه")], [Droplet, L("Water", "ماء")], [Timer, L("Focus", "تركيز")], [StickyNote, L("Note", "ملاحظة")], [Link2, L("Link", "رابط")]];
        const n = small ? 1 : wide ? Math.min(acts.length, w * 1.5) : Math.min(acts.length, w * h);
        return <div className="grid h-full gap-1.5 p-2" style={{ gridTemplateColumns: `repeat(${small ? 1 : wide ? Math.ceil(n) : Math.min(3, w + 1)}, 1fr)` }}>{acts.slice(0, Math.ceil(n)).map(([I, l], i) => { const Ic = I as typeof Plus; return <button key={i} onClick={stop(() => { if (l === L("Water", "ماء")) s.addWater(250); })} className="flex flex-col items-center justify-center gap-0.5 rounded-xl" style={{ background: dark ? "#ffffff14" : "#0000000a" }}><Ic size={18} style={{ color: acc }} />{!small && <span className="text-[10px]">{l as string}</span>}</button>; })}</div>;
      }
      case "prayer": {
        const ornate = def.id.includes("ornate") || def.id.includes("mosque");
        const nx = prayer.next;
        if (small) {
          return (
            <div className="flex h-full flex-col items-center justify-center p-1.5 text-center" style={{ backgroundImage: ornate ? tileDataUri("islamic", st.c1, 0.22, 36) : undefined }}>
              <span className="truncate text-[9px] font-semibold" style={sub}>{nx ? L(nx.name, nx.nameAr) : "—"}</span>
              <span className="text-sm font-extrabold tabular-nums leading-tight" style={{ color: acc }}>{nx ? clockFormat(nx.time) : "—"}</span>
            </div>
          );
        }
        if (wide && w === 2) {
          return (
            <div className="flex h-full items-center justify-between gap-2 px-3 py-2" style={{ backgroundImage: ornate ? tileDataUri("islamic", st.c1, 0.18, 40) : undefined }}>
              <div className="min-w-0">
                <div className="truncate text-[10px]" style={sub}>{L("Next prayer", "الصلاة القادمة")}</div>
                <div className="truncate text-sm font-bold leading-tight">{nx ? L(nx.name[0].toUpperCase() + nx.name.slice(1), nx.nameAr) : "—"}</div>
              </div>
              <div className="text-end flex-none">
                <div className="text-base font-extrabold tabular-nums" style={{ color: acc }}>{nx ? clockFormat(nx.time) : "—"}</div>
                <div className="text-[9px]" style={sub}>{nx ? `-${N(Math.floor(nx.inMin / 60))}h ${N(nx.inMin % 60)}m` : ""}</div>
              </div>
            </div>
          );
        }
        const cols = wide ? "grid-cols-6" : big ? "grid-cols-2" : "grid-cols-2";
        return (
          <div className="flex h-full flex-col overflow-hidden p-2.5" style={{ backgroundImage: ornate ? tileDataUri("islamic", st.c1, 0.2, 46) : undefined }}>
            {h >= 2 && (
              <div className="mb-1 flex items-baseline justify-between gap-1">
                <span className="truncate text-[11px] font-bold">{L("Prayer times", "مواقيت الصلاة")}</span>
                <span className="truncate text-[9px]" style={sub}>{L(CITIES[s.cityIndex]?.city || "Cairo", CITIES[s.cityIndex]?.cityAr || "القاهرة")}</span>
              </div>
            )}
            <div className={`grid flex-1 gap-1 ${cols}`}>
              {PRAYER_NAMES.map(([k, en, ar, icon]) => {
                const isNext = prayer.next?.name === k;
                if (wide) {
                  return (
                    <div key={k} className="flex min-w-0 flex-col items-center justify-center rounded-lg px-0.5 py-1 text-center" style={isNext ? { background: acc, color: dark ? "#000" : "#fff" } : { background: "#8881" }}>
                      <span className="text-[9px] leading-none">{icon}</span>
                      <span className="mt-0.5 w-full truncate text-[8px] leading-tight">{L(en, ar)}</span>
                      <span className="text-[10px] font-bold tabular-nums leading-tight">{clockFormat(prayer[k as "fajr"])}</span>
                    </div>
                  );
                }
                return (
                  <div key={k} className="flex min-w-0 items-center gap-1 rounded-md px-1.5 py-[1px]" style={isNext ? { background: acc, color: dark ? "#000" : "#fff" } : undefined}>
                    {big && <span className="text-[10px]">{icon}</span>}
                    <span className="min-w-0 flex-1 truncate text-[10px] leading-tight">{L(en, ar)}</span>
                    <span className="text-[10px] font-bold tabular-nums">{clockFormat(prayer[k as "fajr"])}</span>
                  </div>
                );
              })}
            </div>
            {big && <p className="mt-1.5 truncate text-[10px]" style={sub}>{N(hj.d)} {HIJRI_MONTHS[lang][hj.m - 1]} · {L("Egyptian Survey Authority", "الهيئة المصرية للمساحة")}</p>}
          </div>
        );
      }
      case "nextprayer": {
        const nx = prayer.next;
        const val = nx ? Math.max(0, Math.min(1, 1 - nx.inMin / 240)) : 0;
        const rSz = Math.max(36, Math.min(H - 16, small ? W - 14 : wide ? H - 14 : W * 0.42));
        return (
          <div className="relative flex h-full items-center justify-center gap-2.5 overflow-hidden p-2.5" style={{ backgroundImage: tileDataUri("islamic", st.c2, 0.14, 48) }}>
            {ringEl(val, nx ? `${Math.floor(nx.inMin / 60)}:${pad(nx.inMin % 60)}` : "—", rSz)}
            {!small && <div className="min-w-0 flex-1">
              <p className="truncate text-[10px]" style={sub}>{L("Next prayer", "الصلاة القادمة")}</p>
              <p className="truncate text-sm font-bold leading-tight">{nx ? L(nx.name[0].toUpperCase() + nx.name.slice(1), nx.nameAr) : "—"}</p>
              <p className="truncate text-xs font-semibold tabular-nums" style={{ color: acc }}>{nx ? clockFormat(nx.time) : ""}</p>
              {h >= 2 && <p className="mt-0.5 truncate text-[9px]" style={sub}>{L(CITIES[s.cityIndex]?.city, CITIES[s.cityIndex]?.cityAr)} · {N(prayer.fajr)} / {N(prayer.maghrib)}</p>}
            </div>}
          </div>
        );
      }
      case "tri": return <div className="flex h-full flex-col justify-center gap-0.5 p-3"><div className="font-bold" style={{ fontSize: small ? 22 : 18 }}>{N(now.getDate())} {!small && now.toLocaleDateString(lang === "ar" ? "ar-EG" : "en", { month: "long" })}</div>{(!small || def.id.includes("hijri")) && <div className="text-xs" style={{ color: acc }}>{N(hj.d)} {HIJRI_MONTHS[lang][hj.m - 1]} {h >= 2 && N(hj.y)}</div>}{!small && <div className="text-xs" style={sub}>{N(cp.d)} {COPTIC_MONTHS[lang][cp.m - 1]} {h >= 2 && N(cp.y)}</div>}</div>;
    }
  })();

  return (
    <div className={`w w-${style} w-scrim`} style={{ width: W, height: H, ...seasonalVars, fontFamily: (WIDGET_FONTS[s.widgetFont] || WIDGET_FONTS.sans).stack, pointerEvents: def.interactive ? "auto" : "none" }} aria-label={def[lang]}>
      <div className="relative h-full">{body}</div>
      {s.decorSurfaces.widgets && s.intensity !== "off" && !small && <SeasonArt family={fam} size={Math.min(26, H * 0.22)} style={{ insetInlineEnd: 6, bottom: 6, opacity: 0.9 }} />}
    </div>
  );
}

function Stopwatch({ L, small, acc }: { L: (a: string, b: string) => string; small: boolean; acc: string }) {
  const [run, setRun] = useState(false); const [t, setT] = useState(0);
  useEffect(() => { if (!run) return; const s = Date.now() - t; const i = setInterval(() => setT(Date.now() - s), 100); return () => clearInterval(i); }, [run]); // eslint-disable-line
  const txt = `${pad(Math.floor(t / 60000))}:${pad(Math.floor(t / 1000) % 60)}`;
  return <div className="flex h-full flex-col items-center justify-center gap-1"><div className="font-mono text-xl font-bold">{txt}</div><button onClick={(e) => { e.stopPropagation(); setRun(!run); }} className="grid h-7 w-7 place-items-center rounded-full text-white" style={{ background: acc }} aria-label={run ? L("Pause", "إيقاف") : L("Start", "ابدأ")}>{run ? <Pause size={13} /> : <Play size={13} />}</button>{!small && <button onClick={(e) => { e.stopPropagation(); setT(0); setRun(false); }} className="text-[10px] opacity-60">{L("Reset", "تصفير")}</button>}</div>;
}

function FocusRing({ small, acc, L }: { small: boolean; acc: string; L: (a: string, b: string) => string }) {
  const [left, setLeft] = useState(25 * 60); const [run, setRun] = useState(false);
  useEffect(() => { if (!run) return; const i = setInterval(() => setLeft((x) => Math.max(0, x - 1)), 1000); return () => clearInterval(i); }, [run]);
  const v = 1 - left / 1500, r = 30, c = 2 * Math.PI * r;
  return <div className="flex h-full items-center justify-center gap-2"><button onClick={(e) => { e.stopPropagation(); setRun(!run); }} className="relative grid place-items-center" aria-label={L("Focus", "تركيز")}><svg width="76" height="76" className="-rotate-90"><circle cx="38" cy="38" r={r} fill="none" stroke="currentColor" strokeOpacity=".14" strokeWidth="6" /><circle cx="38" cy="38" r={r} fill="none" stroke={acc} strokeWidth="6" strokeLinecap="round" strokeDasharray={c} strokeDashoffset={c * (1 - v)} /></svg><span className="absolute text-sm font-bold">{pad(Math.floor(left / 60))}:{pad(left % 60)}</span></button>{!small && <span className="text-[10px] opacity-60">{run ? L("Tap to pause", "اضغط للإيقاف") : L("Tap to start", "اضغط للبدء")}</span>}</div>;
}

function BatteryW({ small, acc, L, N }: { small: boolean; acc: string; L: (a: string, b: string) => string; N: (n: number | string) => string }) {
  const [b, setB] = useState<{ level: number; charging: boolean } | null>(null);
  useEffect(() => { const nav = navigator as Navigator & { getBattery?: () => Promise<{ level: number; charging: boolean }> }; nav.getBattery?.().then((x) => setB({ level: x.level, charging: x.charging })).catch(() => {}); }, []);
  const lv = b ? Math.round(b.level * 100) : null;
  return <div className="flex h-full flex-col items-center justify-center"><div className="text-2xl font-bold" style={{ color: acc }}>{lv === null ? "—" : N(lv) + "%"}</div>{!small && <div className="text-[10px] opacity-60">{lv === null ? L("Battery API unavailable here", "واجهة البطارية غير متاحة هنا") : b?.charging ? L("Charging", "يشحن") : L("On battery", "على البطارية")}</div>}</div>;
}
