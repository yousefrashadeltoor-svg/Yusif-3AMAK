// Chat Markdown renderer.
// Choice: react-markdown (unified/remark/rehype) — pure React elements (no dangerouslySetInnerHTML),
// remark-gfm (tables, task lists, strikethrough, autolinks), rehype-sanitize (XSS-safe schema) and
// rehype-highlight (highlight.js grammars, themed with the app's CSS variables so every theme pack works).
import { memo, useMemo, useState, type ComponentProps, type ReactNode } from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import rehypeSanitize, { defaultSchema } from "rehype-sanitize";
import rehypeHighlight from "rehype-highlight";
import { Check, Copy } from "lucide-react";

const schema = {
  ...defaultSchema,
  attributes: {
    ...defaultSchema.attributes,
    code: [...(defaultSchema.attributes?.code || []), ["className", /^language-[\w+#.-]+$/]],
    span: [...(defaultSchema.attributes?.span || []), ["className", /^hljs-[\w-]+$/]],
  },
  protocols: { ...defaultSchema.protocols, href: ["http", "https", "mailto", "tel"], src: ["http", "https"] },
};

/** Closes constructs a half-streamed answer leaves open so the layout never flickers while tokens arrive. */
export function completeStreaming(text: string): string {
  let out = text;
  const fences = out.match(/^ {0,3}(```|~~~)/gm)?.length || 0;
  if (fences % 2 === 1) return out + (out.endsWith("\n") ? "" : "\n") + "```";
  out = out.replace(/\[([^\]\n]*)\]\((?:[^)\s]*)$/, "$1");            // dangling "[label](http://par"
  out = out.replace(/\[([^\]\n]*)$/, "$1");                              // dangling "[label"
  out = out.replace(/(^|[^\\`])`([^`\n]*)$/, (_m, a, b) => `${a}\`${b}\``);  // unclosed inline code
  if ((out.match(/\*\*/g)?.length || 0) % 2 === 1) out += "**";
  else if ((out.replace(/\*\*/g, "").match(/(?<![\w*])\*(?=\S)/g)?.length || 0) % 2 === 1 && !/^\s*[*]\s/m.test(out.split("\n").at(-1) || "")) out += "*";
  if ((out.match(/~~/g)?.length || 0) % 2 === 1) out += "~~";
  return out;
}

/** Splits at blank lines outside fences so finished blocks stay memoised while only the tail re-renders. */
export function splitBlocks(text: string): string[] {
  const blocks: string[] = []; let cur: string[] = []; let fence = false;
  for (const line of text.split("\n")) {
    if (/^ {0,3}(```|~~~)/.test(line)) fence = !fence;
    if (!fence && line.trim() === "" && cur.length && !cur.at(-1)!.match(/^\s*$/)) { cur.push(line); blocks.push(cur.join("\n")); cur = []; continue; }
    cur.push(line);
  }
  if (cur.length) blocks.push(cur.join("\n"));
  return blocks;
}

const textOf = (n: ReactNode): string => typeof n === "string" || typeof n === "number" ? String(n) : Array.isArray(n) ? n.map(textOf).join("") : n && typeof n === "object" && "props" in n ? textOf((n as { props: { children?: ReactNode } }).props.children) : "";

export function copyText(value: string): Promise<boolean> {
  const fallback = () => { try { const t = document.createElement("textarea"); t.value = value; t.style.position = "fixed"; t.style.opacity = "0"; document.body.appendChild(t); t.select(); const ok = document.execCommand("copy"); t.remove(); return ok; } catch { return false; } };
  return navigator.clipboard?.writeText ? navigator.clipboard.writeText(value).then(() => true, () => fallback()) : Promise.resolve(fallback());
}

export function CopyButton({ value, label, className = "" }: { value: string; label?: string; className?: string }) {
  const [done, setDone] = useState(false);
  return (
    <button type="button" onClick={async () => { if (await copyText(value)) { setDone(true); setTimeout(() => setDone(false), 1600); } }} className={`md-copy ${done ? "is-done" : ""} ${className}`} aria-label={label || "Copy"}>
      {done ? <Check size={13} /> : <Copy size={13} />}{label && <span>{done ? "✓" : label}</span>}
    </button>
  );
}

function CodeBlock({ children }: { children?: ReactNode }) {
  const child = Array.isArray(children) ? children[0] : children;
  const props = (child && typeof child === "object" && "props" in child ? (child as { props: { className?: string; children?: ReactNode } }).props : { className: "", children });
  const lang = /language-([\w+#.-]+)/.exec(props.className || "")?.[1] || "";
  const raw = textOf(props.children).replace(/\n$/, "");
  return (
    <div className="md-code" dir="ltr">
      <div className="md-code-bar"><span>{lang || "text"}</span><CopyButton value={raw} label="Copy" /></div>
      <pre><code className={props.className}>{props.children}</code></pre>
    </div>
  );
}

const safeHref = (h?: string) => !!h && /^(https?:|mailto:|tel:|#)/i.test(h);

const components = {
  h1: (p: ComponentProps<"h1">) => <h1 dir="auto" {...p} />, h2: (p: ComponentProps<"h2">) => <h2 dir="auto" {...p} />,
  h3: (p: ComponentProps<"h3">) => <h3 dir="auto" {...p} />, h4: (p: ComponentProps<"h4">) => <h4 dir="auto" {...p} />,
  h5: (p: ComponentProps<"h5">) => <h5 dir="auto" {...p} />, h6: (p: ComponentProps<"h6">) => <h6 dir="auto" {...p} />,
  p: (p: ComponentProps<"p">) => <p dir="auto" {...p} />,
  li: (p: ComponentProps<"li">) => <li dir="auto" {...p} />,
  blockquote: (p: ComponentProps<"blockquote">) => <blockquote dir="auto" {...p} />,
  a: ({ href, children }: ComponentProps<"a">) => safeHref(href) ? <a href={href} target="_blank" rel="noopener noreferrer nofollow">{children}</a> : <span>{children}</span>,
  img: ({ src, alt }: ComponentProps<"img">) => typeof src === "string" && /^https?:/i.test(src) ? <img src={src} alt={alt || ""} loading="lazy" referrerPolicy="no-referrer" /> : null,
  pre: ({ children }: ComponentProps<"pre">) => <CodeBlock>{children}</CodeBlock>,
  table: (p: ComponentProps<"table">) => <div className="md-table"><table dir="auto" {...p} /></div>,
  input: (p: ComponentProps<"input">) => <input {...p} disabled readOnly className="md-check" />,
};

const Block = memo(function Block({ text, highlight }: { text: string; highlight: boolean }) {
  return (
    <ReactMarkdown remarkPlugins={[remarkGfm]} rehypePlugins={highlight ? [[rehypeSanitize, schema], [rehypeHighlight, { detect: false, ignoreMissing: true }]] : [[rehypeSanitize, schema]]} components={components}>
      {text}
    </ReactMarkdown>
  );
});

/** `streaming` closes partial syntax and skips highlighting of the live tail for smooth, flicker-free updates. */
export function Markdown({ text, streaming = false }: { text: string; streaming?: boolean }) {
  const blocks = useMemo(() => splitBlocks(streaming ? completeStreaming(text) : text), [text, streaming]);
  return <div className="md" dir="auto">{blocks.map((b, i) => <Block key={i} text={b} highlight={!(streaming && i === blocks.length - 1)} />)}</div>;
}

/** Plain-text version of a Markdown answer (for "copy as text"). */
export function markdownToPlain(md: string): string {
  return md.replace(/```[\w+#.-]*\n([\s\S]*?)```/g, "$1").replace(/^#{1,6}\s+/gm, "").replace(/(\*\*|__)(.*?)\1/g, "$2").replace(/(\*|_)(.*?)\1/g, "$2").replace(/~~(.*?)~~/g, "$1").replace(/`([^`]+)`/g, "$1").replace(/!\[([^\]]*)\]\([^)]*\)/g, "$1").replace(/\[([^\]]+)\]\(([^)]+)\)/g, "$1 ($2)").replace(/^>\s?/gm, "").replace(/^\s*[-*+]\s+/gm, "• ").replace(/^\s*---+\s*$/gm, "");
}
