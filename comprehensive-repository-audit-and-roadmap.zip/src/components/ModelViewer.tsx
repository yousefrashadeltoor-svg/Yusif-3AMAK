import { useEffect, useRef, useState } from "react";
import * as THREE from "three";
import { GLTFLoader } from "three/examples/jsm/loaders/GLTFLoader.js";
import { DRACOLoader } from "three/examples/jsm/loaders/DRACOLoader.js";
import { OBJLoader } from "three/examples/jsm/loaders/OBJLoader.js";
import { FBXLoader } from "three/examples/jsm/loaders/FBXLoader.js";
import { STLLoader } from "three/examples/jsm/loaders/STLLoader.js";
import { PLYLoader } from "three/examples/jsm/loaders/PLYLoader.js";
import { ColladaLoader } from "three/examples/jsm/loaders/ColladaLoader.js";
import { clone as skeletonClone } from "three/examples/jsm/utils/SkeletonUtils.js";
import { MeshoptDecoder } from "three/examples/jsm/libs/meshopt_decoder.module.js";
import { Upload, RotateCw, AlertTriangle, Loader2, CheckCircle2, Trash2, Box } from "lucide-react";
import { useStore, useT, fmtNum, newId } from "../lib/store";
import { saveModel, listModelsMeta, getModelData, deleteSavedModel, type SavedModelMeta } from "../lib/idb";
import { fmtBytes } from "../lib/media";

export interface ModelSource { id: string; name: string; url: string; credit: string; license: string }
export const PUBLIC_MODELS: ModelSource[] = [
  { id: "expressive", name: "RobotExpressive", url: "https://modelviewer.dev/shared-assets/models/RobotExpressive.glb", credit: "Tomás Laulhé · Don McCurdy", license: "CC0" },
  { id: "cesium", name: "CesiumMan", url: "https://raw.githubusercontent.com/KhronosGroup/glTF-Sample-Assets/main/Models/CesiumMan/glTF-Binary/CesiumMan.glb", credit: "Cesium (Khronos)", license: "CC-BY 4.0" },
  { id: "fox", name: "Fox", url: "https://raw.githubusercontent.com/KhronosGroup/glTF-Sample-Assets/main/Models/Fox/glTF-Binary/Fox.glb", credit: "PixelMannen (Khronos)", license: "CC0" },
];

export const ACCEPTED_3D = ".glb,.gltf,.obj,.fbx,.stl,.ply,.dae,model/gltf-binary,model/gltf+json,model/obj,model/stl";

export async function parseBuffer(buf: ArrayBuffer, ext: string): Promise<{ object: THREE.Object3D; animations: THREE.AnimationClip[] }> {
  const e = ext.toLowerCase();
  if (e === "glb" || e === "gltf") {
    const loader = new GLTFLoader();
    const draco = new DRACOLoader();
    draco.setDecoderPath("/draco/");
    loader.setDRACOLoader(draco);
    loader.setMeshoptDecoder(MeshoptDecoder);
    return new Promise((res, rej) => {
      loader.parse(buf, "", (gltf) => {
        draco.dispose();
        res({ object: gltf.scene, animations: gltf.animations || [] });
      }, (err) => { draco.dispose(); rej(err); });
    });
  }
  if (e === "obj") {
    const text = new TextDecoder().decode(buf);
    const obj = new OBJLoader().parse(text);
    return { object: obj, animations: [] };
  }
  if (e === "fbx") {
    const obj = new FBXLoader().parse(buf, "");
    return { object: obj, animations: obj.animations || [] };
  }
  if (e === "stl") {
    const geo = new STLLoader().parse(buf);
    geo.computeVertexNormals();
    const mesh = new THREE.Mesh(geo, new THREE.MeshStandardMaterial({ color: 0xc9d6e5, roughness: 0.45, metalness: 0.25 }));
    return { object: mesh, animations: [] };
  }
  if (e === "ply") {
    const geo = new PLYLoader().parse(buf);
    geo.computeVertexNormals();
    const hasColor = !!geo.getAttribute("color");
    const mesh = new THREE.Mesh(geo, new THREE.MeshStandardMaterial({ vertexColors: hasColor, color: hasColor ? 0xffffff : 0xc9d6e5, roughness: 0.5, metalness: 0.15 }));
    return { object: mesh, animations: [] };
  }
  if (e === "dae") {
    const text = new TextDecoder().decode(buf);
    const res = new ColladaLoader().parse(text, "");
    if (!res) throw new Error("Invalid Collada file");
    return { object: res.scene, animations: [] };
  }
  throw new Error("Unsupported 3D format: ." + e);
}

export function fitToStage(obj: THREE.Object3D) {
  obj.updateMatrixWorld(true);
  obj.traverse((child) => {
    const mesh = child as THREE.Mesh;
    if (mesh.isMesh) {
      if (!mesh.material) mesh.material = new THREE.MeshStandardMaterial({ color: 0xd0dae6, roughness: 0.5, metalness: 0.2 });
      const mats = Array.isArray(mesh.material) ? mesh.material : [mesh.material];
      mats.forEach((m) => { m.side = THREE.DoubleSide; });
    }
  });
  const box = new THREE.Box3().setFromObject(obj);
  const size = box.getSize(new THREE.Vector3());
  const maxDim = Math.max(size.x, size.y, size.z);
  const safeMax = Number.isFinite(maxDim) && maxDim > 0.0001 ? maxDim : 1;
  const scale = 2.2 / safeMax;
  obj.scale.multiplyScalar(scale);
  obj.updateMatrixWorld(true);
  const box2 = new THREE.Box3().setFromObject(obj);
  const c = box2.getCenter(new THREE.Vector3());
  const s2 = box2.getSize(new THREE.Vector3());
  if (Number.isFinite(c.x) && Number.isFinite(c.y) && Number.isFinite(c.z)) {
    obj.position.sub(c);
    obj.position.y += (Number.isFinite(s2.y) ? s2.y / 2 : 0) - 1.05;
  }
}

function captureThumb(obj: THREE.Object3D): string {
  const w = 160, h = 160;
  const scene = new THREE.Scene();
  scene.add(new THREE.HemisphereLight(0xffffff, 0x334455, 2.4));
  const key = new THREE.DirectionalLight(0xffffff, 2.2); key.position.set(3, 5, 4); scene.add(key);
  let clone: THREE.Object3D;
  try { clone = skeletonClone(obj); } catch { clone = obj.clone(); }
  scene.add(clone);
  const cam = new THREE.PerspectiveCamera(36, 1, 0.05, 100);
  cam.position.set(0.7, 0.45, 4.1);
  cam.lookAt(0, -0.05, 0);
  const r = new THREE.WebGLRenderer({ antialias: true, alpha: true, preserveDrawingBuffer: true });
  r.setSize(w, h);
  r.outputColorSpace = THREE.SRGBColorSpace;
  r.render(scene, cam);
  const url = r.domElement.toDataURL("image/png");
  r.forceContextLoss();
  r.dispose();
  return url;
}

export function ModelViewer({ height = 270 }: { height?: number }) {
  const t = useT();
  const s = useStore();
  const ref = useRef<HTMLDivElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const [saved, setSaved] = useState<SavedModelMeta[]>([]);
  const [state, setState] = useState<"loading" | "ready" | "error">("loading");
  const [errMsg, setErrMsg] = useState("");
  const [spin, setSpin] = useState(true);
  const [impPct, setImpPct] = useState<number | null>(null);
  const [impLabel, setImpLabel] = useState("");
  const [impDone, setImpDone] = useState("");

  const activeId = s.companion.modelId || "svg";
  const viewId = activeId === "svg" ? PUBLIC_MODELS[0].id : activeId;
  const setActiveId = (id: string) => s.set({ companion: { ...s.companion, modelId: id } });

  useEffect(() => { listModelsMeta().then(setSaved); }, []);

  useEffect(() => {
    const el = ref.current; if (!el) return;
    let raf = 0; let disposed = false;
    const width = Math.max(240, el.clientWidth || 320);
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(38, width / height, 0.05, 500);
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setPixelRatio(Math.min(2, window.devicePixelRatio || 1));
    renderer.setSize(width, height);
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    el.appendChild(renderer.domElement);
    renderer.domElement.style.width = "100%"; renderer.domElement.style.height = height + "px"; renderer.domElement.style.touchAction = "none";

    scene.add(new THREE.HemisphereLight(0xffffff, 0x334455, 2.2));
    const key = new THREE.DirectionalLight(0xffffff, 2.4); key.position.set(3, 6, 4); scene.add(key);
    const rim = new THREE.DirectionalLight(0x88bbff, 1.2); rim.position.set(-4, 2, -3); scene.add(rim);
    const floor = new THREE.Mesh(new THREE.CylinderGeometry(1.25, 1.4, 0.12, 48), new THREE.MeshStandardMaterial({ color: 0x1b2330, roughness: 0.7, metalness: 0.2 }));
    floor.position.y = -1.12; scene.add(floor);
    camera.position.set(0, 0.35, 4.4);

    let mixer: THREE.AnimationMixer | null = null;
    let model: THREE.Object3D | null = null;
    setState("loading"); setErrMsg("");

    (async () => {
      try {
        const pub = PUBLIC_MODELS.find((m) => m.id === viewId);
        let parsed: { object: THREE.Object3D; animations: THREE.AnimationClip[] };
        if (pub) {
          const r = await fetch(pub.url);
          if (!r.ok) throw new Error(`HTTP ${r.status}`);
          const buf = await r.arrayBuffer();
          parsed = await parseBuffer(buf, "glb");
        } else {
          const rec = await getModelData(viewId);
          if (!rec) {
            const firstPub = PUBLIC_MODELS[0];
            const r = await fetch(firstPub.url);
            parsed = await parseBuffer(await r.arrayBuffer(), "glb");
          } else {
            parsed = await parseBuffer(rec.data, rec.ext);
          }
        }
        if (disposed) return;
        model = parsed.object;
        fitToStage(model);
        scene.add(model);
        if (parsed.animations.length) {
          mixer = new THREE.AnimationMixer(model);
          mixer.clipAction(parsed.animations[0]).play();
        }
        setState("ready");
      } catch (e) {
        if (!disposed) { setState("error"); setErrMsg((e as Error).message); }
      }
    })();

    let dragging = false, lastX = 0, rotY = 0;
    const down = (e: PointerEvent) => { dragging = true; lastX = e.clientX; };
    const move = (e: PointerEvent) => { if (!dragging || !model) return; rotY += (e.clientX - lastX) * 0.01; lastX = e.clientX; model.rotation.y = rotY; };
    const up = () => { dragging = false; };
    renderer.domElement.addEventListener("pointerdown", down);
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", up);

    const clock = new THREE.Clock();
    const tick = () => {
      if (disposed) return;
      const dt = Math.min(0.05, clock.getDelta());
      if (mixer) mixer.update(dt);
      if (model && spin && !dragging) { model.rotation.y += dt * 0.45; rotY = model.rotation.y; }
      renderer.render(scene, camera);
      raf = requestAnimationFrame(tick);
    };
    tick();

    return () => {
      disposed = true; cancelAnimationFrame(raf);
      renderer.domElement.removeEventListener("pointerdown", down);
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
      renderer.dispose(); el.replaceChildren();
      scene.traverse((o) => { const m = o as THREE.Mesh; if (m.geometry) m.geometry.dispose(); });
    };
  }, [viewId, height, spin]);

  const handleUpload = (file: File) => {
    const ext = file.name.split(".").pop()?.toLowerCase() || "";
    if (file.size > 150 * 1024 * 1024) { setErrMsg(t("File is larger than 150 MB.", "الملف أكبر من ١٥٠ ميجا.")); return; }
    if (!["glb", "gltf", "obj", "fbx", "stl", "ply", "dae"].includes(ext)) {
      setErrMsg(t("Unsupported format. Use GLB, GLTF, OBJ, FBX, STL, PLY, or DAE.", "صيغة مش مدعومة. استخدم GLB أو GLTF أو OBJ أو FBX أو STL أو PLY أو DAE."));
      return;
    }
    setImpDone(""); setErrMsg(""); setImpPct(2); setImpLabel(t("Reading file…", "بيقرأ الملف…"));
    const reader = new FileReader();
    reader.onprogress = (ev) => {
      if (ev.lengthComputable) setImpPct(Math.max(5, Math.min(70, Math.round((ev.loaded / ev.total) * 70))));
    };
    reader.onerror = () => { setImpPct(null); setErrMsg(t("Could not read this file.", "معرفتش أقرأ الملف.")); };
    reader.onload = async () => {
      try {
        const buf = reader.result as ArrayBuffer;
        setImpPct(78); setImpLabel(t("Parsing 3D geometry…", "بيجهز المجسم 3D…"));
        await new Promise((r) => setTimeout(r, 20));
        const { object } = await parseBuffer(buf, ext);
        fitToStage(object);
        setImpPct(90); setImpLabel(t("Rendering thumbnail & saving…", "بيصور الموديل ويحفظه…"));
        let thumb = "";
        try { thumb = captureThumb(object); } catch { thumb = ""; }
        const id = "m-" + newId();
        await saveModel({ id, name: file.name, ext, size: file.size, thumb, addedAt: Date.now(), data: buf });
        const list = await listModelsMeta();
        setSaved(list);
        setActiveId(id);
        setImpPct(100); setImpLabel(t("Saved & applied!", "اتحفظ واتطبّق بنجاح!"));
        setImpDone(`${file.name} (${fmtBytes(file.size)})`);
        setTimeout(() => { setImpPct(null); setImpLabel(""); }, 1800);
      } catch (e) {
        setImpPct(null);
        setErrMsg(t("Failed to load 3D model: ", "فشل تحميل الموديل: ") + (e as Error).message);
      }
    };
    reader.readAsArrayBuffer(file);
  };

  const remove = async (id: string) => {
    await deleteSavedModel(id);
    const list = await listModelsMeta();
    setSaved(list);
    if (activeId === id) setActiveId(list[0]?.id || PUBLIC_MODELS[0].id);
  };

  const pubSel = PUBLIC_MODELS.find((m) => m.id === activeId);
  const savedSel = saved.find((m) => m.id === activeId);

  return (
    <div>
      <div className="card relative overflow-hidden" style={{ height }}>
        <div ref={ref} className="absolute inset-0 grid place-items-center" />
        {state === "loading" && <div className="absolute inset-0 grid place-items-center bg-black/5"><span className="flex items-center gap-2 text-xs muted"><Loader2 size={15} className="animate-spin" />{t("Loading 3D model…", "بيحمّل الموديل 3D…")}</span></div>}
        {state === "error" && <div className="absolute inset-0 grid place-items-center p-4 text-center"><div><AlertTriangle size={22} className="mx-auto mb-1 text-amber-500" /><p className="text-xs font-medium">{errMsg || t("Could not load online model offline — pick a saved model or upload yours.", "الموديل الأونلاين محتاج نت — اختار موديل محفوظ أو ارفع ملفك.")}</p></div></div>}
        <button onClick={() => setSpin(!spin)} className="absolute end-2 top-2 grid h-8 w-8 place-items-center rounded-full bg-black/35 text-white" aria-label={t("Auto-rotate", "دوران تلقائي")}><RotateCw size={14} className={spin ? "animate-spin" : ""} style={{ animationDuration: "5s" }} /></button>
        {savedSel && <span className="absolute bottom-2 start-2 rounded-full bg-black/45 px-2.5 py-0.5 text-[10px] font-semibold text-white backdrop-blur">{savedSel.name} · {savedSel.ext.toUpperCase()}</span>}
      </div>

      {impPct !== null && (
        <div className="card mt-2 p-3 fade-in">
          <div className="mb-1 flex items-center justify-between text-xs font-semibold"><span>{impLabel}</span><span className="accent tabular-nums">{fmtNum(impPct, s.lang)}%</span></div>
          <div className="h-2 overflow-hidden rounded-full" style={{ background: "var(--line)" }}><div className="h-full rounded-full transition-all duration-200" style={{ width: impPct + "%", background: impPct === 100 ? "#2fa36b" : "var(--accent)" }} /></div>
        </div>
      )}
      {impDone && impPct === null && <p className="mt-2 flex items-center gap-1.5 text-xs font-semibold text-green-600 fade-in"><CheckCircle2 size={14} />{t("Imported & saved offline:", "اتحفظ أوفلاين واتطبّق:")} {impDone}</p>}
      {errMsg && impPct === null && state !== "error" && <p className="mt-2 text-xs text-red-500">{errMsg}</p>}

      <div className="mt-3 flex flex-wrap gap-1.5">
        <button onClick={() => fileRef.current?.click()} className="btn btn-primary w-full py-3 text-sm"><Upload size={17} />{t("Upload a 3D model to be your assistant", "ارفع موديل 3D يكون مساعدك")}</button>
        <p className="w-full text-center text-[10px] muted">GLB · GLTF · OBJ · FBX · STL · PLY · DAE · {t("Draco & Meshopt compressed · up to 150 MB · saved offline", "مضغوط Draco و Meshopt · حتى ١٥٠ ميجا · يتحفظ أوفلاين")}</p>
        <input ref={fileRef} type="file" accept={ACCEPTED_3D} className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) handleUpload(f); e.target.value = ""; }} />
      </div>

      {saved.length > 0 && (
        <div className="mt-3">
          <p className="mb-1.5 text-xs font-bold">{t("Saved in app (works 100% offline)", "محفوظة داخل التطبيق (تعمل 100% أوفلاين)")} ({fmtNum(saved.length, s.lang)})</p>
          <div className="space-y-1.5">
            {saved.map((m) => {
              const on = activeId === m.id;
              return (
                <div key={m.id} className="card flex items-center gap-2.5 p-2" style={{ outline: on ? "2px solid var(--accent)" : undefined }}>
                  <button onClick={() => setActiveId(m.id)} className="flex min-w-0 flex-1 items-center gap-2.5 text-start">
                    {m.thumb ? <img src={m.thumb} alt="" className="h-11 w-11 flex-none rounded-xl object-contain" style={{ background: "var(--soft)" }} /> : <span className="grid h-11 w-11 flex-none place-items-center rounded-xl" style={{ background: "var(--soft)" }}><Box size={18} /></span>}
                    <span className="min-w-0 flex-1">
                      <span className="block truncate text-xs font-bold">{m.name}</span>
                      <span className="block text-[10px] muted">{m.ext.toUpperCase()} · {fmtBytes(m.size)}{on ? " · ✓ " + t("Applied", "مُطبّق") : ""}</span>
                    </span>
                  </button>
                  <button onClick={() => remove(m.id)} className="muted p-1.5" aria-label={t("Delete", "حذف")}><Trash2 size={14} /></button>
                </div>
              );
            })}
          </div>
        </div>
      )}

      <div className="mt-3">
        <p className="mb-1.5 text-[11px] font-semibold muted">{t("Public CC0 / CC-BY examples (require internet the first time)", "نماذج عامة CC0 / CC-BY (تحتاج نت)")}</p>
        <div className="flex flex-wrap gap-1.5">
          <button onClick={() => setActiveId("svg")} className="chip text-[11px]" aria-pressed={activeId === "svg"}>{t("Built-in robot (offline)", "الروبوت المدمج (أوفلاين)")}</button>
          {PUBLIC_MODELS.map((m) => <button key={m.id} onClick={() => setActiveId(m.id)} className="chip text-[11px]" aria-pressed={activeId === m.id}>{m.name} · {m.license}</button>)}
        </div>
      </div>
      {pubSel && <p className="mt-1 text-[10px] muted">{pubSel.name} · {pubSel.credit} · {pubSel.license}</p>}
    </div>
  );
}


/** Compact transparent 3D renderer used by the floating companion itself. */
export function Mini3D({ modelId, width, height }: { modelId: string; width: number; height: number }) {
  const ref = useRef<HTMLDivElement>(null);
  const [ok, setOk] = useState(true);
  useEffect(() => {
    const el = ref.current; if (!el) return;
    let raf = 0, disposed = false;
    const scene = new THREE.Scene();
    const cam = new THREE.PerspectiveCamera(34, width / height, 0.05, 100);
    cam.position.set(0, 0.2, 4.6);
    const r = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    r.setPixelRatio(Math.min(2, window.devicePixelRatio || 1)); r.setSize(width, height); r.outputColorSpace = THREE.SRGBColorSpace;
    el.appendChild(r.domElement); r.domElement.style.pointerEvents = "none";
    scene.add(new THREE.HemisphereLight(0xffffff, 0x334455, 2.4));
    const k = new THREE.DirectionalLight(0xffffff, 2.2); k.position.set(2, 4, 3); scene.add(k);
    let mixer: THREE.AnimationMixer | null = null, model: THREE.Object3D | null = null;
    (async () => {
      try {
        const pub = PUBLIC_MODELS.find((m) => m.id === modelId);
        let parsed;
        if (pub) parsed = await parseBuffer(await (await fetch(pub.url)).arrayBuffer(), "glb");
        else { const rec = await getModelData(modelId); if (!rec) throw new Error("missing"); parsed = await parseBuffer(rec.data, rec.ext); }
        if (disposed) return;
        model = parsed.object; fitToStage(model); scene.add(model);
        if (parsed.animations.length) { mixer = new THREE.AnimationMixer(model); mixer.clipAction(parsed.animations[0]).play(); }
      } catch { if (!disposed) setOk(false); }
    })();
    const clock = new THREE.Clock(); let acc = 0;
    const tick = () => {
      if (disposed) return;
      const dt = Math.min(0.05, clock.getDelta()); acc += dt;
      if (acc >= 1 / 30) { if (mixer) mixer.update(acc); if (model && !mixer) model.rotation.y += acc * 0.5; r.render(scene, cam); acc = 0; }
      raf = requestAnimationFrame(tick);
    };
    tick();
    return () => { disposed = true; cancelAnimationFrame(raf); r.forceContextLoss(); r.dispose(); el.replaceChildren(); };
  }, [modelId, width, height]);
  if (!ok) return null;
  return <div ref={ref} style={{ width, height }} />;
}
