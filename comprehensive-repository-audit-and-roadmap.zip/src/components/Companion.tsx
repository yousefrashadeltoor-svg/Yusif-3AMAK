import { useClockFormat } from "../lib/time";
import { useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { X, StickyNote, ListChecks, AlarmClock, Link2, Zap, MoreHorizontal, Plus, Check, Droplet, ExternalLink, EyeOff, Sparkles, Send, Loader2, PictureInPicture2, Bot, Wrench } from "lucide-react";
import type { Family } from "../lib/calendar";
import { resolveDecor, dayKey } from "../lib/calendar";
import { FAMILY, lanternPaths, starPath, lotusPath, heartPath } from "../lib/pattern";
import { makeChain, stepChain, stepSpring, type Chain, type Spring } from "../lib/physics";
import { useStore, useT, fmtNum, applyActionsDetailed } from "../lib/store";
import { normalizeUrl } from "../lib/media";
import { greeting, miniBrain, moodFor, moodLine, upcomingReminders, type Mood, type Bubble } from "../lib/soul";
import { providerById } from "../lib/providers";
import { streamChat, parseActions } from "../lib/ai";
import { contextualRequest } from "../lib/temporal";
import { seasonIcon, SeasonArt } from "./Decor";
import { Mini3D } from "./ModelViewer";

const BW = 120, BH = 154;

export function useRobotFamily(): Family {
  const userDays = useStore((s) => s.userDays);
  const outfit = useStore((s) => s.companion.outfit);
  const auto = resolveDecor(new Date(), userDays, 2).primary;
  if (outfit === "gold") return "ramadan";
  if (outfit === "snow") return "winter";
  if (outfit === "national") return "national";
  if (outfit === "none") return "friday";
  return auto;
}

function Outfit({ family, hand, mood }: { family: Family; hand?: { x: number; y: number }; mood: Mood }) {
  const st = FAMILY[family];
  if (family === "ramadan" && hand) return <g>{lanternPaths(hand.x, hand.y, 22).map((d, i) => <path key={i} d={d} fill={i === 1 ? st.c3 : st.c1} stroke={st.c1} strokeWidth="1" opacity={i === 1 ? 0.95 : 1} />)}<circle cx={hand.x} cy={hand.y + 12} r="3" fill="#ffd36b" opacity=".9" /></g>;
  if (family === "winter") return <g><path d="M42 64 Q60 74 78 64 L82 78 Q60 88 38 78Z" fill="#c8453b" stroke="#8f2a22" strokeWidth=".8" /><path d="M72 80 l7 26 l-9 0z" fill="#c8453b" /></g>;
  if (family === "national") return <g><path d="M40 70 L82 100" stroke="#ce1126" strokeWidth="5" /><path d="M40 75 L80 104" stroke="#fff" strokeWidth="4" /><path d="M40 80 L78 108" stroke="#111" strokeWidth="4" /></g>;
  if (family === "eid" || family === "birthday" || family === "newyear") return <g><path d="M50 22 L60 -4 L70 22Z" fill={st.c1} stroke={st.c2} strokeWidth="1" /><circle cx="60" cy="-5" r="3" fill={st.c2} /></g>;
  if (family === "spring" || family === "love" || mood === "happy") return <path d={family === "love" ? heartPath(80, 26, 8) : lotusPath(80, 26, 10, 5)} fill={st.c1} />;
  if (family === "islamic" || family === "friday") return <path d={starPath(60, 54, 8, 6, 3)} fill={st.c2} />;
  return null;
}

export function RobotMini({ size = 80, family = "islamic", mood = "idle" }: { size?: number; family?: Family; mood?: Mood }) {
  return (
    <svg viewBox={`0 -10 ${BW} ${BH + 6}`} width={size * 0.78} height={size} aria-hidden>
      <RobotBody head={0} eyes={{ x: 0, y: 0 }} mood={mood} family={family}
        arms={[[[34, 78], [24, 96], [20, 114]], [[86, 78], [96, 96], [100, 114]]]}
        legs={[[[48, 118], [46, 134]], [[72, 118], [74, 134]]]}
        ant={[[[50, 22], [44, 10], [40, 0]], [[70, 22], [76, 10], [80, 0]]]} />
    </svg>
  );
}

type Poly = number[][];
function RobotBody({ head, eyes, mood, family, arms, legs, ant }: { head: number; eyes: { x: number; y: number }; mood: Mood; family: Family; arms: Poly[]; legs: Poly[]; ant: Poly[] }) {
  const pl = (p: Poly) => p.map((q) => q.join(",")).join(" ");
  const sleeping = mood === "sleep";
  const eyeY = 43 + eyes.y * 2 - (mood === "think" ? 2 : 0);
  return (
    <g>
      <defs>
        <radialGradient id="rb-body" cx="35%" cy="30%" r="80%"><stop offset="0" stopColor="#ffffff" /><stop offset=".55" stopColor={mood === "cold" ? "#cfe3f5" : "#d9e2ee"} /><stop offset="1" stopColor="#8d9bb0" /></radialGradient>
        <radialGradient id="rb-visor" cx="40%" cy="30%" r="90%"><stop offset="0" stopColor={mood === "sad" ? "#3d3a52" : "#3a4a66"} /><stop offset="1" stopColor="#0d1424" /></radialGradient>
        <linearGradient id="rb-limb" x1="0" x2="1"><stop offset="0" stopColor="#c3cddb" /><stop offset="1" stopColor="#7d8aa0" /></linearGradient>
      </defs>
      <ellipse cx="60" cy="146" rx="26" ry="4" fill="#000" opacity=".15" />
      {mood === "celebrate" && <g fill="var(--accent2)">{[0, 1, 2, 3, 4].map((i) => <path key={i} d={starPath(18 + i * 22, 8 + (i % 2) * 8, 4, 5, 1.2)} className="twinkle" style={{ animationDelay: i * 0.2 + "s" }} />)}</g>}
      {legs.map((l, i) => <polyline key={i} points={pl(l)} fill="none" stroke="url(#rb-limb)" strokeWidth="9" strokeLinecap="round" strokeLinejoin="round" />)}
      {arms.map((a, i) => <g key={i}><polyline points={pl(a)} fill="none" stroke="url(#rb-limb)" strokeWidth="8" strokeLinecap="round" strokeLinejoin="round" /><circle cx={a[a.length - 1][0]} cy={a[a.length - 1][1]} r="5.5" fill="#e7edf5" stroke="#8d9bb0" /></g>)}
      <rect x="34" y="66" width="52" height="56" rx="18" fill="url(#rb-body)" stroke="#7f8ca2" strokeWidth="1" />
      <rect x="47" y="80" width="26" height="16" rx="5" fill="#0f1a2c" />
      <circle cx="60" cy="88" r="4" fill="var(--accent)" className="twinkle" />
      <g transform={`rotate(${head * 30} 60 64)`}>
        {ant.map((a, i) => <g key={i}><polyline points={pl(a)} fill="none" stroke="#7d8aa0" strokeWidth="2.5" strokeLinecap="round" /><circle cx={a[a.length - 1][0]} cy={a[a.length - 1][1]} r="4" fill={mood === "think" ? "#ffd36b" : "var(--accent2)"} className={mood === "think" ? "twinkle" : ""} /></g>)}
        <rect x="30" y="20" width="60" height="46" rx="20" fill="url(#rb-body)" stroke="#7f8ca2" strokeWidth="1" />
        <rect x="37" y="29" width="46" height="28" rx="13" fill="url(#rb-visor)" />
        {sleeping || mood === "wink" ? (
          <g stroke="#7fd6ff" strokeWidth="2.5" strokeLinecap="round" fill="none">
            <path d="M46 44 q4 3 8 0" />{mood === "wink" ? <path d="M66 44 h8" /> : <path d="M66 44 q4 3 8 0" />}
          </g>
        ) : mood === "sad" ? (
          <g stroke="#7fd6ff" strokeWidth="2.5" strokeLinecap="round" fill="none"><path d="M46 46 q4 -3 8 0" /><path d="M66 46 q4 -3 8 0" /></g>
        ) : mood === "happy" || mood === "celebrate" ? (
          <g stroke="#7fd6ff" strokeWidth="2.8" strokeLinecap="round" fill="none"><path d="M46 46 q4 -5 8 0" /><path d="M66 46 q4 -5 8 0" /></g>
        ) : (
          <g fill="#7fd6ff"><ellipse cx={50 + eyes.x * 3} cy={eyeY} rx="4" ry={mood === "worried" ? 5.5 : 5} className="twinkle" style={{ animationDuration: "4.5s" }} /><ellipse cx={70 + eyes.x * 3} cy={eyeY} rx="4" ry={mood === "worried" ? 5.5 : 5} className="twinkle" style={{ animationDuration: "4.5s" }} /></g>
        )}
        {mood === "happy" && <g fill="#ff9ab5" opacity=".65"><ellipse cx="43" cy="53" rx="4" ry="2.2" /><ellipse cx="77" cy="53" rx="4" ry="2.2" /></g>}
        {mood === "cold" && <g fill="#9fd6ff" opacity=".5"><ellipse cx="43" cy="53" rx="4" ry="2.2" /><ellipse cx="77" cy="53" rx="4" ry="2.2" /></g>}
        {mood === "sad" && <path d="M71 50 q2 5 0 7 q-3 -2 0 -7" fill="#8fd8ff" opacity=".9" />}
        {mood === "worried" && <path d="M82 34 q3 5 0 7 q-4 -2 0 -7" fill="#bfe8ff" opacity=".9" />}
        <ellipse cx="44" cy="27" rx="8" ry="3" fill="#fff" opacity=".7" />
      </g>
      <Outfit family={family} hand={{ x: arms[1][arms[1].length - 1][0], y: arms[1][arms[1].length - 1][1] }} mood={mood} />
      {mood === "celebrate" && <g fill={FAMILY[family].c3} opacity=".9"><circle cx="18" cy="30" r="2" /><circle cx="104" cy="24" r="2.5" /><circle cx="100" cy="60" r="1.8" /></g>}
    </g>
  );
}

export function Companion({ onOpenApp }: { onOpenApp: (tab: string, sub?: string) => void }) {
  const cfg = useStore((s) => s.companion);
  const setCfg = (p: Partial<typeof cfg>) => useStore.getState().set({ companion: { ...cfg, ...p } });
  const reduce = useStore((s) => s.reduceMotion);
  const lang = useStore((s) => s.lang);
  const tasks = useStore((s) => s.tasks);
  const alarms = useStore((s) => s.alarms);
  const t = useT();
  const family = useRobotFamily();
  const scale = cfg.size;
  const W = BW * 0.74 * scale, H = BH * 0.74 * scale;
  const [pos, setPos] = useState(() => ({ x: Math.max(8, window.innerWidth - W - 10), y: Math.max(60, window.innerHeight - H - 120) }));
  const [, force] = useState(0);
  const [bubble, setBubble] = useState<Bubble | null>(null);
  const [shown, setShown] = useState("");
  const [panel, setPanel] = useState(false);
  const [pip, setPip] = useState<Window | null>(null);
  const dismissed = useRef<Record<string, number>>({});
  const sim = useRef<{ arms: Chain[]; legs: Chain[]; ant: Chain[]; head: Spring; tilt: Spring; vx: number; vy: number; x: number; y: number; drag: boolean; gx: number; gy: number; look: { x: number; y: number }; last: number; idleSince: number; downAt: { x: number; y: number; t: number } | null; grab: { x: number; y: number }; tx: number | null; hist: Array<{ x: number; y: number; t: number }> } | null>(null);
  if (!sim.current) sim.current = {
    arms: [makeChain(34, 78, 2, 18, 1.9, 1.3), makeChain(86, 78, 2, 18, 1.25, 1.3)],
    legs: [makeChain(48, 118, 1, 16, 1.62, 0.5), makeChain(72, 118, 1, 22, 1.52, 0.9)],
    ant: [makeChain(50, 22, 2, 11, -2.0, 0.7), makeChain(70, 22, 2, 11, -1.15, 0.7)],
    head: { v: 0, w: 0 }, tilt: { v: 0, w: 0 }, vx: 0, vy: 0, x: pos.x, y: pos.y, drag: false, gx: 0, gy: 900, look: { x: 0, y: 0 }, last: performance.now(), idleSince: performance.now(), downAt: null, grab: { x: 0, y: 0 }, tx: null, hist: [],
  };
  const raf = useRef<number | null>(null);
  const noteRef = useRef<Notification | null>(null);

  // ---- bubble ticker: reminders + moods, Egyptian dialect, directly above the head ----
  useEffect(() => {
    if (!cfg.bubbles || cfg.hidden) return;
    const rotate = () => {
      const now = Date.now();
      const reminders = upcomingReminders(alarms, tasks, lang, new Date()).filter((b) => now - (dismissed.current[b.id] || 0) > 12 * 60e3);
      const today = dayKey(new Date());
      const mine = tasks.filter((t) => t.date === today);
      const mood = moodFor(tasks);
      const lines: Bubble[] = [...reminders];
      if (!lines.length) {
        if (mine.length && mine.every((m) => m.done)) lines.push({ id: "mood-done", kind: "mood", mood: "celebrate", at: now, text: lang === "ar" ? "خلصت كل مهام النهاردة! أنا فخور بيك 🎉" : "All today's tasks are done! 🎉" });
        else lines.push({ id: "mood-" + mood, kind: "mood", mood, at: now, text: moodLine(mood, lang) });
      }
      const line = lines[Math.floor(now / 9000) % lines.length];
      setBubble(line);
    };
    rotate();
    const iv = setInterval(rotate, 9000);
    return () => clearInterval(iv);
  }, [cfg.bubbles, cfg.hidden, alarms, tasks, lang]);

  useEffect(() => {
    if (!bubble) { setShown(""); return; }
    let i = 0; setShown("");
    const iv = setInterval(() => { i += 2; setShown(bubble.text.slice(0, i)); if (i >= bubble.text.length) clearInterval(iv); }, 16);
    return () => clearInterval(iv);
  }, [bubble]);

  const wake = () => { const s = sim.current!; s.idleSince = performance.now(); };
  const loop = () => {
    const s = sim.current!;
    const tick = (now: number) => {
      let dt = Math.min(0.05, (now - s.last) / 1000); s.last = now;
      const steps = Math.min(4, Math.ceil(dt / (1 / 60))); dt = dt / steps;
      for (let k = 0; k < steps; k++) {
        if (!s.drag) {
          s.vx *= 0.94; s.vy *= 0.94;
          const maxX = window.innerWidth - W - 6, maxY = window.innerHeight - H - 80;
          if (Math.abs(s.vx) < 40 && Math.abs(s.vy) < 40) { if (s.tx === null) s.tx = s.x + W / 2 < window.innerWidth / 2 ? 6 : maxX; s.vx += (s.tx - s.x) * 18 * dt; }
          s.x += s.vx * dt; s.y += s.vy * dt;
          if (s.x < 6) { s.x = 6; s.vx = -s.vx * 0.4; } if (s.x > maxX) { s.x = maxX; s.vx = -s.vx * 0.4; }
          if (s.y < 10) { s.y = 10; s.vy = -s.vy * 0.4; } if (s.y > maxY) { s.y = maxY; s.vy = -s.vy * 0.4; }
        }
        const bodyAngle = Math.max(-0.5, Math.min(0.5, -s.vx / 1600));
        stepSpring(s.tilt, bodyAngle, 60, 9, dt, -0.5, 0.5);
        const gx = s.gx - s.vx * 3, gy = s.gy - s.vy * 2;
        const breathe = Math.sin(now / 900) * 0.6;
        stepSpring(s.head, s.look.x * 0.18 + s.gx / 5000 - s.vx / 4000, 40, 7, dt, -0.45, 0.45);
        s.arms.forEach((c, i) => stepChain(c, i ? 86 : 34, 78 + breathe, gx, gy, dt, 0, 0.9, s.drag ? 0.02 : 0.06));
        s.legs.forEach((c, i) => stepChain(c, i ? 72 : 48, 118, gx, gy, dt, 0, 0.88, 0.12));
        const h = s.head.v * 0.52;
        s.ant.forEach((c, i) => { const ax = i ? 70 : 50, ay = 22; const rx = 60 + (ax - 60) * Math.cos(h) - (ay - 64) * Math.sin(h), ry = 64 + (ax - 60) * Math.sin(h) + (ay - 64) * Math.cos(h); stepChain(c, rx, ry, gx * 0.6, gy * 0.6, dt, h, 0.9, 0.1); });
      }
      setPos({ x: s.x, y: s.y });
      force((n) => (n + 1) % 1e6);
      const idle = now - s.idleSince;
      const moving = Math.abs(s.vx) + Math.abs(s.vy) > 2 || s.drag;
      if (!moving && idle > 40000) { raf.current = null; return; }
      raf.current = requestAnimationFrame(tick);
    };
    raf.current = requestAnimationFrame(tick);
  };

  useEffect(() => {
    if (reduce || cfg.hidden) return;
    loop();
    const onOri = (e: DeviceOrientationEvent) => { const s = sim.current!; if (e.gamma == null) return; s.gx = Math.sin(((e.gamma || 0) * Math.PI) / 180) * 900; s.gy = 900 * Math.cos(((e.gamma || 0) * Math.PI) / 180); };
    const onResize = () => { const s = sim.current!; s.tx = null; wake(); };
    window.addEventListener("deviceorientation", onOri);
    window.addEventListener("resize", onResize);
    return () => { if (raf.current) cancelAnimationFrame(raf.current); raf.current = null; window.removeEventListener("deviceorientation", onOri); window.removeEventListener("resize", onResize); };
  }, [reduce, cfg.hidden]); // eslint-disable-line

  const onDown = (e: React.PointerEvent) => {
    const s = sim.current!;
    try { (e.currentTarget as Element).setPointerCapture(e.pointerId); } catch { /* ignore */ }
    s.drag = true; s.tx = null; s.grab = { x: e.clientX - s.x, y: e.clientY - s.y };
    s.downAt = { x: e.clientX, y: e.clientY, t: performance.now() }; s.hist = []; wake();
    if (raf.current === null && !reduce) loop();
  };
  const onMove = (e: React.PointerEvent) => {
    const s = sim.current!; const cx = s.x + W / 2, cy = s.y + H * 0.3;
    s.look = { x: Math.max(-1, Math.min(1, (e.clientX - cx) / 200)), y: Math.max(-1, Math.min(1, (e.clientY - cy) / 200)) };
    if (!s.drag) return;
    if (s.downAt && Math.hypot(e.clientX - s.downAt.x, e.clientY - s.downAt.y) < 8) return;
    const nx = e.clientX - s.grab.x, ny = e.clientY - s.grab.y; const now = performance.now();
    s.hist.push({ x: nx, y: ny, t: now }); s.hist = s.hist.filter((h) => now - h.t < 90);
    const h0 = s.hist[0]; const dt = Math.max(0.016, (now - h0.t) / 1000);
    s.vx = (nx - h0.x) / dt; s.vy = (ny - h0.y) / dt; s.x = nx; s.y = ny;
    if (reduce) setPos({ x: nx, y: ny });
  };
  const onUp = (e: React.PointerEvent) => {
    const s = sim.current!; s.drag = false;
    const d = s.downAt; s.downAt = null;
    if (d && Math.hypot(e.clientX - d.x, e.clientY - d.y) < 16 && performance.now() - d.t < 550) { s.vx = 0; s.vy = 0; setPanel((p) => !p); setBubble(null); }
    if (reduce) { const maxX = window.innerWidth - W - 6; s.x = s.x + W / 2 < window.innerWidth / 2 ? 6 : maxX; setPos({ x: s.x, y: s.y }); }
    wake();
  };

  // ---- real floating window over other apps (Document Picture-in-Picture) ----
  const openPip = async () => {
    const dp = (window as unknown as { documentPictureInPicture?: { requestWindow: (o: { width: number; height: number }) => Promise<Window> } }).documentPictureInPicture;
    if (!dp) { setPanel(false); onOpenApp("me", "companion"); return; }
    try {
      const w = await dp.requestWindow({ width: 240, height: 280 });
      for (const sheet of Array.from(document.styleSheets)) { try { const css = Array.from(sheet.cssRules).map((r) => r.cssText).join(""); const st = w.document.createElement("style"); st.textContent = css; w.document.head.appendChild(st); } catch { /* cross-origin sheet */ } }
      w.document.body.style.margin = "0"; w.document.body.style.background = "transparent";
      setPip(w); setPanel(false);
      w.addEventListener("pagehide", () => setPip(null));
    } catch { onOpenApp("me", "companion"); }
  };

  const hide = async () => {
    setPanel(false);
    if (cfg.notify) {
      try {
        const perm = Notification.permission === "granted" ? "granted" : await Notification.requestPermission();
        if (perm === "granted") { const n = new Notification("DAYFLOW — الرفيق مستخفي", { body: "اضغط هنا ترجّعه تاني في أي وقت 👋", tag: "dayflow-robot", icon: seasonIcon(family) }); noteRef.current = n; n.onclick = () => { setCfg({ hidden: false }); n.close(); }; }
      } catch { /* notifications unavailable */ }
    }
    setCfg({ hidden: true });
  };

  const s = sim.current!;
  const pos0 = { x: pos.x, y: pos.y };
  const arms = reduce ? [[[34, 78], [26, 96], [24, 114]], [[86, 78], [94, 96], [96, 114]] as Poly] : s.arms.map((c) => c.pts.map((p) => [p.x, p.y]));
  const legs = reduce ? [[[48, 118], [47, 134]], [[72, 118], [73, 134]]] as Poly[] : s.legs.map((c) => c.pts.map((p) => [p.x, p.y]));
  const ant = reduce ? [[[50, 22], [44, 12], [40, 2]], [[70, 22], [76, 12], [80, 2]]] as Poly[] : s.ant.map((c) => c.pts.map((p) => [p.x, p.y]));
  const onLeft = pos0.x + W / 2 < window.innerWidth / 2;
  const mood: Mood = bubble?.mood || cfg.emotion;

  if (!cfg.enabled) return null;

  if (cfg.hidden) return (
    <>
      <button onClick={() => setCfg({ hidden: false })} className="fixed bottom-[calc(var(--tabbar-h)+6rem)] end-3 z-[54] flex items-center gap-2 rounded-full px-3 py-2 text-xs font-bold shadow-lg" style={{ background: "var(--accent)", color: "var(--on-accent)" }} aria-label={t("Bring the companion back", "رجّع الرفيق")}>
        <Bot size={15} />{t("Bring companion back", "رجّع الرفيق")}
      </button>
      {pip && <PipRobot win={pip} bubble={bubble?.text || greeting(lang)} lang={lang} family={family} mood={mood} />}
    </>
  );

  return (
    <>
      <div className="fixed z-[55] touch-none select-none" style={{ left: pos0.x, top: pos0.y, width: W, height: H, opacity: cfg.opacity, transform: `rotate(${(s.tilt.v * 180) / Math.PI}deg)` }}>
        {cfg.bubbles && bubble && (
          <div className="absolute z-10" style={{ bottom: "calc(100% - 2px)", [onLeft ? "left" : "right"]: 0, maxWidth: 232 }} role="status" aria-live="polite">
            <div className="relative rounded-2xl px-3 py-2 text-[12.5px] font-medium leading-snug shadow-lg fade-in" style={{ background: "var(--surface)", color: "var(--text)", border: "1px solid var(--line)", borderRadius: 16 }}>
              <div className="mb-0.5 flex items-center gap-1 text-[10px] font-bold opacity-60"><Sparkles size={11} className="accent" />DAYFLOW</div>
              <SeasonArt family={family} size={22} style={{ top: -12, insetInlineStart: -8 }} />
              {shown || bubble.text}
              {bubble.text.length > (shown.length || bubble.text.length) && <span className="twinkle">|</span>}
              {bubble.action && <button onClick={() => onOpenApp(bubble.action === "alarms" ? "alarms" : bubble.action === "tasks" ? "tools" : "me", bubble.action === "tasks" ? "tasks" : bubble.action === "habits" ? "habits" : bubble.action === "media" ? "media" : undefined)} className="mt-1 flex items-center gap-1 text-[11px] font-bold accent">{t("Open", "افتح")}<ExternalLink size={10} /></button>}
              <button onClick={() => { dismissed.current[bubble.id] = Date.now(); setBubble(null); }} className="absolute -end-1.5 -top-1.5 grid h-5 w-5 place-items-center rounded-full bg-black/60 text-white" aria-label={t("Hide message", "إخفاء الرسالة")}><X size={11} /></button>
              <span className="absolute -bottom-[5px] h-3 w-3 rotate-45" style={{ background: "var(--surface)", borderBottom: "1px solid var(--line)", borderRight: "1px solid var(--line)", [onLeft ? "left" : "right"]: 22 }} />
            </div>
          </div>
        )}
        <div className="absolute -end-1 top-1 z-20 flex flex-col gap-1 opacity-0 transition-opacity hover:opacity-100 focus-within:opacity-100 group-hover:opacity-100" style={{ opacity: 0.55 }}>
          <button onClick={hide} className="grid h-6 w-6 place-items-center rounded-full bg-white/85 text-black shadow" aria-label={t("Hide companion", "اخفِ الرفيق")} title={t("Hide (a notification can bring it back)", "اخفِ (يمكن إرجاعه من إشعار)")}><EyeOff size={12} /></button>
          <button onClick={() => { setBubble(null); setPanel(true); }} className="grid h-6 w-6 place-items-center rounded-full bg-white/85 text-black shadow" aria-label={t("Ask the companion", "اسأل الرفيق")}><Bot size={12} /></button>
        </div>
        <div onPointerDown={onDown} onPointerMove={onMove} onPointerUp={onUp} onPointerCancel={onUp} role="button" tabIndex={0}
          aria-label={t("DAYFLOW companion — tap for quick panel, drag to move", "رفيق DAYFLOW — اضغط للوحة السريعة، واسحب للتحريك")}
          onKeyDown={(e) => (e.key === "Enter" || e.key === " ") && setPanel((p) => !p)}
          style={{ cursor: s.drag ? "grabbing" : "grab", width: W, height: H }}>
          {cfg.modelId && cfg.modelId !== "svg" ? <Mini3D modelId={cfg.modelId} width={Math.round(W)} height={Math.round(H)} /> :
          <svg viewBox={`0 -10 ${BW} ${BH + 8}`} width={W} height={H} style={{ overflow: "visible", filter: "drop-shadow(0 6px 10px rgba(0,0,0,.18))" }}>
            <RobotBody head={s.head.v} eyes={s.look} mood={mood} family={family} arms={arms} legs={legs} ant={ant} />
          </svg>}
        </div>
        {mood === "sleep" && <span className="pointer-events-none absolute -top-2 end-0 text-[10px] font-bold accent twinkle">z z</span>}
      </div>
      {panel && <QuickPanel onClose={() => setPanel(false)} side={onLeft ? "left" : "right"} y={pos0.y} lang={lang} onPip={openPip} pipSupported={typeof window !== "undefined" && "documentPictureInPicture" in window} onOpenApp={(a, b) => { setPanel(false); onOpenApp(a, b); }} />}
      {pip && <PipRobot win={pip} bubble={bubble?.text || greeting(lang)} lang={lang} family={family} mood={mood} />}
    </>
  );
}

function PipRobot({ win, bubble, lang, family, mood }: { win: Window; bubble: string; lang: "en" | "ar"; family: Family; mood: Mood }) {
  return createPortal(
    <div style={{ height: "100vh", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "flex-end", padding: 8, background: "transparent", fontFamily: "system-ui, sans-serif" }}>
      <div style={{ background: "#fff", color: "#111", borderRadius: 16, padding: "8px 10px", fontSize: 12, fontWeight: 600, boxShadow: "0 6px 18px #0003", marginBottom: -4, maxWidth: 220 }}>{bubble}</div>
      <div className="float-y"><RobotMini size={180} family={family} mood={mood} /></div>
      <div style={{ fontSize: 9, color: "#666", marginTop: 2 }}>{lang === "ar" ? "نافذة عائمة فوق أي تطبيق" : "Floating over other apps"}</div>
    </div>, win.document.body);
}

function QuickPanel({ onClose, side, y, lang, onOpenApp, onPip, pipSupported }: { onClose: () => void; side: "left" | "right"; y: number; lang: "en" | "ar"; onOpenApp: (tab: string, sub?: string) => void; onPip: () => void; pipSupported: boolean }) {
  const t = useT();
  const s = useStore();
  const clockFormat = useClockFormat();
  const [tab, setTab] = useState<"ai" | "tasks" | "alarms" | "media" | "capture" | "more">("ai");
  const [txt, setTxt] = useState("");
  const [reply, setReply] = useState<{ text: string; mood: Mood } | null>(null);
  const [busy, setBusy] = useState(false);
  const pending = useRef("");
  const today = dayKey(new Date());
  const key = s.apiKeys.find((k) => k.id === s.activeKeyId);
  const tabs = [["ai", Bot, t("AI", "اسألني")], ["tasks", ListChecks, t("Tasks", "مهام")], ["alarms", AlarmClock, t("Alarms", "منبهات")], ["media", Link2, t("Media", "وسائط")], ["capture", Zap, t("Capture", "التقاط")], ["more", MoreHorizontal, t("More", "المزيد")]] as const;
  const top = Math.max(10, Math.min(y - 60, window.innerHeight - 520));
  const parsed = tab === "media" && txt ? normalizeUrl(txt) : null;

  const ask = async (e: React.FormEvent) => {
    e.preventDefault();
    const q = txt.trim(); if (!q) return;
    setBusy(true); setTxt("");
    const request = contextualRequest(pending.current, q);
    const local = miniBrain(request, { alarms: s.alarms, tasks: s.tasks, habitsCount: s.habits.length, water: s.water[today] || 0 }, lang);
    pending.current = local.needs?.length ? request : "";
    const outcome = local.actions?.length ? applyActionsDetailed(local.actions, onOpenApp, request) : { done: [], issues: [] };
    setReply({ text: local.text + (outcome.issues.length ? `\nما اتحفظش: ${outcome.issues.join(" ")}` : ""), mood: local.mood });
    if (key && local.needs) {
      try {
        let full = "";
        await streamChat({ entry: key, model: s.activeModel || key.liveModels?.[0]?.id || providerById(key.provider).models[0].id, messages: [{ role: "user", content: request }] }, { onText: (d) => { full += d; setReply({ text: full, mood: "think" }); } });
        const parsed = parseActions(full);
        const result = applyActionsDetailed(parsed.actions, onOpenApp, request);
        if (result.done.length) pending.current = "";
        setReply({ text: (parsed.clean || full) + (result.issues.length ? `\nما اتحفظش: ${result.issues.join(" ")}` : result.done.length ? `\nاتسجّل: ${result.done.join("، ")}` : ""), mood: result.issues.length ? "think" : "happy" });
      } catch (err) { setReply({ text: (lang === "ar" ? "المفتاح مش راضي يرد: " : "Key error: ") + (err as Error).message, mood: "sad" }); }
    }
    setBusy(false);
  };

  return (
    <div className="fixed inset-0 z-[56]" onClick={onClose}>
      <div onClick={(e) => e.stopPropagation()} className="card sheet absolute w-[min(360px,calc(100vw-24px))] p-3" style={{ top, [side === "left" ? "left" : "right"]: Math.min(76, Math.max(12, window.innerWidth - 372)), background: "var(--surface)", maxHeight: 520 }}>
        <div className="mb-2 flex items-center justify-between"><b className="text-sm">{t("Companion", "الرفيق")}</b><button onClick={onClose} aria-label="Close" className="grid h-7 w-7 place-items-center rounded-full btn-soft"><X size={14} /></button></div>
        <div className="scroll-hide mb-3 flex gap-1 overflow-x-auto">
          {tabs.map(([id, I, l]) => <button key={id} onClick={() => { setTab(id); setReply(null); }} className="chip" aria-pressed={tab === id}><I size={13} />{l}</button>)}
        </div>
        <div className="max-h-[350px] overflow-y-auto">
          {tab === "ai" && <div>
            <p className="mb-2 text-[11px] muted">{key ? `${t("Using", "بيستخدم")} ${providerById(key.provider).name} · ${s.activeModel || (lang === "ar" ? "اختر نموذج" : "pick a model")}` : t("Local Egyptian engine (no key needed). Add a key in the AI tab for bigger models.", "محرك مصري محلي (مش محتاج مفتاح). ضيف مفتاح من تاب AI لنماذج أكبر.")}</p>
            <div className="mb-2 space-y-2">{reply && <div className="rounded-xl p-2.5 text-sm fade-in" style={{ background: "var(--soft)" }}>{reply.text}</div>}</div>
            <form onSubmit={ask} className="flex gap-1.5">
              <input className="field py-2" value={txt} onChange={(e) => setTxt(e.target.value)} placeholder={t("Say anything… “اعمل منبه ٧”", "قول أي حاجة… «اعمل منبه ٧»")} />
              <button className="btn btn-primary px-3" disabled={busy} aria-label={t("Send", "إرسال")}>{busy ? <Loader2 size={15} className="animate-spin" /> : <Send size={15} />}</button>
            </form>
            <div className="mt-2 flex flex-wrap gap-1">{["مهامي فاضلة كام؟", "اعمل منبه ٦:٣٠", "اشرب ماية", "إنت مين؟"].map((q) => <button key={q} onClick={() => setTxt(q)} className="chip text-[11px]">{q}</button>)}</div>
            <button onClick={() => { onClose(); onOpenApp("ai"); }} className="btn btn-soft mt-2 w-full text-xs"><Bot size={13} />{t("Open full AI chat", "افتح محادثة AI الكاملة")}</button>
          </div>}
          {tab === "tasks" && <>
            <form onSubmit={(e) => { e.preventDefault(); if (txt.trim()) { s.addTask(txt.trim()); setTxt(""); } }} className="mb-2 flex gap-2"><input className="field py-2" value={txt} onChange={(e) => setTxt(e.target.value)} placeholder={t("Add a task…", "ضيف مهمة…")} /><button className="btn btn-primary px-3"><Plus size={16} /></button></form>
            {s.tasks.filter((x) => x.date === today).map((x) => <button key={x.id} onClick={() => s.toggleTask(x.id)} className="flex w-full items-center gap-2 py-1.5 text-start text-sm"><span className="grid h-5 w-5 place-items-center rounded-md border-2" style={{ borderColor: "var(--accent)", background: x.done ? "var(--accent)" : "transparent", color: "var(--on-accent)" }}>{x.done && <Check size={12} />}</span><span className={x.done ? "line-through muted" : ""}>{x.title}</span></button>)}
            {!s.tasks.length && <p className="py-3 text-sm muted">{t("No tasks yet.", "مفيش مهام لسه.")}</p>}
          </>}
          {tab === "alarms" && s.alarms.map((a) => <div key={a.id} className="flex items-center justify-between py-1.5"><div><div className="font-bold">{clockFormat(a.time)}</div><div className="muted text-xs">{a.label}</div></div><button role="switch" aria-checked={a.enabled} aria-label={a.label} className="switch" onClick={() => s.updateAlarm(a.id, { enabled: !a.enabled })} /></div>)}
          {tab === "alarms" && !s.alarms.length && <button onClick={() => { onClose(); onOpenApp("alarms"); }} className="btn btn-soft w-full">{t("Create an alarm", "اعمل منبه")}</button>}
          {tab === "media" && <>
            <input className="field mb-2 py-2" value={txt} onChange={(e) => setTxt(e.target.value)} placeholder={t("Paste a link (real preview)", "الصق رابط (معاينة حقيقية)")} />
            {parsed && (parsed.ok ? <div className="rounded-lg p-2 text-xs" style={{ background: "var(--soft)" }}><b>{parsed.site}</b> · {parsed.kind}<div className="muted mt-1 break-all">{parsed.url}</div></div> : <div className="text-xs text-red-500">{t("That doesn't look like a link.", "ده مش رابط.")}</div>)}
            <button onClick={() => { onClose(); onOpenApp("tools", "media"); }} className="btn btn-soft mt-2 w-full text-xs"><ExternalLink size={13} />{t("Open Media Hub", "افتح مركز الوسائط")}</button>
          </>}
          {tab === "capture" && <div className="grid grid-cols-2 gap-2">
            <button onClick={() => s.addWater(250)} className="btn btn-soft flex-col py-4"><Droplet size={18} />+250 ml<span className="muted text-[10px]">{fmtNum(((s.water[today] || 0) / 1000).toFixed(2), s.lang)} L</span></button>
            <button onClick={() => { onClose(); onOpenApp("tools", "focus"); }} className="btn btn-soft flex-col py-4"><Zap size={18} />{t("Start focus", "ابدأ تركيز")}</button>
          </div>}
          {tab === "more" && <div className="space-y-1">
            <button onClick={() => { onClose(); onOpenApp("tools", "notes"); }} className="flex w-full items-center gap-2 rounded-lg p-2 text-sm"><StickyNote size={15} className="accent" />{t("Notes", "ملاحظات")}</button>
            <button onClick={() => { onClose(); onOpenApp("tools", "habits"); }} className="flex w-full items-center gap-2 rounded-lg p-2 text-sm"><ListChecks size={15} className="accent" />{t("Habits", "العادات")}</button>
            <button onClick={onPip} className="flex w-full items-center gap-2 rounded-lg p-2 text-start text-sm"><PictureInPicture2 size={15} className="accent" /><span className="flex-1">{t("Float over other apps", "اعرضه فوق أي تطبيق")}<span className="muted block text-[10px]">{pipSupported ? t("A real always-on-top window (Chrome).", "نافذة حقيقية فوق كل التطبيقات (كروم).") : t("Not supported by this browser; use the Android overlay.", "المتصفح ده مش بيدعمها؛ استخدم نافذة أندرويد.")}</span></span></button>
            <button onClick={() => { onClose(); onOpenApp("me", "settings"); }} className="flex w-full items-center gap-2 rounded-lg p-2 text-sm"><Wrench size={15} className="accent" />{t("Robot settings", "إعدادات الرفيق")}</button>
          </div>}
        </div>
        <button onClick={() => { onClose(); onOpenApp("today"); }} className="btn btn-ghost mt-3 w-full text-xs"><ExternalLink size={13} />{t("Open DAYFLOW", "افتح DAYFLOW")}</button>
      </div>
    </div>
  );
}
