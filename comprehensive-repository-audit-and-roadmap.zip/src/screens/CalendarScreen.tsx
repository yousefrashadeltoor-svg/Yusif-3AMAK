import { ChevronLeft, ChevronRight, Plus, Check, Layers } from "lucide-react";
import { useMemo, useState } from "react";
import { useStore, useT, fmtNum } from "../lib/store";
import { coptic, dayKey, hijri, HIJRI_MONTHS, COPTIC_MONTHS, occasionsOn, resolveDecor, upcomingOccasions } from "../lib/calendar";
import { FAMILY, tileDataUri } from "../lib/pattern";
import { Card, ScreenHeader, Sheet } from "../components/ui";
import { HeaderCrown, Motif, Corner } from "../components/Decor";

export function CalendarScreen() {
  const t = useT();
  const s = useStore();
  const L = s.lang;
  const N = (n: number | string) => fmtNum(n, L);
  const today = new Date();
  const [cursor, setCursor] = useState(new Date(today.getFullYear(), today.getMonth(), 1));
  const [sel, setSel] = useState<Date | null>(null);
  const [newTask, setNewTask] = useState("");
  const y = cursor.getFullYear(), m = cursor.getMonth();
  const first = new Date(y, m, 1); const days = new Date(y, m + 1, 0).getDate();
  const offset = (first.getDay() + 1) % 7; // week starts Saturday (Egypt)
  const weekdays = Array.from({ length: 7 }, (_, i) => new Date(2024, 0, 6 + i).toLocaleDateString(L === "ar" ? "ar-EG" : "en", { weekday: "short" }));
  const hFirst = hijri(first), hLast = hijri(new Date(y, m, days));
  const cells = useMemo(() => Array.from({ length: days }, (_, i) => { const d = new Date(y, m, i + 1); return { d, h: hijri(d), occ: occasionsOn(d), decor: resolveDecor(d, s.userDays, 2) }; }), [y, m, s.userDays, days]);
  const monthOcc = cells.flatMap((c) => c.occ.filter((o) => o.priority >= 70 && (o.id !== "ramadan" || c.h.d === 1) && (o.id !== "october" || c.d.getDate() === 6)).map((o) => ({ o, d: c.d })));
  const Prev = L === "ar" ? ChevronRight : ChevronLeft, Next = L === "ar" ? ChevronLeft : ChevronRight;
  const ramadanBand = (h: { m: number }) => h.m === 9;

  const selDecor = sel ? resolveDecor(sel, s.userDays, 3, s.examSeason) : null;
  const selKey = sel ? dayKey(sel) : "";
  const selTasks = s.tasks.filter((x) => x.date === selKey);

  return (
    <div className="pb-4">
      <ScreenHeader title={cursor.toLocaleDateString(L === "ar" ? "ar-EG" : "en", { month: "long", year: "numeric" })}
        subtitle={hFirst.m ? `${HIJRI_MONTHS[L][hFirst.m - 1]}${hLast.m !== hFirst.m ? " – " + HIJRI_MONTHS[L][hLast.m - 1] : ""} ${N(hLast.y)}` : ""}
        right={<div className="flex gap-1">
          <button className="grid h-10 w-10 place-items-center rounded-full btn-soft" onClick={() => setCursor(new Date(y, m - 1, 1))} aria-label={t("Previous month", "الشهر السابق")}><Prev size={18} /></button>
          <button className="chip" onClick={() => setCursor(new Date(today.getFullYear(), today.getMonth(), 1))}>{t("Today", "اليوم")}</button>
          <button className="grid h-10 w-10 place-items-center rounded-full btn-soft" onClick={() => setCursor(new Date(y, m + 1, 1))} aria-label={t("Next month", "الشهر التالي")}><Next size={18} /></button>
        </div>} />

      <Card className="p-3">
        <div className="mb-1 grid grid-cols-7 text-center text-[11px] font-semibold muted">{weekdays.map((w) => <span key={w}>{w}</span>)}</div>
        <div className="grid grid-cols-7 gap-1">
          {Array.from({ length: offset }, (_, i) => <span key={"e" + i} />)}
          {cells.map(({ d, h, occ, decor }) => {
            const isT = d.toDateString() === today.toDateString();
            const o = occ[0];
            const fam = o ? o.family : null;
            const band = ramadanBand(h);
            return (
              <button key={d.getDate()} onClick={() => setSel(d)} className="relative flex aspect-[4/5] flex-col items-center justify-start overflow-hidden rounded-xl pt-1.5 transition-transform active:scale-95"
                style={{ background: isT ? "var(--accent)" : band ? `color-mix(in oklch, ${FAMILY.ramadan.c1} 14%, transparent)` : fam && o.priority >= 70 ? `color-mix(in oklch, ${FAMILY[fam].c1} 12%, transparent)` : "transparent", color: isT ? "var(--on-accent)" : undefined }}
                aria-label={d.toDateString() + (o ? ", " + (L === "ar" ? o.ar : o.en) : "")}>
                {band && !isT && <span className="absolute inset-0" style={{ backgroundImage: tileDataUri("ramadan", FAMILY.ramadan.c1, 0.35, 24) }} />}
                <span className="relative text-[15px] font-semibold leading-none">{N(d.getDate())}</span>
                <span className="relative mt-0.5 text-[9px] leading-none opacity-60">{N(h.d)}</span>
                {o && o.priority >= 70 && <span className="relative mt-auto mb-1"><Motif family={o.family} size={16} mono={isT ? "currentColor" : undefined} /></span>}
                {!o && d.getDay() === 5 && <span className="relative mt-auto mb-1.5 h-1 w-1 rounded-full" style={{ background: FAMILY.friday.c1, opacity: isT ? 0 : 0.6 }} />}
                {decor.layers.some((l) => l.source === "user") && <span className="absolute end-1 top-1 h-1.5 w-1.5 rounded-full" style={{ background: FAMILY.birthday.c1 }} />}
              </button>
            );
          })}
        </div>
      </Card>

      <h3 className="mb-2 mt-5 px-1 font-bold">{t("This month", "هذا الشهر")}</h3>
      <div className="space-y-2">
        {monthOcc.length === 0 && <p className="muted px-1 text-sm">{t("No major occasions this month.", "لا مناسبات كبرى هذا الشهر.")}</p>}
        {monthOcc.map(({ o, d }) => (
          <Card key={o.id + d.getDate()} className="flex items-center gap-3 p-3" onClick={() => setSel(d)}>
            <div className="grid h-11 w-11 place-items-center rounded-xl" style={{ background: FAMILY[o.family].c3 }}><Motif family={o.family} size={30} /></div>
            <div className="flex-1"><p className="font-semibold">{L === "ar" ? o.ar : o.en}</p><p className="text-xs muted">{d.toLocaleDateString(L === "ar" ? "ar-EG" : "en-GB", { weekday: "long", day: "numeric", month: "long" })}</p></div>
          </Card>
        ))}
      </div>
      <p className="muted mt-4 px-1 text-[11px] leading-relaxed">{t("Hijri dates use the Umm al-Qura calculation and can differ by a day from local moon sighting. Next big occasion: ", "التواريخ الهجرية بحساب أم القرى وقد تختلف يومًا عن الرؤية المحلية. أقرب مناسبة كبرى: ")}{(() => { const u = upcomingOccasions(today, 1)[0]; return u ? (L === "ar" ? u.o.ar : u.o.en) : ""; })()}</p>

      <Sheet open={!!sel} onClose={() => setSel(null)}>
        {sel && selDecor && (() => {
          const f = FAMILY[selDecor.primary]; const hh = hijri(sel), cc = coptic(sel);
          return (
            <div>
              <div className="relative -mx-5 -mt-5 mb-4 overflow-hidden p-5 pt-12 text-white" style={{ background: `linear-gradient(145deg, ${f.c2}, ${f.c1})` }}>
                <div className="absolute inset-0" style={{ backgroundImage: tileDataUri(selDecor.primary, "#fff", 0.2, 56) }} />
                <div className="absolute inset-x-0 top-0"><HeaderCrown family={selDecor.primary} height={48} /></div>
                <Corner family={selDecor.primary} pos="br" size={80} opacity={0.6} />
                <p className="relative text-2xl font-bold">{sel.toLocaleDateString(L === "ar" ? "ar-EG" : "en-GB", { weekday: "long", day: "numeric", month: "long", year: "numeric" })}</p>
                <p className="relative text-sm opacity-90">{N(hh.d)} {HIJRI_MONTHS[L][hh.m - 1]} {N(hh.y)} · {N(cc.d)} {COPTIC_MONTHS[L][cc.m - 1]} {N(cc.y)}</p>
                {selDecor.occasions.map((o) => <p key={o.id} className="relative mt-2 inline-block rounded-full px-3 py-1 text-sm font-semibold" style={{ background: "rgba(255,255,255,.2)" }}>{L === "ar" ? o.ar : o.en}</p>)}
              </div>
              <div className="mb-4">
                <p className="mb-1.5 flex items-center gap-1.5 text-xs font-semibold muted"><Layers size={13} />{t("Decoration for this date", "زينة هذا التاريخ")}</p>
                <div className="flex flex-wrap gap-1.5">{selDecor.layers.map((l, i) => <span key={i} className="chip"><Motif family={l.family} size={14} />{L === "ar" ? l.ar : l.en}<span className="muted text-[10px]">{t({ occasion: "occasion", season: "season", weekday: "weekday", user: "personal", climate: "climate" }[l.source], { occasion: "مناسبة", season: "موسم", weekday: "يوم", user: "شخصي", climate: "مناخ" }[l.source])}</span></span>)}</div>
              </div>
              <p className="mb-2 font-bold">{t("Tasks", "المهام")}</p>
              {selTasks.map((x) => <button key={x.id} onClick={() => s.toggleTask(x.id)} className="flex w-full items-center gap-2 py-1.5 text-start"><span className="grid h-5 w-5 place-items-center rounded-md border-2" style={{ borderColor: "var(--accent)", background: x.done ? "var(--accent)" : "transparent", color: "var(--on-accent)" }}>{x.done && <Check size={12} />}</span><span className={x.done ? "muted line-through" : ""}>{x.title}</span></button>)}
              {!selTasks.length && <p className="muted text-sm">{t("Nothing planned.", "لا شيء مخطط.")}</p>}
              <form onSubmit={(e) => { e.preventDefault(); if (newTask.trim()) { s.addTask(newTask.trim(), selKey); setNewTask(""); } }} className="mt-3 flex gap-2">
                <input value={newTask} onChange={(e) => setNewTask(e.target.value)} className="field py-2" placeholder={t("Plan something for this day…", "خطط لشيء في هذا اليوم…")} />
                <button className="btn btn-primary px-3" aria-label={t("Add", "إضافة")}><Plus size={18} /></button>
              </form>
            </div>
          );
        })()}
      </Sheet>
    </div>
  );
}
