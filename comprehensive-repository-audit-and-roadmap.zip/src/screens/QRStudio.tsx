import { useEffect, useMemo, useRef, useState } from "react";
import QRCodeStyling, { type DotType, type CornerSquareType } from "qr-code-styling";
import QRCode from "qrcode";
import { Download, Image as ImageIcon, Link2, Loader2, Palette, ScanLine, ShieldCheck, Sparkles, Upload, Wifi, User, FileText, Copy, Check, Share2, CircleDot } from "lucide-react";
import { useStore, useT } from "../lib/store";
import { dayKey } from "../lib/calendar";
import { SOCIALS, socialLink, logoData, inferSocial, reviewLink, localShareLink, saveLocalShare, wifiPayload, contactPayload, type LocalShareMeta } from "../lib/qr";
import { makeReviewSnapshot, type ReviewRange } from "../lib/reviewShare";
import { downloadBlob } from "../lib/reviewImage";
import { Card, Honest, Segmented, Sheet, Toggle } from "../components/ui";
import { Motif } from "../components/Decor";
import { PERIODS } from "../lib/ambience";
import { ReviewImage } from "./QRShareViewer";
import { QRScanner } from "./QRScanner";
import { fmtBytes } from "../lib/media";

const DESIGNS = [
  { id: "ivory", en: "Ivory journal", ar: "دفتر عاجي", ink: "#34302b", bg: "#f3eedf", accent: "#857141", dots: "rounded" as DotType, eye: "extra-rounded" as CornerSquareType, family: "islamic" as const, material: "paper", photo: PERIODS.morning.photo },
  { id: "nile", en: "Nile glass", ar: "زجاج النيل", ink: "#123e56", bg: "#deedf4", accent: "#4c89a0", dots: "dots" as DotType, eye: "dot" as CornerSquareType, family: "nile" as const, material: "glass", photo: PERIODS.fajr.photo },
  { id: "ramadan", en: "Lantern night", ar: "ليلة رمضان", ink: "#193b36", bg: "#162c29", accent: "#d8b36b", dots: "classy-rounded" as DotType, eye: "extra-rounded" as CornerSquareType, family: "ramadan" as const, material: "ornate", photo: PERIODS.night.photo },
  { id: "noir", en: "Gallery noir", ar: "معرض داكن", ink: "#111827", bg: "#20222a", accent: "#bec6d9", dots: "square" as DotType, eye: "square" as CornerSquareType, family: "winter" as const, material: "matte", photo: PERIODS.night.photo },
  { id: "spring", en: "Botanical", ar: "حديقة الربيع", ink: "#34553f", bg: "#edf0e8", accent: "#67836a", dots: "extra-rounded" as DotType, eye: "dot" as CornerSquareType, family: "spring" as const, material: "clay", photo: PERIODS.morning.photo },
  { id: "blueprint", en: "Blueprint", ar: "مخطط أزرق", ink: "#233e68", bg: "#e2e9f3", accent: "#3d6798", dots: "square" as DotType, eye: "square" as CornerSquareType, family: "study" as const, material: "grid", photo: PERIODS.noon.photo },
  { id: "sunset", en: "Sunset editorial", ar: "دفتر الغروب", ink: "#673e36", bg: "#f3e3d9", accent: "#af7361", dots: "classy" as DotType, eye: "extra-rounded" as CornerSquareType, family: "autumn" as const, material: "editorial", photo: PERIODS.maghrib.photo },
  { id: "mono", en: "Minimal outline", ar: "خطوط بسيطة", ink: "#171717", bg: "#f9f9f9", accent: "#171717", dots: "rounded" as DotType, eye: "square" as CornerSquareType, family: "friday" as const, material: "outline", photo: PERIODS.asr.photo },
];
const KIND = [
  { id: "link", en: "Link / text", ar: "رابط / نص", icon: Link2 }, { id: "social", en: "Profile", ar: "حسابي", icon: User },
  { id: "review", en: "Review", ar: "التقييم", icon: Sparkles }, { id: "file", en: "Media", ar: "ملفاتي", icon: ImageIcon },
  { id: "wifi", en: "Wi-Fi", ar: "واي فاي", icon: Wifi }, { id: "contact", en: "Contact", ar: "جهة اتصال", icon: FileText },
] as const;
type Kind = typeof KIND[number]["id"];
export function QRStudio() {
  const t = useT(), lang = useStore((s) => s.lang), tasks = useStore((s) => s.tasks), habits = useStore((s) => s.habits), water = useStore((s) => s.water);
  const [tab, setTab] = useState<"create" | "scan">("create"), [kind, setKind] = useState<Kind>("link");
  const [text, setText] = useState("https://www.youtube.com/"), [platform, setPlatform] = useState("instagram"), [username, setUsername] = useState("");
  const [designId, setDesignId] = useState("ivory"), [shape, setShape] = useState<DotType>("rounded"), [eye, setEye] = useState<CornerSquareType>("extra-rounded");
  const [outerShape, setOuterShape] = useState<"square" | "circle">("square"), [logo, setLogo] = useState("auto"), [ownLogo, setOwnLogo] = useState("");
  const [title, setTitle] = useState("DAYFLOW"), [ornament, setOrnament] = useState(true);
  const [range, setRange] = useState<ReviewRange>("day"), [date, setDate] = useState(dayKey(new Date()));
  const [localFile, setLocalFile] = useState<LocalShareMeta | null>(null), [fileMode, setFileMode] = useState<"local" | "url">("local"), [fileUrl, setFileUrl] = useState("");
  const [ssid, setSsid] = useState(""), [password, setPassword] = useState(""), [security, setSecurity] = useState("WPA"), [hidden, setHidden] = useState(false);
  const [name, setName] = useState(""), [phone, setPhone] = useState(""), [email, setEmail] = useState("");
  const [ready, setReady] = useState(false), [busy, setBusy] = useState(false), [error, setError] = useState("");
  const [imageOpen, setImageOpen] = useState(false), [checked, setChecked] = useState(false), [message, setMessage] = useState("");
  const container = useRef<HTMLDivElement>(null), code = useRef<QRCodeStyling | null>(null);
  const design = DESIGNS.find((d) => d.id === designId)!;
  const snapshot = useMemo(() => makeReviewSnapshot(range, date), [range, date, lang, tasks, habits, water]);
  const data = kind === "social" ? socialLink(platform, username) : kind === "review" ? reviewLink(snapshot) : kind === "file" ? (fileMode === "local" ? localFile ? localShareLink(localFile.id) : "" : fileUrl.trim()) : kind === "wifi" ? ssid ? wifiPayload(ssid, password, security, hidden) : "" : kind === "contact" ? name ? contactPayload(name, phone, email) : "" : text;
  const autoLogo = kind === "social" ? platform : kind === "review" || (kind === "file" && fileMode === "local") ? "dayflow" : inferSocial(data);
  const chosenLogo = logo === "custom" ? ownLogo : logoData(logo === "auto" ? autoLogo : logo);
  const bytes = new TextEncoder().encode(data).length;

  useEffect(() => {
    if (tab !== "create" || !container.current) return;
    let valid = true; setReady(false); setError(""); container.current.replaceChildren();
    if (!data.trim()) return;
    try {
      QRCode.create(data, { errorCorrectionLevel: "H" });
      const qr = new QRCodeStyling({ width: 600, height: 600, type: "canvas", data, shape: outerShape, margin: 32,
        qrOptions: { errorCorrectionLevel: "H" }, dotsOptions: { color: design.ink, type: shape },
        cornersSquareOptions: { color: design.ink, type: eye }, cornersDotOptions: { color: design.ink, type: "dot" },
        backgroundOptions: { color: "#ffffff" }, image: chosenLogo,
        imageOptions: { imageSize: .2, margin: 4, hideBackgroundDots: true, saveAsBlob: true } });
      code.current = qr; qr.append(container.current);
      qr.getRawData("png").then(() => { if (valid) setReady(true); }).catch(() => { if (valid) setError(t("Couldn't render this code.", "معرفناش نرسم الرمز ده.")); });
    } catch { setError(t("Too much data for one QR. Choose a shorter review or save the report image separately.", "البيانات أكبر من سعة رمز واحد. اختار فترة أقصر أو احفظ صورة التقرير لوحدها.")); }
    return () => { valid = false; };
  }, [data, design, shape, eye, outerShape, chosenLogo, tab]);

  const exportCode = async (format: "png" | "svg", share = false) => {
    if (!code.current || !ready) return;
    if (kind === "review" && !checked) { setMessage(t("Confirm sharing your private review first.", "أكد الأول إنك موافق تشارك بيانات التقييم.")); return; }
    setBusy(true);
    try {
      const raw = await code.current.getRawData(format); if (!(raw instanceof Blob)) throw new Error("No QR output");
      let blob = raw;
      if (format === "png") {
        const image = await createImageBitmap(raw), canvas = document.createElement("canvas"); canvas.width = 760; canvas.height = 920;
        const g = canvas.getContext("2d")!; g.fillStyle = design.bg; g.fillRect(0, 0, 760, 920);
        g.fillStyle = design.accent; g.textAlign = "center"; g.font = "700 31px system-ui"; g.fillText(title.slice(0, 38) || "DAYFLOW", 380, 77);
        g.fillStyle = "#ffffff"; g.beginPath(); g.roundRect(60, 113, 640, 640, 26); g.fill(); g.drawImage(image, 80, 133, 600, 600); image.close();
        if (ornament) {
          g.strokeStyle = design.accent; g.lineWidth = 2; g.beginPath(); g.roundRect(18, 18, 724, 884, 34); g.stroke();
        }
        g.fillStyle = design.accent; g.font = "22px system-ui"; g.fillText(kind === "file" && fileMode === "local" ? t("Local file · original device only", "ملف محلي · نفس الجهاز") : t("Scan to open", "امسح الرمز عشان تفتح"), 380, 824);
        g.font = "15px system-ui"; g.fillText("DAYFLOW · QR STUDIO", 380, 863);
        blob = await new Promise<Blob>((res, rej) => canvas.toBlob((b) => b ? res(b) : rej(new Error("Image failed")), "image/png"));
      }
      const filename = `dayflow-qr-${design.id}.${format}`;
      const file = new File([blob], filename, { type: blob.type });
      if (share && navigator.canShare?.({ files: [file] })) await navigator.share({ files: [file] });
      else downloadBlob(blob, filename);
    } catch (e) { if ((e as Error).name !== "AbortError") setMessage(t("Couldn't export the QR image.", "معرفناش نحفظ الصورة.")); }
    finally { setBusy(false); }
  };

  const attachLocal = async (file: File) => { setBusy(true); setMessage(""); try { setLocalFile(await saveLocalShare(file)); setMessage(t("Saved locally. The QR opens it on this device.", "اتحفظ محليًا، والرمز هيفتحه على الجهاز ده.")); } catch { setMessage(t("Storage is full or unavailable. Use a hosted URL instead.", "التخزين ممتلئ أو مش متاح. استخدم لينك للملف بدل كده.")); } finally { setBusy(false); } };
  const kindTitle = KIND.find((k) => k.id === kind)!;
  return <div className="qr-studio">
    <div className="qr-studio-heading"><span className="qr-studio-glyph"><ScanLine size={23} /></span><div><h2>{t("QR Studio", "استوديو QR")}</h2><p>{t("A little code, a lot of possibilities.", "رمز صغير، وإمكانيات كتير.")}</p></div><span className="qr-offline-tag"><ShieldCheck size={11} />{t("Offline", "أوفلاين")}</span></div>
    <Segmented value={tab} onChange={setTab} options={[{ id: "create", label: t("Create & style", "اعمل وخصّص") }, { id: "scan", label: t("Scan a QR", "اقرأ رمز") }]} />
    {tab === "scan" ? <QRScanner /> : <>
      <div className="qr-preview-stage" style={{ background: design.bg }} data-qr-material={design.material}>
        <img src={design.photo} alt="" className="qr-stage-photo" />
        <div className="qr-preview-frame" style={{ color: design.accent }}>
          {ornament && <><div className="qr-frame-corner"><Motif family={design.family} size={40} mono={design.accent} /></div><div className="qr-frame-corner bottom"><Motif family={design.family} size={40} mono={design.accent} /></div></>}
          <div className="qr-frame-label">{title || "DAYFLOW"}<small>{lang === "ar" ? kindTitle.ar : kindTitle.en}</small></div>
          <div className="qr-code-box" ref={container} aria-label={t("QR preview", "معاينة رمز QR")} />
          {!data && <p className="qr-preview-empty">{t("Add your content below", "ضيف المحتوى من تحت")}</p>}
          <div className="qr-frame-footer"><ScanLine size={14} />{t("Scan to open", "امسح وافتح")}</div>
        </div>
      </div>
      <div className="qr-preview-tools"><button disabled={!ready || busy} onClick={() => void exportCode("png")} className="btn btn-primary"><Download size={15} />PNG</button><button disabled={!ready || busy} onClick={() => void exportCode("svg")} className="btn btn-soft"><Download size={14} />SVG</button><button disabled={!ready || busy} onClick={() => void exportCode("png", true)} className="btn btn-soft" aria-label={t("Share QR", "شارك الرمز")}><Share2 size={15} /></button><span>{ready ? <Check size={13} /> : busy ? <Loader2 size={13} className="animate-spin" /> : null}{bytes ? `${bytes} B` : ""}</span></div>
      {error && <p className="qr-error" role="alert">{error}</p>}{message && <p className="qr-feedback" role="status">{message}</p>}

      <Card className="qr-control-card"><h3><Link2 size={16} />{t("What's inside?", "إيه اللي جوّه الرمز؟")}</h3>
        <div className="qr-kind-grid">{KIND.map(({ id, en, ar, icon: Icon }) => <button key={id} aria-pressed={kind === id} onClick={() => setKind(id)}><Icon size={16} />{lang === "ar" ? ar : en}</button>)}</div>
        {kind === "link" && <textarea className="field min-h-20" value={text} onChange={(e) => setText(e.target.value)} placeholder={t("Link or text", "رابط أو نص")} aria-label={t("QR content", "محتوى QR")} />}
        {kind === "social" && <div className="space-y-2"><div className="qr-platform-grid">{SOCIALS.filter((p) => p.id !== "dayflow").map((p) => <button key={p.id} className={platform === p.id ? "active" : ""} onClick={() => setPlatform(p.id)}><svg viewBox="0 0 24 24" width={17} height={17} fill={"#" + ("hex" in p ? p.hex : p.color)}><path d={p.path} /></svg><span>{p.name}</span></button>)}</div><input className="field" value={username} onChange={(e) => setUsername(e.target.value)} dir="ltr" placeholder={platform === "whatsapp" ? "+2010..." : SOCIALS.find((p) => p.id === platform)?.type === "link" ? "https://..." : "@username"} aria-label={t("Username or account link", "اسم المستخدم أو رابط الحساب")} /><p className="qr-content-url" dir="ltr">{data}</p><p className="text-xs muted">{t("Enter a country code for WhatsApp. Discord, Signal and Spotify use their share links.", "واتساب محتاج كود الدولة. Discord وSignal وSpotify بيستخدموا رابط المشاركة بتاعهم.")}</p></div>}
        {kind === "review" && <div className="space-y-2"><Segmented value={range} onChange={setRange} options={[{ id: "day", label: t("Day", "يومي") }, { id: "week", label: t("7 days", "أسبوعي") }, { id: "month", label: t("Month to date", "شهري") }]} /><input type="date" className="field" value={date} onChange={(e) => { if (e.target.value) setDate(e.target.value); }} max={dayKey(new Date())} aria-label={t("Review date", "تاريخ التقييم")} /><p className="text-xs muted">{snapshot.start} — {snapshot.end} · {t("All saved tasks, habits and water for this period are included; unrecorded dimensions are excluded.", "بيشمل المهام والعادات والمياه المسجلة للفترة دي. اللي متسجّلش مش بيتحسب.")}</p><button className="btn btn-soft w-full" onClick={() => setImageOpen(true)}><ImageIcon size={15} />{t("View / save full local image", "شوف واحفظ الصورة المحلية كاملة")}</button><label className="flex items-center justify-between gap-2 text-xs"><span>{t("I understand this QR shares private review data with anyone who scans it.", "فاهم إن اللي يمسح الرمز يقدر يشوف بيانات التقييم الخاصة دي.")}</span><Toggle on={checked} onChange={setChecked} label="Review sharing consent" /></label>{!checked && <p className="text-xs text-amber-700">{t("Confirm before sharing. Data is in the QR link, not uploaded to a server.", "أكد قبل المشاركة. البيانات جوّه لينك الرمز، مش مرفوعة على سيرفر.")}</p>}</div>}
        {kind === "file" && <div className="space-y-2"><Segmented value={fileMode} onChange={setFileMode} options={[{ id: "local", label: t("This device", "على الجهاز") }, { id: "url", label: t("Hosted link", "لينك الملف") }]} />{fileMode === "local" ? <><label className="btn btn-soft w-full"><Upload size={15} />{t("Save image, video, audio or file", "ضيف صورة أو فيديو أو موسيقى أو ملف")}<input type="file" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) void attachLocal(f); e.target.value = ""; }} /></label>{localFile && <p className="text-xs font-semibold">{localFile.name} · {fmtBytes(localFile.size)}</p>}<Honest>{t("The QR is a local file reference, not the file itself. It opens immediately in this app on the original device. Other devices need the actual file or a hosted URL.", "الرمز مرجع لملف محلي، مش الملف نفسه. بيفتح فورًا في التطبيق على نفس الجهاز. الأجهزة التانية محتاجة الملف نفسه أو رابط متاح ليه.")}</Honest></> : <><input type="url" className="field" value={fileUrl} onChange={(e) => setFileUrl(e.target.value)} placeholder="https://..." /><p className="text-xs muted">{t("No file is uploaded by DAYFLOW. Paste a public or privately shared media URL you already control.", "DAYFLOW مش بيرفع الملف. الصق لينك صورة أو فيديو أو موسيقى إنت متحكم فيه.")}</p></>}</div>}
        {kind === "wifi" && <div className="grid gap-2"><input className="field" value={ssid} onChange={(e) => setSsid(e.target.value)} placeholder={t("Network name", "اسم الشبكة")} /><input type="password" className="field" value={password} onChange={(e) => setPassword(e.target.value)} placeholder={t("Password", "الباسورد")} /><select className="field" value={security} onChange={(e) => setSecurity(e.target.value)}><option value="WPA">WPA / WPA2</option><option value="WEP">WEP</option><option value="nopass">{t("No password", "من غير باسورد")}</option></select><label className="flex items-center justify-between text-xs">{t("Hidden network", "شبكة مخفية")}<Toggle on={hidden} onChange={setHidden} label="Hidden network" /></label></div>}
        {kind === "contact" && <div className="grid gap-2"><input className="field" value={name} onChange={(e) => setName(e.target.value)} placeholder={t("Name", "الاسم")} /><input type="tel" className="field" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder={t("Phone", "التليفون")} /><input type="email" className="field" value={email} onChange={(e) => setEmail(e.target.value)} placeholder={t("Email", "الإيميل")} /></div>}
      </Card>

      <Card className="qr-control-card"><h3><Palette size={16} />{t("Theme & personality", "الثيم وشخصية الرمز")}</h3><div className="qr-design-grid">{DESIGNS.map((d) => <button key={d.id} aria-pressed={designId === d.id} onClick={() => { setDesignId(d.id); setShape(d.dots); setEye(d.eye); }}><span className="qr-design-mini" data-material={d.material} style={{ background: d.bg, color: d.accent }}><span /><CircleDot size={21} /><span /></span><b>{lang === "ar" ? d.ar : d.en}</b><small>{d.material}</small></button>)}</div>
        <label className="qr-label">{t("Title on the card", "عنوان على الكارت")}<input className="field" value={title} maxLength={38} onChange={(e) => setTitle(e.target.value)} /></label>
        <div className="grid grid-cols-2 gap-2"><label className="qr-label">{t("Modules", "شكل النقط")}<select className="field" value={shape} onChange={(e) => setShape(e.target.value as DotType)}>{["rounded", "dots", "classy", "classy-rounded", "square", "extra-rounded"].map((v) => <option key={v} value={v}>{v}</option>)}</select></label><label className="qr-label">{t("Eyes", "شكل العيون")}<select className="field" value={eye} onChange={(e) => setEye(e.target.value as CornerSquareType)}>{["extra-rounded", "dot", "square"].map((v) => <option key={v} value={v}>{v}</option>)}</select></label></div>
        <label className="flex items-center justify-between text-xs">{t("Circular silhouette", "شكل دائري للرمز")}<Toggle on={outerShape === "circle"} onChange={(v) => setOuterShape(v ? "circle" : "square")} label="Circular QR" /></label>
        <label className="flex items-center justify-between text-xs">{t("Ornamental frame", "إطار مزخرف")}<Toggle on={ornament} onChange={setOrnament} label="Ornamental frame" /></label>
      </Card>
      <Card className="qr-control-card"><h3><ImageIcon size={16} />{t("Logo in the centre", "اللوجو في النص")}</h3><select className="field" value={logo} onChange={(e) => setLogo(e.target.value)}><option value="auto">{t("Match content", "تلقائي حسب المحتوى")}</option><option value="none">{t("No logo", "من غير لوجو")}</option>{SOCIALS.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}<option value="custom">{t("My image", "صورتي")}</option></select>{logo === "custom" && <label className="btn btn-soft w-full"><Upload size={14} />{t("Choose logo under 512 KB", "اختار لوجو أقل من ٥١٢ كيلوبايت")}<input type="file" accept="image/png,image/jpeg,image/webp" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (!f) return; if (f.size > 512 * 1024) { setMessage(t("Logo must be under 512 KB.", "اللوجو لازم يبقى أقل من ٥١٢ كيلوبايت.")); return; } const r = new FileReader(); r.onload = () => setOwnLogo(String(r.result)); r.readAsDataURL(f); }} /></label>}<p className="text-xs muted">{t("Official brand marks from Simple Icons. The logo is kept small with high error correction.", "علامات المنصات من Simple Icons. اللوجو صغير مع تصحيح أخطاء عالي عشان الرمز يتقري.")}</p></Card>
      {kind === "review" && !checked ? <button className="btn btn-primary w-full" onClick={() => setChecked(true)}><ShieldCheck size={15} />{t("Allow sharing this review", "موافق على مشاركة التقييم ده")}</button> : <button className="btn btn-ghost w-full" disabled={!ready} onClick={() => navigator.clipboard?.writeText(data)}><Copy size={14} />{t("Copy QR content", "انسخ محتوى الرمز")}</button>}
      <Sheet open={imageOpen} onClose={() => setImageOpen(false)} title={t("Local review image", "صورة التقييم المحلية")} wide><ReviewImage snapshot={snapshot} /></Sheet>
    </>}
  </div>;
}
