import { useEffect, useRef, useState } from "react";
import jsQR from "jsqr";
import { Camera, Copy, ExternalLink, Image as ImageIcon, Loader2, ScanLine, Square, Upload } from "lucide-react";
import { Card } from "../components/ui";
import { useT } from "../lib/store";
import { QRShareViewer } from "./QRShareViewer";

export function QRScanner() {
  const t = useT(); const [running, setRunning] = useState(false), [busy, setBusy] = useState(false), [result, setResult] = useState(""), [error, setError] = useState("");
  const video = useRef<HTMLVideoElement>(null), stream = useRef<MediaStream | null>(null), timer = useRef<number | null>(null), generation = useRef(0);
  const stop = () => { generation.current++; stream.current?.getTracks().forEach((track) => track.stop()); stream.current = null; if (timer.current !== null) window.clearTimeout(timer.current); timer.current = null; setRunning(false); };
  useEffect(() => { const hide = () => { if (document.hidden) stop(); }; document.addEventListener("visibilitychange", hide); return () => { generation.current++; stream.current?.getTracks().forEach((track) => track.stop()); if (timer.current !== null) window.clearTimeout(timer.current); document.removeEventListener("visibilitychange", hide); }; }, []);
  const readCanvas = (canvas: HTMLCanvasElement) => { const ctx = canvas.getContext("2d", { willReadFrequently: true })!; const data = ctx.getImageData(0, 0, canvas.width, canvas.height); return jsQR(data.data, data.width, data.height, { inversionAttempts: "attemptBoth" })?.data; };
  const start = async () => {
    stop(); setError(""); setResult("");
    if (!navigator.mediaDevices?.getUserMedia) { setError(t("Camera scanning needs HTTPS and browser support. You can read an image instead.", "الكاميرا محتاجة HTTPS ومتصفح يدعمها. تقدر تقرأ صورة بدلها.")); return; }
    const current = generation.current; setBusy(true);
    try {
      const media = await navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: "environment" }, width: { ideal: 1280 } }, audio: false });
      if (current !== generation.current) { media.getTracks().forEach((track) => track.stop()); return; }
      stream.current = media; setRunning(true);
      if (!video.current) throw new Error("Camera surface unavailable");
      video.current.srcObject = media; await video.current.play();
      const canvas = document.createElement("canvas"), ctx = canvas.getContext("2d", { willReadFrequently: true })!;
      const tick = () => {
        if (generation.current !== current || !video.current) return;
        const v = video.current;
        if (v.readyState >= 2 && v.videoWidth) {
          const scale = Math.min(1, 800 / v.videoWidth); canvas.width = Math.round(v.videoWidth * scale); canvas.height = Math.round(v.videoHeight * scale); ctx.drawImage(v, 0, 0, canvas.width, canvas.height);
          const value = readCanvas(canvas); if (value) { setResult(value); stop(); return; }
        }
        timer.current = window.setTimeout(tick, 160);
      }; tick();
    } catch (e) { stop(); setError(t("Couldn't access camera. Check its permission or read an image.", "معرفناش نفتح الكاميرا. راجع الإذن أو اختار صورة QR.")); }
    finally { setBusy(false); }
  };
  const readImage = async (file: File) => {
    stop(); setError(""); setResult(""); setBusy(true);
    try {
      const image = await createImageBitmap(file); const canvas = document.createElement("canvas"), ctx = canvas.getContext("2d", { willReadFrequently: true })!;
      const ratio = Math.min(1, 1800 / Math.max(image.width, image.height)); canvas.width = Math.round(image.width * ratio); canvas.height = Math.round(image.height * ratio); ctx.drawImage(image, 0, 0, canvas.width, canvas.height); image.close();
      const value = readCanvas(canvas); if (!value) throw new Error("No QR found"); setResult(value);
    } catch { setError(t("No readable QR found. Use a clear image without blur.", "مفيش QR واضح في الصورة. جرّب صورة أوضح من غير تمويه.")); }
    finally { setBusy(false); }
  };
  const review = result.includes("#/qr-share/") ? result.split("#/qr-share/")[1] : null;
  const localFile = result.includes("#/qr-file/") ? result.split("#/qr-file/")[1] : null;
  if (review || localFile) return <QRShareViewer kind={review ? "review" : "file"} value={review || localFile || ""} onBack={() => setResult("")} />;
  const safeLink = /^https?:\/\/[^\s]+$/i.test(result) ? result : null;
  return <div className="qr-reader space-y-3">
    <div className="qr-reader-visual"><video ref={video} autoPlay playsInline muted style={{ opacity: running ? 1 : 0 }} /><div className="qr-scan-frame" />{!running && <div className="qr-camera-placeholder"><ScanLine size={48} /><strong>{t("Read a code", "اقرأ الرمز")}</strong><small>{t("Camera or an image — no upload", "بالكاميرا أو من صورة — من غير رفع")}</small></div>}</div>
    <div className="flex gap-2"><button className="btn btn-primary flex-1" disabled={busy} onClick={() => running ? stop() : void start()}>{busy ? <Loader2 size={16} className="animate-spin" /> : running ? <Square size={16} /> : <Camera size={16} />}{running ? t("Stop camera", "اقفل الكاميرا") : t("Start camera", "افتح الكاميرا")}</button><label className="btn btn-soft"><Upload size={16} />{t("Read image", "اقرأ صورة")}<input type="file" accept="image/*" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) void readImage(f); e.target.value = ""; }} /></label></div>
    {error && <p className="qr-error" role="alert">{error}</p>}
    <Card className="p-3"><label className="qr-label">{t("Or paste QR contents", "أو الصق محتوى الرمز")}<textarea className="field min-h-20" value={result} onChange={(e) => setResult(e.target.value)} placeholder={t("A QR link or decoded text", "لينك QR أو النص اللي اتقري")} /></label></Card>
    {result && <Card className="space-y-2 p-4"><h3 className="flex items-center gap-2 font-bold"><ImageIcon size={16} className="accent" />{t("Read result", "النتيجة")}</h3><p className="break-all whitespace-pre-wrap text-sm" dir="auto">{result}</p><div className="flex gap-2"><button className="btn btn-soft" onClick={() => navigator.clipboard?.writeText(result)}><Copy size={14} />{t("Copy", "نسخ")}</button>{safeLink && <a className="btn btn-primary" href={safeLink} target="_blank" rel="noopener noreferrer"><ExternalLink size={14} />{t("Open website", "افتح الموقع")}</a>}</div><p className="text-xs muted">{t("External links are never opened automatically.", "اللينكات الخارجية مش بتتفتح لوحدها.")}</p></Card>}
  </div>;
}
