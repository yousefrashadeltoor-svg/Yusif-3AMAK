import { useEffect, useMemo, useRef, useState } from "react";
import { ClipboardPaste, Download, Pause, Play, X, RotateCcw, Trash2, Share2, Link2, Search, Settings2, ShieldCheck, ShieldAlert, Loader2, Film, Music, Image as ImageIcon, FileText, Globe, ArrowUp, ArrowDown, Pencil, FolderOpen, ScanSearch, RefreshCw, Clock } from "lucide-react";
import { useStore, useT } from "../lib/store";
import { Card, ScreenHeader, Segmented, Sheet, Toggle } from "../components/ui";
import { SiteLogo } from "./MediaHub";
import { fmtBytes } from "../lib/media";
import { ENGINES, analyzeLink, attachNativeEvents, cancelItem, createItem, deleteItem, extractUrls, explainError, isAndroidApk, openStored, pauseItem, pump, resumeItem, retryItem, useDownloads, DEFAULT_ORDER, type Analysis, type DlItem, type DlState } from "../lib/downloads";
import { takePendingShare } from "../lib/share";
import { nativeBridge } from "../lib/nativeBridge";
import type { Site } from "../lib/media";

type Filter = "all" | "active" | "queued" | "paused" | "completed" | "failed";
const KIND_ICON = { video: Film, audio: Music, image: ImageIcon, hls: Film, dash: Film, file: FileText, page: Globe, torrent: FileText } as const;
const fmtEta = (s: number) => (!s || !isFinite(s) ? "—" : s < 60 ? `${Math.round(s)}s` : s < 3600 ? `${Math.floor(s / 60)}m ${Math.round(s % 60)}s` : `${Math.floor(s / 3600)}h ${Math.floor((s % 3600) / 60)}m`);

export function Downloads({ go }: { go: (tab: string, sub?: string) => void }) {
  const t = useT();
  const lang = useStore((s) => s.lang);
  const { items, settings, add, setSettings } = useDownloads();
  const [url, setUrl] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const [an, setAn] = useState<Analysis | null>(null);
  const [pick, setPick] = useState<string>("");
  const [filter, setFilter] = useState<Filter>("all");
  const [q, setQ] = useState("");
  const [sort, setSort] = useState<"new" | "name" | "size">("new");
  const [cfg, setCfg] = useState(false);
  const [clip, setClip] = useState("");
  const [renaming, setRenaming] = useState<DlItem | null>(null);
  const [newName, setNewName] = useState("");
  const [msg, setMsg] = useState("");
  const native = isAndroidApk();
  const seq = useRef(0);

  useEffect(() => attachNativeEvents(), []);
  useEffect(() => { if (settings.autoResume) pump(lang); }, []); // eslint-disable-line
  useEffect(() => { const i = setInterval(() => pump(lang), 5000); return () => clearInterval(i); }, [lang]);

  const analyze = async (raw: string) => {
    const my = ++seq.current; setBusy(true); setErr(""); setAn(null); setMsg("");
    try { const a = await analyzeLink(raw, settings.order); if (my !== seq.current) return; setAn(a); setPick(a.formats[0]?.id || ""); }
    catch (e) { if (my === seq.current) setErr(e instanceof Error && e.message === "invalid link" ? t("That isn't a valid link.", "ده مش رابط صحيح.") : (lang === "ar" ? explainError(e).ar : explainError(e).en)); }
    finally { if (my === seq.current) setBusy(false); }
  };
  const submit = (v = url) => { const u = extractUrls(v)[0] || v.trim(); if (!u) return; setUrl(u); void analyze(u); };

  useEffect(() => {
    const take = () => { const p = takePendingShare(); if (p.length) { setUrl(p[0]); void analyze(p[0]); if (p.length > 1) p.slice(1).forEach((u) => void analyzeLink(u, settings.order).then((a) => { add(createItem(a, { format: a.formats[0]?.id })); pump(lang); }).catch(() => {})); } };
    take(); window.addEventListener("dayflow-share-ready", take); return () => window.removeEventListener("dayflow-share-ready", take);
  }, []); // eslint-disable-line

  useEffect(() => { // clipboard link detection (only on user-visible tab; permission-gated by the browser)
    if (!settings.autoPaste || !navigator.clipboard?.readText) return;
    navigator.clipboard.readText().then((x) => { const u = extractUrls(x)[0]; if (u && u !== url && !items.some((i) => i.url === u)) setClip(u); }).catch(() => {});
  }, []); // eslint-disable-line

  const startDownload = () => {
    if (!an) return;
    const f = an.formats.find((x) => x.id === pick);
    const it = createItem(an, { format: f?.id, quality: f?.label, url: f?.url, name: an.filename });
    add(it); setAn(null); setUrl(""); setMsg(t("Added to the queue.", "اتضافت للطابور.")); pump(lang);
  };

  const shown = useMemo(() => {
    const m: Record<Filter, (i: DlItem) => boolean> = { all: () => true, active: (i) => i.state === "downloading", queued: (i) => i.state === "queued", paused: (i) => i.state === "paused", completed: (i) => i.state === "completed", failed: (i) => i.state === "failed" || i.state === "cancelled" };
    const list = items.filter(m[filter]).filter((i) => !q || (i.name + i.host + i.url).toLowerCase().includes(q.toLowerCase()));
    return [...list].sort((a, b) => sort === "name" ? a.name.localeCompare(b.name) : sort === "size" ? b.size - a.size : b.addedAt - a.addedAt);
  }, [items, filter, q, sort]);
  const total = items.filter((i) => i.state === "completed").reduce((n, i) => n + i.size, 0);
  const count = (f: Filter) => items.filter((i) => ({ all: true, active: i.state === "downloading", queued: i.state === "queued", paused: i.state === "paused", completed: i.state === "completed", failed: i.state === "failed" || i.state === "cancelled" })[f]).length;
  const stateLabel: Record<DlState, string> = { queued: t("Queued", "في الانتظار"), downloading: t("Downloading", "بيتحمّل"), paused: t("Paused", "متوقف"), completed: t("Done", "اكتمل"), failed: t("Failed", "فشل"), cancelled: t("Cancelled", "اتلغى") };

  return (
    <div className="pb-4">
      <ScreenHeader title={t("Downloads", "التحميل")} subtitle={t(`${items.length} items · ${fmtBytes(total)} saved`, `${items.length} عنصر · ${fmtBytes(total)} اتحفظ`)} right={<button onClick={() => setCfg(true)} className="grid h-9 w-9 place-items-center rounded-full btn-soft" aria-label={t("Download settings", "إعدادات التحميل")}><Settings2 size={17} /></button>} />

      <Card className="p-3">
        <div className="flex items-center gap-2">
          <div className="flex min-w-0 flex-1 items-center gap-2 rounded-2xl px-3 py-2" style={{ background: "var(--soft)" }}>
            <Link2 size={16} className="flex-none accent" />
            <input dir="ltr" value={url} onChange={(e) => setUrl(e.target.value)} onKeyDown={(e) => e.key === "Enter" && submit()} placeholder={t("Paste a link…", "الصق الرابط…")} aria-label={t("Link", "الرابط")} className="min-w-0 flex-1 bg-transparent text-sm outline-none" />
            {url && <button onClick={() => { setUrl(""); setAn(null); setErr(""); }} aria-label="clear"><X size={14} className="muted" /></button>}
          </div>
          <button onClick={async () => { try { const x = await navigator.clipboard.readText(); const u = extractUrls(x)[0] || x.trim(); if (u) { setUrl(u); void analyze(u); } } catch { setErr(t("Clipboard access was denied by the system.", "النظام منع الوصول للحافظة.")); } }} className="grid h-11 w-11 flex-none place-items-center rounded-2xl btn-soft" aria-label={t("Paste", "لصق")}><ClipboardPaste size={18} /></button>
          <button onClick={() => submit()} disabled={busy || !url.trim()} className="btn-primary grid h-11 w-11 flex-none place-items-center rounded-2xl disabled:opacity-50" style={{ background: "var(--accent)", color: "var(--on-accent)" }} aria-label={t("Analyze", "تحليل")}>{busy ? <Loader2 size={18} className="animate-spin" /> : <Search size={18} />}</button>
        </div>
        {clip && !url && <button onClick={() => { setUrl(clip); setClip(""); void analyze(clip); }} className="chip mt-2 text-[11px]"><ClipboardPaste size={11} />{t("Link in clipboard — download it?", "في رابط في الحافظة — تحمّله؟")}<span dir="ltr" className="max-w-[160px] truncate muted">{clip}</span></button>}
        {err && <p className="mt-2 rounded-xl p-2 text-xs text-red-500" style={{ background: "color-mix(in oklch, red 8%, transparent)" }}>{err}</p>}
        {msg && <p className="mt-2 text-xs accent">{msg}</p>}

        {an && (
          <div className="mt-3 fade-in">
            <div className="flex gap-3">
              {an.thumb ? <img src={an.thumb} alt="" className="h-20 w-32 flex-none rounded-xl object-cover" onError={(e) => ((e.target as HTMLImageElement).style.display = "none")} /> : <span className="grid h-20 w-20 flex-none place-items-center rounded-xl" style={{ background: "var(--soft)" }}>{(() => { const I = KIND_ICON[an.kind]; return <I size={28} className="accent" />; })()}</span>}
              <div className="min-w-0 flex-1">
                <p className="line-clamp-2 text-sm font-bold" dir="auto">{an.title}</p>
                <p className="mt-0.5 flex items-center gap-1.5 text-[11px] muted"><SiteLogo site={an.site as Site} host={an.host} /><span dir="ltr" className="truncate">{an.host}</span></p>
                <p className="mt-1 flex flex-wrap items-center gap-1.5 text-[11px]">
                  <span className="chip" style={{ color: an.secure ? "var(--accent)" : "#d9822b" }}>{an.secure ? <ShieldCheck size={11} /> : <ShieldAlert size={11} />}{an.secure ? "HTTPS" : t("Not secure (HTTP)", "غير آمن (HTTP)")}</span>
                  {an.size ? <span className="chip">{fmtBytes(an.size)}</span> : null}
                  {an.duration ? <span className="chip"><Clock size={11} />{fmtEta(an.duration)}</span> : null}
                  {an.rangeOk ? <span className="chip">{t("Resumable", "بيكمّل")}</span> : null}
                  {an.fromCache ? <span className="chip">{t("cached", "من الكاش")}</span> : null}
                </p>
                {an.author && <p className="mt-1 text-[11px] muted">{an.author}</p>}
              </div>
            </div>
            {an.engineNote && <p className="mt-2 rounded-xl p-2 text-[11px] leading-relaxed" style={{ background: "var(--soft)", color: "var(--muted)" }}>{an.engineNote}</p>}
            {an.formats.length > 0 && <div className="mt-3 grid gap-1.5" role="radiogroup" aria-label={t("Formats", "الصيغ")}>
              {an.formats.map((f) => <button key={f.id} role="radio" aria-checked={pick === f.id} onClick={() => setPick(f.id)} className="flex items-center gap-2 rounded-xl border p-2 text-start text-xs transition-colors" style={{ borderColor: pick === f.id ? "var(--accent)" : "var(--line)", background: pick === f.id ? "var(--soft)" : "transparent" }}>
                {f.kind === "audio" ? <Music size={14} className="accent" /> : f.kind === "image" ? <ImageIcon size={14} className="accent" /> : <Film size={14} className="accent" />}
                <span className="font-bold">{f.label}</span><span className="min-w-0 flex-1 truncate muted">{f.detail}</span>{f.size ? <span className="muted">{fmtBytes(f.size)}</span> : null}
              </button>)}
            </div>}
            <p className="mt-2 flex flex-wrap items-center gap-1 text-[10px] muted">{t("Engine order:", "ترتيب الأدوات:")}{an.engines.map((e, i) => <span key={e} className="chip text-[10px]" style={{ opacity: !native && ENGINES[e].native ? 0.5 : 1 }}>{i + 1}. {ENGINES[e].name}</span>)}</p>
            <div className="mt-3 flex gap-2">
              <button onClick={startDownload} className="btn-primary flex flex-1 items-center justify-center gap-2 rounded-2xl py-2.5 text-sm font-bold" style={{ background: "var(--accent)", color: "var(--on-accent)" }}><Download size={16} />{t("Download", "تحميل")}</button>
              {an.kind === "page" && <button onClick={() => { if (native) void nativeBridge.openSniffer({ url: an.url }); else setMsg(t("The in-app browser with media sniffing is part of the Android app (WebView).", "المتصفح المدمج واكتشاف الوسائط جزء من تطبيق أندرويد (WebView).")); }} className="btn-soft flex items-center gap-1.5 rounded-2xl px-3 text-xs font-bold"><ScanSearch size={15} />{t("Detect media", "اكتشاف الوسائط")}</button>}
            </div>
          </div>
        )}
      </Card>

      <div className="mt-4 flex items-center gap-2">
        <div className="flex flex-1 items-center gap-2 rounded-2xl px-3 py-2" style={{ background: "var(--soft)" }}><Search size={14} className="muted" /><input value={q} onChange={(e) => setQ(e.target.value)} placeholder={t("Search downloads", "ابحث في التنزيلات")} aria-label={t("Search downloads", "ابحث في التنزيلات")} className="min-w-0 flex-1 bg-transparent text-xs outline-none" /></div>
        <select value={sort} onChange={(e) => setSort(e.target.value as typeof sort)} aria-label={t("Sort", "ترتيب")} className="rounded-2xl px-2 py-2 text-xs" style={{ background: "var(--soft)", color: "var(--text)" }}><option value="new">{t("Newest", "الأحدث")}</option><option value="name">{t("Name", "الاسم")}</option><option value="size">{t("Size", "الحجم")}</option></select>
      </div>
      <div className="mt-2 overflow-x-auto"><Segmented<Filter> value={filter} onChange={setFilter} options={(["all", "active", "queued", "paused", "completed", "failed"] as Filter[]).map((f) => ({ id: f, label: `${({ all: t("All", "الكل"), active: t("Active", "نشط"), queued: t("Queue", "انتظار"), paused: t("Paused", "متوقف"), completed: t("Done", "تم"), failed: t("Failed", "فشل") })[f]} ${count(f)}` }))} /></div>

      <div className="mt-3 grid gap-2.5">
        {shown.length === 0 && <Card className="p-6 text-center text-sm muted"><Download size={26} className="mx-auto mb-2 accent" />{t("Nothing here yet. Paste or share a link to start.", "لسه مفيش حاجة. الصق رابط أو شاركه من أي تطبيق.")}</Card>}
        {shown.map((i) => {
          const pct = i.size ? Math.min(100, (i.got / i.size) * 100) : i.state === "completed" ? 100 : 0;
          const I = KIND_ICON[i.kind] || FileText;
          return (
            <Card key={i.id} className="p-3">
              <div className="flex gap-3">
                {i.thumb ? <img src={i.thumb} alt="" className="h-12 w-12 flex-none rounded-xl object-cover" onError={(e) => ((e.target as HTMLImageElement).style.display = "none")} /> : <span className="grid h-12 w-12 flex-none place-items-center rounded-xl" style={{ background: "var(--soft)" }}><I size={20} className="accent" /></span>}
                <div className="min-w-0 flex-1">
                  <p className="truncate text-[13px] font-bold" dir="auto">{i.name}</p>
                  <p className="mt-0.5 flex items-center gap-1.5 text-[10.5px] muted"><SiteLogo site={i.site as Site} host={i.host} /><span dir="ltr" className="truncate">{i.host}</span><span>·</span><span>{new Date(i.addedAt).toLocaleString(lang === "ar" ? "ar-EG" : "en-US", { dateStyle: "short", timeStyle: "short" })}</span></p>
                  <p className="mt-1 flex flex-wrap items-center gap-1 text-[10.5px]">
                    <span className="chip text-[10px]">{stateLabel[i.state]}</span>
                    {i.quality && <span className="chip text-[10px]">{i.quality}</span>}
                    {i.engine && <span className="chip text-[10px]">{ENGINES[i.engine].name}</span>}
                    <span className="chip text-[10px]" style={{ color: i.secure ? "var(--accent)" : "#d9822b" }}>{i.secure ? <ShieldCheck size={10} /> : <ShieldAlert size={10} />}{i.secure ? t("Safe", "آمن") : t("Unsafe", "غير آمن")}</span>
                  </p>
                </div>
              </div>
              {(i.state === "downloading" || i.state === "paused" || i.state === "queued") && <div className="mt-2.5"><div className="h-1.5 overflow-hidden rounded-full" style={{ background: "var(--line)" }} role="progressbar" aria-valuenow={Math.round(pct)} aria-valuemin={0} aria-valuemax={100}><div className="h-full rounded-full transition-[width] duration-300" style={{ width: pct + "%", background: "var(--accent)" }} /></div>
                <p className="mt-1 flex justify-between text-[10.5px] muted"><span>{fmtBytes(i.got)}{i.size ? ` / ${fmtBytes(i.size)}` : ""} · {Math.round(pct)}%</span><span>{i.state === "downloading" ? `${fmtBytes(i.speed)}/s · ${fmtEta(i.eta)}` : ""}</span></p></div>}
              {i.state === "completed" && <p className="mt-1.5 text-[10.5px] muted">{fmtBytes(i.size)} · {i.savedAs ? `${settings.saveDir}/${i.savedAs}` : ""}{i.checksum ? ` · SHA-256 ${i.checksum.slice(0, 12)}…` : ""}</p>}
              {i.error && i.state !== "completed" && <p className="mt-1.5 text-[11px] text-red-500">{i.error}</p>}
              {i.notices.length > 0 && <ul className="mt-1.5 grid gap-1">{i.notices.slice(-3).map((n, k) => <li key={k} className="rounded-lg px-2 py-1 text-[10.5px] leading-relaxed" style={{ background: "var(--soft)", color: "var(--muted)" }}>{n}</li>)}</ul>}
              <div className="mt-2 flex flex-wrap gap-1.5">
                {i.state === "downloading" && <Act icon={Pause} label={t("Pause", "إيقاف مؤقت")} onClick={() => pauseItem(i.id)} />}
                {(i.state === "paused" || i.state === "queued") && <Act icon={Play} label={t("Resume", "استكمال")} onClick={() => resumeItem(i.id, lang)} />}
                {(i.state === "failed" || i.state === "cancelled") && <Act icon={RotateCcw} label={t("Retry", "إعادة المحاولة")} onClick={() => retryItem(i.id, lang)} />}
                {(i.state === "downloading" || i.state === "queued" || i.state === "paused") && <Act icon={X} label={t("Cancel", "إلغاء")} onClick={() => cancelItem(i.id)} />}
                {i.state === "completed" && <Act icon={FolderOpen} label={t("Open", "فتح")} onClick={() => void openStored(i.id)} />}
                {i.state === "completed" && <Act icon={Share2} label={t("Share", "مشاركة")} onClick={async () => { try { await navigator.share?.({ title: i.name, url: i.url }); } catch { /* user dismissed */ } }} />}
                <Act icon={Pencil} label={t("Rename", "إعادة تسمية")} onClick={() => { setRenaming(i); setNewName(i.name); }} />
                <Act icon={Link2} label={t("Copy link", "نسخ الرابط")} onClick={() => void navigator.clipboard?.writeText(i.url)} />
                <Act icon={Trash2} label={t("Delete", "حذف")} onClick={() => { if (confirm(t("Delete this download and its stored file?", "تحذف التنزيل ده والملف المخزّن؟"))) void deleteItem(i.id, true); }} />
              </div>
            </Card>
          );
        })}
      </div>

      <Sheet open={!!renaming} onClose={() => setRenaming(null)} title={t("Rename", "إعادة تسمية")}>
        <input value={newName} onChange={(e) => setNewName(e.target.value)} className="w-full rounded-xl px-3 py-2 text-sm outline-none" style={{ background: "var(--soft)" }} aria-label={t("File name", "اسم الملف")} />
        <button onClick={() => { if (renaming && newName.trim()) useDownloads.getState().patch(renaming.id, { name: newName.trim() }); setRenaming(null); }} className="btn-primary mt-3 w-full rounded-2xl py-2.5 text-sm font-bold" style={{ background: "var(--accent)", color: "var(--on-accent)" }}>{t("Save", "حفظ")}</button>
      </Sheet>

      <Sheet open={cfg} onClose={() => setCfg(false)} title={t("Download settings", "إعدادات التحميل")} wide>
        <div className="grid gap-3 text-sm">
          <Num label={t("Simultaneous downloads", "تنزيلات متزامنة")} v={settings.concurrent} min={1} max={8} on={(v) => setSettings({ concurrent: v })} />
          <Num label={t("Connections per file", "اتصالات لكل ملف")} v={settings.connections} min={1} max={16} on={(v) => setSettings({ connections: v })} />
          <Num label={t("Speed limit (KB/s, 0 = unlimited)", "حد السرعة (كيلوبايت/ث، 0 = بدون)")} v={settings.speedLimitKBps} min={0} max={100000} step={256} on={(v) => setSettings({ speedLimitKBps: v })} />
          <Num label={t("Automatic retries", "إعادة محاولة تلقائية")} v={settings.autoRetry} min={0} max={6} on={(v) => setSettings({ autoRetry: v })} />
          <Toggle on={settings.wifiOnly} onChange={(v) => setSettings({ wifiOnly: v })} label={t("Wi-Fi only", "Wi-Fi فقط")} />
          <Toggle on={settings.autoResume} onChange={(v) => setSettings({ autoResume: v })} label={t("Resume automatically on open / network return", "استكمال تلقائي عند الفتح أو رجوع الشبكة")} />
          <Toggle on={settings.nightOnly} onChange={(v) => setSettings({ nightOnly: v })} label={t("Night schedule only (23:00–06:00)", "جدولة ليلية فقط (٢٣:٠٠–٠٦:٠٠)")} />
          <Toggle on={settings.autoPaste} onChange={(v) => setSettings({ autoPaste: v })} label={t("Detect links in the clipboard", "اكتشاف الروابط في الحافظة")} />
          <div>
            <p className="mb-1.5 text-xs font-bold muted">{t("Engine priority (used when you customise it; otherwise chosen per link type)", "أولوية الأدوات (تُستخدم لو عدّلتها؛ وإلا بيتختار حسب نوع الرابط)")}</p>
            <div className="grid gap-1">{settings.order.map((e, idx) => <div key={e} className="flex items-center gap-2 rounded-xl px-2 py-1.5 text-xs" style={{ background: "var(--soft)" }}><span className="w-4 muted">{idx + 1}</span><span className="flex-1 font-semibold">{ENGINES[e].name}</span><span className="muted">{ENGINES[e].native ? "Android" : t("built-in", "مدمج")}</span>
              <button aria-label="up" disabled={idx === 0} onClick={() => { const o = [...settings.order]; [o[idx - 1], o[idx]] = [o[idx], o[idx - 1]]; setSettings({ order: o }); }} className="disabled:opacity-30"><ArrowUp size={14} /></button>
              <button aria-label="down" disabled={idx === settings.order.length - 1} onClick={() => { const o = [...settings.order]; [o[idx + 1], o[idx]] = [o[idx], o[idx + 1]]; setSettings({ order: o }); }} className="disabled:opacity-30"><ArrowDown size={14} /></button></div>)}</div>
            <button onClick={() => setSettings({ order: DEFAULT_ORDER })} className="mt-1.5 text-[11px] accent">{t("Reset to smart default", "رجوع للترتيب الذكي")}</button>
          </div>
          <button onClick={async () => { if (!native) { setMsg(t("Engine binaries (yt-dlp, FFmpeg, aria2c) are updated inside the Android app.", "تحديث الأدوات (yt-dlp وFFmpeg وaria2c) بيتم داخل تطبيق أندرويد.")); setCfg(false); return; } try { const r = await nativeBridge.updateEngines(); setMsg(`yt-dlp → ${r?.ytdlp || "?"}`); } catch (e) { setMsg(explainError(e).ar); } setCfg(false); }} className="btn-soft flex items-center justify-center gap-2 rounded-2xl py-2.5 text-sm font-bold"><RefreshCw size={15} />{t("Update engines", "تحديث الأدوات")}</button>
          <button onClick={() => go("tools", "media")} className="text-center text-[11px] muted underline">{t("Open the classic Media Hub", "افتح مركز الوسائط القديم")}</button>
        </div>
      </Sheet>
    </div>
  );
}
function Act({ icon: I, label, onClick }: { icon: typeof Play; label: string; onClick: () => void }) {
  return <button onClick={onClick} className="chip text-[10.5px] active:scale-95" aria-label={label}><I size={12} />{label}</button>;
}
function Num({ label, v, min, max, step = 1, on }: { label: string; v: number; min: number; max: number; step?: number; on: (n: number) => void }) {
  return <label className="flex items-center justify-between gap-3 text-xs"><span className="flex-1">{label}</span><input type="number" value={v} min={min} max={max} step={step} onChange={(e) => on(Math.max(min, Math.min(max, Number(e.target.value) || 0)))} className="w-24 rounded-xl px-2 py-1.5 text-center text-sm outline-none" style={{ background: "var(--soft)" }} /></label>;
}
