import { useMemo, useRef, useState } from "react";
import { Heart, Search, Check, Copy, Upload, Download, AlertTriangle, Palette } from "lucide-react";
import { useStore, useT } from "../lib/store";
import { THEMES, CATEGORIES, contrastReport, inkOn, withViewTransition, type ThemePack, type Category, type Material, type Shape, type Font, type Motion, type Texture } from "../lib/themes";
import type { Family } from "../lib/calendar";
import { FAMILY, tileDataUri } from "../lib/pattern";
import { Card, ScreenHeader, Segmented, Sheet } from "../components/ui";
import { Motif } from "../components/Decor";
import { PERIODS, periodAt, type Period } from "../lib/ambience";
import { prayerTimes, CITIES } from "../lib/prayer";

const FONTS: Record<Font, string> = { sans: "system-ui, sans-serif", serif: "Georgia, 'Noto Naskh Arabic', serif", mono: "ui-monospace, monospace", rounded: "ui-rounded, system-ui, sans-serif", condensed: "'Arial Narrow', system-ui, sans-serif" };
const RADII: Record<Shape, number> = { round: 12, squircle: 16, chamfer: 3, sharp: 1 };

export function useAllThemes() { const custom = useStore((s) => s.customThemes); return useMemo(() => [...THEMES, ...custom], [custom]); }

const CAT_PERIOD: Record<string, Period> = { light: "morning", dark: "night", egypt: "maghrib", islamic: "night", nature: "fajr", glass: "noon", tech: "night", warm: "asr", playful: "fajr", custom: "noon" };
export const themePhoto = (th: ThemePack) => PERIODS[(Object.values(PERIODS).find((p) => p.theme === th.id)?.id) || CAT_PERIOD[th.cat] || "noon"].photo;

export function ThemePreview({ th, compact }: { th: ThemePack; compact?: boolean }) {
  const lang = useStore((s) => s.lang);
  const vars = { ["--bg" as string]: th.bg, ["--surface" as string]: th.surface, ["--text" as string]: th.text, ["--accent" as string]: th.accent, ["--accent2" as string]: th.accent2, ["--on-accent" as string]: inkOn(th.accent), ["--r" as string]: RADII[th.shape] + "px", fontFamily: FONTS[th.font], color: th.text, background: th.bg };
  const f = FAMILY[th.ornament];
  return (
    <div data-material={th.material} data-shape={th.shape} data-texture={th.texture} data-mode={th.mode} className="relative overflow-hidden" style={{ ...vars, aspectRatio: compact ? "3/4" : "9/14", borderRadius: 14 }} dir={lang === "ar" ? "rtl" : "ltr"}>
      <div className="app-bg" style={{ position: "absolute" }} />
      <img src={themePhoto(th)} alt="" aria-hidden className="pointer-events-none absolute inset-x-0 top-0 h-1/2 w-full object-cover" style={{ opacity: th.mode === "dark" ? 0.45 : 0.38, maskImage: "linear-gradient(180deg,#000 30%,transparent)", WebkitMaskImage: "linear-gradient(180deg,#000 30%,transparent)" }} />
      {th.texture === "pattern" && <div className="absolute inset-0" style={{ backgroundImage: tileDataUri(th.ornament, th.text, 0.12, 36) }} />}
      <div className="relative space-y-1.5 p-2">
        <div className="card overflow-hidden p-2 text-white" style={{ background: `linear-gradient(140deg, ${f.c2}, ${f.c1})`, border: "none" }}>
          <div className="flex items-start justify-between"><div><div className="text-[7px] opacity-80">{lang === "ar" ? "صباح الخير" : "Good morning"}</div><div className="text-[10px] font-bold leading-tight">{lang === "ar" ? "الجمعة ١٢" : "Friday 12"}</div></div><Motif family={th.ornament} size={20} mono="#ffffffcc" /></div>
        </div>
        <div className="grid grid-cols-2 gap-1.5">
          <div className="card p-1.5"><div className="text-[6px] opacity-60">{lang === "ar" ? "المنبه" : "Alarm"}</div><div className="text-[11px] font-bold">06:30</div></div>
          <div className="card grid place-items-center p-1.5"><svg width="22" height="22" className="-rotate-90"><circle cx="11" cy="11" r="8" fill="none" stroke={th.text} strokeOpacity=".15" strokeWidth="3" /><circle cx="11" cy="11" r="8" fill="none" stroke={th.accent} strokeWidth="3" strokeDasharray="50" strokeDashoffset="18" strokeLinecap="round" /></svg></div>
        </div>
        <div className="card space-y-1 p-1.5">{[1, 0, 0].map((d, i) => <div key={i} className="flex items-center gap-1"><span className="h-2 w-2 rounded-[3px] border" style={{ borderColor: th.accent, background: d ? th.accent : "transparent" }} /><span className="h-1 flex-1 rounded" style={{ background: th.text, opacity: d ? 0.15 : 0.3 }} /></div>)}</div>
        {!compact && <div className="card p-1.5"><div className="grid grid-cols-7 gap-[2px]">{Array.from({ length: 21 }, (_, i) => <span key={i} className="aspect-square rounded-[2px]" style={{ background: i === 11 ? th.accent : th.text, opacity: i === 11 ? 1 : 0.08 }} />)}</div></div>}
        <div className="flex justify-center"><span className="btn-primary rounded-full px-2 py-0.5 text-[7px] font-bold" style={{ background: th.accent, color: inkOn(th.accent) }}>+ {lang === "ar" ? "جديد" : "New"}</span></div>
      </div>
    </div>
  );
}

export function Themes({ onBack }: { onBack: () => void }) {
  const t = useT();
  const s = useStore();
  const all = useAllThemes();
  const [cat, setCat] = useState<Category | "all" | "fav">("all");
  const [q, setQ] = useState("");
  const [mode, setMode] = useState<"gallery" | "studio" | "surfaces">("gallery");
  const list = all.filter((th) => (cat === "all" || (cat === "fav" ? s.favThemes.includes(th.id) : th.cat === cat)) && (!q || (th.en + th.ar).toLowerCase().includes(q.toLowerCase())));
  const apply = (id: string) => withViewTransition(() => s.set({ themeId: id }));
  return (
    <div className="pb-4">
      <ScreenHeader title={t("Themes", "السمات")} subtitle={t(`${all.length} theme packs`, `${all.length} حزمة سمات`)} onBack={onBack} />
      <DaySchedule />
      <Segmented value={mode} onChange={setMode} options={[{ id: "gallery", label: t("Gallery", "المعرض") }, { id: "studio", label: t("Studio", "الاستوديو") }, { id: "surfaces", label: t("Per surface", "لكل واجهة") }]} />
      {mode === "gallery" && <>
        <div className="relative my-3"><Search size={16} className="muted absolute start-3 top-1/2 -translate-y-1/2" /><input value={q} onChange={(e) => setQ(e.target.value)} className="field ps-9" placeholder={t("Search themes", "ابحث في السمات")} /></div>
        <div className="scroll-hide -mx-4 mb-3 flex gap-1.5 overflow-x-auto px-4">
          <button className="chip" aria-pressed={cat === "all"} onClick={() => setCat("all")}>{t("All", "الكل")}</button>
          <button className="chip" aria-pressed={cat === "fav"} onClick={() => setCat("fav")}><Heart size={12} />{t("Favourites", "المفضلة")}</button>
          {CATEGORIES.map((c) => <button key={c.id} className="chip" aria-pressed={cat === c.id} onClick={() => setCat(c.id)}>{s.lang === "ar" ? c.ar : c.en}</button>)}
        </div>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
          {list.map((th) => {
            const active = s.themeId === th.id; const fav = s.favThemes.includes(th.id);
            return (
              <div key={th.id} className="relative">
                <button onClick={() => apply(th.id)} className="block w-full rounded-2xl p-1 text-start transition" style={{ outline: active ? "2.5px solid var(--accent)" : "1px solid var(--line)", outlineOffset: 1 }} aria-label={th.en} aria-pressed={active}>
                  <ThemePreview th={th} compact />
                  <div className="flex items-center gap-1 px-1 pb-0.5 pt-1.5"><span className="flex-1 truncate text-xs font-semibold">{s.lang === "ar" ? th.ar : th.en}</span>{active && <Check size={14} className="accent" />}</div>
                  <div className="px-1 text-[10px] muted">{th.material} · {th.shape} · {th.font}</div>
                </button>
                <button onClick={() => s.set({ favThemes: fav ? s.favThemes.filter((x) => x !== th.id) : [...s.favThemes, th.id] })} className="absolute end-2.5 top-2.5 grid h-7 w-7 place-items-center rounded-full bg-black/30 text-white backdrop-blur" aria-label={t("Favourite", "مفضلة")}><Heart size={13} fill={fav ? "white" : "none"} /></button>
              </div>
            );
          })}
        </div>
      </>}
      {mode === "studio" && <Studio />}
      {mode === "surfaces" && <Surfaces />}
    </div>
  );
}

function Studio() {
  const t = useT();
  const s = useStore();
  const all = useAllThemes();
  const base = all.find((x) => x.id === s.themeId) || THEMES[0];
  const [d, setD] = useState<ThemePack>({ ...base });
  const [err, setErr] = useState("");
  const fileRef = useRef<HTMLInputElement>(null);
  const report = contrastReport(d);
  const set = (p: Partial<ThemePack>) => setD({ ...d, ...p });
  const save = () => {
    const id = d.custom ? d.id : "custom-" + Date.now().toString(36);
    const pack: ThemePack = { ...d, id, custom: true, cat: "custom", en: d.custom ? d.en : d.en + " (custom)", ar: d.custom ? d.ar : d.ar + " (مخصص)" };
    s.set({ customThemes: [...s.customThemes.filter((x) => x.id !== id), pack], themeId: id });
    setD(pack);
  };
  const exportPack = () => { const blob = new Blob([JSON.stringify({ format: "dayflowtheme", schema: 1, pack: d }, null, 2)], { type: "application/json" }); const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = (d.en || "theme").replace(/\W+/g, "-") + ".dayflowtheme.json"; a.click(); };
  const importPack = async (f: File) => {
    try {
      const j = JSON.parse(await f.text()); const p = j.pack as ThemePack;
      const hex = /^#[0-9a-f]{6}$/i;
      if (j.format !== "dayflowtheme" || !p || ![p.bg, p.surface, p.text, p.accent, p.accent2].every((c) => hex.test(c))) throw new Error("invalid");
      setD({ ...THEMES[0], ...p, custom: true, id: "custom-" + Date.now().toString(36) }); setErr("");
    } catch { setErr(t("That file isn't a valid theme pack.", "هذا الملف ليس حزمة سمات صالحة.")); }
  };
  const opts = <T extends string>(arr: readonly T[], val: T, key: keyof ThemePack) => <div className="flex flex-wrap gap-1.5">{arr.map((o) => <button key={o} className="chip capitalize" aria-pressed={val === o} onClick={() => set({ [key]: o } as Partial<ThemePack>)}>{o}</button>)}</div>;
  return (
    <div className="mt-4 grid gap-4 sm:grid-cols-[180px_1fr]">
      <div className="mx-auto w-44 sm:sticky sm:top-20 sm:self-start"><ThemePreview th={d} /></div>
      <div className="space-y-4">
        <Card className="p-4">
          <p className="mb-3 flex items-center gap-2 font-bold"><Palette size={16} className="accent" />{t("Palette", "الألوان")}</p>
          <div className="grid grid-cols-5 gap-2">{(["bg", "surface", "text", "accent", "accent2"] as const).map((k) => <label key={k} className="flex flex-col items-center gap-1 text-[10px] muted"><input type="color" value={d[k]} onChange={(e) => set({ [k]: e.target.value })} className="h-10 w-10 cursor-pointer rounded-full border-0 bg-transparent" />{k}</label>)}</div>
          <div className="mt-3 space-y-1">{report.map((r) => <div key={r.k} className="flex items-center gap-2 text-xs">{r.v >= r.min ? <Check size={13} className="text-green-600" /> : <AlertTriangle size={13} className="text-amber-500" />}<span className="flex-1">{s.lang === "ar" ? r.ar : r.k}</span><span className={r.v >= r.min ? "" : "font-bold text-amber-600"}>{r.v.toFixed(2)}:1 {r.v < r.min && `(AA ${r.min})`}</span></div>)}</div>
        </Card>
        <Card className="space-y-3 p-4">
          <div><p className="mb-1.5 text-xs font-semibold muted">{t("Material", "الخامة")}</p>{opts<Material>(["paper", "glass", "matte", "glossy", "clay", "flat", "outlined", "blueprint", "neon"], d.material, "material")}</div>
          <div><p className="mb-1.5 text-xs font-semibold muted">{t("Shape", "الشكل")}</p>{opts<Shape>(["round", "squircle", "chamfer", "sharp"], d.shape, "shape")}</div>
          <div><p className="mb-1.5 text-xs font-semibold muted">{t("Typography", "الخط")}</p>{opts<Font>(["sans", "serif", "rounded", "mono", "condensed"], d.font, "font")}</div>
          <div><p className="mb-1.5 text-xs font-semibold muted">{t("Motion", "الحركة")}</p>{opts<Motion>(["calm", "springy", "snappy", "none"], d.motion, "motion")}</div>
          <div><p className="mb-1.5 text-xs font-semibold muted">{t("Texture", "الملمس")}</p>{opts<Texture>(["none", "grain", "grid", "dots", "lines", "mesh", "pattern"], d.texture, "texture")}</div>
          <div><p className="mb-1.5 text-xs font-semibold muted">{t("Ornament affinity", "الزخرفة المفضلة")}</p><div className="flex flex-wrap gap-1.5">{(Object.keys(FAMILY) as Family[]).map((f) => <button key={f} className="chip" aria-pressed={d.ornament === f} onClick={() => set({ ornament: f })}><Motif family={f} size={14} />{s.lang === "ar" ? FAMILY[f].ar : FAMILY[f].en}</button>)}</div></div>
          <label className="flex items-center justify-between text-sm">{t("Mode", "الوضع")}<select className="field w-32 py-1" value={d.mode} onChange={(e) => set({ mode: e.target.value as "light" | "dark" })}><option value="light">{t("Light", "فاتح")}</option><option value="dark">{t("Dark", "داكن")}</option></select></label>
        </Card>
        {err && <p className="text-sm text-red-500">{err}</p>}
        <div className="grid grid-cols-3 gap-2">
          <button className="btn btn-primary col-span-3" onClick={save}><Copy size={15} />{d.custom ? t("Save & apply", "حفظ وتطبيق") : t("Save as my pack", "حفظ كحزمتي")}</button>
          <button className="btn btn-soft" onClick={exportPack}><Download size={15} />{t("Export", "تصدير")}</button>
          <button className="btn btn-soft" onClick={() => fileRef.current?.click()}><Upload size={15} />{t("Import", "استيراد")}</button>
          <button className="btn btn-ghost" onClick={() => setD({ ...base })}>{t("Reset", "إعادة")}</button>
          <input ref={fileRef} type="file" accept=".json,application/json" className="hidden" onChange={(e) => e.target.files?.[0] && importPack(e.target.files[0])} />
        </div>
      </div>
    </div>
  );
}

function Surfaces() {
  const t = useT(); const s = useStore(); const all = useAllThemes(); const [pick, setPick] = useState<null | "widgets" | "alarm" | "companion">(null);
  const name = (id?: string) => { const th = all.find((x) => x.id === id); return th ? (s.lang === "ar" ? th.ar : th.en) : t("Same as app", "مثل التطبيق"); };
  return (
    <div className="mt-4 space-y-3">
      {(["widgets", "alarm", "companion"] as const).map((k) => <Card key={k} className="flex items-center justify-between p-4" onClick={() => setPick(k)}><span className="font-medium">{{ widgets: t("Widgets", "الودجات"), alarm: t("Alarm screen", "شاشة المنبه"), companion: t("Companion panel", "لوحة الرفيق") }[k]}</span><span className="text-sm muted">{name(s.surfaceTheme[k])}</span></Card>)}
      <Card className="flex items-center justify-between p-4"><span><span className="block font-medium">{t("Follow wallpaper colours", "اتباع ألوان الخلفية")}</span><span className="text-xs muted">{t("Android 12+ dynamic colour, in the app build", "ألوان أندرويد ١٢+ الديناميكية، في نسخة التطبيق")}</span></span><span className="chip text-[10px]">Android</span></Card>
      <Sheet open={!!pick} onClose={() => setPick(null)} title={t("Choose pack", "اختر حزمة")}>
        <button className="chip mb-3" onClick={() => { s.set({ surfaceTheme: { ...s.surfaceTheme, [pick!]: undefined } }); setPick(null); }}>{t("Same as app", "مثل التطبيق")}</button>
        <div className="grid grid-cols-3 gap-2">{all.map((th) => <button key={th.id} onClick={() => { s.set({ surfaceTheme: { ...s.surfaceTheme, [pick!]: th.id } }); setPick(null); }} className="text-start"><ThemePreview th={th} compact /><span className="block truncate text-[10px]">{s.lang === "ar" ? th.ar : th.en}</span></button>)}</div>
      </Sheet>
    </div>
  );
}


function DaySchedule() {
  const t = useT(); const s = useStore(); const all = useAllThemes();
  const now = periodAt(new Date(), prayerTimes(CITIES[s.cityIndex] || CITIES[0]));
  return (
    <section className="mb-5">
      <div className="card mb-2 flex items-center gap-3 p-3">
        <span className="flex-1"><span className="block text-sm font-bold">{t("Theme follows the time of day", "الثيم بيتغير مع اليوم")}</span><span className="block text-[11px] muted">{t("Fajr · Morning · Dhuhr · Asr · Maghrib · Night — based on your city's prayer times", "الفجر · الصباح · الظهر · العصر · المغرب · الليل — حسب مواقيت مدينتك")}</span></span>
        <button role="switch" aria-checked={s.autoTimeTheme} aria-label="auto time theme" className="switch" onClick={() => s.set({ autoTimeTheme: !s.autoTimeTheme })} />
      </div>
      <div className="card mb-3 flex items-center gap-3 p-3">
        <span className="flex-1 text-sm font-semibold">{t("Real photo backdrop", "خلفية بصورة حقيقية")}</span>
        <button role="switch" aria-checked={s.ambientPhoto} aria-label="ambient photo" className="switch" onClick={() => s.set({ ambientPhoto: !s.ambientPhoto })} />
      </div>
      <div className="scroll-hide -mx-4 flex gap-3 overflow-x-auto px-4 pb-1">
        {(Object.keys(PERIODS) as Period[]).map((k) => {
          const p = PERIODS[k]; const sel = s.periodThemes[k] || p.theme; const th = all.find((x) => x.id === sel);
          return (
            <div key={k} className="relative w-40 flex-none overflow-hidden rounded-3xl text-white shadow-md" style={{ outline: now === k ? "3px solid var(--accent)" : "none", outlineOffset: 2 }}>
              <img src={p.photo} alt="" className="absolute inset-0 h-full w-full object-cover" />
              <div className="absolute inset-0" style={{ background: "linear-gradient(180deg, rgba(0,0,0,.05), rgba(0,0,0,.7))" }} />
              <div className="relative flex h-44 flex-col justify-end p-3">
                {now === k && <span className="mb-auto self-start rounded-full bg-white/25 px-2 py-0.5 text-[10px] font-bold backdrop-blur">{t("Now", "دلوقتي")}</span>}
                <p className="text-base font-bold leading-tight">{s.lang === "ar" ? p.ar : p.en}</p>
                <select value={sel} onChange={(e) => s.set({ periodThemes: { ...s.periodThemes, [k]: e.target.value } })} className="mt-1.5 w-full rounded-xl bg-white/20 px-2 py-1 text-[11px] font-semibold text-white backdrop-blur outline-none" aria-label={p.en}>
                  {all.map((x) => <option key={x.id} value={x.id} style={{ color: "#111" }}>{s.lang === "ar" ? x.ar : x.en}</option>)}
                </select>
                {th && <div className="mt-1.5 flex gap-1">{[th.bg, th.surface, th.accent, th.accent2].map((c, i) => <span key={i} className="h-3 w-3 rounded-full border border-white/50" style={{ background: c }} />)}</div>}
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
}
