import { useMemo, useState } from "react";
import { Plus, Pencil, Trash2, Check, Flame, Repeat, Bell, Target } from "lucide-react";
import { useStore, useT, fmtNum, newId, type Habit, type HabitType } from "../lib/store";
import { dayKey } from "../lib/calendar";
import { Card, Honest, ScreenHeader, Sheet } from "../components/ui";
import { EmptyState, Motif, useDecor } from "../components/Decor";

const ORDER = [6, 0, 1, 2, 3, 4, 5];
const DAY = (d: number, lang: "en" | "ar", style: "narrow" | "short" = "short") => new Date(2024, 0, 7 + d).toLocaleDateString(lang === "ar" ? "ar-EG" : "en", { weekday: style });
const EMOJI = ["🌅", "📖", "💧", "🏃", "🧘", "📵", "🦷", "✍️", "🧹", "💊", "🌿", "🕌", "🎯", "🥗", "😴"];
const COLORS = ["#2fa36b", "#3e63dd", "#d4a237", "#e5484d", "#7a5cff", "#0f9b8e", "#d6456b"];
const TYPES: Array<{ id: HabitType; en: string; ar: string; hintEn: string; hintAr: string }> = [
  { id: "build", en: "Build", ar: "بناء عادة", hintEn: "Do it every chosen day", hintAr: "تعملها كل يوم مختار" },
  { id: "quit", en: "Quit", ar: "إقلاع", hintEn: "A day counts when you avoid it", hintAr: "اليوم يتحسب لما تبعد عنها" },
  { id: "count", en: "Count", ar: "عدد", hintEn: "Reach a number, e.g. 8 cups", hintAr: "توصل لرقم، مثل ٨ أكواب" },
  { id: "timer", en: "Timer", ar: "مدة", hintEn: "Minutes, e.g. 20 min reading", hintAr: "دقايق، مثل ٢٠ دقيقة قراية" },
];

export function Habits() {
  const t = useT();
  const s = useStore();
  const lang = s.lang;
  const N = (n: number | string) => fmtNum(n, lang);
  const decor = useDecor();
  const [edit, setEdit] = useState<Habit | "new" | null>(null);
  const days = useMemo(() => Array.from({ length: 28 }, (_, i) => { const d = new Date(); d.setDate(d.getDate() - 27 + i); return dayKey(d); }), []);
  const today = dayKey(new Date());
  const streak = (h: Habit) => { let n = 0; for (let i = 0; i < 400; i++) { const d = new Date(); d.setDate(d.getDate() - i); if (h.log.includes(dayKey(d))) n++; else if (i > 0) break; } return n; };
  const scheduled = (h: Habit) => (!h.startDate || h.startDate <= today) && (!h.days?.length || h.days.includes(new Date().getDay()));
  return (
    <div className="pb-4">
      <ScreenHeader title={t("Habits", "العادات")} subtitle={t("Name, days, type, target — all yours", "الاسم والأيام والنوع والهدف — كل حاجة بإيدك")} onBack={() => { location.hash = "#/tools"; }} right={<button className="btn btn-primary" onClick={() => setEdit("new")}><Plus size={17} />{t("New", "جديدة")}</button>} />
      {!s.habits.length && <EmptyState family={decor.primary} title={t("Start one small habit", "ابدأ بعادة صغيرة")} hint={t("20 minutes, 3 days a week — that's enough.", "٢٠ دقيقة، ٣ أيام في الأسبوع — كفاية.")} action={<button className="btn btn-primary" onClick={() => setEdit("new")}>{t("Create a habit", "اعمل عادة")}</button>} />}
      <div className="space-y-3">
        {s.habits.map((h) => {
          const color = h.color || "var(--accent)";
          const on = h.log.includes(today);
          return <Card key={h.id} className="p-4">
            <div className="flex items-start gap-3">
              <button onClick={() => s.toggleHabit(h.id)} disabled={!!h.startDate && h.startDate > today} aria-pressed={on} aria-label={h.en} className="grid h-12 w-12 flex-none place-items-center rounded-2xl text-xl transition active:scale-90 disabled:opacity-40" style={{ background: on ? color : "var(--soft)", color: on ? "#fff" : undefined, border: `2px solid ${on ? color : "transparent"}` }}>{h.emoji || (on ? <Check size={20} /> : "○")}</button>
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2"><p className="truncate font-semibold">{h.en}</p>{h.type === "quit" && <span className="chip px-1.5 py-0 text-[9px]">{t("quit", "إقلاع")}</span>}</div>
                <p className="text-[11px] muted">{(h.days?.length ? ORDER.filter((d) => h.days!.includes(d)).map((d) => DAY(d, lang, "narrow")).join(" ") : t("Every day", "كل يوم"))}{h.startDate ? ` · ${t("Starts", "بتبدأ")} ${h.startDate}` : ""}{h.target ? ` · ${N(h.target)} ${h.unit || ""}` : ""}{h.reminder ? ` · ⏰ ${N(h.reminder)}` : ""}</p>
                {h.details && <p className="mt-0.5 line-clamp-1 text-[11px] muted">{h.details}</p>}
              </div>
              <div className="flex flex-none items-center gap-1"><span className="flex items-center gap-0.5 text-xs font-bold" style={{ color }}><Flame size={12} />{N(streak(h))}</span><button onClick={() => setEdit(h)} className="muted p-1" aria-label={t("Edit", "تعديل")}><Pencil size={13} /></button><button onClick={() => s.removeHabit(h.id)} className="muted p-1" aria-label={t("Delete", "حذف")}><Trash2 size={13} /></button></div>
            </div>
            <div className="mt-3 grid gap-1" style={{ gridTemplateColumns: "repeat(14, 1fr)" }}>{days.map((d) => <button key={d} onClick={() => s.toggleHabit(h.id, d)} aria-label={d} aria-pressed={h.log.includes(d)} className="aspect-square rounded-[3px]" style={{ background: h.log.includes(d) ? color : "var(--line)" }} />)}</div>
            {scheduled(h) && !on && <p className="mt-1.5 text-[10px]" style={{ color }}>{t("Scheduled today — one tap.", "مجدولة النهاردة — ضغطة واحدة.")}</p>}
          </Card>;
        })}
      </div>
      {s.habits.length > 0 && <Honest>{t("Habits are counted in the Review engine (Consistency dimension). Data stays on this device, and skipped non-scheduled days never count as failures.", "العادات بتتحسب في المراجعة (بُعد الاستمرارية). البيانات على جهازك فقط، والأيام اللي مش مجدولة مش بتتحسب فشل.")}</Honest>}
      {edit && <HabitEditor habit={edit === "new" ? null : edit} onClose={() => setEdit(null)} />}
    </div>
  );
}

function HabitEditor({ habit, onClose }: { habit: Habit | null; onClose: () => void }) {
  const t = useT();
  const s = useStore();
  const lang = s.lang;
  const [name, setName] = useState(habit?.en || "");
  const [emoji, setEmoji] = useState(habit?.emoji || "🌅");
  const [type, setType] = useState<HabitType>(habit?.type || "build");
  const [days, setDays] = useState<number[]>(habit?.days?.length ? habit.days : [0, 1, 2, 3, 4, 5, 6]);
  const [target, setTarget] = useState(habit?.target || 1);
  const [unit, setUnit] = useState(habit?.unit || "");
  const [details, setDetails] = useState(habit?.details || "");
  const [reminder, setReminder] = useState(habit?.reminder || "");
  const [color, setColor] = useState(habit?.color || "#2fa36b");
  const valid = name.trim().length > 0 && days.length > 0;
  const save = () => {
    const payload = { en: name.trim(), emoji, type, days, target, unit: unit || undefined, details: details || undefined, reminder: reminder || undefined, color };
    if (habit) s.updateHabit(habit.id, payload); else s.addHabit(payload);
    onClose();
  };
  const presets = [
    { id: "wd", label: t("Sun–Thu", "الأحد–الخميس"), d: [0, 1, 2, 3, 4] },
    { id: "we", label: t("Fri–Sat", "الجمعة–السبت"), d: [5, 6] },
    { id: "3", label: t("3 days", "٣ أيام"), d: [0, 2, 4] },
    { id: "all", label: t("Every day", "كل يوم"), d: [0, 1, 2, 3, 4, 5, 6] },
  ];
  return (
    <Sheet open onClose={onClose} title={habit ? t("Edit habit", "تعديل العادة") : t("New habit", "عادة جديدة")}>
      <label className="mb-1 block text-xs font-semibold muted">{t("Habit name (in your words)", "اسم العادة (بكلامك)")}</label>
      <div className="mb-3 flex gap-2">
        <button onClick={() => { const i = EMOJI.indexOf(emoji); setEmoji(EMOJI[(i + 1) % EMOJI.length]); }} className="grid h-11 w-11 flex-none place-items-center rounded-xl text-xl" style={{ background: "var(--soft)" }} aria-label={t("Change icon", "غيّر الأيقونة")}>{emoji}</button>
        <input autoFocus value={name} onChange={(e) => setName(e.target.value)} className="field" placeholder={t("e.g. Walk 20 minutes", "مثال: مشي ٢٠ دقيقة")} />
      </div>
      <div className="mb-3"><p className="mb-1 text-xs font-semibold muted">{t("Type", "النوع")}</p><div className="grid grid-cols-2 gap-1.5">{TYPES.map((x) => <button key={x.id} onClick={() => setType(x.id)} className="chip justify-start text-[11px]" aria-pressed={type === x.id}><Repeat size={11} />{lang === "ar" ? x.ar : x.en}<span className="muted hidden text-[9px] sm:inline">· {lang === "ar" ? x.hintAr : x.hintEn}</span></button>)}</div></div>
      <div className="mb-3"><p className="mb-1 text-xs font-semibold muted">{t("Days", "الأيام")}</p>
        <div className="mb-1.5 flex flex-wrap gap-1.5">{presets.map((p) => <button key={p.id} className="chip text-[11px]" aria-pressed={p.d.length === days.length && p.d.every((d) => days.includes(d))} onClick={() => setDays(p.d)}>{p.label}</button>)}</div>
        <div className="grid grid-cols-7 gap-1">{ORDER.map((d) => <button key={d} onClick={() => setDays(days.includes(d) ? days.filter((x) => x !== d) : [...days, d])} aria-pressed={days.includes(d)} className="chip justify-center px-0 py-2 text-[11px]">{DAY(d, lang, "narrow")}</button>)}</div>
      </div>
      {(type === "count" || type === "timer") && <div className="mb-3 flex gap-2">
        <div className="flex-1"><p className="mb-1 text-xs font-semibold muted">{t("Target", "الهدف")}</p><input type="number" className="field" value={target} onChange={(e) => setTarget(+e.target.value)} min={1} /></div>
        <div className="flex-1"><p className="mb-1 text-xs font-semibold muted">{t("Unit", "الوحدة")}</p><input className="field" value={unit} onChange={(e) => setUnit(e.target.value)} placeholder={type === "timer" ? t("minutes", "دقايق") : t("cups", "أكواب")} /></div>
      </div>}
      <div className="mb-3"><p className="mb-1 text-xs font-semibold muted">{t("Reminder (optional)", "تذكير (اختياري)")}</p><div className="flex items-center gap-2"><Bell size={15} className="muted" /><input type="time" className="field" value={reminder} onChange={(e) => setReminder(e.target.value)} /><button onClick={() => setReminder("")} className="chip text-[10px]">{t("off", "إيقاف")}</button></div></div>
      <div className="mb-3"><p className="mb-1 text-xs font-semibold muted">{t("Details (optional)", "تفاصيل (اختياري)")}</p><textarea className="field min-h-16" value={details} onChange={(e) => setDetails(e.target.value)} placeholder={t("Why this habit? What counts?", "ليه العادة دي؟ وإيه اللي يتحسب؟")} /></div>
      <div className="mb-4"><p className="mb-1 text-xs font-semibold muted">{t("Colour", "اللون")}</p><div className="flex gap-1.5">{COLORS.map((c) => <button key={c} onClick={() => setColor(c)} aria-pressed={color === c} aria-label={c} className="grid h-8 w-8 place-items-center rounded-full" style={{ background: c, outline: color === c ? "2px solid var(--text)" : "none", outlineOffset: 2 }}>{color === c && <Check size={14} color="#fff" />}</button>)}</div></div>
      <div className="mb-3 flex items-center gap-1.5 rounded-xl p-2 text-xs" style={{ background: "var(--soft)" }}><Target size={13} className="accent" />{t("Counted in Review consistency — always, privately.", "بتتحسب في استمرارية المراجعة — دايمًا وعلى جهازك.")}</div>
      <div className="flex gap-2"><button className="btn btn-ghost" onClick={onClose}>{t("Cancel", "إلغاء")}</button><button className="btn btn-primary flex-1 disabled:opacity-40" disabled={!valid} onClick={save}>{habit ? t("Save changes", "احفظ التعديل") : t("Create habit", "اعمل العادة")}</button></div>
      <div className="mt-3 flex justify-center"><Motif family="spring" size={34} /></div>
    </Sheet>
  );
}

export { HabitEditor };
export const HABIT_ORDER = ORDER;
export const habitEmoji = EMOJI;
export const habitColors = COLORS;
export const habitTypes = TYPES;
export const habitId = newId;
