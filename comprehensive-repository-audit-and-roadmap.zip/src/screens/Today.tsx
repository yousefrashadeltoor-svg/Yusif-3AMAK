import { useClockFormat } from "../lib/time";
import { AlarmClock, Check, Download, Droplet, Plus, Sparkles, ChevronRight, ChevronLeft } from "lucide-react";
import { useMemo, useState } from "react";
import { useStore, useT, nextAlarmTime, fmtNum } from "../lib/store";
import { coptic, dayKey, hijri, HIJRI_MONTHS, COPTIC_MONTHS, upcomingOccasions } from "../lib/calendar";
import { FAMILY, tileDataUri } from "../lib/pattern";
import { Card, Ring } from "../components/ui";
import { PERIODS, periodAt } from "../lib/ambience";
import { Corner, Divider, EmptyState, HeaderCrown, Motif, seasonPhoto, useDecor } from "../components/Decor";
import { useNow } from "../components/WidgetRenderer";
import { reviewAll, sampleHistory } from "../lib/review";
import { prayerTimes, CITIES, PRAYER_NAMES } from "../lib/prayer";

export function Today({ go }: { go: (tab: string, sub?: string) => void }) {
  const clockFormat = useClockFormat();
  const t = useT();
  const s = useStore();
  const now = useNow(30000);
  const decor = useDecor(now);
  const fam = decor.primary;
  const st = FAMILY[fam];
  const L = s.lang;
  const N = (n: number | string) => fmtNum(n, L);
  const hj = hijri(now), cp = coptic(now);
  const key = dayKey(now);
  const tasks = s.tasks.filter((x) => x.date === key);
  const done = tasks.filter((x) => x.done).length;
  const next = nextAlarmTime(s.alarms, now);
  const water = s.water[key] || 0;
  const hr = now.getHours();
  const greet = hr < 5 ? t("Good night", "طابت ليلتك") : hr < 12 ? t("Good morning", "صباح الخير") : hr < 17 ? t("Good afternoon", "طاب يومك") : t("Good evening", "مساء الخير");
  const occ = decor.occasions[0];
  const city = CITIES[s.cityIndex] || CITIES[0];
  const pr = prayerTimes(city, now);
  const up = useMemo(() => upcomingOccasions(new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1), 6), [key]); // eslint-disable-line
  const score = useMemo(() => { if (!s.sampleData) return null; const h = sampleHistory(40); return reviewAll(h).at(-1)!; }, [s.sampleData]);
  const [quick, setQuick] = useState("");
  const rich = s.intensity !== "off";
  const Chev = L === "ar" ? ChevronLeft : ChevronRight;
  const until = next ? Math.round((next.at.getTime() - now.getTime()) / 60000) : 0;

  return (
    <div className="space-y-4 pb-4">
      {/* Hero */}
      <div className="card relative overflow-hidden p-5 text-white" style={{ background: `linear-gradient(145deg, ${st.c2}, ${st.c1})`, border: "none" }}>
        {rich && <img src={seasonPhoto(fam) || PERIODS[periodAt(now)].photo} alt="" aria-hidden className="pointer-events-none absolute inset-0 h-full w-full object-cover opacity-35 mix-blend-luminosity" />}
        {rich && <div className="pointer-events-none absolute inset-0" style={{ background: `linear-gradient(150deg, ${st.c2}cc, ${st.c1}aa)` }} />}
        {rich && <div className="absolute inset-0" style={{ backgroundImage: tileDataUri(fam, "#ffffff", 0.14, 60) }} />}
        {rich && <div className="absolute inset-x-0 top-0 opacity-80"><HeaderCrown family={fam} height={56} /></div>}
        {rich && s.intensity !== "subtle" && <><Corner family={fam} pos="bl" size={70} opacity={0.5} /><Corner family={fam} pos="br" size={70} opacity={0.5} /></>}
        <div className="relative mt-10">
          <p className="text-sm opacity-85">{greet}</p>
          <h2 className="mt-0.5 text-[1.65rem] font-bold leading-tight tracking-tight">{now.toLocaleDateString(L === "ar" ? "ar-EG" : "en-GB", { weekday: "long", day: "numeric", month: "long" })}</h2>
          <p className="mt-1 text-sm opacity-85">{hj.m ? `${N(hj.d)} ${HIJRI_MONTHS[L][hj.m - 1]} ${N(hj.y)}` : ""} · {cp.m ? `${N(cp.d)} ${COPTIC_MONTHS[L][cp.m - 1]} ${N(cp.y)}` : ""}</p>
          <div className="mt-3 flex flex-wrap gap-1.5">
            {decor.layers.map((l, i) => <span key={i} className="rounded-full bg-white/18 px-2.5 py-1 text-xs font-semibold backdrop-blur" style={{ background: "rgba(255,255,255,.18)" }}>{L === "ar" ? l.ar : l.en}</span>)}
          </div>
        </div>
        <div className="absolute -bottom-2 end-3 opacity-95 float-y"><Motif family={fam} size={86} mono="#ffffffdd" /></div>
      </div>

      {occ && occ.priority >= 80 && (
        <Card className="flex items-center gap-3 p-4" onClick={() => go("calendar")}>
          <Motif family={occ.family} size={42} />
          <div className="flex-1"><p className="text-xs muted">{t("Today's occasion", "مناسبة اليوم")}</p><p className="font-bold">{L === "ar" ? occ.ar : occ.en}</p></div>
          <Chev size={18} className="muted" />
        </Card>
      )}

      <Card className="p-3" onClick={() => go("me", "prayer")}>
        <div className="mb-2 flex items-center justify-between"><p className="flex items-center gap-1.5 text-xs font-bold"><span className="text-base">🕌</span>{t("Prayer", "الصلاة")} · {L === "ar" ? city.cityAr : city.city}</p><p className="text-[11px] muted">{t("Next", "القادمة")}: <b className="accent">{L === "ar" ? pr.next?.nameAr : pr.next?.name} {N(pr.next?.time || "")}</b></p></div>
        <div className="grid grid-cols-6 gap-0.5 text-center">{PRAYER_NAMES.map(([k, en, ar, icon]) => <div key={k} className="rounded-lg py-1" style={{ background: pr.next?.name === k ? "var(--accent)" : "var(--soft)", color: pr.next?.name === k ? "var(--on-accent)" : undefined }}><div className="text-[10px]">{icon}</div><div className="truncate text-[9px]">{L === "ar" ? ar : en}</div><div className="text-[10px] font-bold tabular-nums">{N(pr[k as "fajr"])}</div></div>)}</div>
      </Card>

      <div className="grid grid-cols-2 gap-3">
        <Card className="p-4" onClick={() => go("alarms")}>
          <div className="flex items-center gap-2 text-xs muted"><AlarmClock size={14} />{t("Next alarm", "المنبه التالي")}</div>
          {next ? <><p className="mt-2 text-3xl font-bold tracking-tight">{clockFormat(next.alarm.time)}</p><p className="text-xs muted">{t(`in ${Math.floor(until / 60)}h ${until % 60}m`, `بعد ${N(Math.floor(until / 60))} س ${N(until % 60)} د`)}</p></> : <p className="mt-2 text-sm muted">{t("No alarms on", "لا منبهات مفعّلة")}</p>}
        </Card>
        <Card className="flex items-center gap-3 p-4">
          <Ring value={(hr * 60 + now.getMinutes()) / 1440} size={58}><span className="text-xs font-bold">{N(Math.round(((hr * 60 + now.getMinutes()) / 1440) * 100))}%</span></Ring>
          <div><p className="text-xs muted">{t("Day", "اليوم")}</p><p className="font-bold">{N(done)}/{N(tasks.length)}</p><p className="text-xs muted">{t("tasks", "مهام")}</p></div>
        </Card>
      </div>

      <Card className="mb-3 flex items-center gap-3 p-3" onClick={() => go("downloads")}>
        <span className="grid h-10 w-10 flex-none place-items-center rounded-2xl" style={{ background: "var(--accent)", color: "var(--on-accent)" }}><Download size={18} /></span>
        <div className="min-w-0 flex-1"><p className="text-sm font-bold">{t("Downloader", "التحميل")}</p><p className="text-[11px] muted">{t("Paste or share any link — video, audio, images, files", "الصق أو شارك أي رابط — فيديو، صوت، صور، ملفات")}</p></div>
        <ChevronRight size={16} className="muted rtl:rotate-180" />
      </Card>

      <Card className="p-4">
        <div className="mb-2 flex items-center justify-between"><h3 className="font-bold">{t("Today's tasks", "مهام اليوم")}</h3><button onClick={() => go("tools", "tasks")} className="text-xs font-semibold accent">{t("All", "الكل")}</button></div>
        <form onSubmit={(e) => { e.preventDefault(); if (quick.trim()) { s.addTask(quick.trim()); setQuick(""); } }} className="mb-2 flex gap-2">
          <input value={quick} onChange={(e) => setQuick(e.target.value)} className="field py-2" placeholder={t("Add a task for today…", "ضيف مهمة للنهاردة…")} />
          <button className="btn btn-primary px-3" aria-label={t("Add", "إضافة")}><Plus size={18} /></button>
        </form>
        {tasks.length === 0 ? <EmptyState family={fam} title={t("A clear day", "يوم فاضي وهادي")} hint={t("Nothing planned yet.", "لسه مفيش حاجة متخططة.")} /> :
          tasks.map((x) => (
            <button key={x.id} onClick={() => s.toggleTask(x.id)} className="flex w-full items-center gap-3 py-2 text-start">
              <span className="grid h-6 w-6 flex-none place-items-center rounded-lg border-2 transition-all" style={{ borderColor: "var(--accent)", background: x.done ? "var(--accent)" : "transparent", color: "var(--on-accent)" }}>{x.done && <Check size={14} strokeWidth={3} />}</span>
              <span className={`flex-1 ${x.done ? "line-through muted" : ""}`}>{x.title}</span>
              {x.urgent && !x.done && <span className="h-2 w-2 rounded-full bg-red-500" aria-label="urgent" />}
            </button>
          ))}
        {rich && <Divider family={fam} className="mt-3 opacity-70" />}
      </Card>

      <div className="grid grid-cols-2 gap-3">
        <Card className="p-4">
          <div className="flex items-center gap-2 text-xs muted"><Droplet size={14} />{t("Water", "الماء")}</div>
          <p className="mt-1 text-2xl font-bold">{N((water / 1000).toFixed(2))}<span className="text-sm muted"> / {N(s.waterGoal / 1000)} L</span></p>
          <div className="mt-2 h-2 overflow-hidden rounded-full" style={{ background: "var(--line)" }}><div className="h-full rounded-full" style={{ width: Math.min(100, (water / s.waterGoal) * 100) + "%", background: "#3aa0ff", transition: "width var(--dur) var(--ease)" }} /></div>
          <button onClick={() => s.addWater(250)} className="btn btn-soft mt-3 w-full py-1.5 text-xs">+250 ml</button>
        </Card>
        <Card className="p-4">
          <p className="text-xs muted">{t("Habits", "العادات")}</p>
          <div className="mt-2 space-y-1.5">
            {s.habits.slice(0, 4).map((h) => { const on = h.log.includes(key); return (
              <button key={h.id} onClick={() => s.toggleHabit(h.id)} className="flex w-full items-center gap-2 text-start text-xs">
                <span className="h-4 w-4 flex-none rounded-full border-2" style={{ borderColor: "var(--accent)", background: on ? "var(--accent)" : "transparent" }} />
                <span className={`truncate ${on ? "muted line-through" : ""}`}>{h.en}</span>
              </button>); })}
          </div>
        </Card>
      </div>

      {score && (
        <Card className="flex items-center gap-4 p-4" onClick={() => go("me", "review")}>
          <Ring value={score.score / 100} size={62}><span className="text-lg font-bold">{N(score.score)}</span></Ring>
          <div className="min-w-0 flex-1">
            <p className="flex items-center gap-1 text-xs muted"><Sparkles size={13} />{t("Review · yesterday (sample data)", "المراجعة · أمس (بيانات تجريبية)")}</p>
            <p className="mt-0.5 line-clamp-2 text-sm">{L === "ar" ? score.narrative.ar : score.narrative.en}</p>
          </div>
          <Chev size={18} className="muted" />
        </Card>
      )}

      <div>
        <h3 className="mb-2 px-1 font-bold">{t("Coming up", "قريبًا")}</h3>
        <div className="scroll-hide -mx-4 flex gap-3 overflow-x-auto px-4 pb-1">
          {up.map(({ date, o }) => {
            const f = FAMILY[o.family];
            const d = Math.round((date.getTime() - new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime()) / 864e5);
            return (
              <div key={o.id + date.toISOString()} className="card relative w-40 flex-none overflow-hidden p-3 text-white" style={{ background: `linear-gradient(150deg, ${f.c2}, ${f.c1})`, border: "none" }}>
                <div className="absolute inset-0" style={{ backgroundImage: tileDataUri(o.family, "#fff", 0.2, 40) }} />
                <div className="absolute -bottom-2 -end-2"><Motif family={o.family} size={54} mono="#ffffffbb" /></div>
                <p className="relative text-xs opacity-85">{t(`in ${d} days`, `بعد ${N(d)} يومًا`)}</p>
                <p className="relative mt-1 min-h-[2.5rem] text-sm font-bold leading-tight">{L === "ar" ? o.ar : o.en}</p>
                <p className="relative mt-2 text-xs opacity-85">{date.toLocaleDateString(L === "ar" ? "ar-EG" : "en-GB", { day: "numeric", month: "short" })}</p>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
