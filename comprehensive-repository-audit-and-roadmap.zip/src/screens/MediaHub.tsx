import { useEffect, useRef, useState } from "react";
import { siYoutube, siVimeo, siSoundcloud, siTiktok, siInstagram, siX, siFacebook, siInternetarchive } from "simple-icons";
import { Globe, ClipboardPaste, Film, Music, Image as ImageIcon, Pause, Play, X, Scissors, Wand2, RotateCcw, Loader2, Download, ExternalLink, CheckCircle2, AlertTriangle, User, Clock, HardDrive, Sparkles, Smartphone } from "lucide-react";
import { useStore, useT, fmtNum, newId } from "../lib/store";
import { normalizeUrl, fetchPreview, downloadDirect, sanitizeFilename, fmtBytes, SAMPLE_CC0, type Preview, type Site } from "../lib/media";
import { Card, Honest, ScreenHeader, Segmented } from "../components/ui";

type State = "downloading" | "paused" | "done" | "failed" | "stopped";
interface DL { id: string; name: string; url: string; pct: number; bytes: number; state: State; error?: string; ctl?: AbortController; blob?: Blob }

const SITE_ICON: Partial<Record<Site, { path: string; hex: string; title: string }>> = {
  youtube: siYoutube, vimeo: siVimeo, soundcloud: siSoundcloud, tiktok: siTiktok, instagram: siInstagram, x: siX, facebook: siFacebook, archive: siInternetarchive,
};

/** Official platform brand mark (simple-icons, CC0) — bundled, works offline. */
export function SiteLogo({ site, host }: { site: Site; host: string }) {
  const ic = SITE_ICON[site];
  if (!ic) return <span className="grid h-6 w-6 flex-none place-items-center rounded-lg" style={{ background: "var(--soft)" }} title={host}><Globe size={13} className="accent" /></span>;
  return (
    <span className="grid h-6 w-6 flex-none place-items-center rounded-lg shadow-sm" style={{ background: "#" + ic.hex }} title={ic.title}>
      <svg viewBox="0 0 24 24" width="14" height="14" fill="#fff" aria-label={ic.title}><path d={ic.path} /></svg>
    </span>
  );
}

const KBPS: Array<[RegExp, number]> = [[/2160/, 20000], [/1440/, 10000], [/1080p WebM/, 3500], [/1080/, 5000], [/720/, 2800], [/480/, 1300], [/360/, 800], [/240/, 450], [/144/, 220], [/Best/, 6000], [/320/, 320], [/256/, 256], [/192/, 192], [/160/, 160], [/128/, 128], [/OGG/, 160], [/FLAC/, 900], [/WAV/, 1411]];
const estSize = (label: string, sec: number) => ((KBPS.find(([r]) => r.test(label))?.[1] || 1000) * 1000 * sec) / 8;

const ERROR_MESSAGES: Record<string, { en: string; ar: string }> = {
  youtube: { en: "YouTube's page cannot be extracted inside a browser (CORS + player signature). The public oEmbed metadata endpoint was tried; if blocked, use the Android APK engine.", ar: "صفحة يوتيوب مش بتتستخرج جوه المتصفح (حماية CORS وتوقيع المشغّل). حاولنا نقطة oEmbed العامة؛ لو اتمنعت، شغّل نسخة الأندرويد." },
  blocked: { en: "This server blocks cross-site browser downloads (no CORS headers). Direct file download works inside the Android app.", ar: "السيرفر ده بيمنع التحميل من المتصفح (مفيش CORS). التحميل المباشر بيشتغل في تطبيق أندرويد." },
  invalid: { en: "That isn't a valid link.", ar: "ده مش رابط صحيح." },
  network: { en: "The network request failed. Check your connection.", ar: "طلب الشبكة فشل. اتأكد من الاتصال." },
};

export function MediaHub({ onBack }: { onBack: () => void }) {
  const t = useT();
  const s = useStore();
  const N = (n: number | string) => fmtNum(n, s.lang);
  const [txt, setTxt] = useState("");
  const [loading, setLoading] = useState(false);
  const [preview, setPreview] = useState<Preview | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [ms, setMs] = useState<number | null>(null);
  const [queue, setQueue] = useState<DL[]>([]);
  const [group, setGroup] = useState<"video" | "audio" | "images">("video");
  const lastAuto = useRef("");
  const parsed = txt.trim() ? normalizeUrl(txt) : null;
  const isAndroidNative = typeof window !== "undefined" && !!(window as unknown as { Capacitor?: { isNativePlatform?: () => boolean } }).Capacitor?.isNativePlatform?.();

  const load = async (value: string) => {
    setTxt(value); setPreview(null); setError(null); setMs(null);
    if (!value.trim()) return;
    const p0 = normalizeUrl(value);
    if (!p0.ok) { setError("invalid"); return; }
    lastAuto.current = p0.url;
    const t0 = performance.now();
    setLoading(true);
    try {
      const p = await fetchPreview(value);
      setMs(Math.round(performance.now() - t0));
      setPreview(p);
    } catch (e) {
      setError((e as Error).message);
    } finally { setLoading(false); }
  };

  // Auto-preview immediately when a valid link is pasted or typed
  useEffect(() => {
    if (!parsed?.ok || parsed.url === lastAuto.current) return;
    const timer = setTimeout(() => { load(txt); }, 250);
    return () => clearTimeout(timer);
  }, [txt]); // eslint-disable-line

  const paste = async () => { try { const v = await navigator.clipboard.readText(); if (v) load(v); } catch { setError("clipboard"); } };

  const start = (url: string, name: string, nativePreset?: string) => {
    if (isAndroidNative) {
      const bridge = (window as unknown as { Capacitor?: { Plugins?: { DayflowBridge?: { enqueueDownload?: (o: { url: string; name: string; preset?: string }) => void } } } }).Capacitor?.Plugins?.DayflowBridge;
      bridge?.enqueueDownload?.({ url, name, preset: nativePreset });
    }
    const ctl = new AbortController();
    const id = newId();
    setQueue((q) => [{ id, name, url, pct: 0, bytes: 0, state: "downloading", ctl }, ...q]);
    downloadDirect(url, { signal: ctl.signal, onProgress: (pct, bytes) => setQueue((q) => q.map((x) => (x.id === id ? { ...x, pct, bytes } : x))) })
      .then((blob) => {
        setQueue((q) => q.map((x) => (x.id === id ? { ...x, pct: 100, state: "done", blob } : x)));
        const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = sanitizeFilename(name); a.click();
      })
      .catch((e) => {
        const stopped = (e as Error).name === "AbortError";
        setQueue((q) => q.map((x) => (x.id === id ? { ...x, state: stopped ? "stopped" : "failed", error: stopped ? t("Paused", "متوقف") : t("Browser blocked cross-origin fetch — works in Android APK.", "المتصفح منع السحب عبر المواقع — بيشتغل في تطبيق الأندرويد.") } : x)));
      });
  };
  const pause = (id: string) => setQueue((q) => q.map((x) => { if (x.id === id) x.ctl?.abort(); return x.id === id ? { ...x, state: "stopped" } : x; }));
  const resume = (item: DL) => { setQueue((q) => q.filter((x) => x.id !== item.id)); start(item.url, item.name); };
  const remove = (id: string) => setQueue((q) => q.filter((x) => x.id !== id));

  const thumbSizes = preview?.thumb ? [
    { label: t("Original / Max thumbnail", "الصورة المصغرة الأصلية"), ext: "jpg", url: preview.thumb },
    ...(preview.thumb.includes("hqdefault.jpg") ? [
      { label: "MaxRes HD (1280×720)", ext: "jpg", url: preview.thumb.replace("hqdefault.jpg", "maxresdefault.jpg") },
      { label: "SD (640×480)", ext: "jpg", url: preview.thumb.replace("hqdefault.jpg", "sddefault.jpg") },
    ] : []),
  ] : [];

  return (
    <div className="pb-4">
      <ScreenHeader title={t("Media Hub", "مركز الوسائط")} subtitle={t("Instant previews + direct downloads", "معاينة فورية + تحميل مباشر")} onBack={onBack} />

      <Card className="p-4">
        <div className="flex gap-2">
          <input value={txt} onPaste={(e) => { const v = e.clipboardData.getData("text"); if (v) { e.preventDefault(); load(v); } }} onChange={(e) => setTxt(e.target.value)} onKeyDown={(e) => e.key === "Enter" && load(txt)} className="field" placeholder={t("Paste any link (auto-preview)", "الصق أي رابط (معاينة تلقائية)")} inputMode="url" aria-label={t("Link", "الرابط")} />
          <button onClick={paste} className="btn btn-soft flex-none" aria-label={t("Paste from clipboard", "لصق من الحافظة")}><ClipboardPaste size={18} /></button>
          <button onClick={() => load(txt)} disabled={!parsed?.ok || loading} className="btn btn-primary flex-none disabled:opacity-40" aria-label={t("Preview", "معاينة")}>{loading ? <Loader2 size={17} className="animate-spin" /> : <Sparkles size={17} />}</button>
        </div>
        <div className="mt-2 flex flex-wrap items-center gap-2 text-[11px] muted">
          {parsed?.ok && <span className="flex items-center gap-1.5"><SiteLogo site={parsed.site} host={parsed.host} /><b>{parsed.host}</b> · {parsed.kind}</span>}
          {ms !== null && <span>· {t(`loaded in ${ms} ms`, `في ${N(ms)} مللي ثانية`)}</span>}
          <button onClick={() => load(SAMPLE_CC0)} className="chip text-[10px]">{t("Test real CC0 video", "جرّب فيديو CC0 حقيقي")}</button>
        </div>

        {error && <div className="mt-3 rounded-xl p-3 text-xs" style={{ background: "#e5484d12", color: "#c62a2f" }}>
          <p className="flex items-center gap-1 font-bold"><AlertTriangle size={13} />{(ERROR_MESSAGES[error] || ERROR_MESSAGES.network)[s.lang]}</p>
          {error === "clipboard" && <p className="mt-1">{t("Clipboard reading was blocked. Paste manually.", "قراءة الحافظة ممنوعة. الصق يدويًا.")}</p>}
          {parsed?.ok && <a href={parsed.url} target="_blank" rel="noreferrer" className="mt-2 inline-flex items-center gap-1 font-bold"><ExternalLink size={12} />{t("Open original page", "افتح الصفحة الأصلية")}</a>}
        </div>}

        {preview && <div className="mt-4 fade-in">
          <div className="flex gap-3">
            <div className="relative aspect-video w-36 flex-none overflow-hidden rounded-xl" style={{ background: "var(--soft)" }}>
              {preview.thumb ? <img src={preview.thumb} alt="" className="h-full w-full object-cover" /> : <div className="grid h-full place-items-center">{preview.kind === "audio" ? <Music className="muted" size={26} /> : <Film className="muted" size={26} />}</div>}
              {preview.duration ? <span className="absolute bottom-1 end-1 rounded bg-black/75 px-1.5 py-0.5 text-[10px] font-bold text-white"><Clock size={9} className="inline" /> {N(Math.floor(preview.duration / 60))}:{String(preview.duration % 60).padStart(2, "0")}</span> : null}
            </div>
            <div className="min-w-0 flex-1">
              <div className="mb-1 flex items-center gap-1.5">{parsed && <SiteLogo site={parsed.site} host={preview.provider} />}<span className="truncate text-xs font-bold">{preview.provider}</span></div>
              <p className="line-clamp-2 text-[14.5px] font-bold leading-snug">{preview.title}</p>
              <p className="mt-1 flex items-center gap-1 text-xs muted"><User size={11} />{preview.author || "—"}</p>
              <div className="mt-1.5 flex flex-wrap gap-1">
                <span className="chip px-1.5 py-0 text-[9px]"><CheckCircle2 size={9} />{t("Preview ready", "المعاينة جاهزة")}</span>
                {preview.direct && <span className="chip px-1.5 py-0 text-[9px]"><HardDrive size={9} />{preview.direct.type.split("/")[1] || preview.direct.type}{preview.direct.size ? ` · ${fmtBytes(preview.direct.size)}` : ""}</span>}
              </div>
            </div>
          </div>

          <div className="mt-4">
            <Segmented value={group} onChange={setGroup} options={[{ id: "video", label: t("Video", "فيديو") }, { id: "audio", label: t("Audio", "صوت") }, { id: "images", label: t("Images", "صور") }]} />
          </div>

          {group === "video" && <div className="mt-3 space-y-2">
            {preview.direct ? (
              <button onClick={() => start(preview.url, preview.title + "." + (preview.direct!.type.split("/")[1] || "mp4"))} className="flex w-full items-center gap-3 rounded-xl p-2.5 text-start transition active:scale-[.99]" style={{ background: "var(--soft)" }}>
                {preview.thumb ? <img src={preview.thumb} alt="" className="h-10 w-14 flex-none rounded-lg object-cover" /> : <span className="grid h-10 w-14 flex-none place-items-center rounded-lg bg-black/10"><Film size={18} className="accent" /></span>}
                <span className="min-w-0 flex-1"><span className="block truncate text-sm font-bold">{preview.direct.type.toUpperCase()} · {t("Direct file", "ملف مباشر")}</span><span className="block text-[11px] muted">{fmtBytes(preview.direct.size)} · {t("Downloads directly now", "يتحمل مباشرة الآن")}</span></span>
                <Download size={18} className="accent flex-none" />
              </button>
            ) : (
              <>
                {(["Best available", "2160p 4K MP4", "1440p MP4", "1080p MP4", "1080p WebM", "720p MP4", "480p MP4", "360p MP4", "240p MP4", "144p MP4"] as const).map((q) => (
                  <div key={q} className="flex items-center gap-3 rounded-xl p-2.5" style={{ background: "var(--soft)" }}>
                    {preview.thumb ? <img src={preview.thumb} alt="" className="h-10 w-14 flex-none rounded-lg object-cover" /> : <span className="grid h-10 w-14 flex-none place-items-center rounded-lg bg-black/10"><Film size={18} className="accent" /></span>}
                    <div className="min-w-0 flex-1">
                      <p className="flex items-center gap-2 truncate text-sm font-bold">{q}{preview.duration ? <span className="chip px-1.5 py-0 text-[9px]">≈ {fmtBytes(estSize(q, preview.duration))}</span> : null}</p>
                      <p className="truncate text-[10px] muted">{isAndroidNative ? t("Ready via native yt-dlp", "جاهز عبر محرك أندرويد") : t("Requires native Android engine (yt-dlp + FFmpeg)", "يحتاج محرك أندرويد الأصلي (yt-dlp + FFmpeg)")}</p>
                    </div>
                    <button onClick={() => start(preview.url, preview.title + ".mp4", q)} className="btn btn-primary py-1.5 px-3 text-xs flex-none"><Download size={13} />{isAndroidNative ? t("Save", "تحميل") : t("Try", "جرّب")}</button>
                  </div>
                ))}
              </>
            )}
          </div>}

          {group === "audio" && <div className="mt-3 space-y-2">
            {(["MP3 320 kbps", "MP3 192 kbps", "MP3 128 kbps", "M4A / AAC 256", "Opus 160", "OGG Vorbis", "FLAC (lossless)", "WAV (lossless)"] as const).map((af) => (
              <div key={af} className="flex items-center gap-3 rounded-xl p-2.5" style={{ background: "var(--soft)" }}>
                {preview.thumb ? <img src={preview.thumb} alt="" className="h-10 w-10 flex-none rounded-lg object-cover" /> : <span className="grid h-10 w-10 flex-none place-items-center rounded-lg bg-black/10"><Music size={18} className="accent" /></span>}
                <div className="min-w-0 flex-1">
                  <p className="flex items-center gap-2 truncate text-sm font-bold">{af}{preview.duration ? <span className="chip px-1.5 py-0 text-[9px]">≈ {fmtBytes(estSize(af, preview.duration))}</span> : null}</p>
                  <p className="truncate text-[10px] muted">{preview.direct ? t("Direct audio stream", "ملف صوتي مباشر") : t("Extracted by native FFmpeg engine", "يُستخرج بمحرك FFmpeg في أندرويد")}</p>
                </div>
                <button onClick={() => start(preview.url, preview.title + ".mp3", af)} className="btn btn-soft py-1.5 px-3 text-xs flex-none"><Download size={13} /></button>
              </div>
            ))}
          </div>}

          {group === "images" && <div className="mt-3 space-y-2">
            {thumbSizes.length > 0 ? thumbSizes.map((im) => (
              <div key={im.url} className="flex items-center gap-3 rounded-xl p-2.5" style={{ background: "var(--soft)" }}>
                <img src={im.url} alt="" className="h-10 w-14 flex-none rounded-lg object-cover bg-black/10" />
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-bold">{im.label}</p>
                  <p className="truncate text-[10px] muted">JPG · {t("Real image file", "ملف صورة حقيقي")}</p>
                </div>
                <button onClick={() => start(im.url, `${preview.title}.${im.ext}`)} className="btn btn-primary py-1.5 px-3 text-xs flex-none"><Download size={13} />{t("Save", "حفظ")}</button>
              </div>
            )) : <p className="text-xs muted">{t("No thumbnail image found for this link.", "مفيش صورة مصغرة للرابط ده.")}</p>}
          </div>}
        </div>}
      </Card>

      {queue.length > 0 && <>
        <h3 className="mb-2 mt-5 flex items-center justify-between px-1 font-bold">{t("Downloads", "التحميلات")}<span className="chip px-2 py-0 text-[9px]">{t("real", "حقيقي")}</span></h3>
        <div className="space-y-2">{queue.map((q) => <Card key={q.id} className="p-3">
          <div className="flex items-center gap-2"><div className="min-w-0 flex-1"><p className="truncate text-sm font-semibold">{q.name}</p><p className="text-[11px] muted">{q.state === "downloading" ? `${N(q.pct)}% · ${fmtBytes(q.bytes)}` : q.state === "done" ? t("Saved to your device", "اتحفظ على جهازك") : q.error || t("Stopped", "اتوقف")}</p></div>
            {q.state === "downloading" && <button onClick={() => pause(q.id)} className="btn btn-ghost p-2" aria-label={t("Pause", "إيقاف")}><Pause size={14} /></button>}
            {q.state === "stopped" && <button onClick={() => resume(q)} className="btn btn-ghost p-2" aria-label={t("Resume", "استئناف")}><Play size={14} /></button>}
            {(q.state === "failed" || q.state === "done" || q.state === "stopped") && <button onClick={() => remove(q.id)} className="btn btn-ghost p-2" aria-label={t("Remove", "إزالة")}>{q.state === "failed" ? <RotateCcw size={14} /> : <X size={14} />}</button>}
          </div>
          <div className="mt-2 h-1.5 overflow-hidden rounded-full" style={{ background: "var(--line)" }}><div className="h-full rounded-full transition-[width]" style={{ width: q.pct + "%", background: q.state === "done" ? "#2fa36b" : "var(--accent)" }} /></div>
        </Card>)}</div>
      </>}

      <h3 className="mb-2 mt-5 px-1 font-bold">{t("Offline FFmpeg & native toolbox", "صندوق أدوات الوسائط (أندرويد)")}</h3>
      <div className="grid grid-cols-2 gap-2">
        {[[Music, t("Extract audio", "اسحب الصوت")], [Scissors, t("Trim & ringtone", "قص ونغمة رنين")], [Wand2, t("Compress", "ضغط")], [Film, t("Convert", "تحويل")], [ImageIcon, t("Clip → GIF/WebP", "مقطع ← GIF/WebP")], [HardDrive, t("Loudness normalize", "توحيد الصوت")]].map(([I, l], i) => { const Ic = I as typeof Music; return <div key={i} className="card flex items-center gap-2 p-3 text-sm opacity-85"><Ic size={16} className="accent" />{l as string}<span className="ms-auto chip px-1 py-0 text-[8px]"><Smartphone size={9} /> APK</span></div>; })}
      </div>

      <div className="mt-4"><Honest>{t("Direct files & public images download immediately in any browser. Site-protected video streams (YouTube, TikTok, Instagram) require the Android APK's yt-dlp + FFmpeg + aria2c engine (already wired in android/ and omitted from the Play flavor -PnoMediaHub).", "الملفات المباشرة والصور العامة تتحمل فورًا في المتصفح. بث المواقع المحمية (يوتيوب، تيك توك، إنستجرام) يحتاج محرك yt-dlp + FFmpeg + aria2c داخل الـAPK (مكتوب في مجلد android/ ومحذوف من نسخة Play -PnoMediaHub).")}</Honest></div>
    </div>
  );
}
