import { useEffect, useState } from "react";
import { Download, ShieldCheck, Share2, AlertTriangle, File, ArrowLeft } from "lucide-react";
import { decodeReview, loadLocalShare } from "../lib/qr";
import { renderReviewImage, downloadBlob } from "../lib/reviewImage";
import type { ReviewSnapshot } from "../lib/reviewShare";
import { useT } from "../lib/store";
import { Card, ScreenHeader } from "../components/ui";
import { fmtBytes } from "../lib/media";

export function ReviewImage({ snapshot }: { snapshot: ReviewSnapshot }) {
  const t = useT(); const [image, setImage] = useState(""); const [error, setError] = useState("");
  useEffect(() => { try { setImage(renderReviewImage(snapshot)); setError(""); } catch (e) { setError((e as Error).message); } }, [snapshot]);
  const save = async () => { if (image) downloadBlob(await (await fetch(image)).blob(), `dayflow-${snapshot.range}-${snapshot.end}.png`); };
  const share = async () => { if (!image) return; const file = new window.File([await (await fetch(image)).blob()], `dayflow-${snapshot.end}.png`, { type: "image/png" }); try { if (navigator.canShare?.({ files: [file] })) await navigator.share({ files: [file] }); else await save(); } catch (e) { if ((e as Error).name !== "AbortError") await save(); } };
  return <div className="space-y-3">{error ? <p role="alert" className="text-sm text-red-500">{error}</p> : image && <img src={image} className="w-full rounded-3xl border border-[var(--line)]" alt={t("Local review image", "صورة التقييم المحلية")} />}
    {image && <div className="flex gap-2"><button className="btn btn-primary flex-1" onClick={save}><Download size={15} />{t("Save image", "احفظ الصورة")}</button><button className="btn btn-soft" onClick={share}><Share2 size={15} />{t("Share", "شارك")}</button></div>}
  </div>;
}

export function QRShareViewer({ value, kind, onBack }: { value: string; kind: "review" | "file"; onBack: () => void }) {
  const t = useT(); const [snapshot, setSnapshot] = useState<ReviewSnapshot | null>(null); const [file, setFile] = useState<{ name: string; mime: string; size: number; url: string; blob: Blob } | null>(null); const [error, setError] = useState("");
  useEffect(() => { let active = true, objectUrl = ""; setError(""); if (kind === "review") { try { setSnapshot(decodeReview(value)); } catch { setError(t("This review code is invalid.", "رمز التقييم ده مش سليم.")); } } else {
    loadLocalShare(value).then((r) => { if (!active) return; if (!r) { setError(t("This file lives on the device that created the code. Share the actual file or a hosted URL to use another device.", "الملف محفوظ على الجهاز اللي عمل الرمز. لو فتحت من جهاز تاني، شارك الملف نفسه أو لينك مستضاف ليه.")); return; } objectUrl = URL.createObjectURL(r.blob); setFile({ ...r, url: objectUrl }); }).catch(() => setError(t("Local storage couldn't be opened.", "معرفناش نفتح التخزين المحلي.")));
  } return () => { active = false; if (objectUrl) URL.revokeObjectURL(objectUrl); }; }, [value, kind]);
  return <div className="space-y-3 pb-5"><ScreenHeader title={kind === "review" ? t("Shared review", "التقييم المشترك") : t("Local shared file", "الملف المحلي")} onBack={onBack} />
    <p className="flex items-center gap-2 text-xs muted"><ShieldCheck size={14} />{t("Opened locally. No private data was uploaded.", "اتفتح محليًا، من غير ما نرفع بياناتك.")}</p>
    {error && <Card className="p-4"><AlertTriangle size={23} className="mb-2 text-amber-500" /><p className="text-sm leading-relaxed">{error}</p></Card>}
    {snapshot && kind === "review" && <ReviewImage snapshot={snapshot} />}
    {file && <Card className="space-y-3 p-4"><div className="flex items-center gap-2"><File size={20} className="accent" /><span className="min-w-0 flex-1"><b className="block break-all text-sm">{file.name}</b><small className="muted">{fmtBytes(file.size)} · {file.mime}</small></span></div>
      {file.mime.startsWith("image/") && <img className="max-h-[60vh] w-full rounded-2xl object-contain" src={file.url} alt={file.name} />}
      {file.mime.startsWith("video/") && <video className="w-full rounded-2xl" src={file.url} controls />}
      {file.mime.startsWith("audio/") && <audio className="w-full" src={file.url} controls />}
      <button className="btn btn-primary w-full" onClick={() => downloadBlob(file.blob, file.name)}><Download size={15} />{t("Save file", "احفظ الملف")}</button>
    </Card>}
    <button className="btn btn-ghost w-full" onClick={onBack}><ArrowLeft size={14} />{t("Back to QR Studio", "ارجع لاستوديو QR")}</button>
  </div>;
}
