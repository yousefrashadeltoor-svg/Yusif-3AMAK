import { useMemo, useState } from "react";
import { ThumbsUp, ThumbsDown, ChevronDown, Sparkles, Trophy, Moon, Sun, Download, ShieldCheck, Bot } from "lucide-react";
import { useStore, useT, fmtNum } from "../lib/store";
import { fromKey } from "../lib/calendar";
import { reviewHistory, makeReviewSnapshot } from "../lib/reviewShare";
import { ReviewImage } from "./QRShareViewer";
import { DIMS, reviewAll, sampleHistory, styleProfile, weekly, yearly } from "../lib/review";
import { Card, Honest, Ring, ScreenHeader, Segmented, Sheet } from "../components/ui";
import { familyGradient, Motif, useDecor } from "../components/Decor";

/** Tier-2 guard: every number in model output must exist in the Tier-1 facts; else fall back. */
export function guardNarrative(text: string, facts: Record<string, number | string>) {
  const allowed = new Set(Object.values(facts).map(String));
  const nums = text.match(/\d+(\.\d+)?/g) || [];
  const bad = nums.filter((n) => !allowed.has(n));
  return { ok: bad.length === 0, bad };
}

export function Review({ onBack }: { onBack: () => void }) {
  const t = useT();
  const s = useStore();
  const L = s.lang;
  const N = (n: number | string) => fmtNum(n, L);
  const [tab, setTab] = useState<"day" | "week" | "year" | "style">("day");
  const hist = useMemo(() => (s.sampleData ? sampleHistory(365) : reviewHistory()), [s.sampleData, s.tasks, s.water, s.habits]); // eslint-disable-line
  const reviews = useMemo(() => reviewAll(hist, { spiritual: s.spiritual, tone: s.reviewTone, feedback: s.feedback }), [hist, s.spiritual, s.reviewTone, s.feedback]);
  const [idx, setIdx] = useState(reviews.length - 1);
  const [open, setOpen] = useState<string | null>(null);
  const [shareOpen, setShareOpen] = useState(false);
  const r = reviews[Math.min(idx, reviews.length - 1)];
  const decor = useDecor();
  const wk = useMemo(() => weekly(reviews, hist), [reviews, hist]);
  const yr = useMemo(() => yearly(reviews, hist), [reviews, hist]);
  const prof = useMemo(() => styleProfile(hist), [hist]);
  const months = Array.from({ length: 12 }, (_, i) => new Date(2025, i, 1).toLocaleDateString(L === "ar" ? "ar-EG" : "en", { month: "short" }));
  const fb = (id: string, v: number) => s.set({ feedback: { ...s.feedback, [id]: (s.feedback[id] || 0) + v } });

  const shareYear = () => {
    const c = document.createElement("canvas"); c.width = 1080; c.height = 1350; const g = c.getContext("2d")!;
    const gr = g.createLinearGradient(0, 0, 1080, 1350); gr.addColorStop(0, "#1f4e5f"); gr.addColorStop(1, "#d4a237"); g.fillStyle = gr; g.fillRect(0, 0, 1080, 1350);
    g.fillStyle = "#fff"; g.font = "bold 84px system-ui"; g.fillText(t("My year in review", "عامي في مراجعة"), 80, 200);
    g.font = "48px system-ui"; [[t("Days tracked", "أيام مسجلة"), yr.days], [t("Tasks done", "مهام منجزة"), yr.tasks], [t("Focus hours", "ساعات التركيز"), yr.focusH], [t("Best habit streak", "أطول سلسلة"), yr.bestStreak]].forEach(([a, b], i) => { g.globalAlpha = 0.8; g.fillText(String(a), 80, 400 + i * 200); g.globalAlpha = 1; g.font = "bold 96px system-ui"; g.fillText(String(b), 80, 500 + i * 200); g.font = "48px system-ui"; });
    g.globalAlpha = 0.6; g.font = "32px system-ui"; g.fillText("DAYFLOW · " + t("generated on device", "أُنشئ على الجهاز"), 80, 1290);
    const a = document.createElement("a"); a.href = c.toDataURL("image/png"); a.download = "dayflow-year.png"; a.click();
  };

  const facts = { score: r.score, tasksDone: hist[hist.length - 1].tasksDone, focus: hist[hist.length - 1].focusMin };
  const goodOut = `You scored ${facts.score} and finished ${facts.tasksDone} tasks with ${facts.focus} focus minutes.`;
  const badOut = `You scored ${facts.score + 7} and finished ${facts.tasksDone + 3} tasks.`;

  return (
    <div className="pb-4">
      <ScreenHeader title={t("Review", "المراجعة")} subtitle={s.sampleData ? t("Showing sample data — turn off in Settings", "تعرض بيانات تجريبية — يمكن إيقافها من الإعدادات") : t("From your data on this device", "من بياناتك على هذا الجهاز")} onBack={onBack} />
      <button className="btn btn-soft mb-3 w-full" onClick={() => setShareOpen(true)}><Download size={15} />{t("Save this review as an image", "احفظ التقييم ده كصورة")}</button>
      {shareOpen && <Sheet open onClose={() => setShareOpen(false)} title={t("Local review image", "صورة التقييم المحلية")} wide><ReviewImage snapshot={makeReviewSnapshot(tab === "week" ? "week" : "day", r.date)} /><p className="mt-3 text-xs muted">{t("QR sharing and monthly reviews are available under Tools → QR.", "مشاركة QR والتقييم الشهري من أدوات ← QR.")}</p></Sheet>}
      <Segmented value={tab} onChange={setTab} options={[{ id: "day", label: t("Day", "يوم") }, { id: "week", label: t("Week", "أسبوع") }, { id: "year", label: t("Year", "سنة") }, { id: "style", label: t("Style", "نمطك") }]} />

      {tab === "day" && r && (
        <div className="mt-4 space-y-3 fade-in">
          <div className="scroll-hide -mx-4 flex gap-1.5 overflow-x-auto px-4">
            {reviews.slice(-14).map((x, i) => { const j = reviews.length - 14 + i; const d = fromKey(x.date); return (
              <button key={x.date} onClick={() => setIdx(j)} className="flex w-11 flex-none flex-col items-center rounded-xl py-1.5" style={{ background: j === idx ? "var(--accent)" : "var(--soft)", color: j === idx ? "var(--on-accent)" : undefined }}>
                <span className="text-[10px] opacity-75">{d.toLocaleDateString(L === "ar" ? "ar-EG" : "en", { weekday: "narrow" })}</span><span className="text-sm font-bold">{N(d.getDate())}</span>
                <span className="mt-0.5 h-1 w-5 rounded-full" style={{ background: "currentColor", opacity: x.score / 120 }} />
              </button>); })}
          </div>
          <Card className="relative overflow-hidden p-5">
            <div className="flex items-center gap-4">
              <Ring value={r.score / 100} size={92} stroke={9}><span className="text-3xl font-bold">{N(r.score)}</span></Ring>
              <div className="flex-1"><p className="text-xs muted">{fromKey(r.date).toLocaleDateString(L === "ar" ? "ar-EG" : "en-GB", { weekday: "long", day: "numeric", month: "long" })}</p><p className="mt-1 leading-snug">{L === "ar" ? r.narrative.ar : r.narrative.en}</p>
                <div className="mt-2 flex gap-1">{r.context.map((c) => <span key={c} className="chip text-[10px]">{({ ramadan: t("Ramadan-adjusted", "معدّل لرمضان"), friday: t("Friday", "الجمعة"), dayoff: t("Rest day", "يوم راحة") } as Record<string, string>)[c]}</span>)}</div></div>
            </div>
          </Card>
          {r.wins.length > 0 && <Card className="p-4"><p className="mb-2 flex items-center gap-1.5 font-bold"><Trophy size={16} className="accent" />{t("Wins", "إنجازات")}</p>{r.wins.map((w, i) => <p key={i} className="py-1 text-sm">✦ {L === "ar" ? w.ar : w.en}</p>)}</Card>}
          {r.suggestions.length > 0 && <Card className="p-4"><p className="mb-2 flex items-center gap-1.5 font-bold"><Sparkles size={16} className="accent" />{t("Suggestions", "اقتراحات")}</p>{r.suggestions.map((sg) => (
            <div key={sg.id} className="flex items-start gap-2 border-t border-[var(--line)] py-2 first:border-0"><p className="flex-1 text-sm">{L === "ar" ? sg.ar : sg.en}</p>
              <button onClick={() => fb(sg.id, 1)} className="muted p-1" aria-label={t("Helpful", "مفيد")}><ThumbsUp size={14} /></button><button onClick={() => fb(sg.id, -1)} className="muted p-1" aria-label={t("Not helpful", "غير مفيد")}><ThumbsDown size={14} /></button></div>))}
            <p className="mt-1 text-[11px] muted">{t("Your feedback changes which suggestions appear — locally.", "تقييمك يغيّر الاقتراحات التي تظهر — محليًا.")}</p></Card>}
          <Card className="p-4"><p className="mb-2 font-bold">{t("Why this score?", "لماذا هذه النتيجة؟")}</p>
            {r.dims.map((d) => { const meta = DIMS.find((x) => x.id === d.id)!; const isOpen = open === d.id; return (
              <div key={d.id} className="border-t border-[var(--line)] first:border-0">
                <button onClick={() => setOpen(isOpen ? null : d.id)} className="flex w-full items-center gap-3 py-2.5 text-start" aria-expanded={isOpen}>
                  <span className="flex-1 text-sm">{L === "ar" ? meta.ar : meta.en}</span>
                  {d.score === null ? <span className="text-xs muted">{t("not counted", "غير محتسب")}</span> : <><span className="h-1.5 w-20 overflow-hidden rounded-full" style={{ background: "var(--line)" }}><span className="block h-full rounded-full" style={{ width: d.score + "%", background: "var(--accent)" }} /></span><span className="w-7 text-end text-sm font-semibold">{N(d.score)}</span></>}
                  <ChevronDown size={14} className="muted" style={{ transform: isOpen ? "rotate(180deg)" : "none", transition: "transform .2s" }} />
                </button>
                {isOpen && <div className="mb-2 rounded-lg p-2.5 text-xs fade-in" style={{ background: "var(--soft)" }}><p><b>{t("Evidence", "الدليل")}:</b> {L === "ar" ? d.ar : d.en}</p><p className="mt-1 muted"><b>{t("Formula", "المعادلة")}:</b> {L === "ar" ? meta.formulaAr : meta.formula}</p></div>}
              </div>); })}
          </Card>
          <Card className="p-4"><p className="text-xs muted">{t("Tomorrow's suggested priority", "أولوية الغد المقترحة")}</p><p className="mt-1 font-semibold">{L === "ar" ? r.priority.ar : r.priority.en}</p></Card>
        </div>
      )}

      {tab === "week" && (
        <div className="mt-4 space-y-3 fade-in">
          <Card className="p-5"><div className="flex items-end gap-4"><div><p className="text-xs muted">{t("This week", "هذا الأسبوع")}</p><p className="text-4xl font-bold">{N(wk.avg)}</p></div><p className="mb-1 text-sm font-semibold" style={{ color: wk.avg >= wk.prevAvg ? "#2fa36b" : "#e5484d" }}>{wk.avg >= wk.prevAvg ? "▲" : "▼"} {N(Math.abs(wk.avg - wk.prevAvg))} {t("vs last week", "عن الأسبوع الماضي")}</p></div>
            <div className="mt-4 flex h-28 items-end gap-2">{reviews.slice(-7).map((x) => <div key={x.date} className="flex flex-1 flex-col items-center gap-1"><div className="w-full rounded-t-lg" style={{ height: x.score + "%", background: x.date === wk.best?.date ? "var(--accent)" : "color-mix(in oklch, var(--accent) 40%, transparent)" }} /><span className="text-[10px] muted">{fromKey(x.date).toLocaleDateString(L === "ar" ? "ar-EG" : "en", { weekday: "short" })}</span></div>)}</div></Card>
          <div className="grid grid-cols-2 gap-3">
            <Card className="p-4"><Sun size={16} className="accent" /><p className="mt-1 text-xs muted">{t("Best day", "أفضل يوم")}</p><p className="font-bold">{wk.best && fromKey(wk.best.date).toLocaleDateString(L === "ar" ? "ar-EG" : "en", { weekday: "long" })} · {N(wk.best?.score ?? 0)}</p></Card>
            <Card className="p-4"><Moon size={16} className="accent" /><p className="mt-1 text-xs muted">{t("Hardest day", "أصعب يوم")}</p><p className="font-bold">{wk.worst && fromKey(wk.worst.date).toLocaleDateString(L === "ar" ? "ar-EG" : "en", { weekday: "long" })} · {N(wk.worst?.score ?? 0)}</p></Card>
          </div>
          <Card className="p-4"><p className="mb-2 font-bold">{t("Where your time went", "أين ذهب وقتك")}</p>{(() => { const tot = Object.values(wk.cats).reduce((a, b) => a + b, 0) || 1; return Object.entries(wk.cats).map(([k, v]) => <div key={k} className="mb-1.5 flex items-center gap-2 text-sm"><span className="w-16 capitalize">{t(k, { work: "عمل", study: "دراسة", health: "صحة", family: "عائلة", rest: "راحة" }[k] ?? k)}</span><span className="h-2 flex-1 overflow-hidden rounded-full" style={{ background: "var(--line)" }}><span className="block h-full rounded-full" style={{ width: (v / tot) * 100 + "%", background: "var(--accent)" }} /></span><span className="w-12 text-end text-xs muted">{N(Math.round(v / 60))}{t("h", "س")}</span></div>); })()}{!Object.keys(wk.cats).length && <p className="text-sm muted">{t("No categorised time yet.", "لا وقت مصنف بعد.")}</p>}</Card>
          <Card className="p-4 space-y-2">
            <p><b className="accent">{t("Keep", "حافظ")}:</b> {wk.keep && (L === "ar" ? wk.keep.ar : wk.keep.en)} ({N(wk.keep?.v ?? 0)})</p>
            <p><b className="accent">{t("Adjust", "عدّل")}:</b> {wk.adjust && (L === "ar" ? wk.adjust.ar : wk.adjust.en)} ({N(wk.adjust?.v ?? 0)})</p>
            {wk.tryS && <p><b className="accent">{t("Try", "جرّب")}:</b> {L === "ar" ? wk.tryS.ar : wk.tryS.en}</p>}
          </Card>
        </div>
      )}

      {tab === "year" && (
        <div className="mt-4 space-y-3 fade-in">
          <div className="card relative overflow-hidden p-6 text-white" style={{ background: familyGradient(decor.primary), border: "none" }}>
            <div className="absolute -end-4 -top-4 opacity-40"><Motif family={decor.primary} size={140} mono="#fff" /></div>
            <p className="text-sm opacity-80">{t("Your year in review", "عامك في مراجعة")}</p>
            <div className="relative mt-4 grid grid-cols-2 gap-4">{[[t("Days tracked", "أيام مسجلة"), yr.days], [t("Tasks done", "مهام منجزة"), yr.tasks], [t("Focus hours", "ساعات التركيز"), yr.focusH], [t("Best streak", "أطول سلسلة"), yr.bestStreak]].map(([a, b]) => <div key={String(a)}><p className="text-3xl font-bold">{N(b as number)}</p><p className="text-xs opacity-80">{a}</p></div>)}</div>
          </div>
          <Card className="p-4"><p className="mb-3 font-bold">{t("Seasons of your year", "مواسم عامك")}</p><div className="flex h-28 items-end gap-1">{yr.mAvg.map((v, i) => <div key={i} className="flex flex-1 flex-col items-center gap-1"><div className="w-full rounded-t" style={{ height: (v ?? 0) + "%", background: i === yr.busiest ? "var(--accent2)" : "var(--accent)", opacity: v === null ? 0.1 : 0.85 }} /><span className="text-[9px] muted">{months[i]}</span></div>)}</div>
            <p className="mt-3 text-sm">{t("Busiest month", "أكثر الشهور انشغالًا")}: <b>{yr.busiest !== undefined ? months[yr.busiest] : "—"}</b> · {t("Quietest", "الأهدأ")}: <b>{yr.quietest !== undefined ? months[yr.quietest] : "—"}</b></p></Card>
          {yr.ramadan !== null && <Card className="flex items-center gap-3 p-4"><Motif family="ramadan" size={44} /><div><p className="font-bold">{t("Ramadan", "رمضان")}</p><p className="text-sm muted">{t(`Average ${yr.ramadan} vs ${yr.other} the rest of the year (expectations adjusted)`, `المتوسط ${N(yr.ramadan)} مقابل ${N(yr.other ?? 0)} لبقية العام (مع تعديل التوقعات)`)}</p></div></Card>}
          <Card className="p-4"><p className="font-bold">{t("Personal record", "رقم شخصي")}</p><p className="text-sm muted">{t(`Most focus in one day: ${yr.maxFocus.v} min on ${yr.maxFocus.d}`, `أطول تركيز في يوم: ${N(yr.maxFocus.v)} د في ${yr.maxFocus.d}`)}</p></Card>
          <button className="btn btn-primary w-full" onClick={shareYear}><Download size={16} />{t("Save shareable image", "حفظ صورة للمشاركة")}</button>
        </div>
      )}

      {tab === "style" && (
        <div className="mt-4 space-y-3 fade-in">
          <p className="px-1 text-xs muted">{t("Descriptive patterns from your history — not labels about you.", "أنماط وصفية من سجلك — وليست أحكامًا عليك.")}</p>
          {[
            [t("Day rhythm", "إيقاع اليوم"), { early: t("You usually start early", "تبدأ يومك عادة مبكرًا"), middle: t("You start mid-morning", "تبدأ في منتصف الصباح"), late: t("You start later in the day", "تبدأ في وقت متأخر") }[prof.chronotype], t(`First activity around ${prof.firstHour.toFixed(1)}h`, `أول نشاط حوالي ${N(prof.firstHour.toFixed(1))}`)],
            [t("Peak focus", "ذروة التركيز"), t(`Around ${prof.peak}:00`, `حوالي ${N(prof.peak)}:٠٠`), t("Schedule hard work here", "جدول العمل الصعب هنا")],
            [t("Planning style", "أسلوب التخطيط"), { overcommit: t("Plans more than gets done", "تخطط لأكثر مما يُنجز"), lastminute: t("Often reschedules", "تعيد الجدولة كثيرًا"), earlybird: t("Early and steady", "مبكر ومنتظم"), steady: t("Steady", "منتظم") }[prof.planner], ""],
            [t("Snoozes", "الغفوات"), t(`${prof.snoozes.toFixed(1)} per day`, `${N(prof.snoozes.toFixed(1))} يوميًا`), ""],
            [t("Procrastination index", "مؤشر التأجيل"), N(prof.procrastination) + "/100", t("From task reschedules", "من إعادة جدولة المهام")],
            [t("Strongest weekday", "أقوى أيام الأسبوع"), new Date(2024, 0, 7 + prof.bestWeekday).toLocaleDateString(L === "ar" ? "ar-EG" : "en", { weekday: "long" }), ""],
          ].map(([a, b, c]) => <Card key={a} className="p-4"><p className="text-xs muted">{a}</p><p className="font-bold">{b}</p>{c && <p className="text-xs muted">{c}</p>}</Card>)}
        </div>
      )}

      <Card className="mt-5 p-4">
        <p className="flex items-center gap-2 font-bold"><Bot size={17} className="accent" />{t("On-device language model (optional)", "نموذج لغوي على الجهاز (اختياري)")}</p>
        <p className="mt-1 text-sm muted">{t("In the Android app you can download a small, license-checked model to phrase reviews more naturally. It only sees the facts above, never raw records, and every number it writes is checked.", "في تطبيق أندرويد يمكنك تنزيل نموذج صغير مفحوص الترخيص لصياغة المراجعات بشكل أطبع. يرى الحقائق أعلاه فقط، لا السجلات الخام، وكل رقم يكتبه يُتحقق منه.")}</p>
        <div className="mt-3 space-y-2 text-xs">
          {[goodOut, badOut].map((o, i) => { const g = guardNarrative(o, facts); return <div key={i} className="rounded-lg p-2.5" style={{ background: "var(--soft)" }}><p className="font-mono">{o}</p><p className="mt-1 flex items-center gap-1 font-semibold" style={{ color: g.ok ? "#2fa36b" : "#e5484d" }}><ShieldCheck size={13} />{g.ok ? t("Guard: accepted", "الحارس: مقبول") : t(`Guard: rejected (${g.bad.join(", ")} not in facts) → falls back to Review text`, `الحارس: مرفوض (${g.bad.join("، ")} ليست في الحقائق) ← يعود لنص المراجعة`)}</p></div>; })}
        </div>
        <div className="mt-3"><Honest>{t("Example outputs above are fixed strings used to demonstrate the guard; no model runs in this browser preview.", "المخرجات أعلاه نصوص ثابتة لتوضيح الحارس؛ لا يعمل أي نموذج في هذه المعاينة.")}</Honest></div>
      </Card>
    </div>
  );
}
