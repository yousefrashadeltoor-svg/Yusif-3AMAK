// Official brand marks bundled as local SVG sources (offline). Mono marks use currentColor, so they follow the theme.
const files = import.meta.glob("../assets/logos/*.svg", { query: "?raw", import: "default", eager: true }) as Record<string, string>;
const map = new Map<string, string>();
for (const [path, svg] of Object.entries(files)) map.set(path.split("/").pop()!.replace(".svg", ""), svg);

export const hasLogo = (slug?: string) => !!slug && map.has(slug);
export const logoSvg = (slug?: string) => (slug ? map.get(slug) : undefined);
export const logoSlugs = () => [...map.keys()];
