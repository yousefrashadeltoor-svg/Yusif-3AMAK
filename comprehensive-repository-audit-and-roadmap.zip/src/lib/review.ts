// Review Engine — Tier 1 deterministic insight engine (V2-7.2). Pure, local, explainable.
import { dayKey, fromKey, hijri } from "./calendar";
import { mulberry32 } from "./pattern";

export interface DayRecord {
  date: string; dayOff?: boolean;
  tasksPlanned: number; tasksDone: number; reschedules: number;
  startsOnTime: number; starts: number;
  plannedMin: number; actualMin: number; focusMin: number; breaks: number;
  waterMl: number; waterGoal: number; sleepH: number; workoutMin: number; studyMin: number;
  habitsDue: number; habitsDone: number; prayers?: number;
  alarms: number; alarmsOnTime: number; snoozes: number;
  firstHour: number; lastHour: number; peakHour: number;
  cats: Record<string, number>; unlogged?: DimId[];
}

export type DimId = "consistency" | "punctuality" | "completion" | "focus" | "planning" | "balance" | "health" | "learning" | "spiritual" | "followthrough" | "recovery";
export const DIMS: Array<{ id: DimId; en: string; ar: string; formula: string; formulaAr: string }> = [
  { id: "completion", en: "Completion", ar: "الإنجاز", formula: "tasks done ÷ tasks planned", formulaAr: "المهام المنجزة ÷ المهام المخططة" },
  { id: "consistency", en: "Consistency", ar: "الاستمرارية", formula: "habits done ÷ habits due", formulaAr: "العادات المنجزة ÷ المستحقة" },
  { id: "punctuality", en: "Punctuality", ar: "الالتزام بالمواعيد", formula: "activities started on time ÷ started", formulaAr: "الأنشطة التي بدأت في موعدها ÷ كل البدايات" },
  { id: "focus", en: "Focus", ar: "التركيز", formula: "focus minutes ÷ your 28-day median (floor 25 min)", formulaAr: "دقائق التركيز ÷ وسيطك لآخر ٢٨ يومًا (حد أدنى ٢٥ دقيقة)" },
  { id: "planning", en: "Planning accuracy", ar: "دقة التخطيط", formula: "100 − |actual − planned| ÷ planned", formulaAr: "١٠٠ − |الفعلي − المخطط| ÷ المخطط" },
  { id: "balance", en: "Balance", ar: "التوازن", formula: "spread of time across categories (normalised entropy) + rest", formulaAr: "توزيع الوقت على الفئات (إنتروبيا معيارية) + الراحة" },
  { id: "health", en: "Health", ar: "الصحة", formula: "mean of water ÷ goal, sleep vs 7.5 h, workout ÷ 20 min", formulaAr: "متوسط الماء ÷ الهدف، النوم مقابل ٧٫٥ س، الرياضة ÷ ٢٠ د" },
  { id: "learning", en: "Learning", ar: "التعلم", formula: "study minutes ÷ your median (floor 20 min)", formulaAr: "دقائق الدراسة ÷ وسيطك (حد أدنى ٢٠ د)" },
  { id: "spiritual", en: "Spiritual routine (opt-in)", ar: "الورد الروحي (اختياري)", formula: "logged prayers ÷ 5", formulaAr: "الصلوات المسجلة ÷ ٥" },
  { id: "followthrough", en: "Follow-through", ar: "الالتزام بالمنبه", formula: "alarms dismissed on time ÷ alarms − 8 per snooze", formulaAr: "المنبهات المطفأة في موعدها ÷ المنبهات − ٨ لكل غفوة" },
  { id: "recovery", en: "Recovery", ar: "التعافي", formula: "breaks ÷ (focus minutes ÷ 90)", formulaAr: "فترات الراحة ÷ (دقائق التركيز ÷ ٩٠)" },
];

const clamp = (n: number) => Math.max(0, Math.min(100, Math.round(n)));
const median = (a: number[]) => { if (!a.length) return 0; const s = [...a].sort((x, y) => x - y); return s[Math.floor(s.length / 2)]; };

export interface DimScore { id: DimId; score: number | null; en: string; ar: string }
export interface DayReview {
  date: string; score: number; dims: DimScore[]; context: string[];
  wins: Array<{ en: string; ar: string }>; suggestions: Suggestion[]; narrative: { en: string; ar: string };
  priority: { en: string; ar: string };
}
export interface Suggestion { id: string; dim: DimId; en: string; ar: string }

export function contextOf(r: DayRecord) {
  const d = fromKey(r.date);
  const h = hijri(d);
  return { ramadan: h.m === 9, friday: d.getDay() === 5, dayOff: !!r.dayOff };
}

export function scoreDay(r: DayRecord, trailing: DayRecord[], spiritual = false): DimScore[] {
  const ctx = contextOf(r);
  const exp = ctx.ramadan ? 0.75 : 1;
  const focusBase = Math.max(25, median(trailing.map((x) => x.focusMin)) * exp);
  const studyBase = Math.max(20, median(trailing.map((x) => x.studyMin)) * exp);
  const s: Record<DimId, [number | null, string, string]> = {} as never;
  const pct = (a: number, b: number) => (b > 0 ? (100 * a) / b : null);
  const comp = pct(r.tasksDone, r.tasksPlanned);
  s.completion = [comp === null ? null : clamp(comp), `${r.tasksDone}/${r.tasksPlanned} tasks done`, `${r.tasksDone}/${r.tasksPlanned} مهام منجزة`];
  const cons = pct(r.habitsDone, r.habitsDue);
  s.consistency = [cons === null ? null : clamp(cons), `${r.habitsDone}/${r.habitsDue} habits`, `${r.habitsDone}/${r.habitsDue} عادات`];
  const pun = pct(r.startsOnTime, r.starts);
  s.punctuality = [pun === null ? null : clamp(pun), `${r.startsOnTime}/${r.starts} on-time starts`, `${r.startsOnTime}/${r.starts} بدايات في الموعد`];
  s.focus = [clamp((100 * r.focusMin) / focusBase), `${r.focusMin} min vs your usual ${Math.round(focusBase)} min`, `${r.focusMin} د مقابل المعتاد ${Math.round(focusBase)} د`];
  s.planning = [r.plannedMin > 0 ? clamp(100 - (100 * Math.abs(r.actualMin - r.plannedMin)) / r.plannedMin) : null, `planned ${r.plannedMin} min, actual ${r.actualMin} min`, `مخطط ${r.plannedMin} د، فعلي ${r.actualMin} د`];
  const vals = Object.values(r.cats).filter((v) => v > 0); const tot = vals.reduce((a, b) => a + b, 0);
  const ent = tot > 0 && vals.length > 1 ? -vals.reduce((a, v) => a + (v / tot) * Math.log(v / tot), 0) / Math.log(vals.length) : 0;
  s.balance = [tot > 0 ? clamp(ent * 80 + (r.breaks > 0 ? 20 : 0)) : null, `${vals.length} categories, ${r.breaks} breaks`, `${vals.length} فئات، ${r.breaks} استراحات`];
  const water = Math.min(1, r.waterMl / Math.max(1, r.waterGoal));
  const sleep = Math.max(0, 1 - Math.abs(r.sleepH - 7.5) / 3.5);
  const work = Math.min(1, r.workoutMin / (20 * exp));
  s.health = [clamp(((water + sleep + work) / 3) * 100), `${(r.waterMl / 1000).toFixed(1)} L water, ${r.sleepH.toFixed(1)} h sleep, ${r.workoutMin} min workout`, `${(r.waterMl / 1000).toFixed(1)} لتر ماء، ${r.sleepH.toFixed(1)} س نوم، ${r.workoutMin} د رياضة`];
  s.learning = [r.studyMin === 0 && studyBase <= 20 ? null : clamp((100 * r.studyMin) / studyBase), `${r.studyMin} min study vs usual ${Math.round(studyBase)}`, `${r.studyMin} د دراسة مقابل ${Math.round(studyBase)}`];
  s.spiritual = [spiritual && r.prayers !== undefined ? clamp((r.prayers / 5) * 100) : null, `${r.prayers ?? 0}/5 logged`, `${r.prayers ?? 0}/5 مسجلة`];
  s.followthrough = [r.alarms > 0 ? clamp((100 * r.alarmsOnTime) / r.alarms - 8 * r.snoozes) : null, `${r.alarmsOnTime}/${r.alarms} on time, ${r.snoozes} snoozes`, `${r.alarmsOnTime}/${r.alarms} في الموعد، ${r.snoozes} غفوات`];
  const needBreaks = Math.max(1, r.focusMin / 90);
  s.recovery = [clamp((100 * r.breaks) / needBreaks), `${r.breaks} breaks for ${r.focusMin} focus min`, `${r.breaks} استراحات لـ ${r.focusMin} د تركيز`];
  const restOnly: DimId[] = ["health", "recovery", "spiritual", "consistency"];
  return DIMS.map((d) => {
    let [score, en, ar] = s[d.id];
    if (ctx.dayOff && !restOnly.includes(d.id)) score = null; // rest days are not punished
    if (r.unlogged?.includes(d.id)) score = null; // Missing data is not a fabricated measurement
    return { id: d.id, score, en, ar };
  });
}

const W: Partial<Record<DimId, number>> = { completion: 1.3, focus: 1.2, health: 1, consistency: 1.1, followthrough: 0.8, planning: 0.8, balance: 0.7, recovery: 0.6, punctuality: 0.8, learning: 0.8, spiritual: 0.8 };
export function overall(dims: DimScore[]) {
  let a = 0, w = 0;
  for (const d of dims) if (d.score !== null) { a += d.score * (W[d.id] ?? 1); w += W[d.id] ?? 1; }
  return w ? Math.round(a / w) : 0;
}

function hash(s: string) { let h = 2166136261; for (const c of s) h = Math.imul(h ^ c.charCodeAt(0), 16777619); return h >>> 0; }
const pick = <T,>(arr: T[], seed: string) => arr[hash(seed) % arr.length];

const SUGG: Record<DimId, (r: DayRecord) => { en: string; ar: string }> = {
  completion: (r) => ({ en: `Plan ${Math.max(1, r.tasksDone + 1)} tasks tomorrow instead of ${r.tasksPlanned} — you finish more when the list is shorter.`, ar: `خطط لـ ${Math.max(1, r.tasksDone + 1)} مهام غدًا بدلًا من ${r.tasksPlanned} — تنجز أكثر حين تكون القائمة أقصر.` }),
  consistency: () => ({ en: "Attach your weakest habit to something you already do daily, like right after Fajr or after lunch.", ar: "اربط أضعف عاداتك بشيء تفعله يوميًا، مثل بعد الفجر أو بعد الغداء." }),
  punctuality: () => ({ en: "Add a 5-minute pre-reminder to your first activity of the day.", ar: "أضف تذكيرًا قبل ٥ دقائق لأول نشاط في يومك." }),
  focus: (r) => ({ en: `Block one 45-minute focus session around ${String(r.peakHour).padStart(2, "0")}:00 — your strongest hour lately.`, ar: `احجز جلسة تركيز ٤٥ دقيقة حوالي الساعة ${r.peakHour}:٠٠ — أقوى ساعاتك مؤخرًا.` }),
  planning: (r) => ({ en: r.actualMin > r.plannedMin ? "Your activities run long. Add 20% buffer to estimates tomorrow." : "You finish early. Try planning slightly tighter blocks.", ar: r.actualMin > r.plannedMin ? "أنشطتك تطول عن المخطط. أضف هامشًا ٢٠٪ لتقديراتك غدًا." : "تنتهي مبكرًا. جرّب فترات أقصر قليلًا." }),
  balance: () => ({ en: "Give one block tomorrow to a category you skipped this week.", ar: "خصص فترة غدًا لفئة أهملتها هذا الأسبوع." }),
  health: (r) => r.waterMl < r.waterGoal ? ({ en: `You reached ${Math.round((100 * r.waterMl) / r.waterGoal)}% of your water goal. Turn on the 2-hour water nudge.`, ar: `وصلت إلى ${Math.round((100 * r.waterMl) / r.waterGoal)}٪ من هدف الماء. فعّل تذكير الماء كل ساعتين.` }) : ({ en: "Aim for a bedtime that gives you 7½ hours before your first alarm.", ar: "اختر موعد نوم يمنحك ٧٫٥ ساعات قبل أول منبه." }),
  learning: () => ({ en: "Put a 25-minute study block in your calendar right after your best focus window.", ar: "ضع فترة دراسة ٢٥ دقيقة بعد أفضل نافذة تركيز لديك." }),
  spiritual: () => ({ en: "Turn on gentle prayer-time reminders for the prayers you most often miss.", ar: "فعّل تذكيرات لطيفة لمواقيت الصلوات التي تفوتك أكثر." }),
  followthrough: (r) => ({ en: `You snoozed ${r.snoozes} times. Move the alarm 10 minutes later and keep it there for a week.`, ar: `غفوت ${r.snoozes} مرات. أخّر المنبه ١٠ دقائق والتزم به أسبوعًا.` }),
  recovery: () => ({ en: "Take a 5-minute break after every 50 minutes of focus.", ar: "خذ استراحة ٥ دقائق بعد كل ٥٠ دقيقة تركيز." }),
};

export function reviewDay(r: DayRecord, trailing: DayRecord[], opts: { spiritual?: boolean; tone?: "gentle" | "balanced" | "direct"; feedback?: Record<string, number> } = {}): DayReview {
  const dims = scoreDay(r, trailing, opts.spiritual);
  const score = overall(dims);
  const ctx = contextOf(r);
  const context: string[] = [];
  if (ctx.ramadan) context.push("ramadan"); if (ctx.friday) context.push("friday"); if (ctx.dayOff) context.push("dayoff");
  const scored = dims.filter((d) => d.score !== null) as Array<DimScore & { score: number }>;
  const top = [...scored].sort((a, b) => b.score - a.score);
  const wins = top.slice(0, 3).filter((d) => d.score >= 55).map((d) => {
    const meta = DIMS.find((x) => x.id === d.id)!;
    return { en: `${meta.en}: ${d.en}`, ar: `${meta.ar}: ${d.ar}` };
  });
  const fb = opts.feedback || {};
  const low = [...scored].sort((a, b) => (a.score - (fb["s-" + a.id] ?? 0) * 15) - (b.score - (fb["s-" + b.id] ?? 0) * 15)).filter((d) => d.score < 70 && (fb["s-" + d.id] ?? 0) > -2).slice(0, 3);
  const suggestions = low.map((d) => ({ id: "s-" + d.id, dim: d.id, ...SUGG[d.id](r) }));
  const tone = opts.tone || "balanced";
  const band = score >= 80 ? "high" : score >= 55 ? "mid" : "low";
  const O = {
    high: { en: ["A strong day.", "A really solid day.", "Today went well."], ar: ["يوم قوي.", "يوم متماسك بحق.", "مضى اليوم على خير."] },
    mid: { en: ["A steady day.", "A reasonable day with room to grow.", "A fair day."], ar: ["يوم متوازن.", "يوم معقول وفيه مجال للتحسن.", "يوم جيد بشكل عام."] },
    low: tone === "direct" ? { en: ["A tough day — let's fix one thing tomorrow.", "Below your usual today."], ar: ["يوم صعب — لنصلح أمرًا واحدًا غدًا.", "أقل من معدلك اليوم."] }
      : { en: ["A quieter day, and that's okay.", "Not every day is a big one."], ar: ["يوم أهدأ، ولا بأس بذلك.", "ليست كل الأيام كبيرة."] },
  }[band];
  const best = top[0] ? DIMS.find((x) => x.id === top[0].id)! : null;
  const ramEn = ctx.ramadan ? " Expectations were adjusted for Ramadan." : "";
  const ramAr = ctx.ramadan ? " تم تعديل التوقعات لشهر رمضان." : "";
  const offEn = ctx.dayOff ? " This was a rest day, so only health and recovery count." : "";
  const offAr = ctx.dayOff ? " هذا يوم راحة، لذلك تُحتسب الصحة والتعافي فقط." : "";
  const narrative = {
    en: `${pick(O.en, r.date)} ${best ? `Your best area was ${best.en.toLowerCase()} (${top[0].en}).` : ""}${ramEn}${offEn}`,
    ar: `${pick(O.ar, r.date)} ${best ? `أفضل جوانبك كان ${best.ar} (${top[0].ar}).` : ""}${ramAr}${offAr}`,
  };
  const priority = suggestions[0] ? { en: suggestions[0].en, ar: suggestions[0].ar } : { en: "Keep the same rhythm tomorrow.", ar: "حافظ على نفس الإيقاع غدًا." };
  return { date: r.date, score, dims, context, wins, suggestions, narrative, priority };
}

export function reviewAll(hist: DayRecord[], opts: Parameters<typeof reviewDay>[2] = {}) {
  return hist.map((r, i) => reviewDay(r, hist.slice(Math.max(0, i - 28), i), opts));
}

export function weekly(reviews: DayReview[], hist: DayRecord[]) {
  const cur = reviews.slice(-7), prev = reviews.slice(-14, -7);
  const avg = (a: DayReview[]) => (a.length ? Math.round(a.reduce((s, r) => s + r.score, 0) / a.length) : 0);
  const best = [...cur].sort((a, b) => b.score - a.score)[0];
  const worst = [...cur].sort((a, b) => a.score - b.score)[0];
  const cats: Record<string, number> = {};
  for (const h of hist.slice(-7)) for (const [k, v] of Object.entries(h.cats)) cats[k] = (cats[k] || 0) + v;
  const dimAvg = DIMS.map((d) => {
    const v = cur.map((r) => r.dims.find((x) => x.id === d.id)!.score).filter((x): x is number => x !== null);
    return { ...d, v: v.length ? Math.round(v.reduce((a, b) => a + b, 0) / v.length) : null };
  }).filter((d) => d.v !== null) as Array<(typeof DIMS)[number] & { v: number }>;
  const sorted = [...dimAvg].sort((a, b) => b.v - a.v);
  const last = hist[hist.length - 1];
  const tryDim = sorted[sorted.length - 1];
  return {
    avg: avg(cur), prevAvg: avg(prev), best, worst, cats, dimAvg,
    keep: sorted[0], adjust: sorted[sorted.length - 2] || sorted[0], tryS: tryDim ? SUGG[tryDim.id](last) : null,
  };
}

export function yearly(reviews: DayReview[], hist: DayRecord[]) {
  const months = Array.from({ length: 12 }, () => ({ n: 0, s: 0, planned: 0, done: 0, focus: 0 }));
  let ramS = 0, ramN = 0, othS = 0, othN = 0, maxFocus = { v: 0, d: "" }, streak = 0, bestStreak = 0, tasks = 0, focus = 0;
  reviews.forEach((r, i) => {
    const h = hist[i]; const m = fromKey(r.date).getMonth();
    months[m].n++; months[m].s += r.score; months[m].planned += h.plannedMin; months[m].done += h.tasksDone; months[m].focus += h.focusMin;
    if (r.context.includes("ramadan")) { ramS += r.score; ramN++; } else { othS += r.score; othN++; }
    if (h.focusMin > maxFocus.v) maxFocus = { v: h.focusMin, d: r.date };
    streak = h.habitsDone >= h.habitsDue && h.habitsDue > 0 ? streak + 1 : 0; bestStreak = Math.max(bestStreak, streak);
    tasks += h.tasksDone; focus += h.focusMin;
  });
  const mAvg = months.map((m) => (m.n ? Math.round(m.s / m.n) : null));
  const valid = months.map((m, i) => ({ ...m, i })).filter((m) => m.n);
  const busiest = [...valid].sort((a, b) => b.planned - a.planned)[0];
  const quietest = [...valid].sort((a, b) => a.planned - b.planned)[0];
  return { mAvg, busiest: busiest?.i, quietest: quietest?.i, ramadan: ramN ? Math.round(ramS / ramN) : null, other: othN ? Math.round(othS / othN) : null, maxFocus, bestStreak, tasks, focusH: Math.round(focus / 60), days: reviews.length };
}

export function styleProfile(hist: DayRecord[]) {
  const recent = hist.slice(-60);
  const first = median(recent.map((r) => r.firstHour));
  const peak = median(recent.map((r) => r.peakHour));
  const ratio = recent.reduce((a, r) => a + r.tasksPlanned, 0) / Math.max(1, recent.reduce((a, r) => a + r.tasksDone, 0));
  const snz = recent.reduce((a, r) => a + r.snoozes, 0) / Math.max(1, recent.length);
  const resch = recent.reduce((a, r) => a + r.reschedules, 0) / Math.max(1, recent.length);
  const byWd = Array.from({ length: 7 }, () => [0, 0]);
  recent.forEach((r) => { const w = fromKey(r.date).getDay(); byWd[w][0] += r.tasksDone; byWd[w][1]++; });
  const bestWd = byWd.map((x, i) => [x[1] ? x[0] / x[1] : 0, i]).sort((a, b) => b[0] - a[0])[0][1];
  return {
    chronotype: first < 6.5 ? "early" : first > 9 ? "late" : "middle",
    firstHour: first, peak,
    planner: ratio > 1.45 ? "overcommit" : resch > 1.2 ? "lastminute" : first < 6.5 ? "earlybird" : "steady",
    snoozes: snz, procrastination: Math.min(100, Math.round(resch * 40)), bestWeekday: bestWd,
  };
}

/** Deterministic sample history so Review screens have something to explain. Clearly labelled as sample data in UI. */
export function sampleHistory(days = 365, end = new Date()): DayRecord[] {
  const rnd = mulberry32(20260101);
  const out: DayRecord[] = [];
  for (let i = days - 1; i >= 0; i--) {
    const d = new Date(end.getFullYear(), end.getMonth(), end.getDate() - i);
    const ram = hijri(d).m === 9; const fri = d.getDay() === 5;
    const drift = Math.sin(i / 40) * 0.12;
    const q = Math.max(0.2, Math.min(1, 0.68 + drift + (rnd() - 0.5) * 0.35 - (fri ? 0.2 : 0)));
    const planned = Math.round(4 + rnd() * 4);
    const habitsDue = 4;
    const focus = Math.round((ram ? 70 : 100) * q + rnd() * 30);
    const plannedMin = Math.round(240 + rnd() * 180);
    out.push({
      date: dayKey(d), dayOff: fri && rnd() < 0.6,
      tasksPlanned: planned, tasksDone: Math.min(planned, Math.round(planned * q + rnd())), reschedules: Math.round(rnd() * 2.4 * (1 - q)),
      starts: 5, startsOnTime: Math.min(5, Math.round(5 * q + rnd() * 0.8)),
      plannedMin, actualMin: Math.round(plannedMin * (0.8 + rnd() * 0.45)), focusMin: focus, breaks: Math.round(focus / 70 + rnd()),
      waterMl: Math.round((ram ? 1800 : 2100) * (0.6 + q * 0.5)), waterGoal: 2500, sleepH: (ram ? 6.2 : 7) + (rnd() - 0.4) * 1.6,
      workoutMin: rnd() < 0.55 ? Math.round(15 + rnd() * 30) : 0, studyMin: d.getMonth() < 6 ? Math.round(20 + rnd() * 70 * q) : Math.round(rnd() * 40),
      habitsDue, habitsDone: Math.min(habitsDue, Math.round(habitsDue * (q + 0.1))), prayers: Math.min(5, Math.round(3.4 + q * 2 * rnd() + 0.3)),
      alarms: 2, alarmsOnTime: rnd() < q ? 2 : 1, snoozes: Math.round((1 - q) * 3 * rnd()),
      firstHour: (ram ? 3.5 : 6.6) + rnd(), lastHour: 22 + rnd() * 2, peakHour: ram ? 22 : 9 + Math.round(rnd() * 2),
      cats: { work: Math.round(200 * q + rnd() * 60), study: Math.round(60 * rnd()), health: Math.round(30 * rnd()), family: Math.round(50 + 60 * rnd()), rest: Math.round(40 * rnd()) },
    });
  }
  return out;
}
