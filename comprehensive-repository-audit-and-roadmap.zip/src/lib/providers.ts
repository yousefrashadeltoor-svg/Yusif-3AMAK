// Provider + model registry. Real providers, real documentation URLs, real logo slugs
// from the LobeHub static SVG icon set. Unknown logos fall back to the provider mark / initial.
export type Api = "openai" | "anthropic" | "gemini" | "groq" | "openrouter" | "mistral" | "deepseek" | "xai" | "cohere" | "together" | "fireworks" | "perplexity" | "cerebras" | "deepinfra" | "novita" | "hyperbolic" | "sambanova" | "nvidia" | "ollama" | "lmstudio" | "azure" | "custom";
export type Tier = "free" | "cheap" | "balanced" | "premium" | "open" | "reasoning" | "vision" | "fast" | "coding";
export interface ModelInfo { id: string; name: string; logo?: string; tier: Tier[]; ctx: number; note?: string; recommended?: string; supportsImage?: boolean; supportsDoc?: boolean }
export interface Provider {
  id: Api; name: string; logo: string; kind: "openai" | "anthropic" | "gemini"; base: string; docs: string; keys: string;
  detect: RegExp[]; models: ModelInfo[]; local?: boolean; noteEn: string; noteAr: string;
}
/** Logo assets are bundled locally (src/assets/logos). `LOGO` now just echoes the slug; see lib/logos.ts. */
export const LOGO = (slug: string) => slug;

const M = (id: string, name: string, tier: Tier[], ctx: number, logo?: string, note?: string, recommended?: string, supportsImage?: boolean, supportsDoc?: boolean): ModelInfo => ({
  id, name, tier, ctx, logo, note, recommended,
  supportsImage: supportsImage ?? tier.includes("vision"),
  supportsDoc: supportsDoc ?? (id.includes("claude") || id.includes("gemini") || id.includes("gpt-4o") || id.includes("gpt-4.1") || id.includes("gpt-5")),
});

/** Maps any model ID (especially OpenRouter / Groq / Together multi-vendor IDs) to its real official brand logo slug. */
export function modelLogoSlug(modelId: string, fallback: string): string {
  const s = modelId.toLowerCase();
  if (/(^|\/)(gpt|o1|o3|o4|chatgpt)/.test(s) || s.includes("openai")) return "openai";
  if (s.includes("claude") || s.includes("anthropic")) return "claude-color";
  if (s.includes("gemini")) return "gemini-color";
  if (s.includes("gemma")) return "gemma-color";
  if (s.includes("deepseek")) return "deepseek-color";
  if (s.includes("llama") || s.includes("meta-llama")) return "meta-color";
  if (s.includes("qwen") || s.includes("qwq")) return "qwen-color";
  if (s.includes("mistral") || s.includes("mixtral") || s.includes("codestral") || s.includes("pixtral")) return "mistral-color";
  if (s.includes("grok") || s.includes("x-ai")) return "grok";
  if (s.includes("command") || s.includes("cohere")) return "cohere-color";
  if (s.includes("nemotron") || s.includes("nvidia")) return "nvidia-color";
  if (s.includes("phi-") || s.includes("phi4") || s.includes("microsoft")) return "microsoft-color";
  if (s.includes("sonar") || s.includes("perplexity")) return "perplexity-color";
  if (s.includes("kimi") || s.includes("moonshot")) return "kimi-color";
  if (s.includes("huggingface")) return "huggingface-color";
  if (s.includes("bedrock") || s.includes("amazon") || s.includes("nova-")) return "aws-color";
  if (s.includes("glm") || s.includes("zhipu")) return "zhipu-color";
  if (s.includes("ernie") || s.includes("baidu")) return "baidu-color";
  if (s.includes("doubao") || s.includes("bytedance")) return "bytedance-color";
  if (s.includes("minimax")) return "minimax-color";
  if (s.includes("step-") || s.includes("stepfun")) return "stepfun-color";
  if (s.includes("yi-") || s.startsWith("01-ai")) return "yi-color";
  if (s.includes("google/")) return "google-color";
  if (s.includes("liquid")) return "liquid";
  return fallback;
}

/** Excludes audio/TTS, STT, embedding, moderation and image-only endpoints from chat defaults. */
export function isChatModelId(id: string): boolean {
  const s = id.toLowerCase();
  return !/(whisper|orpheus|tts|playai|kokoro|bark|elevenlabs|dall-e|gpt-image|imagen|lyria|embedding|embed|rerank|moderation|llama-guard|shield|whisper-large)/.test(s);
}

export const PROVIDERS: Provider[] = [
  {
    id: "openai", name: "OpenAI", logo: "openai", kind: "openai", base: "https://api.openai.com/v1", docs: "https://platform.openai.com/api-keys",
    keys: "sk-… or sk-proj-…", detect: [/^sk-(?!or-|ant-)[A-Za-z0-9_-]{20,}/],
    noteEn: "Official ChatGPT models. Direct browser access works with your key.", noteAr: "نماذج ChatGPT الرسمية. تعمل من المتصفح بمفتاحك مباشرة.",
    models: [
      M("gpt-4o-mini", "GPT-4o mini", ["cheap", "fast", "vision"], 128000, "openai", "Best value for everyday chat", "أفضل قيمة للمحادثة اليومية"),
      M("gpt-4o", "GPT-4o", ["balanced", "vision"], 128000, "openai"),
      M("gpt-4.1", "GPT-4.1", ["balanced", "coding"], 1047576, "openai", "Long context + strong coding"),
      M("gpt-4.1-mini", "GPT-4.1 mini", ["cheap", "fast"], 1047576, "openai"),
      M("gpt-4.1-nano", "GPT-4.1 nano", ["cheap", "fast"], 1047576, "openai"),
      M("o4-mini", "o4-mini", ["reasoning", "cheap"], 200000, "openai", "Shows its thinking"),
      M("o3", "o3", ["reasoning", "premium"], 200000, "openai"),
      M("gpt-5", "GPT-5", ["premium", "reasoning"], 400000, "openai"),
      M("gpt-5-mini", "GPT-5 mini", ["balanced", "fast"], 400000, "openai"),
    ],
  },
  {
    id: "anthropic", name: "Anthropic", logo: "claude-color", kind: "anthropic", base: "https://api.anthropic.com/v1", docs: "https://console.anthropic.com/settings/keys",
    keys: "sk-ant-…", detect: [/^sk-ant-/],
    noteEn: "Claude models. Browser calls need the direct-browser header, which DAYFLOW sends.", noteAr: "نماذج Claude. المتصفح يحتاج ترويسة الوصول المباشر، وDAYFLOW يرسلها.",
    models: [
      M("claude-sonnet-4-5", "Claude Sonnet 4.5", ["balanced", "coding", "vision"], 200000, "claude-color", "The all-round default", "الافتراضي الشامل"),
      M("claude-haiku-4-5", "Claude Haiku 4.5", ["cheap", "fast"], 200000, "claude-color", "Fast & inexpensive"),
      M("claude-opus-4-1", "Claude Opus 4.1", ["premium", "reasoning"], 200000, "claude-color"),
      M("claude-3-7-sonnet-latest", "Claude 3.7 Sonnet", ["reasoning", "balanced"], 200000, "claude-color"),
      M("claude-3-5-haiku-latest", "Claude 3.5 Haiku", ["cheap", "fast"], 200000, "claude-color"),
    ],
  },
  {
    id: "gemini", name: "Google Gemini", logo: "gemini-color", kind: "gemini", base: "https://generativelanguage.googleapis.com/v1beta", docs: "https://aistudio.google.com/app/apikey",
    keys: "AIza…", detect: [/^AIza[0-9A-Za-z_-]{20,}/],
    noteEn: "Google AI Studio keys. A generous free tier exists.", noteAr: "مفاتيح Google AI Studio. فيه طبقة مجانية سخية.",
    models: [
      M("gemini-2.5-flash", "Gemini 2.5 Flash", ["free", "fast", "vision"], 1048576, "gemini-color", "Free tier available", "فيه استخدام مجاني"),
      M("gemini-2.5-pro", "Gemini 2.5 Pro", ["balanced", "reasoning", "vision"], 1048576, "gemini-color"),
      M("gemini-2.0-flash", "Gemini 2.0 Flash", ["free", "cheap", "fast"], 1048576, "gemini-color"),
      M("gemini-2.0-flash-lite", "Gemini 2.0 Flash Lite", ["free", "cheap"], 1048576, "gemini-color", "Cheapest Google option"),
      M("gemini-2.5-flash-lite", "Gemini 2.5 Flash Lite", ["free", "fast"], 1048576, "gemini-color"),
    ],
  },
  {
    id: "groq", name: "Groq", logo: "groq", kind: "openai", base: "https://api.groq.com/openai/v1", docs: "https://console.groq.com/keys",
    keys: "gsk_…", detect: [/^gsk_/],
    noteEn: "Extremely fast inference. Free tier with rate limits.", noteAr: "أسرع استدلال. طبقة مجانية بحدود معدل.",
    models: [
      M("llama-3.3-70b-versatile", "Llama 3.3 70B", ["free", "open", "fast"], 131072, "meta-color", "Free + very fast", "مجاني وسريع جدًا"),
      M("llama-3.1-8b-instant", "Llama 3.1 8B Instant", ["free", "open", "fast"], 131072, "meta-color", "Cheapest & quickest"),
      M("openai/gpt-oss-120b", "GPT-OSS 120B", ["open", "fast", "balanced"], 131072, "openai"),
      M("qwen/qwen3-32b", "Qwen3 32B", ["open", "free"], 131072, "qwen-color"),
      M("deepseek-r1-distill-llama-70b", "DeepSeek R1 Distill 70B", ["open", "reasoning"], 131072, "deepseek-color", "Shows reasoning"),
      M("gemma2-9b-it", "Gemma 2 9B", ["free", "open", "fast"], 8192, "gemma-color"),
      M("mixtral-8x7b-32768", "Mixtral 8x7B", ["free", "open"], 32768, "mistral-color"),
    ],
  },
  {
    id: "openrouter", name: "OpenRouter", logo: "openrouter", kind: "openai", base: "https://openrouter.ai/api/v1", docs: "https://openrouter.ai/settings/keys",
    keys: "sk-or-v1-…", detect: [/^sk-or-v1-/],
    noteEn: "One key for hundreds of models. Live catalog with real prices is fetched.", noteAr: "مفتاح واحد لمئات النماذج. الكتالوج والأسعار الحقيقية تُجلب مباشرة.",
    models: [
      M("anthropic/claude-sonnet-4.5", "Claude Sonnet 4.5", ["balanced", "coding", "vision"], 200000, "claude-color"),
      M("openai/gpt-4o-mini", "GPT-4o mini", ["cheap", "fast"], 128000, "openai"),
      M("google/gemini-2.5-flash", "Gemini 2.5 Flash", ["cheap", "fast", "vision"], 1048576, "gemini-color"),
      M("deepseek/deepseek-r1", "DeepSeek R1", ["open", "reasoning", "cheap"], 163840, "deepseek-color", "Reasoning visible", "بيوريك التفكير"),
      M("deepseek/deepseek-chat-v3", "DeepSeek V3", ["open", "cheap"], 163840, "deepseek-color", "Cheap + strong Arabic"),
      M("meta-llama/llama-3.3-70b-instruct", "Llama 3.3 70B", ["open", "cheap"], 131072, "meta-color"),
      M("qwen/qwen3-235b-a22b", "Qwen3 235B", ["open", "balanced"], 131072, "qwen-color"),
      M("x-ai/grok-4", "Grok 4", ["premium", "reasoning"], 256000, "grok"),
      M("mistralai/mistral-large", "Mistral Large", ["open", "balanced"], 131072, "mistral-color"),
      M("nvidia/nemotron-3-ultra-550b-a55b", "Nemotron 3 Ultra", ["free", "open"], 262144, "nvidia-color", "Free on OpenRouter", "مجاني على OpenRouter"),
    ],
  },
  {
    id: "mistral", name: "Mistral AI", logo: "mistral-color", kind: "openai", base: "https://api.mistral.ai/v1", docs: "https://console.mistral.ai/api-keys/",
    keys: "…", detect: [/^[A-Za-z0-9]{32}$/],
    noteEn: "European, partly open-weight models. Free experimentation tier.", noteAr: "نماذج أوروبية وبعضها مفتوح الأوزان. طبقة تجريبية مجانية.",
    models: [M("mistral-large-latest", "Mistral Large", ["balanced", "open"], 131072, "mistral-color"), M("mistral-small-latest", "Mistral Small", ["cheap", "fast", "open"], 131072, "mistral-color"), M("open-mistral-nemo", "Mistral NeMo", ["free", "open"], 131072, "mistral-color"), M("codestral-latest", "Codestral", ["coding", "cheap"], 262144, "mistral-color"), M("pixtral-large-latest", "Pixtral Large", ["vision", "balanced"], 131072, "mistral-color")],
  },
  {
    id: "deepseek", name: "DeepSeek", logo: "deepseek-color", kind: "openai", base: "https://api.deepseek.com/v1", docs: "https://platform.deepseek.com/api_keys",
    keys: "sk-…", detect: [],
    noteEn: "Very cheap, strong Arabic, visible reasoning on R1.", noteAr: "رخيص جدًا، عربي قوي، وبيّن التفكير في R1.",
    models: [M("deepseek-chat", "DeepSeek V3", ["cheap", "open"], 64000, "deepseek-color", "Cheapest strong Arabic", "أرخص نموذج عربي قوي"), M("deepseek-reasoner", "DeepSeek R1", ["reasoning", "open", "cheap"], 64000, "deepseek-color", "Thinking shown", "بيوريك التفكير")],
  },
  {
    id: "xai", name: "xAI (Grok)", logo: "grok", kind: "openai", base: "https://api.x.ai/v1", docs: "https://console.x.ai/",
    keys: "xai-…", detect: [/^xai-/],
    noteEn: "Grok models from xAI.", noteAr: "نماذج Grok من xAI.",
    models: [M("grok-4", "Grok 4", ["premium", "reasoning"], 256000, "grok"), M("grok-3", "Grok 3", ["balanced"], 131072, "grok"), M("grok-3-mini", "Grok 3 mini", ["cheap", "reasoning"], 131072, "grok")],
  },
  {
    id: "cohere", name: "Cohere", logo: "cohere-color", kind: "openai", base: "https://api.cohere.ai/compatibility/v1", docs: "https://dashboard.cohere.com/api-keys",
    keys: "…", detect: [],
    noteEn: "Enterprise models with a free trial key.", noteAr: "نماذج للمؤسسات ومفتاح تجريبي مجاني.",
    models: [M("command-r-plus-08-2024", "Command R+", ["balanced", "open"], 128000, "cohere-color"), M("command-r-08-2024", "Command R", ["cheap", "open"], 128000, "cohere-color"), M("command-a-03-2025", "Command A", ["balanced"], 256000, "cohere-color")],
  },
  {
    id: "together", name: "Together AI", logo: "together-color", kind: "openai", base: "https://api.together.xyz/v1", docs: "https://api.together.ai/settings/api-keys",
    keys: "…", detect: [],
    noteEn: "Open-source model hosting, many free endpoints.", noteAr: "استضافة نماذج مفتوحة، وفيه نقاط مجانية.",
    models: [M("meta-llama/Llama-3.3-70B-Instruct-Turbo", "Llama 3.3 70B Turbo", ["open", "fast"], 131072, "meta-color"), M("Qwen/Qwen2.5-72B-Instruct-Turbo", "Qwen 2.5 72B", ["open"], 32768, "qwen-color"), M("deepseek-ai/DeepSeek-R1", "DeepSeek R1", ["open", "reasoning"], 163840, "deepseek-color"), M("meta-llama/Llama-4-Scout-17B-16E-Instruct", "Llama 4 Scout", ["free", "open", "vision"], 1048576, "meta-color")],
  },
  {
    id: "fireworks", name: "Fireworks AI", logo: "fireworks-color", kind: "openai", base: "https://api.fireworks.ai/inference/v1", docs: "https://fireworks.ai/account/api-keys",
    keys: "…", detect: [],
    noteEn: "Fast open-model inference.", noteAr: "استدلال سريع للنماذج المفتوحة.",
    models: [M("accounts/fireworks/models/llama-v3p3-70b-instruct", "Llama 3.3 70B", ["open", "fast"], 131072, "meta-color"), M("accounts/fireworks/models/qwen3-235b-a22b", "Qwen3 235B", ["open", "reasoning"], 131072, "qwen-color"), M("accounts/fireworks/models/deepseek-r1", "DeepSeek R1", ["open", "reasoning"], 163840, "deepseek-color")],
  },
  {
    id: "perplexity", name: "Perplexity", logo: "perplexity-color", kind: "openai", base: "https://api.perplexity.ai", docs: "https://www.perplexity.ai/settings/api",
    keys: "pplx-…", detect: [/^pplx-/],
    noteEn: "Answers with live web citations.", noteAr: "إجابات مع مصادر ويب حديثة.",
    models: [M("sonar", "Sonar", ["cheap", "fast"], 128000, "perplexity-color", "Web-grounded", "بيرد من الويب"), M("sonar-pro", "Sonar Pro", ["balanced"], 200000, "perplexity-color"), M("sonar-reasoning", "Sonar Reasoning", ["reasoning"], 128000, "perplexity-color")],
  },
  {
    id: "cerebras", name: "Cerebras", logo: "cerebras-color", kind: "openai", base: "https://api.cerebras.ai/v1", docs: "https://cloud.cerebras.ai/",
    keys: "csk-…", detect: [/^csk-/],
    noteEn: "Wafer-scale speed; generous free tier.", noteAr: "سرعة فائقة وطبقة مجانية سخية.",
    models: [M("llama-3.3-70b", "Llama 3.3 70B", ["free", "fast", "open"], 131072, "meta-color"), M("llama3.1-8b", "Llama 3.1 8B", ["free", "fast"], 32768, "meta-color"), M("qwen-3-32b", "Qwen3 32B", ["free", "open"], 131072, "qwen-color")],
  },
  {
    id: "deepinfra", name: "DeepInfra", logo: "deepinfra-color", kind: "openai", base: "https://api.deepinfra.com/v1/openai", docs: "https://deepinfra.com/dash/api_keys",
    keys: "…", detect: [],
    noteEn: "Cheap open-model hosting.", noteAr: "استضافة رخيصة للنماذج المفتوحة.",
    models: [M("meta-llama/Llama-3.3-70B-Instruct", "Llama 3.3 70B", ["open", "cheap"], 131072, "meta-color"), M("deepseek-ai/DeepSeek-R1", "DeepSeek R1", ["open", "reasoning", "cheap"], 163840, "deepseek-color")],
  },
  {
    id: "novita", name: "Novita AI", logo: "novita-color", kind: "openai", base: "https://api.novita.ai/v3/openai", docs: "https://novita.ai/settings/key-management",
    keys: "sk_…", detect: [/^sk_[A-Za-z0-9]{20,}/],
    noteEn: "Open-source models, free credits on sign-up.", noteAr: "نماذج مفتوحة ورصيد مجاني عند التسجيل.",
    models: [M("meta-llama/llama-3.3-70b-instruct", "Llama 3.3 70B", ["open", "cheap"], 131072, "meta-color"), M("deepseek/deepseek-r1", "DeepSeek R1", ["open", "reasoning"], 163840, "deepseek-color")],
  },
  {
    id: "hyperbolic", name: "Hyperbolic", logo: "hyperbolic-color", kind: "openai", base: "https://api.hyperbolic.xyz/v1", docs: "https://app.hyperbolic.xyz/settings",
    keys: "…", detect: [],
    noteEn: "Open models with a free tier.", noteAr: "نماذج مفتوحة مع طبقة مجانية.",
    models: [M("meta-llama/Llama-3.3-70B-Instruct", "Llama 3.3 70B", ["open", "free"], 131072, "meta-color"), M("deepseek-ai/DeepSeek-R1", "DeepSeek R1", ["open", "reasoning"], 163840, "deepseek-color")],
  },
  {
    id: "sambanova", name: "SambaNova", logo: "sambanova-color", kind: "openai", base: "https://api.sambanova.ai/v1", docs: "https://cloud.sambanova.ai/apis",
    keys: "…", detect: [],
    noteEn: "Very fast Llama hosting, free tier.", noteAr: "استضافة Llama فائقة السرعة بطبقة مجانية.",
    models: [M("Meta-Llama-3.3-70B-Instruct", "Llama 3.3 70B", ["free", "fast", "open"], 131072, "meta-color"), M("DeepSeek-R1", "DeepSeek R1", ["reasoning", "free"], 32768, "deepseek-color")],
  },
  {
    id: "nvidia", name: "NVIDIA NIM", logo: "nvidia-color", kind: "openai", base: "https://integrate.api.nvidia.com/v1", docs: "https://build.nvidia.com/",
    keys: "nvapi-…", detect: [/^nvapi-/],
    noteEn: "Free API credits for hosted open models.", noteAr: "رصيد API مجاني لنماذج مفتوحة مستضافة.",
    models: [M("nvidia/llama-3.3-nemotron-super-49b-v1", "Nemotron Super 49B", ["free", "open"], 131072, "nvidia-color"), M("deepseek-ai/deepseek-r1", "DeepSeek R1", ["reasoning", "free"], 163840, "deepseek-color")],
  },
  {
    id: "ollama", name: "Ollama (on this device)", logo: "ollama", kind: "openai", base: "http://localhost:11434/v1", docs: "https://ollama.com/download",
    keys: "not required", detect: [], local: true,
    noteEn: "Fully local. Needs Ollama running on 127.0.0.1:11434 with CORS enabled.", noteAr: "محلي بالكامل. محتاج تشغيل Ollama على 127.0.0.1:11434 مع تفعيل CORS.",
    models: [M("llama3.2", "Llama 3.2", ["open", "free"], 131072, "meta-color", "Runs on your machine", "بيشتغل على جهازك"), M("qwen2.5", "Qwen 2.5", ["open", "free"], 32768, "qwen-color"), M("gemma3", "Gemma 3", ["open", "free"], 131072, "gemma-color"), M("deepseek-r1", "DeepSeek R1", ["open", "reasoning", "free"], 131072, "deepseek-color"), M("phi4", "Phi-4", ["open", "free"], 16384, "microsoft-color")],
  },
  {
    id: "lmstudio", name: "LM Studio (on this device)", logo: "lmstudio", kind: "openai", base: "http://localhost:1234/v1", docs: "https://lmstudio.ai/",
    keys: "not required", detect: [], local: true,
    noteEn: "Fully local. Start the LM Studio server on port 1234.", noteAr: "محلي بالكامل. شغّل سيرفر LM Studio على المنفذ 1234.",
    models: [M("local-model", "Loaded model", ["open", "free"], 0, "lmstudio")],
  },
  {
    id: "azure", name: "Azure OpenAI", logo: "azure-color", kind: "openai", base: "https://YOUR-RESOURCE.openai.azure.com/openai", docs: "https://portal.azure.com/",
    keys: "…", detect: [],
    noteEn: "Enterprise deployment: put your resource URL in “Custom base URL”.", noteAr: "نشر للمؤسسات: ضع رابط المورد في «رابط مخصص».",
    models: [M("gpt-4o-mini", "GPT-4o mini (deployment)", ["balanced"], 128000, "openai"), M("gpt-4o", "GPT-4o (deployment)", ["balanced", "vision"], 128000, "openai")],
  },
  {
    id: "custom", name: "Custom OpenAI-compatible", logo: "openai", kind: "openai", base: "", docs: "",
    keys: "…", detect: [],
    noteEn: "Any OpenAI-compatible endpoint, including self-hosted.", noteAr: "أي نقطة متوافقة مع OpenAI، بما فيها استضافتك الخاصة.",
    models: [M("custom", "Your model name", ["open"], 0)],
  },
];
export const providerById = (id: Api) => PROVIDERS.find((p) => p.id === id) || PROVIDERS[PROVIDERS.length - 1];

/** Real detection: prefix → provider. Order matters; never classify an OpenRouter key as OpenAI. */
export function detectProvider(key: string): Api | null {
  const k = key.trim();
  if (/^sk-or-v1-/i.test(k)) return "openrouter";
  if (/^sk-ant-/i.test(k)) return "anthropic";
  if (/^gsk_/i.test(k)) return "groq";
  if (/^AIza/i.test(k)) return "gemini";
  if (/^xai-/i.test(k)) return "xai";
  if (/^pplx-/i.test(k)) return "perplexity";
  if (/^csk-/i.test(k)) return "cerebras";
  if (/^nvapi-/i.test(k)) return "nvidia";
  for (const p of PROVIDERS) if (p.id !== "openai" && p.detect.some((r) => r.test(k))) return p.id;
  if (/^sk-proj-/i.test(k)) return "openai";
  if (/^sk-[A-Za-z0-9]{32,}$/.test(k)) return "deepseek";
  return null;
}

export const TIERS: Array<{ id: Tier; en: string; ar: string }> = [
  { id: "free", en: "Free", ar: "مجاني" }, { id: "cheap", en: "Cheap", ar: "رخيص" }, { id: "balanced", en: "Balanced", ar: "متوازن" },
  { id: "premium", en: "Premium", ar: "مدفوع غالي" }, { id: "open", en: "Open source", ar: "مفتوح المصدر" }, { id: "reasoning", en: "Shows thinking", ar: "بيورّي التفكير" },
  { id: "vision", en: "Vision", ar: "بيشوف صور" }, { id: "fast", en: "Fast", ar: "سريع" }, { id: "coding", en: "Coding", ar: "برمجة" },
];

/** Provider logos + per-model logos, all from the official LobeHub static icon set. */
export function logoFor(p: Provider, model?: ModelInfo) {
  return LOGO(model?.logo || p.logo);
}
