// Prayer times — calculated on device with the standard solar equations (no network, no location API).
// Method: Egyptian General Survey Authority (Fajr 19.5°, Isha 17.5°), Asr standard (Shafi'i).
export interface PrayerTimes { fajr: string; sunrise: string; dhuhr: string; asr: string; maghrib: string; isha: string; next: { name: string; nameAr: string; time: string; inMin: number } | null }
export interface Location { lat: number; lng: number; city: string; cityAr: string; tz: number }

export const CITIES: Location[] = [
  { lat: 30.0444, lng: 31.2357, city: "Cairo", cityAr: "القاهرة", tz: 2 },
  { lat: 31.2001, lng: 29.9187, city: "Alexandria", cityAr: "الإسكندرية", tz: 2 },
  { lat: 25.6872, lng: 32.6396, city: "Luxor", cityAr: "الأقصر", tz: 2 },
  { lat: 24.0889, lng: 32.8998, city: "Aswan", cityAr: "أسوان", tz: 2 },
  { lat: 29.9668, lng: 32.5498, city: "Suez", cityAr: "السويس", tz: 2 },
  { lat: 27.9158, lng: 34.3299, city: "Sharm El-Sheikh", cityAr: "شرم الشيخ", tz: 2 },
  { lat: 21.4225, lng: 39.8262, city: "Makkah", cityAr: "مكة المكرمة", tz: 3 },
  { lat: 24.4686, lng: 39.6142, city: "Madinah", cityAr: "المدينة المنورة", tz: 3 },
  { lat: 25.2048, lng: 55.2708, city: "Dubai", cityAr: "دبي", tz: 4 },
  { lat: 51.5074, lng: -0.1278, city: "London", cityAr: "لندن", tz: 0 },
];

const rad = (d: number) => (d * Math.PI) / 180, deg = (r: number) => (r * 180) / Math.PI;
const fixHour = (h: number) => ((h % 24) + 24) % 24;

function julian(date: Date) {
  let y = date.getFullYear(), m = date.getMonth() + 1; const d = date.getDate();
  if (m <= 2) { y -= 1; m += 12; }
  const a = Math.floor(y / 100), b = 2 - a + Math.floor(a / 4);
  return Math.floor(365.25 * (y + 4716)) + Math.floor(30.6001 * (m + 1)) + d + b - 1524.5;
}

export function prayerTimes(loc: Location, date = new Date()): PrayerTimes {
  const jd = julian(date);
  const d = jd - 2451545.0;
  const g = rad(357.529 + 0.98560028 * d);
  const q = 280.459 + 0.98564736 * d;
  const L = rad((q + 1.915 * Math.sin(g) + 0.02 * Math.sin(2 * g)) % 360);
  const e = rad(23.439 - 0.00000036 * d);
  const RA = deg(Math.atan2(Math.cos(e) * Math.sin(L), Math.cos(L))) / 15;
  const decl = Math.asin(Math.sin(e) * Math.sin(L));
  const eqt = q / 15 - fixHour(RA);
  const midDay = fixHour(12 - eqt - loc.lng / 15 + loc.tz);
  const hourAngle = (alt: number) => {
    const cosH = (Math.sin(rad(alt)) - Math.sin(rad(loc.lat)) * Math.sin(decl)) / (Math.cos(rad(loc.lat)) * Math.cos(decl));
    if (cosH > 1 || cosH < -1) return null;
    return deg(Math.acos(cosH)) / 15;
  };
  const t = (alt: number, before = true) => { const h = hourAngle(alt); if (h === null) return null; return fixHour(before ? midDay - h : midDay + h); };
  const fajr = t(-19.5), sunrise = t(-0.833), maghrib = t(-0.833, false), isha = t(-17.5, false);
  // Asr: shadow factor 1
  const asrAlt = deg(Math.atan(1 / (1 + Math.tan(Math.abs(rad(loc.lat) - decl)))));
  const asr = t(asrAlt, false);
  const fmt = (h: number | null) => { if (h === null) return "—"; const total = Math.round(h * 60); return `${String(Math.floor(total / 60) % 24).padStart(2, "0")}:${String(total % 60).padStart(2, "0")}`; };
  const times = { fajr: fmt(fajr), sunrise: fmt(sunrise), dhuhr: fmt(midDay), asr: fmt(asr), maghrib: fmt(maghrib), isha: fmt(isha) };
  const nowMin = date.getHours() * 60 + date.getMinutes();
  const list = [["fajr", "الفجر", times.fajr], ["sunrise", "الشروق", times.sunrise], ["dhuhr", "الظهر", times.dhuhr], ["asr", "العصر", times.asr], ["maghrib", "المغرب", times.maghrib], ["isha", "العشاء", times.isha]] as const;
  let next: PrayerTimes["next"] = null;
  for (const [name, nameAr, time] of list) {
    const [hh, mm] = time.split(":").map(Number);
    const diff = hh * 60 + mm - nowMin;
    if (diff > 0) { next = { name, nameAr, time, inMin: diff }; break; }
  }
  if (!next) { const [hh, mm] = times.fajr.split(":").map(Number); next = { name: "fajr", nameAr: "الفجر", time: times.fajr, inMin: 1440 - nowMin + hh * 60 + mm }; }
  return { ...times, next };
}

export const PRAYER_NAMES: Array<[keyof Omit<PrayerTimes, "next">, string, string, string]> = [
  ["fajr", "Fajr", "الفجر", "🌅"], ["sunrise", "Sunrise", "الشروق", "☀️"], ["dhuhr", "Dhuhr", "الظهر", "🕛"],
  ["asr", "Asr", "العصر", "🌤️"], ["maghrib", "Maghrib", "المغرب", "🌇"], ["isha", "Isha", "العشاء", "🌙"],
];
