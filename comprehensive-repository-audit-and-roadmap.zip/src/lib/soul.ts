// Egyptian-dialect soul engine: a fast, local, template + intent engine.
// Used by the robot for reminders/emotions and as the offline AI fallback. No network.
import { nextAlarmTime, type Alarm, type Task } from "./store";
import { upcomingOccasions } from "./calendar";
import { dayKey } from "./calendar";
import { futureAt, parseDateIntent, parseTimeIntent } from "./temporal";

export type Mood = "idle" | "happy" | "sad" | "cold" | "welcome" | "sleep" | "think" | "celebrate" | "wink" | "worried";
export interface Bubble { id: string; text: string; kind: "reminder" | "mood" | "tip" | "reply" | "ask"; mood?: Mood; at: number; action?: "alarms" | "tasks" | "habits" | "media" | "ai" | "settings" }

const pick = <T,>(a: T[], seed = Math.random()) => a[Math.floor(seed * a.length) % a.length];
const h = (s: string) => { let x = 0; for (const c of s) x = (x * 31 + c.charCodeAt(0)) >>> 0; return x; };

const GREET_MORNING = ["صباح الفل يا صاحبي ☀️", "صباح الخير يا نجم، قوم بقى نعمل حاجة حلوة النهاردة", "صباحك سكر يا باشا، إيه خطة النهاردة؟", "النهاردة يوم جديد، يلا نبدأه صح", "صباح الجدعنة ☕", "قوم يا معلم، الدنيا مستنياك", "صباح الورد، فنجان قهوة ونبدأ 💛", "يا هلا بالصبح، إيه أول حاجة هنعملها؟", "صباحك فل وياسمين، يومك سعيد", "قوم نفطر ونرتب يومنا يا وحش", "صباح الخير، أنا جهزتلك ملخص يومك", "صباح النية الحلوة يا صديقي"];
const GREET_EVENING = ["مساء الجمال يا فندم 🌙", "إيه الأخبار؟ يومك كان عامل إيه؟", "مسا الخير، نلخص يومنا شوية؟", "لسه بدري، تعمل حاجة صغيرة مفيدة؟", "مساء الفل، عامل إيه في نفسك؟", "مسا الخير يا صاحبي، ريح شوية", "شكل اليوم كان طويل، خد نفسك", "بالليل بنرتاح ونحكي، إيه أخبارك؟", "لو تعبان قولي، ولو مبسوط شاركني", "مساء السكينة، إيه أحلى حاجة حصلت النهاردة؟"];
const TIPS = ["اشرب كوباية ماية، دماغك هتشكرك 💧", "خد نفس عميق ٤ ثواني، وطلعه في ٦", "الوقفة ٥ دقايق بتعمل أكتر من قهوة", "متذاكرش وانت تعبان، خد ٢٠ دقيقة نوم أحسن", "الموبايل بعيد عن السرير بيفرق جدًا في نومك", "خطّط ٣ حاجات بس للنهاردة، وهتخلصهم", "التمرين مش لازم ساعة، ١٠ دقايق مشي كفاية", "قول لنفسك حاجة حلوة، انت تستاهل", "بص على بعيد كل نص ساعة، عينك هترتاح", "قسّم الشغل الكبير لخطوات صغيرة وابدأ بأسهل واحدة", "متقارنش نفسك بحد، قارن نفسك بنفسك امبارح", "لو حسّيت إنك متلخبط، اكتب أفكارك على ورقة", "اشرب ماية قبل القهوة، وهتلاقي فرق", "النهاردة مش لازم تكون مثالي، خليك موجود بس"];
const HAPPY = ["كده عاجبني! استمر 👏", "برافو يا وحش 🔥", "أنا فخور بيك والله", "شغل نضيف، كمل كده", "ما شاء الله عليك ✨", "ده بالظبط اللي بقوله", "تسلم إيدك يا نجم، خطوة عظيمة", "حلو أوي كده، أنا فرحان لك", "شفت؟ قلتلك هتقدر 💪", "إنجاز يشجع، خليك على الحال", "ماشي صح، وأنا معاك للآخر", "ده رقم حلو، كمّل عليه"];
const SAD = ["عادي يا صاحبي، أيام وحشة بتيجي وبتعدي 🤍", "متزعلش من نفسك، انت بتحاول وده مهم", "تعالى نعمل حاجة صغيرة سهلة ونفسيتك تتحسن", "الدنيا مش دايمًا سبرينت، امشي براحتك", "خدها بالراحة النهاردة، مش مطلوب منك كل حاجة", "كلنا بنقع، المهم إنك بتقوم تاني", "لو محتاج تكلم حد، متسكتش. أنا هنا برضه", "اليوم الوحش مش بيعرّفك، انت أكبر من يوم", "خد مساحة لنفسك، مفيش حاجة هتطير", "أنا معاك ومش هزعل منك لو ماعملتش حاجة"];
const COLD = ["الجو برد يا معلم، البس تقيل واشرب سخن ☕", "برد النهاردة! متنساش الشال والجاكيت", "إدفي كويس، ومتنساش تشرب ماية حتى في البرد"];
const SLEEP = ["أنا نمت شوية… في حاجة محتاجها؟", "صحيت! كنت بحلم بمهامك 😴", "يلا نشتغل تاني، أنا فايق"];
const WELCOME = ["أهلاً بيك يا صاحبي 👋", "نوّرت، أقدر أساعدك في إيه؟", "تحت أمرك، اسأل أو قولي أعمل إيه", "أهلاً! أنا معاك هنا في أي وقت", "يلا بينا، إيه اللي محتاجه النهاردة؟", "أنا جاهز، اختار: مهمة، منبه، عادة، أو أي سؤال", "نورت يا غالي، عايز نرتب إيه؟", "قولي أي حاجة، ولو مش فاهمه هسألك"];
const CELEBRATE = ["خلّصتها! جامد والله 🎉", "كده تمام، واحدة واحدة بنخلص", "إنجاز صغير بس بيفرق 👏", "الله ينور، فضلت خطوة واحدة", "شغل عالي، افتخر بنفسك شوية", "دي كانت خطوة مهمة، عاش 🎊", "أنا مبسوط أكتر منك، بجد", "خلّص النهاردة وارتاح، تستاهل"];
const THINK = ["سيبني أفكر لحظة…", "بقلب في بياناتك…", "تمام، براجع التفاصيل…"];

export const BUBBLE_TEXTS = { GREET_MORNING, GREET_EVENING, TIPS, HAPPY, SAD, COLD, SLEEP, WELCOME, CELEBRATE, THINK };

export function greeting(lang: "en" | "ar", _mood: Mood = "idle", seed = Math.random()) {
  if (lang === "en") return pick(["Morning, sunshine ☀️", "Evening, friend 🌙", "Hey! What are we doing today?", "Ready when you are."], seed);
  const hr = new Date().getHours();
  if (hr < 12) return pick(GREET_MORNING, seed);
  if (hr >= 18) return pick(GREET_EVENING, seed);
  return pick(WELCOME, seed);
}

export function moodFor(tasks: Task[], now = new Date()): Mood {
  const today = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")}`;
  const list = tasks.filter((t) => t.date === today);
  const done = list.filter((t) => t.done).length;
  if (list.length && done === list.length) return "celebrate";
  if (now.getMonth() <= 1) return "cold";
  const hr = now.getHours();
  if (hr < 5) return "sleep";
  if (done > 0) return "happy";
  if (list.length > 5 && done === 0) return "worried";
  return "idle";
}

export function moodLine(mood: Mood, lang: "en" | "ar") {
  if (lang === "en") return ({ happy: "Nice work!", sad: "It's okay.", cold: "Bundle up.", welcome: "Welcome!", sleep: "Zzz…", think: "Thinking…", celebrate: "You did it!", wink: "On it.", worried: "Lots to do…", idle: "I'm here." })[mood];
  return ({ happy: pick(HAPPY), sad: pick(SAD), cold: pick(COLD), welcome: pick(WELCOME), sleep: pick(SLEEP), think: pick(THINK), celebrate: pick(CELEBRATE), wink: "تحت أمرك 😉", worried: "عندك حاجات كتير، خلينا نبدأ بحاجة صغيرة", idle: "أنا هنا لو احتاجتني" })[mood];
}

/** Upcoming reminders with a live countdown. Egyptian Arabic. Deterministic ordering. */
export function upcomingReminders(alarms: Alarm[], tasks: Task[], lang: "en" | "ar", now = new Date()): Bubble[] {
  const out: Bubble[] = [];
  const today = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")}`;
  const na = nextAlarmTime(alarms, now);
  if (na) {
    const mins = Math.round((na.at.getTime() - now.getTime()) / 60000);
    const hh = Math.floor(mins / 60), mm = mins % 60;
    const when = hh > 0 ? `${hh} ساعة${mm ? " و" + mm + " دقيقة" : ""}` : `${mm} دقيقة`;
    out.push({ id: "alarm-" + na.alarm.id, kind: "reminder", mood: "worried", at: na.at.getTime(), action: "alarms",
      text: lang === "ar" ? `فاضل ${when} على منبه «${na.alarm.label || "الصبح"}» ⏰` : `Alarm “${na.alarm.label || "next"}” in ${when} ⏰` });
  }
  const timed = tasks.filter((task) => !task.done && /^\d{4}-\d{2}-\d{2}$/.test(task.date)).map((task) => {
    const at = new Date(`${task.date}T${task.dueTime || "12:00"}:00`);
    return { task, at, remaining: at.getTime() - now.getTime() };
  }).filter((item) => item.remaining > 0 && item.remaining <= 2 * 864e5).sort((a, b) => a.remaining - b.remaining)[0];
  if (timed) {
    const minutes = Math.ceil(timed.remaining / 60000);
    const left = minutes >= 1440 ? `${Math.floor(minutes / 1440)} يوم` : minutes >= 60 ? `${Math.floor(minutes / 60)} ساعة${minutes % 60 ? ` و${minutes % 60} دقيقة` : ""}` : `${minutes} دقيقة`;
    out.push({ id: "task-" + timed.task.id, kind: "reminder", mood: "idle", at: timed.at.getTime(), action: "tasks",
      text: lang === "ar" ? `مهمة «${timed.task.title}» يوم ${timed.task.date}${timed.task.dueTime ? ` الساعة ${timed.task.dueTime}` : ""}، فاضل ${left}.` : `“${timed.task.title}” on ${timed.task.date}${timed.task.dueTime ? ` at ${timed.task.dueTime}` : ""} in ${left}.` });
  } else {
    const todo = tasks.filter((t) => t.date === today && !t.done && !t.dueTime);
    if (todo[0]) out.push({ id: "task-" + todo[0].id, kind: "reminder", mood: "idle", at: 0, action: "tasks",
      text: lang === "ar" ? `فاكر «${todo[0].title}»؟ لسه مستنياك 📌${todo.length > 1 ? ` وعندك ${todo.length} مهام تاني` : ""}` : `“${todo[0].title}” is still waiting 📌` });
  }
  const up = upcomingOccasions(now, 1).filter((u) => u.date.getTime() - now.getTime() < 30 * 864e5)[0];
  if (up) {
    const d = Math.round((up.date.getTime() - now.getTime()) / 864e5);
    const name = lang === "ar" ? up.o.ar : up.o.en;
    out.push({ id: "occ-" + up.o.id, kind: "tip", mood: "happy", at: up.date.getTime(), action: "settings",
      text: lang === "ar" ? (d <= 0 ? `النهاردة ${name}! كل سنة وانت طيب 🌟` : `فاضل ${d} يوم على ${name} 🎊`) : `${name} in ${d} days 🎊` });
  }
  return out;
}

export interface MiniReply { text: string; mood: Mood; actions?: Array<{ intent: string } & Record<string, string>>; needs?: string[] }

const APP_FACTS_AR = [
  "DAYFLOW فيه ٦ تابات: اليوم، التقويم، المنبهات، الأدوات، المرافق، وأنا (AI).",
  "التقويم بيجمع ٣ تقاويم: الميلادي والهجري (أم القرى) والقبطي، مع المناسبات المصرية والإسلامية.",
  "الودجات فيها أكتر من ١٣٠ تصميم، وكل واحد بيغيّر شكله لما تكبّره أو تصغّره.",
  "المراجعة فيها ١١ بُعد وكل نتيجة ليها سبب مكتوب، ومفيش داتا بتطلع من جهازك.",
  "مركز الوسائط بيعمل Preview حقيقي من معلومات الموقع، والتحميل الفعلي بيشتغل في نسخة أندرويد.",
  "العادات بتتضاف بالاسم والأيام والنوع والهدف، وبتتحسب في المراجعة.",
  "مفاتيح الـAPI بتتخزن على جهازك فقط، ومفيش أي سيرفر وسيط.",
];

/** Fast local intent engine. Understands Egyptian Arabic commands and app questions. */
export function miniBrain(input: string, ctx: { alarms: Alarm[]; tasks: Task[]; habitsCount: number; water: number }, lang: "en" | "ar", now = new Date()): MiniReply {
  const western = (input || "").replace(/[٠-٩]/g, (c) => String("٠١٢٣٤٥٦٧٨٩".indexOf(c))).replace(/[۰-۹]/g, (c) => String("۰۱۲۳۴۵۶۷۸۹".indexOf(c)));
  const q = western.trim().toLowerCase();
  const ar = lang === "ar";
  const act = (intent: string, args: Record<string, string>) => ({ intent, ...args });
  const wantedDate = parseDateIntent(western, now);
  const wantedTime = parseTimeIntent(western, now);
  const daysText = (d: string) => ar ? d : d;
  // A specific date is one-off. A weekday set repeats only when the user explicitly asks for it.
  if (/(منبه|نبهني|صحيني|alarm|wake)/.test(q)) {
    if (wantedDate.kind === "ambiguous") return { text: wantedDate.reason, mood: "think", needs: ["date"] };
    if (wantedTime.kind === "ambiguous") return { text: wantedTime.reason, mood: "think", needs: ["time"] };
    if (wantedDate.kind === "date" && wantedTime.kind === "time" && wantedTime.relative && wantedDate.date !== wantedTime.date) return { text: "تقصد بعد المدة دي من دلوقتي، ولا في اليوم اللي قلته؟ حدّد المعاد.", mood: "think", needs: ["date", "time"] };
    if (wantedTime.kind === "none") return { text: ar ? "أظبط المنبّه الساعة كام؟ قولّي مثلاً ٧ الصبح أو ٧ بالليل." : "What time? For example, 7 AM or 7 PM.", mood: "think", needs: ["time"] };
    if (wantedDate.kind === "none" && !wantedTime.relative) return { text: ar ? "تمام، المنبّه ده أنهي يوم؟ النهاردة ولا بكرة ولا كل يوم معين؟" : "Which day is this alarm for? Today, tomorrow, or a repeating weekday?", mood: "think", needs: ["date"] };
    const recurring = wantedDate.kind === "repeat";
    const date = wantedDate.kind === "date" ? wantedDate.date : wantedDate.kind === "repeat" ? wantedDate.startDate : wantedTime.date;
    if (date && !futureAt(date, wantedTime.time, now)) return { text: ar ? "المعاد ده فات؛ تختار يوم أو ساعة لسه جايين؟" : "That time has passed. Which future date or time should I use?", mood: "think", needs: ["date", "time"] };
    const days = recurring ? wantedDate.days.join(",") : "";
    return { text: ar ? `تمام، منبّه ${wantedTime.time} ${recurring ? `في الأيام اللي اخترتها${date ? ` بداية من ${date}` : ""}` : `يوم ${daysText(date!)}`} هيتسجّل دلوقتي. تقدر تشوفه في المنبّهات.` : `I'll save the alarm for ${date || "your selected weekdays"} at ${wantedTime.time}.`, mood: "happy", actions: [act("addAlarm", { time: wantedTime.time, label: ar ? "منبّه من المساعد" : "Assistant alarm", days, ...(date ? { date } : {}) })] };
  }
  if (/(مهمة|تاسك|أضيف|ضيف|task|todo)/.test(q) && !/(عادة|عادات|habit)/.test(q)) {
    if (wantedDate.kind === "ambiguous" || wantedDate.kind === "repeat") return { text: wantedDate.kind === "ambiguous" ? wantedDate.reason : "المهام المتكررة مش مدعومة بالشكل ده؛ حدّد يوم واحد، أو اعملها عادة.", mood: "think", needs: ["date"] };
    if (wantedTime.kind === "ambiguous") return { text: wantedTime.reason, mood: "think", needs: ["time"] };
    if (wantedDate.kind === "date" && wantedTime.kind === "time" && wantedTime.relative && wantedDate.date !== wantedTime.date) return { text: "تقصد بعد المدة دي من دلوقتي، ولا في اليوم اللي قلته؟ حدّد المعاد.", mood: "think", needs: ["date", "time"] };
    const title = western
      .replace(/(?:بعد\s+(?:بكر[هةا]|غد)|بكر[هةا]|غدا|النهارده|النهاردة|اليوم|tomorrow|today)/gi, " ")
      .replace(/(?:بعد\s+(?:\d+|يومين|تلات|ثلاثة|اسبوعين|اسبوع)\s*(?:يوم|ايام|اسبوع|اسابيع|days?|weeks?)?)/gi, " ")
      .replace(/\d{4}[-/]\d{1,2}[-/]\d{1,2}|\d{1,2}[/.]\d{1,2}[/.]\d{4}/g, " ")
      .replace(/(?:الساعة|الساعه|ساعة|at)\s*\d{1,2}(?::\d{2})?\s*(?:الصبح|صباح|مسا|مساء|بالليل|العصر|am|pm)?/gi, " ")
      .replace(/\b\d{1,2}:\d{2}\b/g, " ")
      .replace(/(?:الاحد|الاتنين|الاثنين|التلات|الثلاثاء|الاربعاء|الخميس|الجمعة|السبت)\s*(?:الجاي|اللي جاي|القادم)?/gi, " ")
      .replace(/(?:ضيف|أضف|اعمل|مهمة|تاسك|task|todo|لي|عليا|عندي)/gi, " ")
      .replace(/\s+/g, " ").trim();
    if (title.length < 2) return { text: ar ? "أكتبلي اسم المهمة وأنا أضيفها فورًا 📝" : "Tell me the task name 📝", mood: "think", needs: ["title"] };
    const date = wantedDate.kind === "date" ? wantedDate.date : wantedTime.kind === "time" && wantedTime.relative ? wantedTime.date! : dayKey(now);
    if (date < dayKey(now) || (wantedTime.kind === "time" && !futureAt(date, wantedTime.time, now))) return { text: ar ? "المعاد ده فات؛ حدّد تاريخ أو وقت جاي للمهمة." : "That time has passed. Please choose a future date or time.", mood: "think", needs: ["date", "time"] };
    const detail = wantedTime.kind === "time" ? ` الساعة ${wantedTime.time}` : "";
    return { text: ar ? date === dayKey(now) ? `هسجّل «${title}» للنهاردة${detail}.` : `هسجّل «${title}» ليوم ${date}${detail}، مش للنهاردة.` : `I'll save “${title}” for ${date}${detail}.`, mood: "happy", actions: [act("addTask", { title, date, ...(wantedTime.kind === "time" ? { time: wantedTime.time } : {}) })] };
  }
  if (/(ماية|ماء|water|اشرب)/.test(q)) return { text: ar ? "سجلتلك كوباية ٢٥٠ مل 💧 كمّل واشرب تاني بعد شوية" : "Logged 250 ml 💧", mood: "happy", actions: [act("addWater", { ml: "250" })] };
  if (/(عادة|عادات|habit)/.test(q)) {
    if (/(?:ضيف|اضف|اعمل|ابدأ|ابدء|add|create|start)/.test(q)) {
      if (wantedDate.kind === "ambiguous") return { text: wantedDate.reason, mood: "think", needs: ["date"] };
      if (wantedDate.kind === "none" || wantedDate.kind === "date") return { text: ar ? "العادة دي هتتكرر في أنهي أيام؟ قولّي مثلاً كل يوم، أو كل يوم اتنين وخميس." : "Which days should this habit repeat?", mood: "think", needs: ["days"] };
      const name = western.replace(/(?:ضيف|اضف|أضف|اعمل|ابدأ|ابدء|عادة|عادات|habit|add|create|start|كل يوم|كل اسبوع|ابتداء من|بداية من|بكره|بكرة|بكرا|بكر[هةا]|غدا|tomorrow)/gi, " ").replace(/(?:الاحد|الاتنين|الاثنين|اتنين|التلات|الثلاثاء|الاربعاء|الخميس|الجمعة|السبت)/gi, " ").replace(/\d{4}[-/]\d{1,2}[-/]\d{1,2}|\d{1,2}[/.]\d{1,2}[/.]\d{4}/g, " ").replace(/\s+/g, " ").trim();
      if (!name || name.length > 150) return { text: ar ? "إيه اسم العادة اللي عايز تعملها؟" : "What is the habit called?", mood: "think", needs: ["name"] };
      return { text: ar ? `هسجّل عادة «${name}» في أيامها${wantedDate.startDate ? ` بداية من ${wantedDate.startDate}` : ""}.` : `I'll add “${name}” to your selected days.`, mood: "happy", actions: [act("addHabit", { name, days: wantedDate.days.join(","), ...(wantedDate.startDate ? { date: wantedDate.startDate } : {}) })] };
    }
    return { text: ar ? `عندك ${ctx.habitsCount} عادات متسجلة. تفتح تاب العادات ونضيف واحدة جديدة بالاسم والأيام؟` : `You track ${ctx.habitsCount} habits.`, mood: "idle", actions: [act("open", { tab: "tools", sub: "habits" })] };
  }
  if (/(تحميل|فيديو|رابط|media|download|لينك)/.test(q)) return { text: ar ? "افتح مركز الوسائط والصق الرابط، هيجيبلك اسم الفيديو وصورته والمدة أحجام الصيغ. للتحميل الفعلي محتاج نسخة أندرويد." : "Open the Media Hub and paste the link.", mood: "idle", actions: [act("open", { tab: "tools", sub: "media" })] };
  if (/(صباح|ازيك|إزيك|عامل ايه|hello|hi|هاي)/.test(q)) return { text: greeting(lang, "happy"), mood: "happy" };
  if (/(تعبان|زعلان|sad|مش كويس)/.test(q)) return { text: ar ? pick(SAD) : "I'm sorry. Want to do one small thing together?", mood: "sad" };
  if (/(حلو|تمام|شكرا|برافو|تم|خلصت)/.test(q)) return { text: ar ? pick(HAPPY) : "Nice one!", mood: "celebrate" };
  if (/(الجو|برد|cold|شتا)/.test(q)) return { text: ar ? pick(COLD) : "Bundle up!", mood: "cold" };
  if (/(كام مهمة|مهامي|المهام|task count)/.test(q)) {
    const left = ctx.tasks.filter((t) => !t.done).length;
    return { text: ar ? `فاضل عندك ${left} مهمة${left ? "، تحب نبدأ بأصغر واحدة؟" : "، كده خلصت كل حاجة 👏"}` : `${left} tasks left.`, mood: left ? "idle" : "celebrate" };
  }
  if (/(مراجع|تقييم|review|درجة)/.test(q)) return { text: ar ? "المراجعة بتاعتك موجودة في تاب «أنا». كل درجة ليها شرح «ليه؟» ومفيش داتا بتطلع بره الجهاز." : "Your Review is under Me.", mood: "idle", actions: [act("open", { tab: "me", sub: "review" })] };
  if (/(مين انت|اسمك|who are you)/.test(q)) return { text: ar ? "أنا رفيق DAYFLOW، شغال على جهازك، بفكر بسرعة وبعرف كل حاجة في التطبيق. لو عايز ذكاء أكبر اربط مفتاح من تاب «أنا»." : "I'm the DAYFLOW companion.", mood: "welcome" };
  if (/(منبهاتي|المنبه|alarm)/.test(q)) return { text: ar ? `عندك ${ctx.alarms.filter((a) => a.enabled).length} منبه شغّال. أفتحلك؟` : "Want to open Alarms?", mood: "idle", actions: [act("open", { tab: "alarms" })] };
  const fact = APP_FACTS_AR.find((f) => f.includes(q.slice(0, 3)));
  if (ar && q.length > 2 && /(dayflow|تطبيق|التطبيق|ازاي|إزاي|فين|مميزات)/.test(q)) return { text: pick(APP_FACTS_AR, h(q) / 4294967296) + " اسألني عن أي حاجة تانية.", mood: "idle" };
  if (fact) return { text: fact, mood: "idle" };
  const genericAr = ["فهمت قصدك، بس محتاج توضيح أكتر شوية عشان أساعدك صح", "خليني أتأكد: تقصد إنك عايز تعمل إيه بالظبط؟", "أنا معاك، قولي التفاصيل وأنا أتصرف", "ممكن أعملك ده، بس قولي الأول: امتى وازاي؟"];
  return { text: ar ? pick(genericAr, h(q) / 4294967296) : "Got it — can you give me a bit more detail?", mood: "think", needs: ["details"] };
}
