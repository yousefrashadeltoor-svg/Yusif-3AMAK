// Time-of-day ambience: each period of the day has its own real photograph + theme pack.
// Periods follow on-device prayer times when available (Fajr → Shurooq → Dhuhr → Asr → Maghrib → Isha).
import dawn from "../assets/photos/dawn.jpg";
import noon from "../assets/photos/noon.jpg";
import asr from "../assets/photos/asr.jpg";
import maghrib from "../assets/photos/maghrib.jpg";
import night from "../assets/photos/night.jpg";
import snowPhoto from "../assets/photos/snow.jpg";
import autumnTree from "../assets/photos/autumn-tree.jpg";

import maple from "../assets/decor/maple.png";
import fallen from "../assets/decor/fallen.png";
import wind from "../assets/decor/wind.png";
import snow from "../assets/decor/snow.png";
import star from "../assets/decor/star.png";
import sparkle from "../assets/decor/sparkle.png";
import crescent from "../assets/decor/crescent.png";
import blossom from "../assets/decor/blossom.png";
import tulip from "../assets/decor/tulip.png";
import wave from "../assets/decor/wave.png";
import balloon from "../assets/decor/balloon.png";
import confetti from "../assets/decor/confetti.png";
import heart from "../assets/decor/heart.png";
import lotus from "../assets/decor/lotus.png";
import dove from "../assets/decor/dove.png";
import herb from "../assets/decor/herb.png";
import snowman from "../assets/decor/snowman.png";
import gift from "../assets/decor/gift.png";
import books from "../assets/decor/books.png";
import type { Family } from "./calendar";

export type Period = "fajr" | "morning" | "noon" | "asr" | "maghrib" | "night";

export interface PeriodInfo { id: Period; en: string; ar: string; photo: string; theme: string; tint: string }

export const PERIODS: Record<Period, PeriodInfo> = {
  fajr: { id: "fajr", en: "Dawn", ar: "الفجر", photo: dawn, theme: "luxor-dawn", tint: "rgba(40,30,60,.35)" },
  morning: { id: "morning", en: "Morning", ar: "الصباح", photo: noon, theme: "paper-white", tint: "rgba(255,255,255,.18)" },
  noon: { id: "noon", en: "Noon", ar: "الظهر", photo: noon, theme: "nile-blue", tint: "rgba(20,60,110,.18)" },
  asr: { id: "asr", en: "Afternoon", ar: "العصر", photo: asr, theme: "desert-gold", tint: "rgba(120,70,20,.25)" },
  maghrib: { id: "maghrib", en: "Sunset", ar: "المغرب", photo: maghrib, theme: "aswan-sunset", tint: "rgba(60,20,30,.38)" },
  night: { id: "night", en: "Night", ar: "الليل", photo: night, theme: "cairo-night", tint: "rgba(5,8,20,.5)" },
};

export interface PrayerLike { fajr: string; sunrise: string; dhuhr: string; asr: string; maghrib: string; isha: string }
const toMin = (hhmm?: string) => { if (!hhmm) return NaN; const [h, m] = hhmm.split(":").map(Number); return h * 60 + m; };

export function periodAt(d: Date, p?: Partial<PrayerLike>): Period {
  const m = d.getHours() * 60 + d.getMinutes();
  const f = toMin(p?.fajr) || 4 * 60 + 30, sr = toMin(p?.sunrise) || 6 * 60, dh = toMin(p?.dhuhr) || 12 * 60;
  const as = toMin(p?.asr) || 15 * 60, mg = toMin(p?.maghrib) || 17 * 60 + 45, is = toMin(p?.isha) || 19 * 60 + 10;
  if (m >= f && m < sr + 60) return "fajr";
  if (m >= sr + 60 && m < dh - 30) return "morning";
  if (m >= dh - 30 && m < as) return "noon";
  if (m >= as && m < mg - 20) return "asr";
  if (m >= mg - 20 && m < is + 30) return "maghrib";
  return "night";
}

/** Realistic decor art per season family: falling (sprites), static corner piece, optional backdrop photo. */
export interface DecorArt { fall: string[]; corner?: string; backdrop?: string; motion: "fall" | "float" | "drift" }
export const DECOR_ART: Record<Family, DecorArt> = {
  autumn: { fall: [maple, fallen, wind, maple], corner: maple, backdrop: autumnTree, motion: "fall" },
  winter: { fall: [snow, snow, snow, sparkle], corner: snowman, backdrop: snowPhoto, motion: "fall" },
  spring: { fall: [blossom, tulip, blossom, herb], corner: tulip, motion: "drift" },
  summer: { fall: [wave, sparkle, star], corner: wave, motion: "float" },
  ramadan: { fall: [star, crescent, sparkle, star], corner: crescent, motion: "float" },
  islamic: { fall: [star, sparkle], corner: crescent, motion: "float" },
  friday: { fall: [sparkle, star], corner: dove, motion: "float" },
  eid: { fall: [balloon, confetti, star, gift], corner: gift, motion: "float" },
  national: { fall: [dove, sparkle, confetti], corner: dove, motion: "drift" },
  nile: { fall: [lotus, wave, herb], corner: lotus, motion: "drift" },
  coptic: { fall: [star, sparkle, dove], corner: dove, motion: "float" },
  love: { fall: [heart, blossom, heart], corner: heart, motion: "float" },
  study: { fall: [sparkle, star], corner: books, motion: "float" },
  birthday: { fall: [balloon, confetti, gift, sparkle], corner: balloon, motion: "float" },
  newyear: { fall: [confetti, sparkle, star, balloon], corner: sparkle, motion: "fall" },
};

export const ART_CREDITS = [
  "Photos: Wikimedia Commons (CC0 / Public domain) — Sunset over the Nile (Kyobe), Liechtenstein landscape, Desert dusk, A.-G. Decamps ‘Sunset, Tombs near Cairo’ (Walters), Milky Way over Åbyfjorden, Snowflake macro, Autumn tree Valea Morilor.",
  "Seasonal art: Google Noto Emoji (animated set, CC BY 4.0) — rendered as static images.",
  "Ornaments: Wikimedia Commons (CC0 / Public domain) SVGs.",
];
