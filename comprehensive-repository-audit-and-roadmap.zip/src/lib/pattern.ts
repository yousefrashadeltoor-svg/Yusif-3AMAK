// pattern-engine — procedural, mathematically exact ornament geometry ("glue" per V2-3.3).
// Fixed seeds, no hand-drawn art. Output: SVG strings / path data.
import type { Family } from "./calendar";

export function mulberry32(seed: number) {
  return () => {
    seed |= 0; seed = (seed + 0x6d2b79f5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const f = (n: number) => +n.toFixed(2);

export function starPath(cx: number, cy: number, n: number, ro: number, ri: number, rot = -Math.PI / 2) {
  let d = "";
  for (let i = 0; i < n * 2; i++) {
    const r = i % 2 ? ri : ro;
    const a = rot + (i * Math.PI) / n;
    d += (i ? "L" : "M") + f(cx + r * Math.cos(a)) + " " + f(cy + r * Math.sin(a));
  }
  return d + "Z";
}

export function polygonPath(cx: number, cy: number, n: number, r: number, rot = 0) {
  let d = "";
  for (let i = 0; i < n; i++) {
    const a = rot + (i * 2 * Math.PI) / n;
    d += (i ? "L" : "M") + f(cx + r * Math.cos(a)) + " " + f(cy + r * Math.sin(a));
  }
  return d + "Z";
}

/** Islamic {n/k} star rosette: star + interlaced polygon frame. */
export function rosette(cx: number, cy: number, r: number, n = 8) {
  return [
    starPath(cx, cy, n, r, r * Math.cos(Math.PI / n) * 0.62),
    polygonPath(cx, cy, n, r * 0.98, Math.PI / n),
    starPath(cx, cy, n, r * 0.5, r * 0.32),
  ];
}

export function snowflakePath(cx: number, cy: number, r: number) {
  let d = "";
  for (let i = 0; i < 6; i++) {
    const a = (i * Math.PI) / 3 - Math.PI / 2;
    const ex = cx + r * Math.cos(a), ey = cy + r * Math.sin(a);
    d += `M${f(cx)} ${f(cy)}L${f(ex)} ${f(ey)}`;
    for (const t of [0.45, 0.72]) {
      const bx = cx + r * t * Math.cos(a), by = cy + r * t * Math.sin(a);
      const bl = r * (t === 0.45 ? 0.3 : 0.2);
      for (const s of [-1, 1]) {
        const ba = a + (s * Math.PI) / 4;
        d += `M${f(bx)} ${f(by)}L${f(bx + bl * Math.cos(ba))} ${f(by + bl * Math.sin(ba))}`;
      }
    }
  }
  return d;
}

export function wavePath(w: number, h: number, amp: number, periods: number, phase = 0, y0 = h / 2) {
  let d = `M0 ${f(y0)}`;
  const steps = 48;
  for (let i = 1; i <= steps; i++) {
    const x = (i / steps) * w;
    d += `L${f(x)} ${f(y0 + amp * Math.sin(phase + (i / steps) * periods * 2 * Math.PI))}`;
  }
  return d;
}

export function lotusPath(cx: number, cy: number, r: number, petals = 5) {
  let d = "";
  for (let i = 0; i < petals; i++) {
    const a = -Math.PI / 2 + ((i - (petals - 1) / 2) * Math.PI) / (petals + 1.2);
    const tx = cx + r * Math.cos(a), ty = cy + r * Math.sin(a);
    const w = r * 0.32;
    const nx = -Math.sin(a) * w, ny = Math.cos(a) * w;
    const mx = cx + r * 0.5 * Math.cos(a), my = cy + r * 0.5 * Math.sin(a);
    d += `M${f(cx)} ${f(cy)}Q${f(mx + nx)} ${f(my + ny)} ${f(tx)} ${f(ty)}Q${f(mx - nx)} ${f(my - ny)} ${f(cx)} ${f(cy)}Z`;
  }
  return d;
}

export function crescentPath(cx: number, cy: number, r: number) {
  const r2 = r * 0.82;
  return `M${f(cx)} ${f(cy - r)}A${r} ${r} 0 1 0 ${f(cx)} ${f(cy + r)}A${r2} ${r2} 0 1 1 ${f(cx)} ${f(cy - r)}Z`;
}

/** Fanous lantern: procedural polygons (cap, body, base). */
export function lanternPaths(cx: number, top: number, s: number) {
  return [
    `M${f(cx)} ${f(top)}L${f(cx + s * 0.18)} ${f(top + s * 0.22)}L${f(cx - s * 0.18)} ${f(top + s * 0.22)}Z`,
    `M${f(cx - s * 0.3)} ${f(top + s * 0.24)}L${f(cx + s * 0.3)} ${f(top + s * 0.24)}L${f(cx + s * 0.38)} ${f(top + s * 0.55)}L${f(cx + s * 0.22)} ${f(top + s * 0.9)}L${f(cx - s * 0.22)} ${f(top + s * 0.9)}L${f(cx - s * 0.38)} ${f(top + s * 0.55)}Z`,
    `M${f(cx - s * 0.16)} ${f(top + s * 0.92)}L${f(cx + s * 0.16)} ${f(top + s * 0.92)}L${f(cx)} ${f(top + s * 1.05)}Z`,
  ];
}

export function heartPath(cx: number, cy: number, s: number) {
  return `M${f(cx)} ${f(cy + s * 0.35)}C${f(cx - s * 0.9)} ${f(cy - s * 0.2)} ${f(cx - s * 0.35)} ${f(cy - s * 0.75)} ${f(cx)} ${f(cy - s * 0.3)}C${f(cx + s * 0.35)} ${f(cy - s * 0.75)} ${f(cx + s * 0.9)} ${f(cy - s * 0.2)} ${f(cx)} ${f(cy + s * 0.35)}Z`;
}

export function leafPath(cx: number, cy: number, s: number, a = 0) {
  const c = Math.cos(a), si = Math.sin(a);
  const p = (x: number, y: number) => `${f(cx + x * c - y * si)} ${f(cy + x * si + y * c)}`;
  return `M${p(0, -s)}Q${p(s * 0.6, 0)} ${p(0, s)}Q${p(-s * 0.6, 0)} ${p(0, -s)}Z M${p(0, -s)}L${p(0, s)}`;
}

export function sparklePath(cx: number, cy: number, s: number) {
  return starPath(cx, cy, 4, s, s * 0.22);
}

export interface FamilyStyle { c1: string; c2: string; c3: string; en: string; ar: string }
export const FAMILY: Record<Family, FamilyStyle> = {
  ramadan: { c1: "#d4a237", c2: "#1f4e5f", c3: "#f3dfa2", en: "Ramadan lantern", ar: "فانوس رمضان" },
  islamic: { c1: "#1e7a5f", c2: "#c9a24a", c3: "#e8f1ea", en: "Islamic geometry", ar: "هندسة إسلامية" },
  eid: { c1: "#c8962c", c2: "#7a2e5c", c3: "#fbe8b8", en: "Eid festive", ar: "زينة العيد" },
  winter: { c1: "#7fb2d9", c2: "#2f5a80", c3: "#e8f3fb", en: "Winter crystal", ar: "بلورات الشتاء" },
  spring: { c1: "#e98aa6", c2: "#5e9e4f", c3: "#fde9ef", en: "Spring floral", ar: "زهور الربيع" },
  summer: { c1: "#2fa3c4", c2: "#f2a541", c3: "#e3f6fb", en: "Summer wave", ar: "موج الصيف" },
  autumn: { c1: "#c46a2f", c2: "#8a5a2b", c3: "#f8e6d4", en: "Autumn leaf", ar: "أوراق الخريف" },
  national: { c1: "#ce1126", c2: "#c09300", c3: "#f5f5f5", en: "National ribbon", ar: "شريط وطني" },
  nile: { c1: "#2b6cb0", c2: "#3aa17e", c3: "#e5f0fa", en: "Nile lotus", ar: "لوتس النيل" },
  coptic: { c1: "#8b5a2b", c2: "#b8860b", c3: "#f6ecdc", en: "Coptic geometric", ar: "زخرفة قبطية" },
  love: { c1: "#d6456b", c2: "#f08fa8", c3: "#fde4ea", en: "Hearts", ar: "قلوب" },
  study: { c1: "#4f6bd8", c2: "#7a8fe0", c3: "#e8ecfb", en: "Study", ar: "دراسة" },
  birthday: { c1: "#e0a020", c2: "#d6456b", c3: "#fff2d6", en: "Birthday sparkle", ar: "بريق الميلاد" },
  friday: { c1: "#2e7d6b", c2: "#9bc4b6", c3: "#e6f2ee", en: "Friday accent", ar: "لمسة الجمعة" },
  newyear: { c1: "#c9a227", c2: "#3b3f8f", c3: "#f5efd9", en: "New Year", ar: "العام الجديد" },
};

/** Motif paths for a family at a box of size s centred at (cx,cy). */
export function motif(family: Family, cx: number, cy: number, s: number): { fill: string[]; stroke: string[] } {
  switch (family) {
    case "ramadan": return { fill: [crescentPath(cx - s * 0.15, cy, s * 0.42)], stroke: lanternPaths(cx + s * 0.28, cy - s * 0.45, s * 0.7) };
    case "islamic": case "friday": return { fill: [], stroke: rosette(cx, cy, s * 0.46, family === "friday" ? 6 : 8) };
    case "eid": return { fill: [starPath(cx, cy, 8, s * 0.45, s * 0.22)], stroke: [polygonPath(cx, cy, 8, s * 0.3, Math.PI / 8)] };
    case "winter": return { fill: [], stroke: [snowflakePath(cx, cy, s * 0.45)] };
    case "spring": return { fill: [lotusPath(cx, cy + s * 0.25, s * 0.55, 6)], stroke: [] };
    case "nile": return { fill: [lotusPath(cx, cy + s * 0.15, s * 0.5, 5)], stroke: [wavePath(s, s, s * 0.05, 2, 0, cy + s * 0.3).replace(/^M0/, `M${cx - s / 2}`)] };
    case "summer": return { fill: [], stroke: [0, 1, 2].map((i) => translatePath(wavePath(s, s, s * 0.07, 1.5, i, s * 0.3 + i * s * 0.18), cx - s / 2, cy - s / 2)) };
    case "autumn": return { fill: [leafPath(cx, cy, s * 0.42, 0.6)], stroke: [] };
    case "national": return { fill: [], stroke: [`M${cx - s * 0.45} ${cy + s * 0.2}C${cx - s * 0.15} ${cy - s * 0.4} ${cx + s * 0.15} ${cy + s * 0.4} ${cx + s * 0.45} ${cy - s * 0.2}`] };
    case "coptic": return { fill: [], stroke: [`M${cx} ${cy - s * 0.42}V${cy + s * 0.42}M${cx - s * 0.42} ${cy}H${cx + s * 0.42}`, polygonPath(cx, cy, 4, s * 0.3, Math.PI / 4), ...[0, 1, 2, 3].map((i) => polygonPath(cx + Math.cos(i * Math.PI / 2) * s * 0.42, cy + Math.sin(i * Math.PI / 2) * s * 0.42, 4, s * 0.07, Math.PI / 4))] };
    case "love": return { fill: [heartPath(cx, cy, s * 0.55)], stroke: [] };
    case "study": return { fill: [], stroke: [`M${cx - s * 0.4} ${cy - s * 0.25}L${cx} ${cy - s * 0.1}L${cx + s * 0.4} ${cy - s * 0.25}V${cy + s * 0.3}L${cx} ${cy + s * 0.45}L${cx - s * 0.4} ${cy + s * 0.3}Z M${cx} ${cy - s * 0.1}V${cy + s * 0.45}`] };
    case "birthday": case "newyear": return { fill: [sparklePath(cx, cy, s * 0.4), sparklePath(cx + s * 0.32, cy - s * 0.3, s * 0.14), sparklePath(cx - s * 0.32, cy + s * 0.28, s * 0.1)], stroke: [] };
  }
}

function translatePath(d: string, dx: number, dy: number) {
  return d.replace(/([ML])(-?[\d.]+) (-?[\d.]+)/g, (_, c, x, y) => `${c}${f(+x + dx)} ${f(+y + dy)}`);
}

/** Seamless tile pattern for a family, as an SVG data URI (used as background texture). */
export function tileDataUri(family: Family, color: string, opacity = 0.08, size = 56) {
  const s = size;
  let body = "";
  if (family === "islamic" || family === "ramadan" || family === "eid" || family === "friday") {
    const n = family === "friday" ? 6 : 8;
    for (const [x, y] of [[0, 0], [s, 0], [0, s], [s, s], [s / 2, s / 2]]) body += `<path d="${starPath(x, y, n, s * 0.36, s * 0.2)}"/>`;
    body += `<path d="${polygonPath(s / 2, s / 2, n, s * 0.5, Math.PI / n)}"/>`;
  } else if (family === "winter") {
    body += `<path d="${snowflakePath(s / 2, s / 2, s * 0.22)}"/><path d="${snowflakePath(0, 0, s * 0.12)}"/><path d="${snowflakePath(s, s, s * 0.12)}"/>`;
  } else if (family === "summer" || family === "nile") {
    body += `<path d="${wavePath(s, s, s * 0.08, 1, 0, s * 0.3)}"/><path d="${wavePath(s, s, s * 0.08, 1, 0, s * 0.8)}"/>`;
  } else if (family === "spring" || family === "love") {
    body += `<path d="${lotusPath(s / 2, s * 0.7, s * 0.28, 5)}"/>`;
  } else if (family === "coptic") {
    body += `<path d="${polygonPath(s / 2, s / 2, 4, s * 0.3, Math.PI / 4)}"/><path d="M${s / 2} ${s * 0.3}V${s * 0.7}M${s * 0.3} ${s / 2}H${s * 0.7}"/>`;
  } else {
    body += `<path d="${sparklePath(s / 2, s / 2, s * 0.14)}"/>`;
  }
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${s}" height="${s}" viewBox="0 0 ${s} ${s}"><g fill="none" stroke="${color}" stroke-opacity="${opacity}" stroke-width="1">${body}</g></svg>`;
  return `url("data:image/svg+xml,${encodeURIComponent(svg)}")`;
}
