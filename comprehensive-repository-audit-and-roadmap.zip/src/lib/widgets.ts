// WidgetDefinition catalog (V2-6.3). Shared shape with the native renderer (JSON-schema validated there).
export type Arche =
  | "digital" | "analog" | "flip" | "sunarc" | "world" | "ring" | "list" | "checklist" | "month" | "week" | "heatmap"
  | "timeline" | "hero" | "countdown" | "drop" | "note" | "matrix" | "kanban" | "spark" | "donut" | "radar" | "bars"
  | "battery" | "counter" | "compass" | "download" | "portrait" | "quick" | "mosaic" | "dial" | "tri" | "prayer" | "nextprayer";
export type Form = "1x1" | "2x1" | "2x2" | "4x1" | "4x2" | "4x4";
export const FORMS: Form[] = ["1x1", "2x1", "2x2", "4x1", "4x2", "4x4"];
export type WCat = "clock" | "alarms" | "calendar" | "occasions" | "plan" | "tasks" | "habits" | "focus" | "review" | "media" | "utility" | "companion";

export interface WidgetDef { id: string; en: string; ar: string; cat: WCat; arche: Arche; variant: number; interactive: boolean; forms: Form[] }

export const WCATS: Array<{ id: WCat; en: string; ar: string }> = [
  { id: "clock", en: "Clock", ar: "الساعة" }, { id: "alarms", en: "Alarms", ar: "المنبهات" }, { id: "calendar", en: "Calendar", ar: "التقويم" },
  { id: "occasions", en: "Occasions", ar: "المناسبات" }, { id: "plan", en: "Plan & today", ar: "الخطة واليوم" }, { id: "tasks", en: "Tasks & notes", ar: "المهام والملاحظات" },
  { id: "habits", en: "Habits & health", ar: "العادات والصحة" }, { id: "focus", en: "Focus & study", ar: "التركيز والدراسة" }, { id: "review", en: "Review & stats", ar: "المراجعة والإحصاءات" },
  { id: "media", en: "Media Hub", ar: "مركز الوسائط" }, { id: "utility", en: "Utility", ar: "أدوات" }, { id: "companion", en: "Companion", ar: "الرفيق" },
];

type Row = [string, string, Arche, 0 | 1];
const C: Record<WCat, Row[]> = {
  clock: [["Minimal digital", "رقمية بسيطة", "digital", 0], ["Bold block", "كتلة عريضة", "digital", 0], ["Split flap", "لوحة متقلبة", "flip", 0], ["Flip clock", "ساعة قلّابة", "flip", 0], ["Dot-matrix", "مصفوفة نقطية", "digital", 0], ["Stacked words", "كلمات متراصة", "digital", 0], ["Analog classic", "عقارب كلاسيكية", "analog", 0], ["Analog skeleton", "عقارب هيكلية", "analog", 0], ["Analog luxury", "عقارب فاخرة", "analog", 0], ["Analog minimal", "عقارب بسيطة", "analog", 0], ["Sun-arc clock", "ساعة قوس الشمس", "sunarc", 0], ["Orbit clock", "ساعة المدار", "analog", 0], ["World clock", "ساعة عالمية", "world", 0], ["Dual-time", "توقيت مزدوج", "world", 0], ["Clock + day summary", "ساعة + ملخص اليوم", "digital", 0], ["Bedside clock", "ساعة السرير", "digital", 0]],
  alarms: [["Next alarm pill", "كبسولة المنبه التالي", "countdown", 1], ["Alarm ring-dial", "قرص المنبه", "dial", 1], ["Alarm list + toggles", "قائمة المنبهات", "checklist", 1], ["Alarm timeline strip", "شريط المنبهات الزمني", "timeline", 0], ["Alarm week grid", "شبكة أسبوع المنبهات", "week", 0], ["Countdown to alarm", "عد تنازلي للمنبه", "countdown", 0], ["Sleep-alarm combo", "النوم والمنبه", "dial", 1], ["Snooze tracker", "متتبع الغفوة", "bars", 0]],
  calendar: [["Month compact", "شهر مدمج", "month", 0], ["Month with artwork", "شهر بالزخارف", "month", 0], ["Month heatmap", "خريطة حرارية شهرية", "heatmap", 0], ["Week strip", "شريط الأسبوع", "week", 0], ["Week columns", "أعمدة الأسبوع", "week", 0], ["Agenda list", "قائمة الأجندة", "list", 0], ["Agenda with artwork", "أجندة بالزخارف", "list", 0], ["Year dots", "نقاط السنة", "mosaic", 0], ["Hijri month", "الشهر الهجري", "month", 0], ["Coptic month", "الشهر القبطي", "month", 0], ["Tri-calendar date card", "بطاقة التقاويم الثلاثة", "tri", 0], ["Day ring (24h)", "حلقة اليوم ٢٤ س", "ring", 0], ["Schedule river", "نهر الجدول", "timeline", 0], ["Date flip", "تاريخ قلاب", "flip", 0]],
  occasions: [["Occasion hero", "بطل المناسبة", "hero", 0], ["Occasion countdown ring", "حلقة العد للمناسبة", "ring", 0], ["Upcoming carousel", "المناسبات القادمة", "list", 0], ["Ramadan imsakiya", "إمساكية رمضان", "list", 0], ["Iftar countdown", "العد للإفطار", "countdown", 0], ["Eid greeting card", "بطاقة تهنئة العيد", "hero", 0], ["Season greeting", "تحية الموسم", "hero", 0], ["Nile & Egyptian seasons", "النيل والمواسم المصرية", "hero", 0], ["National-day card", "بطاقة اليوم الوطني", "hero", 0], ["Friday card", "بطاقة الجمعة", "hero", 0], ["Hijri date card", "بطاقة التاريخ الهجري", "tri", 0]],
  plan: [["Current activity", "النشاط الحالي", "timeline", 0], ["Now · Next · Later", "الآن · التالي · لاحقًا", "list", 0], ["Timeline vertical", "خط زمني رأسي", "timeline", 0], ["Timeline horizontal", "خط زمني أفقي", "timeline", 0], ["Free-time gauge", "مقياس الوقت الحر", "dial", 0], ["Day progress ring", "حلقة تقدم اليوم", "ring", 0], ["Daily brief", "موجز اليوم", "list", 0], ["Top priorities", "أهم الأولويات", "checklist", 1], ["Focus window", "نافذة التركيز", "timeline", 0], ["Plan board", "لوحة الخطة", "kanban", 0], ["Yesterday · Today · Tomorrow", "أمس · اليوم · غدًا", "week", 0], ["Schedule health", "صحة الجدول", "ring", 0], ["Routine checklist", "قائمة الروتين", "checklist", 1]],
  tasks: [["Checklist", "قائمة تحقق", "checklist", 1], ["Task rings", "حلقات المهام", "ring", 0], ["Eisenhower matrix", "مصفوفة أيزنهاور", "matrix", 1], ["Kanban strip", "شريط كانبان", "kanban", 0], ["Quick-add bar", "شريط إضافة سريعة", "quick", 1], ["Pinned note paper", "ورقة ملاحظة مثبتة", "note", 0], ["Sticky-note stack", "كومة ملاحظات لاصقة", "note", 0], ["Notes grid", "شبكة الملاحظات", "mosaic", 0], ["Handwritten note", "ملاحظة بخط اليد", "note", 0], ["Checklist cards", "بطاقات تحقق", "checklist", 1], ["Overdue list", "المتأخرات", "list", 0], ["Subtasks tree", "شجرة المهام الفرعية", "list", 1], ["Shopping list", "قائمة التسوق", "checklist", 1], ["Voice-note button", "زر ملاحظة صوتية", "quick", 1], ["Journal prompt", "سؤال اليوميات", "note", 0]],
  habits: [["Habit grid", "شبكة العادات", "heatmap", 1], ["Habit heatmap", "خريطة العادات", "heatmap", 0], ["Streak card", "بطاقة السلسلة", "counter", 0], ["Water drop", "قطرة ماء", "drop", 1], ["Water bottle", "زجاجة ماء", "drop", 1], ["Water cups", "أكواب الماء", "bars", 1], ["Sleep dial", "قرص النوم", "dial", 0], ["Bedtime countdown", "العد لوقت النوم", "countdown", 0], ["Workout today", "تمرين اليوم", "ring", 1], ["Workout week", "تمارين الأسبوع", "bars", 0], ["Medication schedule", "جدول الأدوية", "checklist", 1], ["Mood strip", "شريط المزاج", "mosaic", 1]],
  focus: [["Focus timer ring", "حلقة مؤقت التركيز", "ring", 1], ["Pomodoro cycle", "دورة بومودورو", "dial", 1], ["Study planner", "مخطط الدراسة", "list", 0], ["Exam countdown stack", "عد الامتحانات", "countdown", 0], ["Subject progress", "تقدم المواد", "bars", 0], ["Deep-work block", "فترة عمل عميق", "timeline", 0], ["Break reminder", "تذكير الاستراحة", "countdown", 0], ["Study streak", "سلسلة الدراسة", "counter", 0]],
  review: [["Daily score ring", "حلقة نتيجة اليوم", "ring", 0], ["Weekly radar", "رادار الأسبوع", "radar", 0], ["Yearly mosaic", "فسيفساء السنة", "mosaic", 0], ["Strengths card", "بطاقة نقاط القوة", "bars", 0], ["What you did", "ماذا أنجزت", "list", 0], ["Productivity sparkline", "خط الإنتاجية", "spark", 0], ["Time-budget donut", "دونات ميزانية الوقت", "donut", 0], ["Consistency calendar", "تقويم الاستمرارية", "heatmap", 0], ["Trend arrow", "سهم الاتجاه", "spark", 0], ["Milestone card", "بطاقة الإنجاز", "counter", 0], ["Personal records", "الأرقام الشخصية", "bars", 0]],
  media: [["Active downloads", "التنزيلات النشطة", "download", 1], ["Paste-link tile", "بلاطة لصق الرابط", "quick", 1], ["Download history", "سجل التنزيلات", "list", 0], ["Recent audio", "أحدث الصوتيات", "list", 0], ["Recent video", "أحدث الفيديو", "mosaic", 0], ["Storage usage", "استخدام التخزين", "donut", 0]],
  utility: [["Battery ring", "حلقة البطارية", "battery", 0], ["Battery detail", "تفاصيل البطارية", "battery", 0], ["Quick actions grid", "شبكة الإجراءات السريعة", "quick", 1], ["Stopwatch", "ساعة إيقاف", "digital", 1], ["Timer", "مؤقت", "ring", 1], ["Unit tile", "بلاطة الوحدات", "quick", 0], ["Tasbih counter", "عداد التسبيح", "counter", 1], ["Khatma tracker", "متتبع الختمة", "bars", 1], ["Prayer schedule", "جدول الصلوات", "prayer", 0], ["Qibla compass", "بوصلة القبلة", "compass", 0], ["Prayer times strip", "شريط مواقيت الصلاة", "prayer", 0], ["Next prayer", "الصلاة القادمة", "nextprayer", 0], ["Prayer times (ornate)", "المواقيت بالزخرفة", "prayer", 0], ["Next prayer ring", "حلقة الصلاة القادمة", "nextprayer", 0], ["Fajr & Maghrib card", "بطاقة الفجر والمغرب", "nextprayer", 0], ["Mosque board", "لوحة المسجد", "prayer", 0], ["Adhkar & Tasbih", "الأذكار والتسبيح", "counter", 1], ["Khatma + prayer", "الختمة والصلاة", "bars", 0], ["Countdown", "عد تنازلي", "countdown", 0], ["Anniversary card", "بطاقة الذكرى", "hero", 0], ["Date calculator", "حاسبة التاريخ", "tri", 0], ["QR quick scan", "مسح QR سريع", "quick", 1]],
  companion: [["Companion portrait", "صورة الرفيق", "portrait", 0], ["Companion quick-actions", "إجراءات الرفيق", "quick", 1], ["Companion mood", "مزاج الرفيق", "portrait", 0], ["Companion tip", "نصيحة الرفيق", "portrait", 0]],
};

const slug = (s: string) => s.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
export const WIDGETS: WidgetDef[] = (Object.keys(C) as WCat[]).flatMap((cat) =>
  C[cat].map((r, i) => ({
    id: cat + "-" + slug(r[0]), en: r[0], ar: r[1], cat, arche: r[2], variant: i, interactive: !!r[3],
    forms: r[2] === "matrix" || r[2] === "kanban" || r[2] === "month" ? ["2x2", "4x2", "4x4"] : r[2] === "note" ? ["2x1", "2x2", "4x2", "4x4"] : FORMS,
  }))
);

export type WStyle = "oneui" | "material" | "ios" | "editorial" | "neon" | "paper" | "clay" | "outline" | "amoled" | "seasonal";
export const WSTYLES: Array<{ id: WStyle; en: string; ar: string }> = [
  { id: "oneui", en: "One UI Glass", ar: "زجاج One UI" }, { id: "material", en: "Material You", ar: "Material You" }, { id: "ios", en: "iOS-inspired", ar: "مستوحى من iOS" },
  { id: "editorial", en: "Editorial", ar: "تحريري" }, { id: "neon", en: "Neon", ar: "نيون" }, { id: "paper", en: "Paper", ar: "ورق" },
  { id: "clay", en: "Soft Clay", ar: "صلصال" }, { id: "outline", en: "Minimal Outline", ar: "خطوط بسيطة" }, { id: "amoled", en: "AMOLED", ar: "أموليد" }, { id: "seasonal", en: "Seasonal", ar: "موسمي" },
];

export const WIDGET_FONTS: Record<string, { en: string; ar: string; stack: string }> = {
  sans: { en: "System sans", ar: "خط النظام", stack: `system-ui, "Segoe UI", "Noto Sans Arabic", sans-serif` },
  naskh: { en: "Naskh (serif)", ar: "نسخ", stack: `"Noto Naskh Arabic", "Amiri", "Traditional Arabic", serif` },
  kufi: { en: "Kufi", ar: "كوفي", stack: `"Noto Kufi Arabic", "Reem Kufi", "Segoe UI", sans-serif` },
  cairo: { en: "Cairo", ar: "القاهرة", stack: `"Cairo", "Noto Kufi Arabic", system-ui, sans-serif` },
  rounded: { en: "Rounded", ar: "مستدير", stack: `ui-rounded, "Noto Sans Arabic", system-ui, sans-serif` },
  mono: { en: "Mono numerals", ar: "أرقام ثابتة", stack: `ui-monospace, "Noto Sans Arabic", monospace` },
};
export const formSize = (f: Form): [number, number] => { const [w, h] = f.split("x").map(Number); return [w, h]; };
/** WidgetFormResolver — nearest declared form for a given cell size (mirrors Android 12+ responsive mapping). */
export function resolveForm(def: WidgetDef, w: number, h: number): Form {
  let best = def.forms[0], bestScore = -Infinity;
  for (const f of def.forms) {
    const [fw, fh] = formSize(f);
    if (fw > w || fh > h) continue;
    const s = fw * fh * 10 - (w - fw) - (h - fh);
    if (s > bestScore) { bestScore = s; best = f; }
  }
  return best;
}
