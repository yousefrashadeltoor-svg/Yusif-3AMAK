// Capacitor JS-to-Native bridge (no-op in browser, invokes real Kotlin plugins in Android APK).
export interface DayflowNative {
  scheduleAlarm(opts: { id: string; time: string; date?: string; days: number[]; label: string; soundUri?: string; vibrate: boolean; snooze: number }): Promise<void>;
  cancelAlarm(opts: { id: string }): Promise<void>;
  getDeviceTones(): Promise<{ tones: Array<{ title: string; uri: string; type: string }> }>;
  pinWidget(opts: { designId: string; style: string; w: number; h: number }): Promise<{ pinned: boolean }>;
  openWidgetHub(): Promise<void>;
  startCompanionOverlay(opts: { enabled: boolean; size: number; opacity: number; modelId?: string }): Promise<{ hasPermission: boolean }>;
  requestOverlayPermission(): Promise<void>;
  enqueueDownload(opts: { url: string; name: string; preset?: string }): Promise<void>;
  analyzeLink(opts: { url: string }): Promise<{ json: string }>;
  startDownload(opts: { id: string; url: string; name: string; engines: string[]; format: string; quality: string; saveDir: string; connections: number }): Promise<void>;
  pauseDownload(opts: { id: string }): Promise<void>;
  cancelDownload(opts: { id: string }): Promise<void>;
  updateEngines(): Promise<{ ytdlp: string }>;
  openSniffer(opts: { url: string }): Promise<void>;
  getPendingShare(): Promise<{ text: string }>;
  syncState(opts: { json: string }): Promise<void>;
}

function plugin(): Partial<DayflowNative> | null {
  if (typeof window === "undefined") return null;
  const cap = (window as unknown as { Capacitor?: { isNativePlatform?: () => boolean; Plugins?: { DayflowBridge?: Partial<DayflowNative> } } }).Capacitor;
  if (!cap?.isNativePlatform?.()) return null;
  return cap.Plugins?.DayflowBridge || null;
}

export const isAndroidApk = () => !!plugin();

export const nativeBridge = {
  scheduleAlarm: (opts: Parameters<DayflowNative["scheduleAlarm"]>[0]) => plugin()?.scheduleAlarm?.(opts),
  cancelAlarm: (opts: Parameters<DayflowNative["cancelAlarm"]>[0]) => plugin()?.cancelAlarm?.(opts),
  getDeviceTones: () => plugin()?.getDeviceTones?.(),
  pinWidget: (opts: Parameters<DayflowNative["pinWidget"]>[0]) => plugin()?.pinWidget?.(opts),
  openWidgetHub: () => plugin()?.openWidgetHub?.(),
  startCompanionOverlay: (opts: Parameters<DayflowNative["startCompanionOverlay"]>[0]) => plugin()?.startCompanionOverlay?.(opts),
  requestOverlayPermission: () => plugin()?.requestOverlayPermission?.(),
  enqueueDownload: (opts: Parameters<DayflowNative["enqueueDownload"]>[0]) => plugin()?.enqueueDownload?.(opts),
  analyzeLink: (opts: Parameters<DayflowNative["analyzeLink"]>[0]) => plugin()?.analyzeLink?.(opts),
  startDownload: (opts: Parameters<DayflowNative["startDownload"]>[0]) => plugin()?.startDownload?.(opts),
  pauseDownload: (opts: Parameters<DayflowNative["pauseDownload"]>[0]) => plugin()?.pauseDownload?.(opts),
  cancelDownload: (opts: Parameters<DayflowNative["cancelDownload"]>[0]) => plugin()?.cancelDownload?.(opts),
  updateEngines: () => plugin()?.updateEngines?.(),
  openSniffer: (opts: Parameters<DayflowNative["openSniffer"]>[0]) => plugin()?.openSniffer?.(opts),
  getPendingShare: () => plugin()?.getPendingShare?.(),
  syncState: (json: string) => plugin()?.syncState?.({ json }),
};
