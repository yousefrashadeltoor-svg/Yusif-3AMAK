// Media Hub pure logic (V2-9): URL normalisation & classification, format grouping, queue state machine.
// The extraction engine (yt-dlp/ffmpeg/aria2c) is native-only; this module is engine-agnostic.

export type Site = "youtube" | "vimeo" | "soundcloud" | "instagram" | "x" | "facebook" | "tiktok" | "archive" | "generic";
export interface ParsedUrl { ok: boolean; url: string; host: string; site: Site; kind: "video" | "playlist" | "channel" | "audio" | "image" | "unknown"; id?: string; reason?: string }

const TRACKING = /^(utm_|fbclid|gclid|si$|feature$|igshid|ref_src|mc_)/;

export function normalizeUrl(raw: string): ParsedUrl {
  const text = raw.trim();
  const m = text.match(/https?:\/\/[^\s<>"']+/i) || text.match(/(?:www\.)?[a-z0-9-]+\.[a-z]{2,}\/[^\s<>"']*/i);
  if (!m) return { ok: false, url: "", host: "", site: "generic", kind: "unknown", reason: "no-link" };
  let u: URL;
  try { u = new URL(m[0].startsWith("http") ? m[0] : "https://" + m[0]); } catch { return { ok: false, url: "", host: "", site: "generic", kind: "unknown", reason: "invalid" }; }
  if (u.protocol !== "https:" && u.protocol !== "http:") return { ok: false, url: "", host: "", site: "generic", kind: "unknown", reason: "scheme" };
  for (const k of [...u.searchParams.keys()]) if (TRACKING.test(k)) u.searchParams.delete(k);
  u.hash = u.hash.startsWith("#t=") ? u.hash : "";
  const host = u.hostname.replace(/^(www\.|m\.|music\.)/, "");
  let site: Site = "generic", kind: ParsedUrl["kind"] = "unknown", id: string | undefined;
  if (/(^|\.)youtube\.com$|^youtu\.be$/.test(host)) {
    site = "youtube";
    if (host === "youtu.be") { id = u.pathname.slice(1); kind = "video"; const ts = u.searchParams.get("t"); u = new URL("https://www.youtube.com/watch?v=" + id + (ts ? "&t=" + encodeURIComponent(ts) : "")); }
    else if (u.searchParams.get("list") && !u.searchParams.get("v")) { kind = "playlist"; id = u.searchParams.get("list")!; }
    else if (u.searchParams.get("v")) { kind = u.searchParams.get("list") ? "playlist" : "video"; id = u.searchParams.get("v")!; }
    else if (/^\/shorts\//.test(u.pathname)) { kind = "video"; id = u.pathname.split("/")[2]; }
    else if (/^\/(@|channel\/|c\/)/.test(u.pathname)) kind = "channel";
  } else if (/vimeo\.com$/.test(host)) { site = "vimeo"; kind = /\/showcase\//.test(u.pathname) ? "playlist" : "video"; id = u.pathname.split("/").filter(Boolean).pop(); }
  else if (/soundcloud\.com$/.test(host)) { site = "soundcloud"; kind = /\/sets\//.test(u.pathname) ? "playlist" : "audio"; }
  else if (/instagram\.com$/.test(host)) { site = "instagram"; kind = /\/p\//.test(u.pathname) ? "image" : "video"; }
  else if (/(^|\.)x\.com$|twitter\.com$/.test(host)) { site = "x"; kind = "video"; }
  else if (/facebook\.com$|fb\.watch$/.test(host)) { site = "facebook"; kind = "video"; }
  else if (/tiktok\.com$/.test(host)) { site = "tiktok"; kind = "video"; }
  else if (/archive\.org$/.test(host)) { site = "archive"; kind = "video"; }
  else if (/\.(mp4|webm|mkv|mov)$/i.test(u.pathname)) kind = "video";
  else if (/\.(mp3|ogg|opus|m4a|flac|wav)$/i.test(u.pathname)) kind = "audio";
  else if (/\.(jpe?g|png|webp|gif)$/i.test(u.pathname)) kind = "image";
  return { ok: true, url: u.toString(), host, site, kind, id };
}

export interface YtFormat { format_id: string; ext: string; vcodec?: string; acodec?: string; height?: number; fps?: number; abr?: number; tbr?: number; filesize?: number; filesize_approx?: number; dynamic_range?: string }
export interface Preset { id: string; label: string; height?: number; containers: string[]; fps?: number; hdr?: boolean; size?: number; formatIds: string[] }

const est = (f: YtFormat, dur: number) => f.filesize ?? f.filesize_approx ?? (f.tbr ? (f.tbr * 1000 * dur) / 8 : 0);

/** Groups a raw yt-dlp format list into user-facing presets (never a raw list). */
export function groupFormats(formats: YtFormat[], duration: number) {
  const video = formats.filter((f) => f.vcodec && f.vcodec !== "none");
  const audio = formats.filter((f) => (!f.vcodec || f.vcodec === "none") && f.acodec && f.acodec !== "none");
  const bestAudio = [...audio].sort((a, b) => (b.abr ?? 0) - (a.abr ?? 0))[0];
  const heights = [2160, 1440, 1080, 720, 480, 360];
  const label: Record<number, string> = { 2160: "4K", 1440: "1440p", 1080: "1080p", 720: "720p", 480: "480p", 360: "360p" };
  const presets: Preset[] = [];
  for (const h of heights) {
    const at = video.filter((f) => f.height === h);
    if (!at.length) continue;
    const top = [...at].sort((a, b) => (b.tbr ?? 0) - (a.tbr ?? 0))[0];
    const containers = [...new Set(at.map((f) => (f.vcodec?.startsWith("avc") ? "MP4 H.264" : f.vcodec?.startsWith("hev") || f.vcodec?.startsWith("hvc") ? "MP4 HEVC" : f.vcodec?.startsWith("av01") ? "WebM AV1" : f.vcodec?.startsWith("vp9") || f.vcodec?.startsWith("vp09") ? "WebM VP9" : f.ext.toUpperCase())))];
    presets.push({ id: "v" + h, label: label[h], height: h, containers, fps: Math.max(...at.map((f) => f.fps ?? 30)), hdr: at.some((f) => f.dynamic_range && f.dynamic_range !== "SDR"), size: est(top, duration) + (bestAudio ? est(bestAudio, duration) : 0), formatIds: [top.format_id, bestAudio?.format_id].filter(Boolean) as string[] });
  }
  if (presets.length) {
    presets.unshift({ ...presets[0], id: "best", label: "Best" });
    const last = presets[presets.length - 1];
    presets.push({ ...last, id: "small", label: "Smallest" });
  }
  const audioOut = [
    ["mp3-320", "MP3 320"], ["mp3-192", "MP3 192"], ["mp3-128", "MP3 128"], ["m4a", "M4A / AAC"], ["opus", "Opus"], ["ogg", "OGG"], ["flac", "FLAC"], ["wav", "WAV"],
  ].map(([id, l]) => {
    const kbps = id.startsWith("mp3-") ? +id.split("-")[1] : id === "flac" ? 900 : id === "wav" ? 1411 : bestAudio?.abr ?? 128;
    return { id, label: l, size: (kbps * 1000 * duration) / 8, copy: (id === "m4a" && bestAudio?.ext === "m4a") || (id === "opus" && bestAudio?.acodec === "opus") };
  });
  return { presets, audio: audioOut, raw: formats.length };
}

export type DlState = "queued" | "fetching" | "downloading" | "paused" | "post" | "completed" | "failed" | "cancelled";
export type DlEvent = "start" | "info" | "progress" | "pause" | "resume" | "postprocess" | "done" | "error" | "cancel" | "retry";
const T: Record<DlState, Partial<Record<DlEvent, DlState>>> = {
  queued: { start: "fetching", cancel: "cancelled", pause: "paused" },
  fetching: { info: "downloading", error: "failed", cancel: "cancelled", pause: "paused" },
  downloading: { progress: "downloading", pause: "paused", postprocess: "post", done: "completed", error: "failed", cancel: "cancelled" },
  paused: { resume: "queued", cancel: "cancelled" },
  post: { done: "completed", error: "failed", cancel: "cancelled" },
  completed: {}, cancelled: { retry: "queued" }, failed: { retry: "queued", cancel: "cancelled" },
};
/** Idempotent transition: invalid events leave state unchanged. */
export const transition = (s: DlState, e: DlEvent): DlState => T[s][e] ?? s;

export function sanitizeFilename(name: string) {
  return name.replace(/[\u0000-\u001f\u007f<>:"/\\|?*\u202a-\u202e\u2066-\u2069]/g, "").replace(/\s+/g, " ").trim().slice(0, 150) || "download";
}

export const fmtBytes = (b: number) => (b <= 0 ? "—" : b < 1e6 ? (b / 1e3).toFixed(0) + " KB" : b < 1e9 ? (b / 1e6).toFixed(1) + " MB" : (b / 1e9).toFixed(2) + " GB");

/** Anonymised fixture shaped like real yt-dlp --dump-single-json output (used only for the format-grouping demo). */
export const FIXTURE = {
  title: "Sample fixture — public-domain test clip", uploader: "Fixture", duration: 596,
  formats: [
    { format_id: "140", ext: "m4a", acodec: "mp4a.40.2", vcodec: "none", abr: 129, filesize: 9_640_000 },
    { format_id: "251", ext: "webm", acodec: "opus", vcodec: "none", abr: 140, filesize: 10_100_000 },
    { format_id: "137", ext: "mp4", vcodec: "avc1.640028", height: 1080, fps: 30, tbr: 4400 },
    { format_id: "248", ext: "webm", vcodec: "vp9", height: 1080, fps: 30, tbr: 2600 },
    { format_id: "399", ext: "mp4", vcodec: "av01.0.08M.08", height: 1080, fps: 30, tbr: 2100 },
    { format_id: "136", ext: "mp4", vcodec: "avc1.4d401f", height: 720, fps: 30, tbr: 2300 },
    { format_id: "247", ext: "webm", vcodec: "vp9", height: 720, fps: 30, tbr: 1500 },
    { format_id: "135", ext: "mp4", vcodec: "avc1.4d401e", height: 480, fps: 30, tbr: 1100 },
    { format_id: "134", ext: "mp4", vcodec: "avc1.4d401e", height: 360, fps: 30, tbr: 650 },
  ] as YtFormat[],
};

export interface Preview { title: string; author?: string; thumb?: string; provider: string; kind: ParsedUrl["kind"]; duration?: number; url: string; description?: string; direct?: { type: string; size: number } | null }
const TIMEOUT = 12000;
const withTimeout = (ms: number) => { const c = new AbortController(); const t = setTimeout(() => c.abort(), ms); return { signal: c.signal, clear: () => clearTimeout(t) }; };

/** Real preview. Uses the provider's public oEmbed endpoint (no key, no scraping of protected pages). */
export async function fetchPreview(raw: string): Promise<Preview> {
  const p = normalizeUrl(raw);
  if (!p.ok) throw new Error("invalid");
  const target = encodeURIComponent(p.url);
  const tryJson = async (u: string) => { const { signal, clear } = withTimeout(TIMEOUT); try { const r = await fetch(u, { signal, mode: "cors" }); if (!r.ok) throw new Error("HTTP " + r.status); return await r.json(); } finally { clear(); } };
  let j: Record<string, any> | null = null;
  let provider = p.host;
  try {
    if (p.site === "youtube") { j = await tryJson(`https://www.youtube.com/oembed?format=json&url=${target}`); provider = "YouTube"; }
    else if (p.site === "vimeo") { j = await tryJson(`https://vimeo.com/api/oembed.json?url=${target}`); provider = "Vimeo"; }
    else if (p.site === "soundcloud") { j = await tryJson(`https://soundcloud.com/oembed?format=json&url=${target}`); provider = "SoundCloud"; }
    else if (p.site === "tiktok") { j = await tryJson(`https://www.tiktok.com/oembed?url=${target}`); provider = "TikTok"; }
    else { j = await tryJson(`https://noembed.com/embed?url=${target}`); provider = (j?.provider_name as string) || p.host; }
  } catch {
    j = null;
    // second public oEmbed relay (no key, CORS-enabled) before giving up
    try { const { signal, clear } = withTimeout(TIMEOUT); const r = await fetch(`https://noembed.com/embed?url=${target}`, { signal }); clear(); if (r.ok) { const k = await r.json(); if (k && !k.error) { j = k; provider = k.provider_name || p.host; } } } catch { /* still nothing */ }
  }
  // direct media URL: real HEAD to learn type + size where the server allows CORS
  let direct: Preview["direct"] = null;
  if (p.site === "generic" || /\.(mp4|webm|mp3|ogg|opus|m4a|flac|wav|jpe?g|png|webp)$/i.test(p.url)) {
    try {
      const { signal, clear } = withTimeout(8000);
      const r = await fetch(p.url, { method: "HEAD", signal });
      clear();
      if (r.ok) direct = { type: r.headers.get("content-type") || "unknown", size: +(r.headers.get("content-length") || 0) };
    } catch { direct = null; }
  }
  if (!j && !direct) {
    const reason = p.site === "youtube" ? "youtube" : p.site === "generic" ? "blocked" : p.site;
    throw new Error(reason);
  }
  return {
    title: j?.title || p.url.split("/").pop() || p.host,
    author: j?.author_name || j?.account_name,
    thumb: j?.thumbnail_url,
    provider: (j && j.error) ? p.host : provider,
    kind: p.kind, duration: j?.duration ? Math.round(j.duration) : undefined,
    url: p.url, description: j?.description, direct,
  };
}

/** Real direct download with byte progress (only works for CORS-enabled direct files). */
export async function downloadDirect(url: string, cb: { onProgress: (pct: number, bytes: number) => void; signal: AbortSignal }): Promise<Blob> {
  const r = await fetch(url, { signal: cb.signal });
  if (!r.ok) throw new Error("HTTP " + r.status);
  const total = +(r.headers.get("content-length") || 0);
  const reader = r.body?.getReader();
  if (!reader) { const b = await r.blob(); cb.onProgress(100, b.size); return b; }
  const chunks: Uint8Array[] = []; let got = 0; let last = 0;
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    chunks.push(value); got += value.length;
    const now = performance.now();
    if (now - last > 90) { last = now; cb.onProgress(total ? Math.min(99, Math.round((got / total) * 100)) : 0, got); }
  }
  cb.onProgress(100, got);
  return new Blob(chunks as BlobPart[], { type: r.headers.get("content-type") || "application/octet-stream" });
}

export const SAMPLE_CC0 = "https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4";
