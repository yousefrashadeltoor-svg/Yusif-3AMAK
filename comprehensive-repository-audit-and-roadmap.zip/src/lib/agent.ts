import { useStore, applyActionsDetailed } from "./store";
import { fromKey, dayKey } from "./calendar";
import { futureAt, isValidTime } from "./temporal";
export interface AgentAction { intent: string; [key: string]: unknown }
export interface ActionProposal { action: AgentAction; title: string; detail: string }
const text = (x: unknown, max = 800) => typeof x === "string" && x.trim().length > 0 && x.length <= max;
const time = (x: unknown) => typeof x === "string" && /^([01]\d|2[0-3]):[0-5]\d$/.test(x);
const days = (x: unknown): number[] | null => { const a = Array.isArray(x) ? x : typeof x === "string" && x.trim() ? x.split(",").map(Number) : x === "" ? [] : null; return a && a.length <= 7 && a.every((n) => Number.isInteger(n) && n >= 0 && n <= 6) ? [...new Set(a)] : null; };
const date = (x: unknown) => typeof x === "string" && /^\d{4}-\d{2}-\d{2}$/.test(x) && Number.isFinite(+fromKey(x)) && dayKey(fromKey(x)) === x;
const routes = ["today", "calendar", "alarms", "tools", "me", "ai", "downloads"];
export function validateAction(a: AgentAction): ActionProposal | null {
  const s = useStore.getState();
  const labels: Record<string, string> = { addAlarm: "حفظ منبّه", addTask: "إضافة مهمة", addHabit: "إضافة عادة", addNote: "إضافة ملاحظة", addWater: "تسجيل مياه", toggleTask: "تحديث المهمة", toggleAlarm: "تفعيل / إيقاف منبّه", updateNote: "تعديل ملاحظة", logHabit: "تسجيل العادة", setTheme: "تغيير الثيم", setClock: "تغيير نظام الساعة", open: "فتح شاشة" };
  let ok = false, detail = "";
  switch (a.intent) {
    case "addAlarm": ok = time(a.time) && days(a.days) !== null && (date(a.date) ? futureAt(a.date as string, a.time as string) : !!days(a.days)?.length); detail = `${a.label || "منبّه"} · ${a.date || String(a.days)} · ${a.time}`; break;
    case "addTask": ok = text(a.title) && (a.date === undefined || date(a.date)) && (a.time === undefined || (isValidTime(a.time) && futureAt(typeof a.date === "string" ? a.date : dayKey(new Date()), a.time as string))); detail = `${a.title} · ${a.date || dayKey(new Date())}${a.time ? ` · ${a.time}` : ""}`; break;
    case "addHabit": ok = text(a.name, 150) && !!days(a.days)?.length; detail = `${a.name} · ${String(a.days)}`; break;
    case "addNote": ok = text(a.text, 10000); detail = String(a.text).slice(0, 150); break;
    case "addWater": ok = Number.isFinite(Number(a.ml)) && Number(a.ml) > 0 && Number(a.ml) <= 5000; detail = `${a.ml} ml`; break;
    case "toggleTask": ok = s.tasks.some((t) => t.id === a.id) && typeof a.done === "boolean"; detail = s.tasks.find((t) => t.id === a.id)?.title || ""; break;
    case "toggleAlarm": ok = s.alarms.some((t) => t.id === a.id) && typeof a.enabled === "boolean"; detail = s.alarms.find((t) => t.id === a.id)?.label || ""; break;
    case "updateNote": ok = s.notes.some((n) => n.id === a.id) && text(a.text, 10000); detail = String(a.text).slice(0, 150); break;
    case "logHabit": ok = s.habits.some((h) => h.id === a.id) && date(a.date) && typeof a.done === "boolean"; detail = s.habits.find((h) => h.id === a.id)?.en || ""; break;
    case "setTheme": ok = typeof a.id === "string" && /^[a-z0-9-]+$/.test(a.id); detail = String(a.id); break;
    case "setClock": ok = typeof a.hour12 === "boolean"; detail = a.hour12 ? "12 ساعة" : "24 ساعة"; break;
    case "open": ok = routes.includes(String(a.tab)) && (a.sub === undefined || typeof a.sub === "string" && /^[a-z-]+$/.test(a.sub)); detail = `${a.tab}${a.sub ? ` / ${a.sub}` : ""}`; break;
  }
  return ok ? { action: a, title: labels[a.intent] || a.intent, detail } : null;
}
export function executeProposal(proposal: ActionProposal, go: (tab: string, sub?: string) => void) {
  const a = proposal.action, s = useStore.getState();
  if (!validateAction(a)) throw new Error("Action is no longer valid");
  switch (a.intent) {
    case "addAlarm": case "addTask": case "addHabit": case "addNote": case "addWater": {
      const action = Object.fromEntries(Object.entries(a).map(([k, v]) => [k, String(v)])) as { intent: string; [key: string]: string };
      const outcome = applyActionsDetailed([action], go);
      if (outcome.issues.length) throw new Error(outcome.issues.join(" "));
      break;
    }
    case "toggleTask": s.updateTask(String(a.id), { done: Boolean(a.done), status: a.done ? "done" : "todo" }); break;
    case "toggleAlarm": s.updateAlarm(String(a.id), { enabled: Boolean(a.enabled) }); break;
    case "updateNote": s.set({ notes: s.notes.map((n) => n.id === a.id ? { ...n, text: String(a.text) } : n) }); break;
    case "logHabit": s.updateHabit(String(a.id), { log: s.habits.find((h) => h.id === a.id)!.log.filter((d) => d !== a.date).concat(a.done ? [String(a.date)] : []) }); break;
    case "setTheme": s.set({ themeId: String(a.id), autoTimeTheme: false }); break;
    case "setClock": s.set({ hour12: Boolean(a.hour12) }); break;
    case "open": go(String(a.tab), typeof a.sub === "string" ? a.sub : undefined); break;
  }
}
