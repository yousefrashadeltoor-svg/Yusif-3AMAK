// Private context is built on explicit consent; credentials are never serialised.
import { useStore } from "./store";
import { coptic, dayKey, hijri, resolveDecor } from "./calendar";
import { prayerTimes, CITIES } from "./prayer";
import type { SourceRef } from "./ai";

export function buildAppContext() {
  const s = useStore.getState(), date = new Date();
  const sections: Record<string, unknown> = {
    date: { local: date.toString(), iso: date.toISOString(), timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone, gregorian: dayKey(date), hijri: hijri(date), coptic: coptic(date) },
    tasks: s.tasks, habits: s.habits, alarms: s.alarms, notes: s.notes, water: s.water,
    journal: s.journal, medication: s.meds, countdowns: s.countdowns, personalDays: s.userDays,
    prayerTimes: prayerTimes(CITIES[s.cityIndex] || CITIES[0]),
    settings: { theme: s.themeId, autoTimeTheme: s.autoTimeTheme, periodThemes: s.periodThemes, language: s.lang, hour12: s.hour12, waterGoal: s.waterGoal, reviewTone: s.reviewTone, spiritual: s.spiritual, decoration: s.intensity, decorLayer: s.decorLayer, widgetFont: s.widgetFont, companion: s.companion },
    widgets: s.placed, currentDecor: resolveDecor(date, s.userDays), tasbih: s.tasbih, khatma: s.khatma,
  };
  let remaining = 26000; const compact: Record<string, unknown> = {}, limited: string[] = [];
  for (const [k, value] of Object.entries(sections)) {
    const encoded = JSON.stringify(value);
    if (encoded.length <= remaining) { compact[k] = value; remaining -= encoded.length; }
    else if (Array.isArray(value)) {
      const out: unknown[] = [];
      for (const v of value) { const cost = JSON.stringify(v).length; if (cost > remaining) break; out.push(v); remaining -= cost; }
      compact[k] = { items: out, total: value.length, included: out.length }; limited.push(k);
    } else { compact[k] = { available: true, omittedToFitBudget: true }; limited.push(k); }
  }
  compact.contextLimits = { limitedSections: limited, note: "Only included records are visible. Unlogged focus, sleep and background native execution are unknown." };
  const sources: SourceRef[] = [{ kind: "app", title: "DAYFLOW · التاريخ والإعدادات", origin: "available" },
    ...["tasks", "habits", "alarms", "notes", "water", "journal", "medication"].map((k) => ({ kind: "app" as const, title: `DAYFLOW · ${k}`, origin: "available" as const }))];
  return { json: JSON.stringify(compact), sources };
}
