// DAYFLOW domain core — three calendars, occasions, and the DecorResolver.
// Pure TypeScript, deterministic, no network. Hijri uses Intl "islamic-umalqura",
// Coptic uses Intl "coptic". Orthodox Easter uses the Meeus Julian algorithm.

export type Family =
  | "ramadan" | "islamic" | "eid" | "winter" | "spring" | "summer" | "autumn"
  | "national" | "nile" | "coptic" | "love" | "study" | "birthday" | "friday" | "newyear";

export interface CalParts { y: number; m: number; d: number }

const cache = new Map<string, CalParts>();
function parts(date: Date, cal: "islamic-umalqura" | "coptic"): CalParts {
  const key = cal + date.getFullYear() + "-" + date.getMonth() + "-" + date.getDate();
  const hit = cache.get(key);
  if (hit) return hit;
  let res: CalParts = { y: 0, m: 0, d: 0 };
  try {
    const f = new Intl.DateTimeFormat("en-u-ca-" + cal, { day: "numeric", month: "numeric", year: "numeric", timeZone: "UTC" });
    const p = f.formatToParts(new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate(), 12)));
    const get = (t: string) => parseInt(p.find((x) => x.type === t)?.value || "0", 10);
    res = { y: get("year") || parseInt(p.find((x) => (x.type as string) === "relatedYear")?.value || "0", 10), m: get("month"), d: get("day") };
  } catch { /* Intl calendar unsupported: leave zeros, UI falls back gracefully */ }
  cache.set(key, res);
  return res;
}
export const hijri = (d: Date) => parts(d, "islamic-umalqura");
export const coptic = (d: Date) => parts(d, "coptic");

export const HIJRI_MONTHS = {
  en: ["Muharram", "Safar", "Rabi' I", "Rabi' II", "Jumada I", "Jumada II", "Rajab", "Sha'ban", "Ramadan", "Shawwal", "Dhu al-Qi'dah", "Dhu al-Hijjah"],
  ar: ["محرم", "صفر", "ربيع الأول", "ربيع الآخر", "جمادى الأولى", "جمادى الآخرة", "رجب", "شعبان", "رمضان", "شوال", "ذو القعدة", "ذو الحجة"],
};
export const COPTIC_MONTHS = {
  en: ["Thout", "Paopi", "Hathor", "Koiak", "Tobi", "Meshir", "Paremhat", "Parmouti", "Pashons", "Paoni", "Epip", "Mesori", "Nasie"],
  ar: ["توت", "بابه", "هاتور", "كيهك", "طوبة", "أمشير", "برمهات", "برمودة", "بشنس", "بؤونة", "أبيب", "مسرى", "نسيء"],
};

export function orthodoxEaster(year: number): Date {
  const a = year % 4, b = year % 7, c = year % 19;
  const d = (19 * c + 15) % 30;
  const e = (2 * a + 4 * b - d + 34) % 7;
  const month = Math.floor((d + e + 114) / 31);
  const day = ((d + e + 114) % 31) + 1;
  const julian = new Date(year, month - 1, day);
  julian.setDate(julian.getDate() + 13); // Julian→Gregorian offset valid 1900–2099
  return julian;
}

export interface Occasion {
  id: string; en: string; ar: string; family: Family; priority: number;
  kind: "islamic" | "national" | "coptic" | "civil" | "personal";
  phase?: string; strength?: number; // 0..1 escalation
}

const sameDay = (a: Date, b: Date) => a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate();
export const dayKey = (d: Date) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
export const fromKey = (k: string) => { const [y, m, d] = k.split("-").map(Number); return new Date(y, m - 1, d); };

const FIXED: Array<[number, number, Omit<Occasion, "priority"> & { priority?: number }]> = [
  [1, 1, { id: "newyear", en: "New Year", ar: "رأس السنة الميلادية", family: "newyear", kind: "civil" }],
  [1, 7, { id: "coptic-christmas", en: "Coptic Christmas", ar: "عيد الميلاد المجيد", family: "coptic", kind: "coptic" }],
  [1, 19, { id: "epiphany", en: "Epiphany (Theophany)", ar: "عيد الغطاس", family: "coptic", kind: "coptic" }],
  [1, 25, { id: "jan25", en: "Revolution of 25 January", ar: "ثورة ٢٥ يناير", family: "national", kind: "national" }],
  [2, 14, { id: "valentine", en: "Valentine's Day", ar: "عيد الحب", family: "love", kind: "civil", priority: 30 }],
  [3, 21, { id: "mothers", en: "Mother's Day", ar: "عيد الأم", family: "love", kind: "civil" }],
  [4, 25, { id: "sinai", en: "Sinai Liberation Day", ar: "عيد تحرير سيناء", family: "national", kind: "national" }],
  [5, 1, { id: "labour", en: "Labour Day", ar: "عيد العمال", family: "national", kind: "civil", priority: 40 }],
  [6, 30, { id: "jun30", en: "June 30 Revolution", ar: "ثورة ٣٠ يونيو", family: "national", kind: "national" }],
  [7, 23, { id: "jul23", en: "July 23 Revolution", ar: "ثورة ٢٣ يوليو", family: "national", kind: "national" }],
  [8, 15, { id: "wafaa", en: "Wafaa El-Nil", ar: "عيد وفاء النيل", family: "nile", kind: "national" }],
  [9, 11, { id: "nayrouz", en: "Nayrouz (Coptic New Year)", ar: "عيد النيروز", family: "coptic", kind: "coptic" }],
  [9, 27, { id: "cross", en: "Feast of the Cross", ar: "عيد الصليب", family: "coptic", kind: "coptic", priority: 40 }],
];

const HIJRI_OCC: Array<[number, number, number, Omit<Occasion, "priority"> & { priority?: number }]> = [
  // month, startDay, length
  [1, 1, 1, { id: "hijri-newyear", en: "Islamic New Year", ar: "رأس السنة الهجرية", family: "islamic", kind: "islamic" }],
  [3, 12, 1, { id: "mawlid", en: "Mawlid an-Nabi", ar: "المولد النبوي الشريف", family: "islamic", kind: "islamic" }],
  [7, 27, 1, { id: "isra", en: "Isra and Mi'raj", ar: "الإسراء والمعراج", family: "islamic", kind: "islamic" }],
  [8, 15, 1, { id: "midshaban", en: "Mid-Sha'ban", ar: "ليلة النصف من شعبان", family: "islamic", kind: "islamic" }],
  [9, 27, 1, { id: "qadr", en: "Laylat al-Qadr (27th night)", ar: "ليلة القدر (ليلة ٢٧)", family: "ramadan", kind: "islamic", priority: 95 }],
  [10, 1, 3, { id: "eid-fitr", en: "Eid al-Fitr", ar: "عيد الفطر المبارك", family: "eid", kind: "islamic", priority: 100 }],
  [12, 9, 1, { id: "arafah", en: "Day of Arafah", ar: "يوم عرفة", family: "islamic", kind: "islamic", priority: 95 }],
  [12, 10, 4, { id: "eid-adha", en: "Eid al-Adha", ar: "عيد الأضحى المبارك", family: "eid", kind: "islamic", priority: 100 }],
];

export function occasionsOn(date: Date): Occasion[] {
  const out: Occasion[] = [];
  const m = date.getMonth() + 1, d = date.getDate();
  for (const [fm, fd, o] of FIXED) if (fm === m && fd === d) out.push({ priority: 70, ...o });
  // October Victory escalation 6 → 24 October (Suez popular resistance day)
  if (m === 10 && d >= 6 && d <= 24) {
    const strength = d === 6 ? 1 : d === 24 ? 0.7 : Math.max(0.25, 1 - (d - 6) / 18);
    out.push({ id: "october", en: d === 6 ? "October Victory" : d === 24 ? "Suez National Day" : "October Victory season", ar: d === 6 ? "انتصارات أكتوبر" : d === 24 ? "العيد القومي للسويس" : "موسم انتصارات أكتوبر", family: "national", kind: "national", priority: d === 6 ? 90 : 45, strength });
  }
  const h = hijri(date);
  if (h.m) {
    if (h.m === 9) {
      const phase = h.d <= 10 ? "early" : h.d <= 20 ? "middle" : "last-ten";
      out.push({ id: "ramadan", en: phase === "last-ten" ? "Ramadan · Last ten nights" : `Ramadan · Day ${h.d}`, ar: phase === "last-ten" ? "رمضان · العشر الأواخر" : `رمضان · اليوم ${h.d}`, family: "ramadan", kind: "islamic", priority: 85, phase, strength: phase === "early" ? 0.55 : phase === "middle" ? 0.75 : 1 });
    }
    for (const [hm, hd, len, o] of HIJRI_OCC) if (h.m === hm && h.d >= hd && h.d < hd + len) out.push({ priority: 80, ...o });
  }
  const easter = orthodoxEaster(date.getFullYear());
  if (sameDay(easter, date)) out.push({ id: "easter", en: "Easter", ar: "عيد القيامة المجيد", family: "coptic", kind: "coptic", priority: 75 });
  const sham = new Date(easter); sham.setDate(sham.getDate() + 1);
  if (sameDay(sham, date)) out.push({ id: "sham", en: "Sham El-Nessim", ar: "شم النسيم", family: "spring", kind: "national", priority: 85 });
  return out.sort((a, b) => b.priority - a.priority);
}

export function climateSeason(date: Date): { family: Family; en: string; ar: string } {
  const m = date.getMonth() + 1;
  if (m === 12 || m <= 2) return { family: "winter", en: "Winter", ar: "الشتاء" };
  if (m <= 5) return { family: "spring", en: "Spring", ar: "الربيع" };
  if (m <= 8) return { family: "summer", en: "Summer", ar: "الصيف" };
  return { family: "autumn", en: "Autumn", ar: "الخريف" };
}

export interface UserDay { id: string; date: string /* MM-DD */; en: string; ar: string; kind: "birthday" | "anniversary" | "custom"; family: Family }
export interface DecorLayer { source: "occasion" | "season" | "weekday" | "user" | "climate"; family: Family; en: string; ar: string; strength: number }
export interface DecorStack { layers: DecorLayer[]; primary: Family; occasions: Occasion[] }

/** DecorResolver: occasion → season → weekday accent → user day → climate season, with a hard layer budget. */
export function resolveDecor(date: Date, userDays: UserDay[] = [], budget = 3, examSeason = false): DecorStack {
  const occ = occasionsOn(date);
  const layers: DecorLayer[] = [];
  for (const o of occ) layers.push({ source: "occasion", family: o.family, en: o.en, ar: o.ar, strength: o.strength ?? 1 });
  const m = date.getMonth() + 1;
  if (examSeason && (m === 1 || m === 5 || m === 6)) layers.push({ source: "season", family: "study", en: "Exam season", ar: "موسم الامتحانات", strength: 0.5 });
  if (m === 9 && date.getDate() >= 15 || m === 10 && date.getDate() <= 5) layers.push({ source: "season", family: "study", en: "Back to school", ar: "العودة للمدارس", strength: 0.4 });
  if (date.getDay() === 5) layers.push({ source: "weekday", family: "friday", en: "Friday", ar: "الجمعة", strength: 0.35 });
  const md = dayKey(date).slice(5);
  for (const u of userDays) if (u.date === md) layers.push({ source: "user", family: u.family, en: u.en, ar: u.ar, strength: 0.9 });
  const c = climateSeason(date);
  layers.push({ source: "climate", family: c.family, en: c.en, ar: c.ar, strength: 0.3 });
  // de-duplicate families, keep order of priority, respect budget
  const seen = new Set<Family>();
  const final = layers.filter((l) => (seen.has(l.family) ? false : (seen.add(l.family), true))).slice(0, budget);
  return { layers: final, primary: final[0].family, occasions: occ };
}

export function upcomingOccasions(from: Date, count = 8, horizon = 400): Array<{ date: Date; o: Occasion }> {
  const out: Array<{ date: Date; o: Occasion }> = [];
  const seen = new Set<string>();
  for (let i = 0; i < horizon && out.length < count; i++) {
    const d = new Date(from.getFullYear(), from.getMonth(), from.getDate() + i);
    for (const o of occasionsOn(d)) {
      const key = o.id === "ramadan" || o.id === "october" ? o.id : o.id + d.getFullYear();
      if (seen.has(key)) continue;
      seen.add(key);
      out.push({ date: d, o });
    }
  }
  return out;
}
