// Theme Packs (V2-5). A pack = palette + material + shape + type + motion + texture + ornament affinity.
import type { Family } from "./calendar";

export type Material = "paper" | "glass" | "matte" | "glossy" | "clay" | "flat" | "outlined" | "blueprint" | "neon";
export type Shape = "round" | "squircle" | "chamfer" | "sharp";
export type Font = "sans" | "serif" | "mono" | "rounded" | "condensed";
export type Motion = "calm" | "springy" | "snappy" | "none";
export type Texture = "none" | "grain" | "grid" | "dots" | "pattern" | "lines" | "mesh";
export type Category = "light" | "dark" | "egypt" | "islamic" | "nature" | "glass" | "tech" | "warm" | "playful" | "custom";

export interface ThemePack {
  id: string; en: string; ar: string; cat: Category; mode: "light" | "dark";
  bg: string; surface: string; text: string; accent: string; accent2: string;
  material: Material; shape: Shape; font: Font; motion: Motion; texture: Texture; ornament: Family;
  version: number; custom?: boolean;
}

type Row = [string, string, Category, "l" | "d", string, string, string, string, string, Material, Shape, Font, Motion, Texture, Family];
const R: Row[] = [
  ["Paper White", "ورق أبيض", "light", "l", "#f7f5f0", "#ffffff", "#1d1c1a", "#2f6f5e", "#c9a24a", "paper", "round", "serif", "calm", "grain", "islamic"],
  ["Ivory Journal", "دفتر عاجي", "light", "l", "#f4eddc", "#fbf7ec", "#2b2418", "#8a5a2b", "#5c7a4d", "paper", "sharp", "serif", "calm", "lines", "coptic"],
  ["Linen", "كتان", "light", "l", "#efe9e1", "#f8f4ee", "#2d2a26", "#7b6a58", "#a0805d", "matte", "squircle", "sans", "calm", "grain", "spring"],
  ["Silver Mist", "ضباب فضي", "light", "l", "#e9edf1", "#f6f8fa", "#1c2530", "#4a6a8a", "#8aa0b6", "glass", "round", "sans", "calm", "mesh", "winter"],
  ["Arctic", "قطبي", "light", "l", "#eaf4f8", "#ffffff", "#0e2a36", "#1b8bb4", "#7cc6dd", "flat", "squircle", "rounded", "snappy", "none", "winter"],
  ["Porcelain", "بورسلين", "light", "l", "#f3f4f7", "#ffffff", "#20232b", "#3c5ccf", "#d64f7a", "glossy", "round", "sans", "springy", "none", "spring"],
  ["Newsprint", "ورق الصحف", "light", "l", "#ecebe6", "#f6f5f1", "#111111", "#111111", "#b3261e", "outlined", "sharp", "serif", "none", "lines", "islamic"],
  ["Library", "مكتبة", "light", "l", "#e8e1d3", "#f4efe4", "#2a2016", "#6b2d2d", "#2f5a45", "paper", "chamfer", "serif", "calm", "grain", "coptic"],
  ["Midnight", "منتصف الليل", "dark", "d", "#0d1220", "#161d30", "#e6e9f2", "#7aa2ff", "#c9a24a", "matte", "round", "sans", "calm", "dots", "islamic"],
  ["Graphite", "جرافيت", "dark", "d", "#1a1b1e", "#24262a", "#ececec", "#9fb4c7", "#d1a35c", "matte", "squircle", "sans", "snappy", "none", "winter"],
  ["AMOLED Black", "أسود أموليد", "dark", "d", "#000000", "#0b0b0b", "#f2f2f2", "#4fd1c5", "#f6ad55", "flat", "round", "sans", "snappy", "none", "friday"],
  ["Obsidian", "سبج", "dark", "d", "#0f0e12", "#1b1920", "#ece8f4", "#b392f0", "#5ad1a8", "glossy", "chamfer", "sans", "springy", "none", "islamic"],
  ["Slate", "أردواز", "dark", "d", "#1c232b", "#26303a", "#e3e9ef", "#5fb3b3", "#e0b45c", "matte", "squircle", "condensed", "calm", "lines", "nile"],
  ["Deep Ink", "حبر عميق", "dark", "d", "#0b1530", "#13204a", "#e5ebff", "#f0c24b", "#76a6ff", "paper", "round", "serif", "calm", "grain", "ramadan"],
  ["Carbon", "كربون", "dark", "d", "#121314", "#1d1f21", "#e8e8e8", "#ff6b4a", "#9aa5b1", "outlined", "sharp", "mono", "snappy", "grid", "national"],
  ["Nile Blue", "أزرق النيل", "egypt", "l", "#e7f0f8", "#f7fbff", "#0f2742", "#1f5fa8", "#2fa37e", "glass", "round", "sans", "calm", "pattern", "nile"],
  ["Desert Gold", "ذهب الصحراء", "egypt", "l", "#f3e7cf", "#fbf4e4", "#3a2a12", "#b07d1e", "#7a4a1d", "paper", "chamfer", "serif", "calm", "grain", "coptic"],
  ["Pharaonic Teal & Gold", "فيروزي وذهبي فرعوني", "egypt", "d", "#0c2b2e", "#123a3e", "#f3e9cc", "#d4a83a", "#3fb3a4", "glossy", "chamfer", "serif", "calm", "pattern", "nile"],
  ["Cairo Night", "ليل القاهرة", "egypt", "d", "#120f1c", "#1d1830", "#f1e8d6", "#e7b04a", "#8f7bd8", "glass", "squircle", "sans", "springy", "pattern", "islamic"],
  ["Khan El-Khalili", "خان الخليلي", "egypt", "d", "#2a160c", "#3a2014", "#f6e6cc", "#e39b2b", "#2c8c7a", "clay", "chamfer", "serif", "calm", "pattern", "ramadan"],
  ["Luxor Dawn", "فجر الأقصر", "egypt", "l", "#fbe9da", "#fff6ee", "#3b2318", "#d2693c", "#c9a24a", "glass", "round", "serif", "calm", "mesh", "nile"],
  ["Aswan Sunset", "غروب أسوان", "egypt", "d", "#2b1420", "#3b1c2c", "#fbe6dc", "#ff8a5b", "#ffc46b", "glossy", "round", "sans", "springy", "mesh", "nile"],
  ["Siwa Oasis", "واحة سيوة", "egypt", "l", "#efe6d2", "#faf5ea", "#2f2a1b", "#5b8a3c", "#c48a3a", "clay", "squircle", "rounded", "calm", "grain", "spring"],
  ["Alexandria Corniche", "كورنيش الإسكندرية", "egypt", "l", "#e3f1f6", "#f7fcfe", "#0b2c3a", "#167ea3", "#e3a64a", "flat", "round", "sans", "springy", "lines", "summer"],
  ["Sinai Granite", "جرانيت سيناء", "egypt", "d", "#231d1d", "#302828", "#eee3df", "#d07a5a", "#9db0a6", "matte", "chamfer", "condensed", "calm", "grain", "national"],
  ["Red Sea Reef", "شعاب البحر الأحمر", "egypt", "d", "#04263a", "#06344f", "#e2f6fb", "#ff7f6b", "#3fd3c3", "glass", "round", "rounded", "springy", "mesh", "summer"],
  ["Papyrus", "بردي", "egypt", "l", "#ece0bf", "#f6eed6", "#33291a", "#6f6230", "#a1442a", "paper", "sharp", "serif", "none", "lines", "nile"],
  ["Delta Green", "أخضر الدلتا", "egypt", "l", "#e5efe0", "#f5faf2", "#1c2d18", "#3f7f33", "#b8932f", "matte", "round", "sans", "calm", "grain", "spring"],
  ["Ramadan Lantern", "فانوس رمضان", "islamic", "d", "#0f1f2b", "#172d3d", "#f6ecd2", "#e1a93b", "#4fb39a", "glass", "squircle", "serif", "calm", "pattern", "ramadan"],
  ["Mamluk Geometry", "هندسة مملوكية", "islamic", "l", "#efe5d3", "#faf3e6", "#2a1d10", "#9b3b1f", "#1d5a6e", "paper", "chamfer", "serif", "calm", "pattern", "islamic"],
  ["Andalusian Tile", "زليج أندلسي", "islamic", "l", "#e8f0f3", "#ffffff", "#132a33", "#1b6f8a", "#c78a2b", "glossy", "chamfer", "serif", "springy", "pattern", "islamic"],
  ["Mihrab", "محراب", "islamic", "d", "#1a1410", "#2a2018", "#f3e7d0", "#c99a45", "#6fa38a", "clay", "round", "serif", "calm", "pattern", "islamic"],
  ["Arabesque Emerald", "أرابيسك زمردي", "islamic", "d", "#06221b", "#0c3128", "#e5f4ec", "#d7b65a", "#3cc18f", "glossy", "squircle", "serif", "calm", "pattern", "islamic"],
  ["Zellige", "زليج", "islamic", "l", "#e5f2ee", "#fbfffd", "#0f2a24", "#167a63", "#2d5fa8", "outlined", "chamfer", "sans", "snappy", "pattern", "friday"],
  ["Muqarnas Night", "مقرنصات الليل", "islamic", "d", "#101326", "#191d38", "#ece9fb", "#d9b25f", "#7f8cff", "glass", "chamfer", "serif", "calm", "pattern", "ramadan"],
  ["Sage", "مريمية", "nature", "l", "#e9eee6", "#f6f9f4", "#1f2a1e", "#5d7f5a", "#b49a6a", "matte", "squircle", "rounded", "calm", "grain", "spring"],
  ["Forest", "غابة", "nature", "d", "#0f1d16", "#173026", "#e2efe5", "#6fc28b", "#d9b46a", "matte", "round", "sans", "calm", "grain", "autumn"],
  ["Mint Fresh", "نعناع منعش", "nature", "l", "#e6f7f1", "#ffffff", "#103028", "#14a37f", "#ff8c6b", "flat", "round", "rounded", "springy", "dots", "spring"],
  ["Rain", "مطر", "nature", "d", "#141c24", "#1d2833", "#dfe8f0", "#6fa8dc", "#9fc5e8", "glass", "round", "sans", "calm", "lines", "winter"],
  ["Dune", "كثيب", "nature", "l", "#f1e3cc", "#fbf2e2", "#3b2c18", "#c27c3e", "#6a7f5a", "clay", "round", "sans", "calm", "grain", "summer"],
  ["Aurora", "شفق قطبي", "nature", "d", "#071422", "#0e2033", "#e3f3ff", "#58e0b0", "#b07bff", "glass", "round", "sans", "springy", "mesh", "winter"],
  ["Ocean Deep", "أعماق المحيط", "nature", "d", "#031a2b", "#08283f", "#dff1ff", "#2bb3e3", "#7ce0d2", "glossy", "round", "sans", "calm", "mesh", "summer"],
  ["Coral", "مرجان", "nature", "l", "#fdeee8", "#fff8f5", "#3a1d16", "#e2583e", "#2a9d8f", "flat", "squircle", "rounded", "springy", "none", "summer"],
  ["Meadow", "مرج", "nature", "l", "#eef5e2", "#fbfdf6", "#22301a", "#6a9a2e", "#e0a33a", "paper", "round", "rounded", "springy", "dots", "spring"],
  ["Snowfield", "حقل الثلج", "nature", "l", "#f2f6fa", "#ffffff", "#1b2733", "#5a7fa8", "#b0c4d8", "glass", "round", "sans", "calm", "pattern", "winter"],
  ["Soft Glass", "زجاج ناعم", "glass", "l", "#dfe7f3", "#ffffff", "#17202c", "#4f7cff", "#ff7aa8", "glass", "round", "sans", "springy", "mesh", "spring"],
  ["Frosted Premium", "زجاج مصنفر فاخر", "glass", "d", "#101418", "#1a2028", "#eef2f6", "#c8b48a", "#8fb3d9", "glass", "squircle", "sans", "calm", "mesh", "winter"],
  ["One UI Glass", "زجاج بأسلوب One UI", "glass", "l", "#e4ebf5", "#ffffff", "#141a22", "#3e7bfa", "#5ac8a8", "glass", "squircle", "rounded", "springy", "mesh", "friday"],
  ["Classic iOS-inspired", "كلاسيكي مستوحى من iOS", "glass", "l", "#f2f2f7", "#ffffff", "#000000", "#007aff", "#34c759", "glass", "squircle", "sans", "springy", "none", "spring"],
  ["Fluid Glass", "زجاج سائل", "glass", "d", "#0d1022", "#171b36", "#eef0ff", "#8ea2ff", "#ff9ad5", "glass", "round", "rounded", "springy", "mesh", "eid"],
  ["Soft Clay", "صلصال ناعم", "glass", "l", "#e8e3dc", "#efeae3", "#2d2924", "#c06c4a", "#6b8f7a", "clay", "round", "rounded", "springy", "none", "autumn"],
  ["Layered Depth", "عمق متعدد الطبقات", "glass", "d", "#15171c", "#20232a", "#eceef2", "#6ad1ff", "#ffcf6a", "glossy", "squircle", "sans", "springy", "dots", "newyear"],
  ["Neon Grid", "شبكة نيون", "tech", "d", "#0a0716", "#120d26", "#f0e9ff", "#ff3fd8", "#3ff0ff", "neon", "sharp", "mono", "snappy", "grid", "newyear"],
  ["Terminal", "طرفية", "tech", "d", "#050a05", "#0b140b", "#b6f5b6", "#39ff7a", "#ffd23f", "outlined", "sharp", "mono", "none", "lines", "study"],
  ["Synthwave Dusk", "غسق سينث", "tech", "d", "#1a0b2e", "#2a1145", "#ffe9f7", "#ff6ac1", "#ffb86b", "neon", "round", "condensed", "springy", "grid", "summer"],
  ["Blueprint", "مخطط أزرق", "tech", "d", "#0d3466", "#0f3c75", "#e6f0ff", "#ffffff", "#9fd0ff", "blueprint", "sharp", "mono", "none", "grid", "study"],
  ["Cyber Mint", "نعناع سيبراني", "tech", "d", "#06161a", "#0b2328", "#d9fbf3", "#3dffc5", "#7aa8ff", "neon", "chamfer", "mono", "snappy", "grid", "winter"],
  ["Monochrome Pro", "أحادي احترافي", "tech", "l", "#f0f0f0", "#ffffff", "#0a0a0a", "#0a0a0a", "#6b6b6b", "outlined", "sharp", "condensed", "snappy", "none", "friday"],
  ["Coffee", "قهوة", "warm", "d", "#1e1410", "#2b1d17", "#f2e4d6", "#c88a55", "#8fae8b", "matte", "round", "serif", "calm", "grain", "autumn"],
  ["Champagne", "شمبانيا", "warm", "l", "#f6eee0", "#fffaf1", "#2f2618", "#8a6a26", "#9c6b7b", "glossy", "squircle", "serif", "calm", "none", "eid"],
  ["Rose Quartz", "كوارتز وردي", "warm", "l", "#f8e8ea", "#fff6f7", "#3a1f26", "#c45a78", "#7c8fc4", "glass", "round", "rounded", "springy", "mesh", "love"],
  ["Terracotta", "تيراكوتا", "warm", "l", "#f1e0d4", "#faf0e8", "#3a2116", "#b5532e", "#4f7a6a", "clay", "chamfer", "sans", "calm", "grain", "coptic"],
  ["Sunset", "غروب", "warm", "d", "#26111a", "#371a26", "#ffe8de", "#ff7a59", "#ffc85c", "glossy", "round", "sans", "springy", "mesh", "summer"],
  ["Amber", "كهرمان", "warm", "d", "#1b1408", "#2a1f0d", "#fbeccc", "#f2a516", "#d8693b", "matte", "squircle", "condensed", "snappy", "none", "autumn"],
  ["Saffron", "زعفران", "warm", "l", "#fbefd6", "#fff8e8", "#3a2808", "#a65a0a", "#a83a3a", "paper", "round", "serif", "calm", "pattern", "ramadan"],
  ["Candy", "حلوى", "playful", "l", "#fff0f6", "#ffffff", "#3a1030", "#ff4fa3", "#7a5cff", "glossy", "round", "rounded", "springy", "dots", "birthday"],
  ["Pastel Cloud", "سحابة باستيل", "playful", "l", "#eef0ff", "#ffffff", "#232552", "#8a7bff", "#5fd3c0", "clay", "round", "rounded", "springy", "none", "spring"],
  ["Sticker Pop", "ملصقات", "playful", "l", "#fff7d6", "#ffffff", "#141414", "#ff5a36", "#2f7bff", "outlined", "round", "rounded", "springy", "dots", "birthday"],
  ["Arcade", "أركيد", "playful", "d", "#14092b", "#1f1040", "#fff4d6", "#ffd23f", "#3fd0ff", "neon", "sharp", "mono", "snappy", "grid", "newyear"],
];

const slug = (s: string) => s.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
export const THEMES: ThemePack[] = R.map((r) => ({
  id: slug(r[0]), en: r[0], ar: r[1], cat: r[2], mode: r[3] === "l" ? "light" : "dark",
  bg: r[4], surface: r[5], text: r[6], accent: r[7], accent2: r[8], material: r[9], shape: r[10], font: r[11], motion: r[12], texture: r[13], ornament: r[14], version: 1,
}));

export const CATEGORIES: Array<{ id: Category; en: string; ar: string }> = [
  { id: "light", en: "Light editorial", ar: "فاتح تحريري" }, { id: "dark", en: "Dark", ar: "داكن" },
  { id: "egypt", en: "Egyptian heritage", ar: "تراث مصري" }, { id: "islamic", en: "Islamic & geometric", ar: "إسلامي وهندسي" },
  { id: "nature", en: "Nature", ar: "طبيعة" }, { id: "glass", en: "Glass & depth", ar: "زجاج وعمق" },
  { id: "tech", en: "Tech", ar: "تقني" }, { id: "warm", en: "Warm", ar: "دافئ" }, { id: "playful", en: "Playful", ar: "مرح" },
  { id: "custom", en: "My packs", ar: "حزمي" },
];

// ---- colour utilities & WCAG contrast ----
export function hexToRgb(h: string): [number, number, number] {
  const x = h.replace("#", "");
  const n = parseInt(x.length === 3 ? x.split("").map((c) => c + c).join("") : x, 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}
function lum(h: string) {
  const [r, g, b] = hexToRgb(h).map((v) => { const c = v / 255; return c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4); });
  return 0.2126 * r + 0.7152 * g + 0.0722 * b;
}
export function contrast(a: string, b: string) {
  const l1 = lum(a), l2 = lum(b);
  return (Math.max(l1, l2) + 0.05) / (Math.min(l1, l2) + 0.05);
}
export const inkOn = (bg: string) => (contrast(bg, "#ffffff") >= contrast(bg, "#111111") ? "#ffffff" : "#111111");

export function contrastReport(t: ThemePack) {
  return [
    { k: "Text / background", ar: "النص / الخلفية", v: contrast(t.text, t.bg), min: 4.5 },
    { k: "Text / surface", ar: "النص / السطح", v: contrast(t.text, t.surface), min: 4.5 },
    { k: "Accent / surface (UI)", ar: "اللون المميز / السطح", v: contrast(t.accent, t.surface), min: 3 },
    { k: "Accent label ink", ar: "حبر زر اللون المميز", v: contrast(inkOn(t.accent), t.accent), min: 4.5 },
  ];
}

const FONTS: Record<Font, string> = {
  sans: `system-ui, -apple-system, "Segoe UI", Roboto, "Noto Sans Arabic", "Noto Sans", Tahoma, sans-serif`,
  serif: `"Iowan Old Style", Georgia, "Noto Naskh Arabic", "Amiri", "Times New Roman", serif`,
  mono: `ui-monospace, "SF Mono", "Cascadia Mono", Menlo, "Noto Sans Arabic", monospace`,
  rounded: `ui-rounded, "SF Pro Rounded", "Nunito", system-ui, "Noto Sans Arabic", sans-serif`,
  condensed: `"Roboto Condensed", "Arial Narrow", system-ui, "Noto Sans Arabic", sans-serif`,
};
const RADII: Record<Shape, string> = { round: "18px", squircle: "26px", chamfer: "4px", sharp: "2px" };
const MOTION: Record<Motion, [string, string]> = {
  calm: ["420ms", "cubic-bezier(.2,.7,.2,1)"], springy: ["520ms", "cubic-bezier(.34,1.56,.64,1)"],
  snappy: ["160ms", "cubic-bezier(.2,0,0,1)"], none: ["0ms", "linear"],
};

export function applyTheme(t: ThemePack, el: HTMLElement = document.documentElement) {
  const s = el.style;
  s.setProperty("--bg", t.bg); s.setProperty("--surface", t.surface); s.setProperty("--text", t.text);
  s.setProperty("--accent", t.accent); s.setProperty("--accent2", t.accent2); s.setProperty("--on-accent", inkOn(t.accent));
  s.setProperty("--font", FONTS[t.font]); s.setProperty("--r", RADII[t.shape]);
  s.setProperty("--dur", MOTION[t.motion][0]); s.setProperty("--ease", MOTION[t.motion][1]);
  el.dataset.material = t.material; el.dataset.shape = t.shape; el.dataset.texture = t.texture; el.dataset.mode = t.mode;
  el.style.colorScheme = t.mode;
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.setAttribute("content", t.bg);
}

export function withViewTransition(fn: () => void) {
  const d = document as Document & { startViewTransition?: (cb: () => void) => unknown };
  if (d.startViewTransition && !window.matchMedia("(prefers-reduced-motion: reduce)").matches) d.startViewTransition(fn);
  else fn();
}
