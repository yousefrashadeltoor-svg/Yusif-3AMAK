import { dayKey, fromKey } from "./calendar";

export type DateIntent =
  | { kind: "none" }
  | { kind: "date"; date: string; phrase: string }
  | { kind: "repeat"; days: number[]; phrase: string; startDate?: string }
  | { kind: "ambiguous"; reason: string; soft?: boolean };

export type TimeIntent =
  | { kind: "none" }
  | { kind: "time"; time: string; phrase: string; date?: string; relative?: boolean }
  | { kind: "ambiguous"; reason: string };

const DAYS: Array<[RegExp, number]> = [
  [/(?:^|[^\p{L}])و?(?:الاحد|sunday|sun)(?=$|[^\p{L}])/iu, 0],
  [/(?:^|[^\p{L}])و?(?:الاثنين|الاتنين|اتنين|اثنين|monday|mon)(?=$|[^\p{L}])/iu, 1],
  [/(?:^|[^\p{L}])و?(?:التلات|التلاتاء|تلات|الثلاثاء|tuesday|tue)(?=$|[^\p{L}])/iu, 2],
  [/(?:^|[^\p{L}])و?(?:الاربعاء|اربعاء|wednesday|wed)(?=$|[^\p{L}])/iu, 3],
  [/(?:^|[^\p{L}])و?(?:الخميس|خميس|thursday|thu)(?=$|[^\p{L}])/iu, 4],
  [/(?:^|[^\p{L}])و?(?:الجمعة|الجمعه|جمعة|friday|fri)(?=$|[^\p{L}])/iu, 5],
  [/(?:^|[^\p{L}])و?(?:السبت|سبت|saturday|sat)(?=$|[^\p{L}])/iu, 6],
];
const MONTH_NAMES = ["يناير", "فبراير", "مارس", "ابريل", "مايو", "يونيو", "يوليو", "اغسطس", "سبتمبر", "اكتوبر", "نوفمبر", "ديسمبر"];
const MONTHS_EN = ["january", "february", "march", "april", "may", "june", "july", "august", "september", "october", "november", "december"];

export function normalizeDateWords(value: string): string {
  return value
    .replace(/[٠-٩]/g, (c) => String("٠١٢٣٤٥٦٧٨٩".indexOf(c)))
    .replace(/[۰-۹]/g, (c) => String("۰۱۲۳۴۵۶۷۸۹".indexOf(c)))
    .replace(/[\u064B-\u065F\u0670\u0640]/g, "")
    .replace(/[إأآٱ]/g, "ا").replace(/ى/g, "ي")
    .toLowerCase();
}

export function isValidDay(value: unknown): value is string {
  if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const d = fromKey(value);
  return Number.isFinite(+d) && dayKey(d) === value;
}

export const isValidTime = (value: unknown): value is string => typeof value === "string" && /^([01]\d|2[0-3]):[0-5]\d$/.test(value);

export function contextualRequest(previous: string, reply: string): string {
  if (!previous) return reply;
  const freshCommand = /^(?:اعمل|اعملي|ضيف|اضف|اكتب|حط|سجل|انشئ|create|add|set|schedule)\s+(?:منبه|مهمة|تاسك|عادة|task|alarm|habit)/i.test(normalizeDateWords(reply.trim()));
  return freshCommand ? reply : `${previous} ${reply}`;
}

const calendarDay = (now: Date, offset: number): string => dayKey(new Date(now.getFullYear(), now.getMonth(), now.getDate() + offset));


const monthIndex = (name: string) => { const n = name.toLowerCase().replace("يونيه", "يونيو").replace("يوليه", "يوليو"); return Math.max(MONTH_NAMES.indexOf(n), MONTHS_EN.indexOf(n)); };
const daysInMonth = (y: number, m0: number) => new Date(y, m0 + 1, 0).getDate();
const keyOf = (y: number, m0: number, d: number) => `${y}-${String(m0 + 1).padStart(2, "0")}-${String(d).padStart(2, "0")}`;
/** Next calendar occurrence (today counts) of day/month; Feb-29 searches forward up to 8 years. */
function nextOccurrence(month: number, day: number, now: Date): string | null {
  if (month < 1 || month > 12 || day < 1) return null;
  for (let y = now.getFullYear(); y <= now.getFullYear() + 8; y++) {
    if (day > daysInMonth(y, month - 1)) continue;
    const key = keyOf(y, month - 1, day);
    if (key >= dayKey(now)) return key;
  }
  return null;
}
function nextDayOfMonth(day: number, now: Date): string | null {
  if (day < 1 || day > 31) return null;
  for (let i = 0; i < 14; i++) {
    const y = now.getFullYear() + Math.floor((now.getMonth() + i) / 12), m0 = (now.getMonth() + i) % 12;
    if (day > daysInMonth(y, m0)) continue;
    const key = keyOf(y, m0, day);
    if (key >= dayKey(now)) return key;
  }
  return null;
}
/** Month-level phrases: بعد شهر / الشهر الجاي / أول الشهر الجاي / آخر الشهر / in 2 months. */
function parseMonthPhrases(q: string, now: Date): DateIntent | null {
  const y = now.getFullYear(), m = now.getMonth(), d = now.getDate();
  const addMonths = (n: number): DateIntent => { const t = m + n, ty = y + Math.floor(t / 12), tm = ((t % 12) + 12) % 12; return { kind: "date", date: keyOf(ty, tm, Math.min(d, daysInMonth(ty, tm))), phrase: n === 1 ? "الشهر الجاي" : `بعد ${n} شهور` }; };
  if (/(?:اول|بداية|بدايه)\s+(?:يوم\s+(?:في\s+)?)?(?:ال)?شهر\s+(?:الجاي|الجايه|الجاية|اللي جاي|القادم|المقبل)|first\s+(?:day\s+)?of\s+next\s+month|1st\s+of\s+next\s+month/i.test(q)) { const t = m + 1; return { kind: "date", date: keyOf(y + Math.floor(t / 12), t % 12, 1), phrase: "أول الشهر الجاي" }; }
  if (/(?:اخر|نهاية|نهايه)\s+(?:يوم\s+(?:في\s+)?)?(?:ال)?شهر(?!\s+(?:الجاي|القادم|المقبل))|end\s+of\s+(?:the\s+|this\s+)?month|last\s+day\s+of\s+(?:the\s+|this\s+)?month/i.test(q)) return { kind: "date", date: keyOf(y, m, daysInMonth(y, m)), phrase: "آخر الشهر" };
  if (/(?:اخر|نهاية|نهايه)\s+(?:ال)?شهر\s+(?:الجاي|القادم|المقبل)|end\s+of\s+next\s+month/i.test(q)) { const t = m + 1, ty = y + Math.floor(t / 12), tm = t % 12; return { kind: "date", date: keyOf(ty, tm, daysInMonth(ty, tm)), phrase: "آخر الشهر الجاي" }; }
  const after = q.match(/(?:بعد|in)\s+(?:(\d{1,2})\s+(?:شهور|اشهر|شهر|months?)|(شهرين|شهر)(?!\p{L}))/iu);
  if (after) { const n = after[1] ? Number(after[1]) : after[2] === "شهرين" ? 2 : 1; return n > 0 && n <= 36 ? addMonths(n) : { kind: "ambiguous", reason: "حدّد بعد كام شهر بالظبط." }; }
  if (/(?:الشهر\s+(?:الجاي|الجايه|الجاية|اللي جاي|القادم|المقبل)|next month)/i.test(q)) return addMonths(1);
  return null;
}

/** True when the user's own words contain any date/time wording, even one the local parser cannot resolve. */
export function hasTemporalHint(input: string): boolean {
  const q = normalizeDateWords(input);
  return /(?:بكر|غدا|بعد|الجاي|الجايه|الجاية|القادم|المقبل|اللي جاي|لاحق|اول|اخر|نهاية|بداية|الاسبوع|الشهر|السنه|السنة|يوم\s|ايام|اسبوع|شهر|الاحد|الاثنين|الاتنين|التلات|الثلاثاء|الاربعاء|الخميس|الجمعه|الجمعة|السبت|يناير|فبراير|مارس|ابريل|مايو|يونيو|يوليو|اغسطس|سبتمبر|اكتوبر|نوفمبر|ديسمبر|tomorrow|next|later|week|month|monday|tuesday|wednesday|thursday|friday|saturday|sunday|\d{1,4}[-/.]\d{1,2})/i.test(q);
}

/** Splits a multi-command message into clauses so each action reads its own date. */
export function splitClauses(input: string): string[] {
  const parts = input.split(/[\n؛;.!؟?]+|\s+(?:وبعدين|و بعدين|وبعد كده|وبعد كدا|وكمان|و كمان|وايضا|و ايضا|ثم|then|also|and then|plus)\s+/i).map((x) => x.trim()).filter(Boolean);
  return parts.length ? parts : [input];
}

/** Picks the clause that belongs to an action (by order when counts match, else by word overlap). */
export function clauseForAction(request: string, actionText: string, index: number, total: number): string {
  const clauses = splitClauses(request);
  if (clauses.length <= 1) return request;
  const words = normalizeDateWords(actionText).split(/[^\p{L}\p{N}]+/u).filter((w) => w.length > 2);
  const scores = clauses.map((c) => { const n = normalizeDateWords(c); return words.filter((w) => n.includes(w)).length; });
  const best = Math.max(...scores);
  if (best > 0 && scores.filter((x) => x === best).length === 1) return clauses[scores.indexOf(best)];
  return clauses.length === total ? clauses[index] : request;
}

export function parseDateIntent(input: string, now = new Date()): DateIntent {
  const q = normalizeDateWords(input);
  const start = q.match(/(?:ابتداء\s+من|بداية\s+من|بدايه\s+من|من|starting(?:\s+on)?)\s+(بعد\s+بكر[هةا]|بكر[هةا]|غدا|tomorrow|\d{4}[-/]\d{1,2}[-/]\d{1,2}|\d{1,2}[/.]\d{1,2}[/.]\d{4})/i);
  if (start && /(?:كل يوم|كل\s+(?:يوم\s+)?(?:الاتنين|الاثنين|اتنين|التلات|الثلاثاء|الخميس|الجمعة|السبت)|every\s+(?:day|monday|tuesday|wednesday|thursday|friday|saturday|sunday)|يوميا|daily)/i.test(q)) {
    const recur = parseDateIntent(q.replace(start[0], ""), now);
    const first = parseDateIntent(start[1], now);
    if (recur.kind === "repeat" && first.kind === "date") return { ...recur, startDate: first.date };
    return { kind: "ambiguous", reason: "حدد تاريخ بداية التكرار بالضبط، مثل 15/06/2027." };
  }
  const explicit = q.match(/(?<!\d)(\d{4})[-/]([01]?\d)[-/]([0-3]?\d)(?!\d)/);
  if (explicit) {
    const value = `${explicit[1]}-${explicit[2].padStart(2, "0")}-${explicit[3].padStart(2, "0")}`;
    return isValidDay(value) ? { kind: "date", date: value, phrase: explicit[0] } : { kind: "ambiguous", reason: "تاريخ غير صالح؛ اكتب التاريخ بصيغة سنة-شهر-يوم." };
  }
  const dmy = q.match(/(?<!\d)([0-3]?\d)[/.]([01]?\d)[/.](\d{4})(?!\d)/);
  if (dmy) {
    const value = `${dmy[3]}-${dmy[2].padStart(2, "0")}-${dmy[1].padStart(2, "0")}`;
    return isValidDay(value) ? { kind: "date", date: value, phrase: dmy[0] } : { kind: "ambiguous", reason: "التاريخ ده مش صالح؛ اكتب اليوم والشهر والسنة." };
  }
  const namedMonth = q.match(/(?<!\d)(\d{1,2})\s+(يناير|فبراير|مارس|ابريل|مايو|يونيو|يونيه|يوليو|يوليه|اغسطس|سبتمبر|اكتوبر|نوفمبر|ديسمبر|january|february|march|april|may|june|july|august|september|october|november|december)\s+(\d{4})(?!\d)/i);
  if (namedMonth) {
    const month = monthIndex(namedMonth[2]) + 1;
    const value = `${namedMonth[3]}-${String(month).padStart(2, "0")}-${namedMonth[1].padStart(2, "0")}`;
    return isValidDay(value) ? { kind: "date", date: value, phrase: namedMonth[0] } : { kind: "ambiguous", reason: "التاريخ ده مش صالح؛ اكتب اليوم والشهر والسنة." };
  }
  const noYear = q.match(/(?<!\d)(\d{1,2})\s+(يناير|فبراير|مارس|ابريل|مايو|يونيو|يونيه|يوليو|يوليه|اغسطس|سبتمبر|اكتوبر|نوفمبر|ديسمبر|january|february|march|april|may|june|july|august|september|october|november|december)(?!\p{L})/iu);
  if (noYear) { const d = nextOccurrence(monthIndex(noYear[2]) + 1, Number(noYear[1]), now); return d ? { kind: "date", date: d, phrase: noYear[0] } : { kind: "ambiguous", reason: "التاريخ ده مش صالح؛ اكتب اليوم والشهر." }; }

  const isRepeat = /(?:كل يوم|يوميا|every day|\bdaily\b|كل\s+(?:الاحد|الاتنين|الاثنين|اتنين|اثنين|التلات|تلات|الثلاثاء|الاربعاء|اربعاء|الخميس|خميس|الجمعة|جمعة|السبت|سبت)|every\s+(?:monday|tuesday|wednesday|thursday|friday|saturday|sunday)|كل اسبوع)/i.test(q);
  const names: number[] = [];
  for (const [regex, n] of DAYS) if (regex.test(q)) names.push(n);
  const weekdays = [...new Set(names)].sort();
  if (isRepeat && weekdays.length) return { kind: "repeat", days: weekdays, phrase: "أيام متكررة" };
  if (isRepeat && (/كل يوم|يوميا|every day|daily/.test(q))) return { kind: "repeat", days: [0, 1, 2, 3, 4, 5, 6], phrase: "كل يوم" };
  if (isRepeat) return { kind: "ambiguous", reason: "حدّد أيام التكرار، زي كل يوم اتنين أو كل يوم." };

  const after = q.match(/(?:بعد|in)\s+(?:(\d{1,3})\s+(يوم|ايام|اسبوع|اسابيع|days?|weeks?)|(يومين|اسبوعين|اسبوع|يوم)(?!\p{L}))/iu);
  if (after) {
    const word = after[3] || "", n = after[1] ? Number(after[1]) : /يومين|اسبوعين/.test(word) ? 2 : 1;
    if (!Number.isFinite(n) || n <= 0 || n > 365) return { kind: "ambiguous", reason: "حدّد بعد كام يوم بالظبط." };
    const weeks = /اسبوع|weeks?/i.test(after[2] || word);
    return { kind: "date", date: calendarDay(now, n * (weeks ? 7 : 1)), phrase: after[0] };
  }
  const monthly = parseMonthPhrases(q, now);
  if (monthly) return monthly;
  if (/(?:بعد\s+(?:بكر[هةا]|غد)|day after tomorrow)/i.test(q)) return { kind: "date", date: calendarDay(now, 2), phrase: "بعد بكرة" };
  if (/(?:بكر[هةا]|غدا|tomorrow)/i.test(q)) return { kind: "date", date: calendarDay(now, 1), phrase: "بكرة" };
  if (/(?:النهارده|النهاردة|اليوم|today)/i.test(q)) return { kind: "date", date: dayKey(now), phrase: "النهاردة" };

  if (weekdays.length > 1) return { kind: "ambiguous", reason: "أنهي يوم بالظبط؟ لو متكرر قول كل يوم اتنين وخميس." };
  if (/(?:بعد الجاي|بعد القادم|week after next|مش\s+بكر(?![\s\S]*بعد\s+بكر))/i.test(q)) return { kind: "ambiguous", soft: true, reason: "حدّد التاريخ المقصود باليوم والشهر والسنة عشان ما أختارش أسبوع غلط." };
  if (weekdays.length === 1) {
    const target = weekdays[0];
    const weekday = q.match(/(?:الاحد|الاثنين|الاتنين|التلات|التلاتاء|الثلاثاء|الاربعاء|الخميس|الجمعة|الجمعه|السبت|sunday|monday|tuesday|wednesday|thursday|friday|saturday)/i)?.[0] || "";
    const nextWeek = /(?:الاسبوع\s+(?:الجاي|اللي جاي|القادم)|next week)/i.test(q);
    const delta = nextWeek
      ? 7 - (now.getDay() + 1) % 7 + (target + 1) % 7
      : (target - now.getDay() + 7) % 7 || (/الجاي|القادم|المقبل|اللي جاي|next/i.test(q) ? 7 : 0);
    return { kind: "date", date: calendarDay(now, delta), phrase: weekday };
  }
  if (/(?:الاسبوع\s+(?:الجاي|الجاية|اللي جاي|القادم|المقبل)|next week)/i.test(q)) return { kind: "date", date: calendarDay(now, 7), phrase: "الأسبوع الجاي" };
  const dm = q.match(/(?<![\d:])([0-3]?\d)[/.]([01]?\d)(?![/.\d:])/);
  if (dm) { const d = nextOccurrence(Number(dm[2]), Number(dm[1]), now); return d ? { kind: "date", date: d, phrase: dm[0] } : { kind: "ambiguous", reason: "التاريخ ده مش صالح؛ اكتب اليوم والشهر." }; }
  const dayOnly = q.match(/(?:يوم|day)\s+(\d{1,2})(?![\d:/.])/);
  if (dayOnly) { const d = nextDayOfMonth(Number(dayOnly[1]), now); return d ? { kind: "date", date: d, phrase: dayOnly[0] } : { kind: "ambiguous", reason: "اليوم ده مش موجود في الشهر؛ حدّد يوم صحيح." }; }
  const relativeTime = parseTimeIntent(q, now);
  if (relativeTime.kind === "time" && relativeTime.relative) return { kind: "none" };
  if (/(?:بعد\s+(?!الضهر|الظهر)|الجاي|القادم|المقبل|لاحقا|لاحق|later\b|next\b|future\b|upcoming\b)/i.test(q)) return { kind: "ambiguous", soft: true, reason: "قولّي التاريخ المقصود بشكل واضح، زي بكرة أو 15/06/2027." };
  return { kind: "none" };
}

export function parseTimeIntent(input: string, now = new Date()): TimeIntent {
  const q = normalizeDateWords(input).replace(/\d{4}[-/]\d{1,2}[-/]\d{1,2}/g, " ").replace(/\d{1,2}[/.]\d{1,2}[/.]\d{4}/g, " ");
  const later = q.match(/(?:بعد|in)\s+(?:(\d{1,3}|ساعتين|ساعتان|ساعة|نص|نصف)\s*(ساعات|ساعة|ساعه|دقايق|دقائق|دقيقة|دقيقه|hours?|minutes?)|(ساعتين|ساعتان))/i);
  if (later) {
    const unit = later[2] || later[3] || "";
    const amount = /ساعتين|ساعتان/.test(later[1] || later[3] || "") ? 2 : /نص|نصف/.test(later[1] || "") ? 0.5 : /ساعة|ساعه/.test(later[1] || "") ? 1 : Number(later[1]);
    const minutes = Math.round(amount * (/دقايق|دقائق|دقيقة|دقيقه|minutes?/i.test(unit) ? 1 : 60));
    if (minutes <= 0 || minutes > 7 * 1440) return { kind: "ambiguous", reason: "حدد فاضل كام ساعة أو دقيقة بالظبط." };
    const target = new Date(now.getTime() + minutes * 60000);
    return { kind: "time", time: `${String(target.getHours()).padStart(2, "0")}:${String(target.getMinutes()).padStart(2, "0")}`, date: dayKey(target), relative: true, phrase: later[0] };
  }
  const match = q.match(/(?<!\d)(\d{1,2}):([0-5]\d)(?!\d)/) || q.match(/(?:الساعه|ساعة|الساعة|at)\s*(\d{1,2})(?!\d)(?:\s*(ونص|وربع))?/) || q.match(/(?<!\d)(\d{1,2})(?=\s*(?:الصبح|صباح|الفجر|مسا|مساء|بالليل|الليل|العصر|الظهر|\bam\b|\bpm\b))/);
  if (!match) return { kind: "none" };
  let hour = Number(match[1]);
  const minute = match[2] && /^\d+$/.test(match[2]) ? Number(match[2]) : match[2] === "ونص" ? 30 : match[2] === "وربع" ? 15 : 0;
  if (hour > 23) return { kind: "ambiguous", reason: "الساعة لازم تكون بين 00 و23." };
  const period = q.slice(match.index! + match[0].length).match(/^\s*(?:الصبح|صباحا|صباح|الفجر|فجرا|مسا|مساء|مساءا|بالليل|الليل|بعد الضهر|العصر|الظهر|ضهرا|am\b|pm\b|ص\b|م\b)/i)?.[0]?.trim() ||
    q.match(/(?:الصبح|صباحا|صباح|الفجر|فجرا|مسا|مساء|بالليل|الليل|بعد الضهر|العصر|الظهر|ضهرا|\bam\b|\bpm\b)/i)?.[0] || "";
  if (/^(?:مسا|مساء|مساءا|pm|بعد الضهر|العصر)$/.test(period)) { if (hour < 12) hour += 12; }
  else if (/^(?:بالليل|الليل)$/.test(period)) { if (hour === 12) hour = 0; else if (hour >= 5 && hour < 12) hour += 12; }
  else if (/^(?:الصبح|صباحا|صباح|الفجر|فجرا|am|ص)$/.test(period)) { if (hour === 12) hour = 0; }
  else if (hour < 13 && !/^0\d:/.test(match[0]) && !/24\s*(?:hour|ساعه)/i.test(q)) return { kind: "ambiguous", reason: "الساعة دي صباح ولا مساء؟ اكتب مثلاً ٧ الصبح أو ٧ بالليل." };
  return { kind: "time", time: `${String(hour).padStart(2, "0")}:${String(minute).padStart(2, "0")}`, phrase: match[0] };
}

export function futureAt(date: string, time: string, now = new Date()) {
  if (!isValidDay(date) || !isValidTime(time)) return false;
  const [h, m] = time.split(":").map(Number);
  const at = fromKey(date); at.setHours(h, m, 0, 0);
  return at > now;
}