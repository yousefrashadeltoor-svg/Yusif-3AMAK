// IndexedDB storage for user-imported 3D models (handles 15MB–100MB+ offline safely, no 5MB localStorage limit).

export interface SavedModel {
  id: string;
  name: string;
  ext: string;
  size: number;
  thumb: string; // rendered PNG data URL
  addedAt: number;
  data: ArrayBuffer;
}

export type SavedModelMeta = Omit<SavedModel, "data">;

const DB = "dayflow-models-db";
const STORE = "models";

function openDb(): Promise<IDBDatabase> {
  return new Promise((res, rej) => {
    const req = indexedDB.open(DB, 1);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORE)) db.createObjectStore(STORE, { keyPath: "id" });
    };
    req.onsuccess = () => res(req.result);
    req.onerror = () => rej(req.error);
  });
}

export async function saveModel(m: SavedModel): Promise<void> {
  const db = await openDb();
  return new Promise((res, rej) => {
    const tx = db.transaction(STORE, "readwrite");
    tx.objectStore(STORE).put(m);
    tx.oncomplete = () => { db.close(); res(); };
    tx.onerror = () => { db.close(); rej(tx.error); };
  });
}

export async function listModelsMeta(): Promise<SavedModelMeta[]> {
  try {
    const db = await openDb();
    return await new Promise((res, rej) => {
      const tx = db.transaction(STORE, "readonly");
      const req = tx.objectStore(STORE).getAll();
      req.onsuccess = () => {
        db.close();
        const items = ((req.result || []) as SavedModel[]).map(({ data: _d, ...meta }) => meta).sort((a, b) => b.addedAt - a.addedAt);
        res(items);
      };
      req.onerror = () => { db.close(); rej(req.error); };
    });
  } catch {
    return [];
  }
}

export async function getModelData(id: string): Promise<SavedModel | null> {
  try {
    const db = await openDb();
    return await new Promise((res, rej) => {
      const tx = db.transaction(STORE, "readonly");
      const req = tx.objectStore(STORE).get(id);
      req.onsuccess = () => { db.close(); res((req.result as SavedModel) || null); };
      req.onerror = () => { db.close(); rej(req.error); };
    });
  } catch {
    return null;
  }
}

export async function deleteSavedModel(id: string): Promise<void> {
  const db = await openDb();
  return new Promise((res, rej) => {
    const tx = db.transaction(STORE, "readwrite");
    tx.objectStore(STORE).delete(id);
    tx.oncomplete = () => { db.close(); res(); };
    tx.onerror = () => { db.close(); rej(tx.error); };
  });
}
