import type { ReviewSnapshot } from "./reviewShare";
import { DIMS } from "./review";
export function renderReviewImage(snapshot: ReviewSnapshot): string {
  const rtl = snapshot.lang === "ar";
  const sections = [
    { title: rtl ? "التقييم من بياناتك المسجلة" : "Score from recorded data", lines: [`${snapshot.score ?? "—"} / 100 · ${snapshot.start} → ${snapshot.end}`, snapshot.narrative] },
    { title: rtl ? "الأبعاد" : "Dimensions", lines: snapshot.dimensions.map((d) => { const m = DIMS.find((x) => x.id === d.id); return `${rtl ? m?.ar || d.id : m?.en || d.id}: ${d.value === null ? (rtl ? "مش مسجّل" : "Not recorded") : d.value + "/100"}`; }) },
    { title: rtl ? "المهام" : "Tasks", lines: snapshot.tasks.length ? snapshot.tasks.map((t) => `${t.done ? "✓" : "○"} ${t.title} · ${t.date}`) : [rtl ? "مفيش مهام مسجّلة للفترة دي" : "No tasks recorded for this period"] },
    { title: rtl ? "العادات" : "Habits", lines: snapshot.habits.length ? snapshot.habits.map((h) => `${h.name} · ${h.completed}/${h.due}`) : [rtl ? "مفيش عادات مسجّلة" : "No habits recorded"] },
    { title: rtl ? "المياه والتفاصيل" : "Water & details", lines: [`${(snapshot.water.reduce((n, w) => n + w.ml, 0) / 1000).toFixed(2)} L`, ...snapshot.water.filter((w) => w.ml > 0).map((w) => `${w.date}: ${w.ml}/${w.goal} ml`), `${rtl ? "ملاحظات" : "Notes"}: ${snapshot.notesCount} · ${rtl ? "تدوينات" : "Journal entries"}: ${snapshot.journalCount}`, `${rtl ? "أيام ليها تقييم" : "Days with score"}: ${snapshot.daysRecorded}`] },
  ];
  const canvas = document.createElement("canvas"); canvas.width = 1000;
  let g = canvas.getContext("2d")!; g.font = "26px system-ui";
  const wrap = (text: string) => { const lines: string[] = []; let line = ""; for (const word of text.split(/\s+/)) { const next = `${line} ${word}`.trim(); if (g.measureText(next).width > 830 && line) { lines.push(line); line = word; } else line = next; } if (line) lines.push(line); return lines; };
  const prepared = sections.map((s) => ({ ...s, lines: s.lines.flatMap(wrap) }));
  const height = 240 + prepared.reduce((n, s) => n + 104 + s.lines.length * 40, 0) + 60;
  if (height > 18000) throw new Error(rtl ? "التقرير كبير؛ اختار فترة أقصر للصورة." : "Report is too large; choose a shorter period.");
  canvas.height = height; g = canvas.getContext("2d")!;
  g.fillStyle = "#f5f2e9"; g.fillRect(0, 0, 1000, height);
  const grad = g.createLinearGradient(0, 0, 1000, 230); grad.addColorStop(0, "#153f37"); grad.addColorStop(1, "#497a6b"); g.fillStyle = grad; g.fillRect(0, 0, 1000, 230);
  g.direction = rtl ? "rtl" : "ltr"; g.textAlign = rtl ? "right" : "left";
  const x = rtl ? 925 : 75;
  g.fillStyle = "#e6cd94"; g.font = "700 25px system-ui"; g.fillText("DAYFLOW · REVIEW", x, 64);
  g.fillStyle = "white"; g.font = "700 46px system-ui";
  const labels = rtl ? { day: "يومك في صورة", week: "أسبوعك في صورة", month: "شهرَك في صورة" } : { day: "Your day in review", week: "Your week in review", month: "Your month in review" };
  g.fillText(labels[snapshot.range], x, 131);
  g.fillStyle = "#ffffffcc"; g.font = "22px system-ui"; g.fillText(`${snapshot.start}  —  ${snapshot.end}`, x, 184);
  let y = 260;
  for (const section of prepared) {
    const cardH = 84 + section.lines.length * 40;
    g.fillStyle = "#ffffff"; g.beginPath(); g.roundRect(40, y, 920, cardH, 24); g.fill();
    g.fillStyle = "#2f6f5e"; g.font = "700 29px system-ui"; g.fillText(section.title, x, y + 49);
    g.fillStyle = "#242b29"; g.font = "26px system-ui";
    section.lines.forEach((line, i) => g.fillText(line, x, y + 95 + i * 40));
    y += cardH + 20;
  }
  g.font = "19px system-ui"; g.fillStyle = "#5f726b";
  g.fillText(rtl ? "صورة محلية · من غير رفع بيانات · مش توثيق رسمي" : "Rendered locally · No upload · Not a certified record", x, height - 28);
  return canvas.toDataURL("image/png");
}
export function downloadBlob(blob: Blob, filename: string) { const url = URL.createObjectURL(blob); const a = document.createElement("a"); a.href = url; a.download = filename; a.click(); setTimeout(() => URL.revokeObjectURL(url), 10000); }
