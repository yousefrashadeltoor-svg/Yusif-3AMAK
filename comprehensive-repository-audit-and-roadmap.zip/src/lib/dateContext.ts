// Date grounding for the AI: the model is told the exact local date/time/zone and a 15-day lookup table,
// so relative phrases ("بكرة", "الخميس الجاي") map to real ISO dates instead of defaulting to today.
import { dayKey } from "./calendar";

const AR_DAYS = ["الأحد", "الاثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت"];
const EN_DAYS = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

export function utcOffsetLabel(d: Date): string {
  const off = -d.getTimezoneOffset(), sign = off >= 0 ? "+" : "-", a = Math.abs(off);
  return `${sign}${String(Math.floor(a / 60)).padStart(2, "0")}:${String(a % 60).padStart(2, "0")}`;
}

/** ISO-8601 local timestamp with explicit offset, e.g. 2027-05-10T14:30:00+03:00. */
export function localIso(d: Date): string {
  const p = (n: number) => String(n).padStart(2, "0");
  return `${dayKey(d)}T${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}${utcOffsetLabel(d)}`;
}

export function buildDateContext(now = new Date()): string {
  const tz = (() => { try { return Intl.DateTimeFormat().resolvedOptions().timeZone || "local"; } catch { return "local"; } })();
  const rows: string[] = [];
  for (let i = 0; i < 15; i++) {
    const d = new Date(now.getFullYear(), now.getMonth(), now.getDate() + i);
    const tag = i === 0 ? " (today / النهاردة)" : i === 1 ? " (tomorrow / بكرة)" : i === 2 ? " (day after tomorrow / بعد بكرة)" : "";
    rows.push(`${dayKey(d)} = ${EN_DAYS[d.getDay()]} / ${AR_DAYS[d.getDay()]}${tag}`);
  }
  return [
    "== CURRENT DATE & TIME (authoritative, device-local) ==",
    `Now: ${localIso(now)} · time zone: ${tz} (UTC${utcOffsetLabel(now)}) · weekday: ${EN_DAYS[now.getDay()]} / ${AR_DAYS[now.getDay()]} (0=Sunday)`,
    "Calendar lookup (use it; never compute from memory):",
    ...rows,
    "Rules: every addTask/addAlarm/addHabit action MUST carry `date` as ISO YYYY-MM-DD resolved from this table (and `time` as 24h HH:mm).",
    "\"بكرة\"/tomorrow = the row tagged tomorrow, NOT today. A bare weekday name = its first occurrence strictly after today if it is today's weekday and the user said \"الجاي/next\", else the nearest upcoming row.",
    "\"الأسبوع الجاي\" = +7 days from today. \"آخر الشهر\" = last day of the current month. \"أول الشهر الجاي\" = first day of next month.",
    "Add `dateText` with the user's original date phrase. If one message has several commands, each action has its own date.",
  ].join("\n");
}

/** Human confirmation text for a resolved date/time, e.g. «الجمعة ١٤ مايو ٢٠٢٧ · ٧:٠٠ م». */
export function describeWhen(date: string | undefined, time: string | undefined, lang: "ar" | "en", hour12 = true): string {
  const parts: string[] = [];
  if (date && /^\d{4}-\d{2}-\d{2}$/.test(date)) {
    const [y, m, d] = date.split("-").map(Number);
    const local = new Date(y, m - 1, d);
    parts.push(new Intl.DateTimeFormat(lang === "ar" ? "ar-EG" : "en-US", { weekday: "long", day: "numeric", month: "long", year: "numeric" }).format(local));
  }
  if (time && /^\d{2}:\d{2}$/.test(time)) {
    const [h, mi] = time.split(":").map(Number);
    const num = (s: string) => (lang === "ar" ? s.replace(/\d/g, (c) => "٠١٢٣٤٥٦٧٨٩"[+c]) : s);
    const hh = hour12 ? h % 12 || 12 : h;
    parts.push(num(`${hour12 ? hh : String(hh).padStart(2, "0")}:${String(mi).padStart(2, "0")}`) + (hour12 ? (lang === "ar" ? (h < 12 ? " ص" : " م") : h < 12 ? " AM" : " PM") : ""));
  }
  return parts.join(" · ");
}
