import { dayKey, fromKey } from "./calendar";
import { DIMS, reviewDay, type DayRecord, type DimId } from "./review";
import { useStore } from "./store";
export type ReviewRange = "day" | "week" | "month";
export interface ReviewSnapshot {
  version: 1; start: string; end: string; range: ReviewRange; generatedAt: string;
  score: number | null; dimensions: { id: DimId; value: number | null }[];
  tasks: { title: string; date: string; done: boolean }[];
  habits: { name: string; completed: number; due: number }[];
  water: { date: string; ml: number; goal: number }[];
  notesCount: number; journalCount: number;
  daysRecorded: number; narrative: string; lang: "ar" | "en";
}

export function realDayRecord(date: string, state = useStore.getState()): DayRecord {
  const d = fromKey(date), tasks = state.tasks.filter((t) => t.date === date);
  const due = state.habits.filter((h) => (!h.startDate || h.startDate <= date) && (!h.createdAt || dayKey(new Date(h.createdAt)) <= date) && (!h.days?.length || h.days.includes(d.getDay())));
  return { date, tasksPlanned: tasks.length, tasksDone: tasks.filter((t) => t.done).length, reschedules: 0,
    startsOnTime: 0, starts: 0, plannedMin: 0, actualMin: 0, focusMin: 0, breaks: 0,
    waterMl: state.water[date] || 0, waterGoal: state.waterGoal, sleepH: 0, workoutMin: 0, studyMin: 0,
    habitsDue: due.length, habitsDone: due.filter((h) => h.log.includes(date)).length, alarms: 0, alarmsOnTime: 0, snoozes: 0,
    firstHour: 0, lastHour: 0, peakHour: 0, cats: {}, unlogged: ["focus", "planning", "balance", "health", "learning", "recovery", "spiritual"] };
}

export function reviewHistory(days = 30, end = dayKey(new Date())) {
  const d = fromKey(end);
  return Array.from({ length: days }, (_, i) => realDayRecord(dayKey(new Date(d.getFullYear(), d.getMonth(), d.getDate() - days + 1 + i))));
}

export function makeReviewSnapshot(range: ReviewRange, date: string): ReviewSnapshot {
  const state = useStore.getState(), end = fromKey(date);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || Number.isNaN(+end)) throw new Error("Invalid date");
  const length = range === "month" ? end.getDate() : range === "week" ? 7 : 1;
  const keys = Array.from({ length }, (_, i) => dayKey(new Date(end.getFullYear(), end.getMonth(), end.getDate() - length + 1 + i)));
  const days = keys.map((k) => realDayRecord(k, state));
  const reviews = days.map((d) => reviewDay(d, [], { tone: state.reviewTone }));
  const measured = reviews.filter((r) => r.dims.some((d) => d.score !== null));
  const score = measured.length ? Math.round(measured.reduce((n, r) => n + r.score, 0) / measured.length) : null;
  const tasks = state.tasks.filter((t) => keys.includes(t.date)).map(({ title, date, done }) => ({ title, date, done }));
  const habits = state.habits.map((h) => ({ name: state.lang === "ar" ? h.ar || h.en : h.en,
    completed: h.log.filter((k) => keys.includes(k)).length,
    due: keys.filter((k) => (!h.startDate || h.startDate <= k) && (!h.createdAt || dayKey(new Date(h.createdAt)) <= k) && (!h.days?.length || h.days.includes(fromKey(k).getDay()))).length,
  })).filter((h) => h.due || h.completed);
  const done = tasks.filter((t) => t.done).length;
  const narrative = state.lang === "ar" ? `عملت ${done} من ${tasks.length} مهام، وسجّلت ${habits.reduce((n, h) => n + h.completed, 0)} مرة لعاداتك. التقييم بيحسب البيانات اللي سجلتها بس، مش النوم أو التركيز اللي متسجّلوش.` : `You completed ${done} of ${tasks.length} tasks and logged ${habits.reduce((n, h) => n + h.completed, 0)} habits. Only recorded data counts; unlogged sleep and focus are excluded.`;
  return { version: 1, start: keys[0], end: date, range, generatedAt: new Date().toISOString(), score,
    dimensions: DIMS.map((d) => { const v = reviews.map((r) => r.dims.find((x) => x.id === d.id)?.score).filter((v): v is number => v != null); return { id: d.id, value: v.length ? Math.round(v.reduce((a, b) => a + b, 0) / v.length) : null }; }),
    tasks, habits, water: keys.map((k) => ({ date: k, ml: state.water[k] || 0, goal: state.waterGoal })),
    notesCount: state.notes.filter((n) => keys.includes(dayKey(new Date(n.at)))).length,
    journalCount: state.journal.filter((j) => keys.includes(j.date)).length, daysRecorded: measured.length, narrative, lang: state.lang };
}
