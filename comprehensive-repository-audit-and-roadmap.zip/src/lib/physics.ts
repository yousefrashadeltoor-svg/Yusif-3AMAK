// JointPhysicsEngine (web mirror) — deterministic verlet chains with joint limits + spring-damper joints.
// Fixed timestep, capped substeps: stable at low frame rates.

export interface Pt { x: number; y: number; px: number; py: number }
export interface Chain { pts: Pt[]; len: number; rest: number; limit: number }

export function makeChain(ax: number, ay: number, n: number, len: number, rest: number, limit = 1.2): Chain {
  const pts: Pt[] = [];
  for (let i = 0; i <= n; i++) {
    const x = ax + Math.cos(rest) * len * i, y = ay + Math.sin(rest) * len * i;
    pts.push({ x, y, px: x, py: y });
  }
  return { pts, len, rest, limit };
}

const wrap = (a: number) => Math.atan2(Math.sin(a), Math.cos(a));

export function stepChain(c: Chain, ax: number, ay: number, gx: number, gy: number, dt: number, bodyAngle = 0, damping = 0.92, stiffness = 0.08) {
  const p0 = c.pts[0];
  p0.px = p0.x; p0.py = p0.y; p0.x = ax; p0.y = ay;
  for (let i = 1; i < c.pts.length; i++) {
    const p = c.pts[i];
    const vx = (p.x - p.px) * damping, vy = (p.y - p.py) * damping;
    p.px = p.x; p.py = p.y;
    p.x += vx + gx * dt * dt; p.y += vy + gy * dt * dt;
  }
  for (let it = 0; it < 4; it++) {
    for (let i = 1; i < c.pts.length; i++) {
      const a = c.pts[i - 1], b = c.pts[i];
      const ref = i === 1 ? c.rest + bodyAngle : Math.atan2(a.y - c.pts[i - 2].y, a.x - c.pts[i - 2].x);
      let ang = Math.atan2(b.y - a.y, b.x - a.x);
      let d = wrap(ang - ref);
      d -= d * stiffness; // gentle return-to-rest (muscle tone)
      if (d > c.limit) d = c.limit; if (d < -c.limit) d = -c.limit;
      ang = ref + d;
      b.x = a.x + Math.cos(ang) * c.len; b.y = a.y + Math.sin(ang) * c.len;
    }
  }
}

export interface Spring { v: number; w: number }
export function stepSpring(s: Spring, target: number, k: number, c: number, dt: number, min = -1, max = 1) {
  const acc = -k * (s.v - target) - c * s.w;
  s.w += acc * dt; s.v += s.w * dt;
  if (s.v < min) { s.v = min; s.w = 0; } if (s.v > max) { s.v = max; s.w = 0; }
}

/** Kinetic energy proxy of a chain (used by tests/telemetry to assert settling). */
export const chainEnergy = (c: Chain) => c.pts.reduce((e, p) => e + (p.x - p.px) ** 2 + (p.y - p.py) ** 2, 0);
