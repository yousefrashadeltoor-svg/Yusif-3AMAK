import { strToU8, strFromU8, zlibSync, unzlibSync } from "fflate";
import { siYoutube, siFacebook, siWhatsapp, siInstagram, siX, siTiktok, siTelegram, siPinterest, siGithub, siDiscord, siSnapchat, siReddit, siSpotify, siTwitch, siSignal, siVimeo } from "simple-icons";
import type { ReviewSnapshot } from "./reviewShare";

export const SOCIALS = [
  { id: "dayflow", name: "DAYFLOW", color: "2F6F5E", path: "M12 2 15 9 22 12 15 15 12 22 9 15 2 12 9 9Z", type: "username", build: (s: string) => "https://dayflow.app/" + encodeURIComponent(s) },
  { id: "youtube", name: "YouTube", ...siYoutube, type: "username", build: (s: string) => `https://www.youtube.com/@${encodeURIComponent(s)}` },
  { id: "facebook", name: "Facebook", ...siFacebook, type: "username", build: (s: string) => `https://www.facebook.com/${encodeURIComponent(s)}` },
  { id: "whatsapp", name: "WhatsApp", ...siWhatsapp, type: "phone", build: (s: string) => `https://wa.me/${s.replace(/[^\d]/g, "")}` },
  { id: "instagram", name: "Instagram", ...siInstagram, type: "username", build: (s: string) => `https://www.instagram.com/${encodeURIComponent(s)}/` },
  { id: "tiktok", name: "TikTok", ...siTiktok, type: "username", build: (s: string) => `https://www.tiktok.com/@${encodeURIComponent(s)}` },
  { id: "telegram", name: "Telegram", ...siTelegram, type: "username", build: (s: string) => `https://t.me/${encodeURIComponent(s)}` },
  { id: "x", name: "X / Twitter", ...siX, type: "username", build: (s: string) => `https://x.com/${encodeURIComponent(s)}` },
  { id: "pinterest", name: "Pinterest", ...siPinterest, type: "username", build: (s: string) => `https://www.pinterest.com/${encodeURIComponent(s)}/` },
  { id: "github", name: "GitHub", ...siGithub, type: "username", build: (s: string) => `https://github.com/${encodeURIComponent(s)}` },
  { id: "snapchat", name: "Snapchat", ...siSnapchat, type: "username", build: (s: string) => `https://www.snapchat.com/add/${encodeURIComponent(s)}` },
  { id: "reddit", name: "Reddit", ...siReddit, type: "username", build: (s: string) => `https://www.reddit.com/user/${encodeURIComponent(s)}/` },
  { id: "twitch", name: "Twitch", ...siTwitch, type: "username", build: (s: string) => `https://www.twitch.tv/${encodeURIComponent(s)}` },
  { id: "vimeo", name: "Vimeo", ...siVimeo, type: "username", build: (s: string) => `https://vimeo.com/${encodeURIComponent(s)}` },
  { id: "discord", name: "Discord", ...siDiscord, type: "link", build: (s: string) => s },
  { id: "spotify", name: "Spotify", ...siSpotify, type: "link", build: (s: string) => s },
  { id: "signal", name: "Signal", ...siSignal, type: "link", build: (s: string) => s },
];
export type SocialId = typeof SOCIALS[number]["id"];
export function socialLink(id: string, value: string) {
  const p = SOCIALS.find((s) => s.id === id);
  const clean = value.trim().replace(/^@/, "");
  if (!p || !clean) return "";
  if (/^https?:\/\//i.test(value.trim())) return new URL(value.trim()).toString();
  return p.build(clean);
}
export function logoData(id: string): string | undefined {
  const p = SOCIALS.find((s) => s.id === id); if (!p) return undefined;
  const color = "hex" in p ? p.hex : p.color;
  return "data:image/svg+xml," + encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" width="80" height="80" viewBox="0 0 80 80"><rect width="80" height="80" rx="16" fill="white"/><g transform="translate(15 15) scale(2.0833)"><path d="${p.path}" fill="#${color}"/></g></svg>`);
}
export function inferSocial(url: string) {
  return SOCIALS.find((p) => p.id !== "dayflow" && url.includes(p.id === "x" ? "x.com" : p.id === "whatsapp" ? "wa.me" : p.id === "telegram" ? "t.me" : p.id + "."))?.id || "none";
}

function b64url(bytes: Uint8Array) { let s = ""; bytes.forEach((b) => s += String.fromCharCode(b)); return btoa(s).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, ""); }
function unb64(value: string) { const s = atob(value.replace(/-/g, "+").replace(/_/g, "/")); return Uint8Array.from(s, (x) => x.charCodeAt(0)); }
export function reviewPayload(snapshot: ReviewSnapshot) { return b64url(zlibSync(strToU8(JSON.stringify(snapshot)), { level: 9 })); }
export function reviewLink(snapshot: ReviewSnapshot) { return `${location.origin}${location.pathname}#/qr-share/${reviewPayload(snapshot)}`; }
export function decodeReview(value: string): ReviewSnapshot {
  const payload = value.includes("/qr-share/") ? value.split("/qr-share/")[1].split(/[?&]/)[0] : value;
  if (!payload || payload.length > 15000 || !/^[\w-]+$/.test(payload)) throw new Error("Invalid review code");
  const bytes = unzlibSync(unb64(payload));
  if (bytes.byteLength > 180000) throw new Error("Review payload is too large");
  const data = JSON.parse(strFromU8(bytes));
  if (data.version !== 1 || !["day", "week", "month"].includes(data.range) || !Array.isArray(data.tasks) || data.tasks.length > 1500 || !Array.isArray(data.habits) || data.habits.length > 500 || !Array.isArray(data.water) || data.water.length > 31 || typeof data.narrative !== "string" || typeof data.start !== "string" || typeof data.end !== "string" || !Array.isArray(data.dimensions)) throw new Error("Invalid review contents");
  return data as ReviewSnapshot;
}

const esc = (s: string) => s.replace(/([\\;,:])/g, "\\$1").replace(/\n/g, " ");
export const wifiPayload = (ssid: string, password: string, security = "WPA", hidden = false) => `WIFI:T:${security};S:${esc(ssid)};P:${esc(password)};H:${hidden};;`;
export const contactPayload = (name: string, phone: string, email: string) => `MECARD:N:${esc(name)};TEL:${esc(phone)};EMAIL:${esc(email)};;`;

export interface LocalShareMeta { id: string; name: string; mime: string; size: number; createdAt: number }
interface LocalShare extends LocalShareMeta { blob: Blob }
function db() { return new Promise<IDBDatabase>((resolve, reject) => { const r = indexedDB.open("dayflow-qr-files", 1); r.onupgradeneeded = () => r.result.createObjectStore("files", { keyPath: "id" }); r.onsuccess = () => resolve(r.result); r.onerror = () => reject(r.error); }); }
export async function saveLocalShare(file: File): Promise<LocalShareMeta> {
  const record: LocalShare = { id: crypto.randomUUID(), name: file.name, mime: file.type || "application/octet-stream", size: file.size, createdAt: Date.now(), blob: file };
  const d = await db(); await new Promise<void>((res, rej) => { const tx = d.transaction("files", "readwrite"); tx.objectStore("files").put(record); tx.oncomplete = () => res(); tx.onerror = () => rej(tx.error); }); d.close();
  const { blob: _blob, ...meta } = record; return meta;
}
export async function loadLocalShare(id: string): Promise<LocalShare | null> { const d = await db(); const value = await new Promise<LocalShare | null>((res, rej) => { const r = d.transaction("files", "readonly").objectStore("files").get(id); r.onsuccess = () => res(r.result || null); r.onerror = () => rej(r.error); }); d.close(); return value; }
export const localShareLink = (id: string) => `${location.origin}${location.pathname}#/qr-file/${encodeURIComponent(id)}`;
