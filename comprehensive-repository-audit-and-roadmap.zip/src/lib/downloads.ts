// Download manager core: URL extraction, link analysis, engine planning + fallback chain, and the in-WebView
// "http-multipart" / "hls-segments" engines (real multi-connection Range downloads with byte-accurate resume).
// Native engines (yt-dlp, NewPipe, gallery-dl, N_m3u8DL-RE, aria2c, FFmpeg) live in the Android project and are
// reached through nativeBridge; in a plain browser they are reported as unavailable with the real reason.
import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";
import { normalizeUrl, sanitizeFilename, groupFormats, type ParsedUrl, type YtFormat } from "./media";
import { nativeBridge, isAndroidApk } from "./nativeBridge";

export type EngineId = "ytdlp" | "newpipe" | "gallerydl" | "n_m3u8dl" | "aria2c" | "http-multipart" | "hls-segments";
export const ENGINES: Record<EngineId, { name: string; native: boolean; en: string; ar: string }> = {
  ytdlp: { name: "yt-dlp", native: true, en: "Thousands of sites (+FFmpeg merge)", ar: "آلاف المواقع (+دمج FFmpeg)" },
  newpipe: { name: "NewPipe Extractor", native: true, en: "Fast YouTube/SoundCloud extraction", ar: "استخراج سريع ليوتيوب وساوند كلاود" },
  gallerydl: { name: "gallery-dl", native: true, en: "Images, albums, galleries", ar: "الصور والألبومات والمعارض" },
  n_m3u8dl: { name: "N_m3u8DL-RE", native: true, en: "HLS / DASH segmented streams", ar: "بثوث HLS / DASH المجزأة" },
  aria2c: { name: "aria2c", native: true, en: "Multi-connection files, torrents", ar: "ملفات متعددة الاتصالات وتورنت" },
  "http-multipart": { name: "HTTP multipart", native: false, en: "Built-in segmented Range downloader", ar: "محمّل Range مجزّأ مدمج" },
  "hls-segments": { name: "HLS segments", native: false, en: "Built-in HLS segment downloader", ar: "محمّل مقاطع HLS مدمج" },
};
export const DEFAULT_ORDER: EngineId[] = ["ytdlp", "newpipe", "gallerydl", "n_m3u8dl", "aria2c", "hls-segments", "http-multipart"];

/** Robust link extraction from long shared text (http/https/magnet), trimming trailing punctuation. */
export function extractUrls(text: string): string[] {
  const found = text.match(/(?:https?:\/\/|magnet:\?)[^\s<>"'\u200e\u200f]+/gi) || [];
  const bare = text.match(/(?<![\w@/.-])(?:www\.)[a-z0-9-]+\.[a-z]{2,}[^\s<>"']*/gi) || [];
  const clean = [...found, ...bare.map((b) => "https://" + b)].map((u) => u.replace(/[)\]}>.,;:!?،؛'"]+$/g, ""));
  return [...new Set(clean)];
}

export type LinkKind = "hls" | "dash" | "image" | "video" | "audio" | "file" | "page" | "torrent";
export function classifyLink(raw: string): { kind: LinkKind; parsed: ParsedUrl } {
  if (/^magnet:/i.test(raw)) return { kind: "torrent", parsed: { ok: true, url: raw, host: "magnet", site: "generic", kind: "unknown" } };
  const parsed = normalizeUrl(raw);
  const path = parsed.ok ? new URL(parsed.url).pathname.toLowerCase() : "";
  if (/\.m3u8$/.test(path)) return { kind: "hls", parsed };
  if (/\.mpd$/.test(path)) return { kind: "dash", parsed };
  if (/\.torrent$/.test(path)) return { kind: "torrent", parsed };
  if (/\.(jpe?g|png|webp|gif|avif|bmp|svg)$/.test(path)) return { kind: "image", parsed };
  if (/\.(mp4|webm|mkv|mov|avi|m4v|ts)$/.test(path)) return { kind: "video", parsed };
  if (/\.(mp3|m4a|aac|flac|wav|opus|ogg)$/.test(path)) return { kind: "audio", parsed };
  if (/\.[a-z0-9]{2,5}$/.test(path) && !/\.(html?|php|aspx?)$/.test(path)) return { kind: "file", parsed };
  if (parsed.site === "instagram" && parsed.kind === "image") return { kind: "image", parsed };
  return { kind: "page", parsed };
}

/** Smart engine order by link type (user priority list is respected within each plan). */
export function planEngines(kind: LinkKind, site: string, order: EngineId[] = DEFAULT_ORDER, native = isAndroidApk()): EngineId[] {
  const prefs: Record<LinkKind, EngineId[]> = {
    page: site === "youtube" ? ["newpipe", "ytdlp", "n_m3u8dl"] : ["ytdlp", "gallerydl", "n_m3u8dl", "newpipe"],
    image: ["gallerydl", "aria2c", "http-multipart", "ytdlp"],
    hls: ["n_m3u8dl", "hls-segments", "ytdlp", "aria2c"], dash: ["n_m3u8dl", "ytdlp"],
    video: ["aria2c", "http-multipart", "ytdlp"], audio: ["aria2c", "http-multipart", "ytdlp"], file: ["aria2c", "http-multipart"], torrent: ["aria2c"],
  };
  const wanted = prefs[kind];
  // Smart per-type order by default; the user's own priority list (Settings) overrides it only once customised.
  const custom = order.join() !== DEFAULT_ORDER.join();
  void native; // non-native engines stay in the plan so the user sees why each was skipped
  return custom ? [...wanted].sort((a, b) => order.indexOf(a) - order.indexOf(b)) : wanted;
}

export interface ErrInfo { code: string; ar: string; en: string }
/** Turns the real thrown error into a precise, human reason (never a generic "failed"). */
export function explainError(e: unknown): ErrInfo {
  const msg = e instanceof Error ? e.message : String(e);
  const name = e instanceof Error ? e.name : "";
  const http = msg.match(/HTTP (\d{3})/)?.[1];
  if (name === "AbortError" || /timeout|timed out/i.test(msg)) return { code: "timeout", ar: "انتهت مهلة الاتصال (Timeout)", en: "Connection timed out" };
  if (http === "403" || http === "451") return { code: "blocked", ar: `الموقع رفض الطلب (HTTP ${http}) — غالبًا حظر IP أو حماية ضد التحميل`, en: `Server refused the request (HTTP ${http}) — IP block or hotlink protection` };
  if (http === "401") return { code: "auth", ar: "الرابط يحتاج تسجيل دخول/Cookies (HTTP 401)", en: "Login/cookies required (HTTP 401)" };
  if (http === "404" || http === "410") return { code: "gone", ar: `الملف غير موجود أو محذوف (HTTP ${http})`, en: `File not found or removed (HTTP ${http})` };
  if (http === "429") return { code: "rate", ar: "الموقع حدّد معدل الطلبات (HTTP 429)", en: "Rate limited (HTTP 429)" };
  if (http && +http >= 500) return { code: "server", ar: `خطأ في خادم الموقع (HTTP ${http})`, en: `Server error (HTTP ${http})` };
  if (/native-only/.test(msg)) return { code: "native", ar: "هذا المحرك يعمل داخل تطبيق أندرويد فقط", en: "This engine only runs inside the Android app" };
  if (/Failed to fetch|NetworkError|Load failed|CORS/i.test(msg)) return { code: "cors", ar: "المتصفح منع الطلب (CORS) أو الشبكة مقطوعة — الموقع لا يسمح بالتحميل من صفحات الويب", en: "Blocked by the browser (CORS) or the network is down" };
  if (/unsupported|DRM|protected/i.test(msg)) return { code: "unsupported", ar: "صيغة غير مدعومة أو بث محمي", en: "Unsupported format or protected stream" };
  if (/private|login/i.test(msg)) return { code: "private", ar: "رابط خاص", en: "Private link" };
  return { code: "unknown", ar: msg.slice(0, 160), en: msg.slice(0, 160) };
}
export const chainNotice = (failed: EngineId, why: ErrInfo, next: EngineId | undefined, lang: "ar" | "en") => lang === "ar"
  ? `فشلت الأداة الأولى (${ENGINES[failed].name}) بسبب: ${why.ar}.${next ? ` سيتم التحميل بواسطة الأداة (${ENGINES[next].name}).` : " لا توجد أداة تالية."}`
  : `First tool (${ENGINES[failed].name}) failed: ${why.en}.${next ? ` Falling back to (${ENGINES[next].name}).` : " No further tool."}`;

export function filenameFromHeaders(cd: string | null, url: string): string {
  const star = cd?.match(/filename\*=(?:UTF-8'')?([^;]+)/i)?.[1];
  const plain = cd?.match(/filename="?([^";]+)"?/i)?.[1];
  let n = star ? (() => { try { return decodeURIComponent(star.replace(/"/g, "")); } catch { return star; } })() : plain;
  if (!n) { try { n = decodeURIComponent(new URL(url).pathname.split("/").filter(Boolean).pop() || ""); } catch { n = ""; } }
  return sanitizeFilename(n || "download");
}

export interface HlsVariant { url: string; bandwidth: number; height?: number; fps?: number; codecs?: string }
export function parseM3u8(text: string, base: string): { variants: HlsVariant[]; segments: string[]; encrypted: boolean; duration: number } {
  const lines = text.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
  const variants: HlsVariant[] = [], segments: string[] = []; let dur = 0;
  const abs = (u: string) => new URL(u, base).toString();
  for (let i = 0; i < lines.length; i++) {
    const l = lines[i];
    if (l.startsWith("#EXT-X-STREAM-INF:")) {
      const bw = Number(l.match(/BANDWIDTH=(\d+)/)?.[1] || 0), res = l.match(/RESOLUTION=\d+x(\d+)/)?.[1], fps = l.match(/FRAME-RATE=([\d.]+)/)?.[1], codecs = l.match(/CODECS="([^"]+)"/)?.[1];
      const next = lines[i + 1]; if (next && !next.startsWith("#")) variants.push({ url: abs(next), bandwidth: bw, height: res ? +res : undefined, fps: fps ? +fps : undefined, codecs });
    } else if (l.startsWith("#EXTINF:")) dur += parseFloat(l.slice(8)) || 0;
    else if (!l.startsWith("#")) segments.push(abs(l));
  }
  return { variants: variants.sort((a, b) => b.bandwidth - a.bandwidth), segments, encrypted: /#EXT-X-KEY:METHOD=(?!NONE)/.test(text), duration: dur };
}

export interface Analysis {
  url: string; kind: LinkKind; host: string; site: string; secure: boolean; title: string; thumb?: string; author?: string; duration?: number;
  size?: number; mime?: string; rangeOk?: boolean; filename: string;
  formats: Array<{ id: string; label: string; detail: string; size?: number; kind: "video" | "audio" | "image" | "file"; url?: string; height?: number }>;
  engines: EngineId[]; engineNote?: string; native: boolean; fromCache?: boolean;
}
const cache = new Map<string, { at: number; value: Analysis }>();
const fetchT = async (u: string, init: RequestInit = {}, ms = 12000) => { const c = new AbortController(); const t = setTimeout(() => c.abort(), ms); try { return await fetch(u, { ...init, signal: c.signal }); } finally { clearTimeout(t); } };

/** Real analysis of a link: native yt-dlp -J in the APK; otherwise HEAD/Range probe, M3U8 parsing and public oEmbed. */
export async function analyzeLink(raw: string, order: EngineId[] = DEFAULT_ORDER): Promise<Analysis> {
  const { kind, parsed } = classifyLink(raw);
  if (!parsed.ok) throw new Error("invalid link");
  const key = parsed.url;
  const hit = cache.get(key);
  if (hit && Date.now() - hit.at < 10 * 60_000) return { ...hit.value, fromCache: true };
  const native = isAndroidApk();
  const base: Analysis = { url: parsed.url, kind, host: parsed.host, site: parsed.site, secure: parsed.url.startsWith("https:"), title: parsed.host, filename: filenameFromHeaders(null, parsed.url), formats: [], engines: planEngines(kind, parsed.site, order, native), native };
  if (native) {
    try {
      const json = await nativeBridge.analyzeLink?.({ url: parsed.url });
      if (json?.json) {
        const j = JSON.parse(json.json) as { title?: string; uploader?: string; thumbnail?: string; duration?: number; formats?: YtFormat[]; webpage_url_domain?: string };
        const g = groupFormats(j.formats || [], j.duration || 0);
        base.title = j.title || base.title; base.author = j.uploader; base.thumb = j.thumbnail; base.duration = j.duration; base.filename = sanitizeFilename(j.title || "download");
        base.formats = [
          ...g.presets.map((p) => ({ id: p.id, label: p.label, detail: `${p.containers.join(" / ")}${p.fps ? ` · ${p.fps}fps` : ""}${p.hdr ? " · HDR" : ""}`, size: p.size, kind: "video" as const, height: p.height })),
          ...g.audio.map((a) => ({ id: a.id, label: a.label, detail: a.copy ? "stream copy" : "FFmpeg", size: a.size, kind: "audio" as const })),
        ];
        cache.set(key, { at: Date.now(), value: base }); return base;
      }
    } catch (e) { base.engineNote = explainError(e).ar; }
  }
  if (kind === "hls") {
    const r = await fetchT(parsed.url); if (!r.ok) throw new Error("HTTP " + r.status);
    const p = parseM3u8(await r.text(), parsed.url);
    base.duration = p.duration || undefined; base.mime = "application/vnd.apple.mpegurl";
    base.filename = filenameFromHeaders(null, parsed.url).replace(/\.m3u8$/i, "") + ".ts";
    base.formats = p.variants.length ? p.variants.map((v, i) => ({ id: "hls" + i, label: v.height ? `${v.height}p` : `${Math.round(v.bandwidth / 1000)} kbps`, detail: `${Math.round(v.bandwidth / 1000)} kbps${v.fps ? ` · ${v.fps}fps` : ""}${v.codecs ? ` · ${v.codecs.split(",")[0]}` : ""}`, kind: "video" as const, url: v.url, height: v.height }))
      : [{ id: "hls-main", label: "HLS", detail: `${p.segments.length} segments${p.encrypted ? " · encrypted (AES-128)" : ""}`, kind: "video" as const, url: parsed.url }];
  } else if (kind !== "page" && kind !== "torrent") {
    try {
      let r = await fetchT(parsed.url, { headers: { Range: "bytes=0-0" } });
      if (!r.ok) r = await fetchT(parsed.url, { method: "HEAD" });
      r.body?.cancel().catch(() => {});
      const range = r.headers.get("content-range")?.match(/\/(\d+)$/)?.[1];
      base.size = range ? +range : Number(r.headers.get("content-length") || 0) || undefined;
      base.mime = r.headers.get("content-type")?.split(";")[0] || undefined;
      base.rangeOk = r.status === 206 || /bytes/i.test(r.headers.get("accept-ranges") || "");
      base.filename = filenameFromHeaders(r.headers.get("content-disposition"), r.url || parsed.url);
      base.title = base.filename;
    } catch (e) { base.engineNote = explainError(e).ar; }
    const fk: "video" | "audio" | "image" | "file" = kind === "video" ? "video" : kind === "audio" ? "audio" : kind === "image" ? "image" : "file";
    base.formats = [{ id: "original", label: (base.filename.split(".").pop() || "file").toUpperCase(), detail: `${base.mime || "unknown type"}${base.rangeOk ? " · resumable · multi-connection" : ""}`, size: base.size, kind: fk, url: parsed.url }];
    if (kind === "image") base.thumb = parsed.url;
  } else if (kind === "page") {
    try {
      const { fetchPreview } = await import("./media");
      const pv = await fetchPreview(parsed.url);
      base.title = pv.title; base.thumb = pv.thumb; base.author = pv.author; base.duration = pv.duration;
      if (pv.direct) { base.size = pv.direct.size; base.mime = pv.direct.type; }
    } catch (e) { base.engineNote = explainError(e).ar; }
    base.engineNote ||= native ? undefined : "الصيغ الفعلية لمواقع الفيديو يستخرجها yt-dlp/NewPipe داخل تطبيق أندرويد؛ المتصفح لا يستطيع قراءتها (CORS).";
  }
  if (kind !== "torrent") cache.set(key, { at: Date.now(), value: base });
  return base;
}

/* ───────────────────────── store ───────────────────────── */
export type DlState = "queued" | "downloading" | "paused" | "completed" | "failed" | "cancelled";
export interface DlItem {
  id: string; url: string; name: string; kind: LinkKind; host: string; site: string; secure: boolean; thumb?: string; quality?: string; format?: string;
  size: number; got: number; state: DlState; engine?: EngineId; plan: EngineId[]; notices: string[]; error?: string; addedAt: number; doneAt?: number;
  speed: number; eta: number; resumable: boolean; parts: number; partSize: number; priority: number; checksum?: string; savedAs?: string; mime?: string; variantUrl?: string; scheduledAt?: number; saveDir?: string; retries?: number;
}
export interface DlSettings { order: EngineId[]; concurrent: number; connections: number; speedLimitKBps: number; wifiOnly: boolean; autoResume: boolean; autoRetry: number; autoPaste: boolean; nightOnly: boolean; saveDir: string }
interface DlStore { items: DlItem[]; settings: DlSettings; add(i: DlItem): void; patch(id: string, p: Partial<DlItem>): void; remove(id: string): void; setSettings(p: Partial<DlSettings>): void }
export const useDownloads = create<DlStore>()(persist((set) => ({
  items: [],
  settings: { order: DEFAULT_ORDER, concurrent: 3, connections: 6, speedLimitKBps: 0, wifiOnly: false, autoResume: true, autoRetry: 2, autoPaste: true, nightOnly: false, saveDir: "Downloads/DayFlow" },
  add: (i) => set((s) => ({ items: [i, ...s.items] })),
  patch: (id, p) => set((s) => ({ items: s.items.map((x) => (x.id === id ? { ...x, ...p } : x)) })),
  remove: (id) => set((s) => ({ items: s.items.filter((x) => x.id !== id) })),
  setSettings: (p) => set((s) => ({ settings: { ...s.settings, ...p } })),
}), { name: "dayflow-downloads", version: 1, storage: createJSONStorage(() => localStorage), partialize: (s) => ({ items: s.items.map((i) => (i.state === "downloading" ? { ...i, state: "paused" as DlState, speed: 0 } : i)), settings: s.settings }) }));

/* ───────────── IndexedDB part storage (resume across reloads) ───────────── */
let dbp: Promise<IDBDatabase> | null = null;
const db = () => dbp ||= new Promise((res, rej) => { const r = indexedDB.open("dayflow-dl", 1); r.onupgradeneeded = () => r.result.createObjectStore("parts"); r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); });
const tx = async <T,>(mode: IDBTransactionMode, fn: (s: IDBObjectStore) => IDBRequest<T>): Promise<T> => { const d = await db(); return new Promise((res, rej) => { const q = fn(d.transaction("parts", mode).objectStore("parts")); q.onsuccess = () => res(q.result); q.onerror = () => rej(q.error); }); };
export const putPart = (id: string, n: number, b: Blob) => tx("readwrite", (s) => s.put(b, `${id}:${n}`));
export const getPart = (id: string, n: number) => tx<Blob | undefined>("readonly", (s) => s.get(`${id}:${n}`));
export const hasPart = async (id: string, n: number) => (await tx("readonly", (s) => s.count(`${id}:${n}`))) > 0;
export const dropParts = async (id: string) => { const d = await db(); await new Promise<void>((res) => { const t = d.transaction("parts", "readwrite"); t.objectStore("parts").delete(IDBKeyRange.bound(`${id}:`, `${id}:\uffff`)); t.oncomplete = () => res(); t.onerror = () => res(); }); };
export async function assemble(item: DlItem): Promise<Blob> {
  const parts: Blob[] = [];
  for (let i = 0; i < item.parts; i++) { const p = await getPart(item.id, i); if (!p) throw new Error(`missing part ${i}`); parts.push(p); }
  return new Blob(parts, { type: item.mime || "application/octet-stream" });
}

/* ───────────────────────── runtime ───────────────────────── */
const ctl = new Map<string, AbortController>();
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
const connWifiOk = () => { const c = (navigator as unknown as { connection?: { type?: string } }).connection; return !c?.type || c.type === "wifi" || c.type === "ethernet"; };
const patch = (id: string, p: Partial<DlItem>) => useDownloads.getState().patch(id, p);
const get = (id: string) => useDownloads.getState().items.find((i) => i.id === id)!;
export const PART = 4 * 1024 * 1024;

export function createItem(a: Analysis, opt: { name?: string; quality?: string; format?: string; url?: string; priority?: number; scheduledAt?: number } = {}): DlItem {
  const id = Math.random().toString(36).slice(2, 10) + Date.now().toString(36);
  const size = a.formats.find((f) => f.id === opt.format)?.size ?? a.size ?? 0;
  const variantUrl = opt.url || a.formats.find((f) => f.id === opt.format)?.url;
  return { id, url: a.url, name: sanitizeFilename(opt.name || a.filename), kind: a.kind, host: a.host, site: a.site, secure: a.secure, thumb: a.thumb, quality: opt.quality, format: opt.format, size, got: 0, state: "queued", plan: a.engines, notices: [], addedAt: Date.now(), speed: 0, eta: 0, resumable: !!a.rangeOk, parts: 0, partSize: PART, priority: opt.priority ?? 1, mime: a.mime, variantUrl, scheduledAt: opt.scheduledAt };
}

function throttle(id: string) {
  const s = useDownloads.getState().settings; let last = Date.now(), bytes = 0, shown = 0;
  return async (n: number) => {
    bytes += n; const now = Date.now();
    if (s.speedLimitKBps > 0) { const need = (bytes / (s.speedLimitKBps * 1024)) * 1000; const have = now - last; if (need > have) await sleep(need - have); }
    if (now - last >= 1000) { const dt = (now - last) / 1000; patch(id, { speed: bytes / dt, eta: get(id).size ? Math.max(0, (get(id).size - get(id).got) / (bytes / dt)) : 0 }); last = now; bytes = 0; }
    if (now - shown > 250) { shown = now; patch(id, { got: get(id).got }); }
  };
}

async function engineHttp(item: DlItem, signal: AbortSignal) {
  const s = useDownloads.getState().settings; const url = item.variantUrl || item.url;
  const probe = await fetch(url, { headers: { Range: "bytes=0-0" }, signal });
  if (!probe.ok && probe.status !== 206) throw new Error("HTTP " + probe.status);
  const total = probe.status === 206 ? Number(probe.headers.get("content-range")?.split("/")[1] || 0) : Number(probe.headers.get("content-length") || 0);
  const ranged = probe.status === 206 && total > 0; probe.body?.cancel().catch(() => {});
  const name = filenameFromHeaders(probe.headers.get("content-disposition"), url);
  patch(item.id, { size: total || item.size, resumable: ranged, mime: probe.headers.get("content-type")?.split(";")[0] || item.mime, name: item.name === "download" ? name : item.name });
  const pace = throttle(item.id);
  if (!ranged) { // single stream, not resumable (server has no Range support) — said honestly in the UI
    const r = await fetch(url, { signal }); if (!r.ok) throw new Error("HTTP " + r.status);
    const reader = r.body!.getReader(); const chunks: BlobPart[] = []; let got = 0;
    for (;;) { const { done, value } = await reader.read(); if (done) break; chunks.push(value); got += value.length; patch(item.id, { got }); await pace(value.length); }
    await putPart(item.id, 0, new Blob(chunks)); patch(item.id, { parts: 1, got, size: got }); return;
  }
  const parts = Math.ceil(total / PART); patch(item.id, { parts, partSize: PART });
  let next = 0, got = 0;
  for (let i = 0; i < parts; i++) if (await hasPart(item.id, i)) got += Math.min(PART, total - i * PART);
  patch(item.id, { got }); const doneSet = new Set<number>(); for (let i = 0; i < parts; i++) if (await hasPart(item.id, i)) doneSet.add(i);
  const worker = async () => {
    for (;;) {
      while (next < parts && doneSet.has(next)) next++;
      if (next >= parts) return; const i = next++;
      const a = i * PART, b = Math.min(total - 1, a + PART - 1);
      let n = 0;
      for (let attempt = 0; ; attempt++) {
        try {
          const r = await fetch(url, { headers: { Range: `bytes=${a}-${b}` }, signal }); if (r.status !== 206) throw new Error("HTTP " + r.status);
          const reader = r.body!.getReader(); const chunks: BlobPart[] = []; n = 0;
          for (;;) { const { done, value } = await reader.read(); if (done) break; chunks.push(value); n += value.length; patch(item.id, { got: get(item.id).got + value.length }); await pace(value.length); }
          if (n !== b - a + 1) throw new Error("short read");
          await putPart(item.id, i, new Blob(chunks)); break;
        } catch (e) { patch(item.id, { got: Math.max(0, get(item.id).got - n) }); n = 0; if (signal.aborted || attempt >= 3) throw e; await sleep(500 * 2 ** attempt); }
      }
    }
  };
  await Promise.all(Array.from({ length: Math.max(1, Math.min(16, s.connections)) }, worker));
}

async function engineHls(item: DlItem, signal: AbortSignal) {
  const url = item.variantUrl || item.url;
  let r = await fetch(url, { signal }); if (!r.ok) throw new Error("HTTP " + r.status);
  let pl = parseM3u8(await r.text(), url);
  if (pl.variants.length && !pl.segments.length) { const v = pl.variants[0]; r = await fetch(v.url, { signal }); if (!r.ok) throw new Error("HTTP " + r.status); pl = parseM3u8(await r.text(), v.url); }
  if (pl.encrypted) throw new Error("unsupported: encrypted HLS stream");
  if (!pl.segments.length) throw new Error("unsupported: empty playlist");
  patch(item.id, { parts: pl.segments.length, resumable: true, mime: "video/mp2t", size: 0 });
  let next = 0; const pace = throttle(item.id); const total = pl.segments.length;
  const done = new Set<number>(); for (let i = 0; i < total; i++) if (await hasPart(item.id, i)) done.add(i);
  let got = 0; for (const i of done) got += (await getPart(item.id, i))?.size || 0; patch(item.id, { got });
  const worker = async () => { for (;;) { while (done.has(next)) next++; if (next >= total) return; const i = next++;
    for (let a = 0; ; a++) { try { const x = await fetch(pl.segments[i], { signal }); if (!x.ok) throw new Error("HTTP " + x.status); const b = await x.blob(); await putPart(item.id, i, b); patch(item.id, { got: get(item.id).got + b.size, size: Math.round(((get(item.id).got + b.size) / (i + 1)) * total) }); await pace(b.size); break; } catch (e) { if (signal.aborted || a >= 3) throw e; await sleep(400 * 2 ** a); } } } };
  await Promise.all(Array.from({ length: 6 }, worker));
}

async function sha256(b: Blob) { if (b.size > 300e6 || !crypto.subtle) return undefined; const h = await crypto.subtle.digest("SHA-256", await b.arrayBuffer()); return [...new Uint8Array(h)].map((x) => x.toString(16).padStart(2, "0")).join(""); }
export function saveBlob(blob: Blob, name: string) { const u = URL.createObjectURL(blob); const a = document.createElement("a"); a.href = u; a.download = name; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(u), 60_000); }

/** Runs the engine chain for one item. Each failure produces the real reason + the announced fallback. */
export async function runItem(id: string, lang: "ar" | "en" = "ar") {
  const item0 = get(id); if (!item0 || ctl.has(id)) return;
  const st = useDownloads.getState().settings;
  if (st.wifiOnly && !connWifiOk()) { patch(id, { state: "paused", error: lang === "ar" ? "Wi-Fi فقط مفعّل — ينتظر شبكة Wi-Fi" : "Wi-Fi only — waiting for Wi-Fi" }); return; }
  const c = new AbortController(); ctl.set(id, c); patch(id, { state: "downloading", error: undefined });
  const notice: string[] = [...item0.notices];
  const plan = item0.plan.length ? item0.plan : planEngines(item0.kind, item0.site, st.order);
  let lastErr: ErrInfo | null = null;
  for (let k = 0; k < plan.length; k++) {
    const eng = plan[k]; const nextEng = plan[k + 1];
    if (c.signal.aborted) break;
    try {
      if (ENGINES[eng].native) {
        if (!isAndroidApk()) throw new Error("native-only engine");
        patch(id, { engine: eng });
        await nativeBridge.startDownload?.({ id, url: item0.variantUrl || item0.url, name: item0.name, engines: plan.slice(k), format: item0.format || "", quality: item0.quality || "", saveDir: item0.saveDir || st.saveDir, connections: st.connections });
        return; // native engine reports progress through the "dayflow-download" event
      }
      patch(id, { engine: eng });
      if (eng === "hls-segments" && !(item0.kind === "hls" || /\.m3u8/i.test(item0.url))) throw new Error("unsupported: not an HLS playlist");
      if (eng === "hls-segments") await engineHls(get(id), c.signal); else await engineHttp(get(id), c.signal);
      const fin = get(id); const blob = await assemble(fin);
      saveBlob(blob, fin.name.replace(/\.m3u8$/i, ".ts"));
      patch(id, { state: "completed", got: blob.size, size: blob.size, speed: 0, eta: 0, doneAt: Date.now(), checksum: await sha256(blob), savedAs: fin.name, notices: notice });
      ctl.delete(id); return;
    } catch (e) {
      if (c.signal.aborted) { ctl.delete(id); return; }
      lastErr = explainError(e);
      const skippable = lastErr.code === "native";
      const msg = skippable ? (lang === "ar" ? `الأداة (${ENGINES[eng].name}) غير متاحة هنا: ${lastErr.ar}.${nextEng ? ` ننتقل إلى (${ENGINES[nextEng].name}).` : ""}` : `${ENGINES[eng].name} unavailable here: ${lastErr.en}.${nextEng ? ` Trying ${ENGINES[nextEng].name}.` : ""}`) : chainNotice(eng, lastErr, nextEng, lang);
      notice.push(msg); patch(id, { notices: [...notice] });
    }
  }
  ctl.delete(id);
  const tries = get(id)?.retries || 0;
  const auto = st.autoRetry > 0 && !!lastErr && ["timeout", "server", "rate"].includes(lastErr.code) && tries < st.autoRetry;
  patch(id, { state: auto ? "queued" : "failed", speed: 0, retries: tries + (auto ? 1 : 0), error: lastErr ? (lang === "ar" ? lastErr.ar : lastErr.en) : "failed", notices: notice });
  if (auto) { await sleep(2500 * (tries + 1)); if (get(id)?.state === "queued") pump(lang); }
}
export const pauseItem = (id: string) => { ctl.get(id)?.abort(); ctl.delete(id); void nativeBridge.pauseDownload?.({ id }); patch(id, { state: "paused", speed: 0 }); };
export const resumeItem = (id: string, lang: "ar" | "en" = "ar") => { patch(id, { state: "queued", error: undefined }); pump(lang); };
export const cancelItem = (id: string) => { ctl.get(id)?.abort(); ctl.delete(id); void nativeBridge.cancelDownload?.({ id }); patch(id, { state: "cancelled", speed: 0 }); };
export const retryItem = (id: string, lang: "ar" | "en" = "ar") => { patch(id, { state: "queued", error: undefined, notices: [] }); pump(lang); };
export async function deleteItem(id: string, withFile: boolean) { ctl.get(id)?.abort(); ctl.delete(id); if (withFile) await dropParts(id); else await dropParts(id); useDownloads.getState().remove(id); }
export async function openStored(id: string) { const it = get(id); if (!it) return; saveBlob(await assemble(it), it.name); }

/** Queue pump: honours concurrency, priority, schedule and night-only window. Call after any queue change. */
export function pump(lang: "ar" | "en" = "ar") {
  const { items, settings } = useDownloads.getState();
  const running = items.filter((i) => i.state === "downloading").length;
  const hour = new Date().getHours();
  const free = settings.concurrent - running; if (free <= 0) return;
  const ready = items.filter((i) => i.state === "queued" && (!i.scheduledAt || i.scheduledAt <= Date.now()) && (!settings.nightOnly || hour >= 23 || hour < 6)).sort((a, b) => b.priority - a.priority || a.addedAt - b.addedAt).slice(0, free);
  ready.forEach((i) => void runItem(i.id, lang).finally(() => pump(lang)));
}

/** Progress events pushed by the native engines (Foreground Service) → same store the UI reads. */
export function attachNativeEvents() {
  const h = (e: Event) => { const d = (e as CustomEvent).detail as Partial<DlItem> & { id: string; notice?: string }; if (!d?.id || !get(d.id)) return; const { notice, ...rest } = d; patch(d.id, { ...rest, notices: notice ? [...get(d.id).notices, notice] : get(d.id).notices }); };
  window.addEventListener("dayflow-download", h); return () => window.removeEventListener("dayflow-download", h);
}
export { isAndroidApk };
