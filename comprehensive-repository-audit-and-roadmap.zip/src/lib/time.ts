import { useStore } from "./store";

export function clockParts(value: string | Date, hour12: boolean, lang: "ar" | "en", seconds = false) {
  const bits = typeof value === "string" ? value.split(":").map(Number) : [value.getHours(), value.getMinutes(), value.getSeconds()];
  const [h, m, sec = 0] = bits;
  if (!Number.isFinite(h) || !Number.isFinite(m)) return { time: "—", suffix: "", full: "—" };
  const number = (s: string) => lang === "ar" ? s.replace(/\d/g, (d) => "٠١٢٣٤٥٦٧٨٩"[+d]) : s;
  const hour = hour12 ? h % 12 || 12 : h;
  const time = number(`${hour12 ? hour : String(hour).padStart(2, "0")}:${String(m).padStart(2, "0")}${seconds ? ":" + String(sec).padStart(2, "0") : ""}`);
  const suffix = hour12 ? (lang === "ar" ? h < 12 ? "ص" : "م" : h < 12 ? "AM" : "PM") : "";
  return { time, suffix, full: `${time}${suffix ? " " + suffix : ""}` };
}

export function useClockFormat() {
  const hour12 = useStore((s) => s.hour12);
  const lang = useStore((s) => s.lang);
  return (value: string | Date, seconds = false) => clockParts(value, hour12, lang, seconds).full;
}
