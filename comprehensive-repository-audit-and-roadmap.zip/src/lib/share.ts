// Share-intent plumbing: Android (ACTION_SEND → native → "dayflow-share" event / getPendingShare) and PWA share_target (?text=&url=).
import { extractUrls } from "./downloads";
import { nativeBridge } from "./nativeBridge";

let pending: string[] = [];
export const takePendingShare = () => { const p = pending; pending = []; return p; };
export function pushShare(text: string): boolean {
  const urls = extractUrls(text || "");
  if (!urls.length) return false;
  pending = [...new Set([...pending, ...urls])];
  window.dispatchEvent(new CustomEvent("dayflow-share-ready"));
  return true;
}
/** Wire all entry points (cold start + warm start). Returns a cleanup. `open` navigates to the Downloads tab. */
export function initShare(open: () => void) {
  const take = (text?: string) => { if (text && pushShare(text)) open(); };
  const q = new URLSearchParams(location.search);
  const fromQuery = [q.get("url"), q.get("text"), q.get("title")].filter(Boolean).join(" ");
  if (fromQuery) { take(fromQuery); history.replaceState(null, "", location.pathname + location.hash); }
  void nativeBridge.getPendingShare()?.then((r) => take(r?.text)).catch(() => {});
  const h = (e: Event) => take((e as CustomEvent).detail?.text as string);
  window.addEventListener("dayflow-share", h);
  return () => window.removeEventListener("dayflow-share", h);
}
