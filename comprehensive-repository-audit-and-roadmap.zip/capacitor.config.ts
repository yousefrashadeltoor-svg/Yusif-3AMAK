import type { CapacitorConfig } from "@capacitor/cli";

const config: CapacitorConfig = {
  appId: "app.dayflow.android",
  appName: "DAYFLOW",
  webDir: "dist",
  android: {
    allowMixedContent: false,
    backgroundColor: "#f7f5f0",
  },
  server: {
    androidScheme: "https",
  },
};

export default config;
