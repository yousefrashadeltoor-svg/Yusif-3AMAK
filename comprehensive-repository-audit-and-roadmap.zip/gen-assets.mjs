import sharp from "sharp";

const photos = {
  "dawn.jpg": ["#241b3a", "#7a4a6e", "#d79bb0"],
  "noon.jpg": ["#4f93d6", "#9cc8ef", "#dcefff"],
  "asr.jpg": ["#9c6a24", "#c89238", "#f0cf8e"],
  "maghrib.jpg": ["#2c0f1e", "#7e2f3a", "#e0703a"],
  "night.jpg": ["#04060f", "#0b1430", "#16235a"],
  "snow.jpg": ["#b9d2e6", "#dcebf6", "#ffffff"],
  "autumn-tree.jpg": ["#5e2f17", "#9c4f22", "#e3a23a"],
};

const vgrad = (w, h, [a, b, c]) => {
  const g = `<linearGradient id="g" x1="0" y1="0" x2="0" y2="1">
    <stop offset="0%" stop-color="${a}"/><stop offset="55%" stop-color="${b}"/><stop offset="100%" stop-color="${c}"/>
  </linearGradient>`;
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}"><defs>${g}</defs><rect width="${w}" height="${h}" fill="url(#g)"/>
    <circle cx="${w*0.7}" cy="${h*0.32}" r="${h*0.13}" fill="#ffffff" opacity="0.18"/></svg>`;
};

const decorColors = {
  maple: "#c0492b", fallen: "#a85a2a", wind: "#8fb6d6", snow: "#ffffff",
  star: "#ffe27a", sparkle: "#fff0a8", crescent: "#ffe9a8", blossom: "#f7b6d2",
  tulip: "#e26d8a", wave: "#7fc4d6", balloon: "#e26d8a", confetti: "#7ad1a0",
  heart: "#e85d75", lotus: "#f2a9c4", dove: "#dfe7ef", herb: "#6fae5a",
  snowman: "#eaf2f8", gift: "#e07a5f", books: "#9b6bd6",
};

const decorSvg = (color) => `<svg xmlns="http://www.w3.org/2000/svg" width="64" height="64">
  <defs><radialGradient id="r" cx="50%" cy="40%" r="60%">
    <stop offset="0%" stop-color="${color}"/><stop offset="100%" stop-color="${color}" stop-opacity="0.65"/>
  </radialGradient></defs>
  <circle cx="32" cy="30" r="20" fill="url(#r)"/>
  <circle cx="32" cy="30" r="20" fill="none" stroke="#ffffff" stroke-opacity="0.25" stroke-width="2"/>
</svg>`;

import fs from "fs";

(async () => {
  fs.mkdirSync("src/assets/photos", { recursive: true });
  fs.mkdirSync("src/assets/decor", { recursive: true });
  fs.mkdirSync("src/assets/art", { recursive: true });

  for (const [name, cols] of Object.entries(photos)) {
    await sharp(Buffer.from(vgrad(1200, 800, cols))).jpeg({ quality: 82 }).toFile(`src/assets/photos/${name}`);
    console.log("photo", name);
  }
  for (const [name, color] of Object.entries(decorColors)) {
    await sharp(Buffer.from(decorSvg(color))).png().toFile(`src/assets/decor/${name}.png`);
    console.log("decor", name);
  }
  await sharp(Buffer.from(vgrad(1000, 700, ["#05060f", "#0b1430", "#1b2a5a"]))).jpeg({ quality: 82 }).toFile("src/assets/art/cairo-night.jpg");
  await sharp(Buffer.from(vgrad(1000, 700, ["#1a0a2a", "#4a1d52", "#c9542e"]))).jpeg({ quality: 82 }).toFile("src/assets/art/fanous.jpg");
  console.log("art jpgs generated");
  console.log("DONE");
})();
