# Logo map (provider / model family → bundled file)

Source: `@lobehub/icons-static-svg` (MIT) — official brand marks, bundled offline in `src/assets/logos/`. Regenerate with `node scripts/vendor-logos.mjs`.

## Providers
| Provider | id | File |
|---|---|---|
| OpenAI | openai | src/assets/logos/openai.svg |
| Anthropic | anthropic | src/assets/logos/claude-color.svg |
| Google Gemini | gemini | src/assets/logos/gemini-color.svg |
| Groq | groq | src/assets/logos/groq.svg |
| OpenRouter | openrouter | src/assets/logos/openrouter.svg |
| Mistral AI | mistral | src/assets/logos/mistral-color.svg |
| DeepSeek | deepseek | src/assets/logos/deepseek-color.svg |
| xAI (Grok) | xai | src/assets/logos/grok.svg |
| Cohere | cohere | src/assets/logos/cohere-color.svg |
| Together AI | together | src/assets/logos/together-color.svg |
| Fireworks AI | fireworks | src/assets/logos/fireworks-color.svg |
| Perplexity | perplexity | src/assets/logos/perplexity-color.svg |
| Cerebras | cerebras | src/assets/logos/cerebras-color.svg |
| DeepInfra | deepinfra | src/assets/logos/deepinfra-color.svg |
| Novita AI | novita | src/assets/logos/novita-color.svg |
| Hyperbolic | hyperbolic | src/assets/logos/hyperbolic-color.svg |
| SambaNova | sambanova | src/assets/logos/sambanova-color.svg |
| NVIDIA NIM | nvidia | src/assets/logos/nvidia-color.svg |
| Ollama (on this device) | ollama | src/assets/logos/ollama.svg |
| LM Studio (on this device) | lmstudio | src/assets/logos/lmstudio.svg |
| Azure OpenAI | azure | src/assets/logos/azure-color.svg |
| Custom OpenAI-compatible | custom | src/assets/logos/openai.svg |

## Model families (resolved by `modelLogoSlug`)
| Pattern | File |
|---|---|
| `/(^\|\/)(gpt\|o1\|o3\|o4\|chatgpt)/.test(s) \|\| s.includes("openai")` | openai.svg |
| `s.includes("claude") \|\| s.includes("anthropic")` | claude-color.svg |
| `s.includes("gemini")` | gemini-color.svg |
| `s.includes("gemma")` | gemma-color.svg |
| `s.includes("deepseek")` | deepseek-color.svg |
| `s.includes("llama") \|\| s.includes("meta-llama")` | meta-color.svg |
| `s.includes("qwen") \|\| s.includes("qwq")` | qwen-color.svg |
| `s.includes("mistral") \|\| s.includes("mixtral") \|\| s.includes("codestral") \|\| s.includes("pixtral")` | mistral-color.svg |
| `s.includes("grok") \|\| s.includes("x-ai")` | grok.svg |
| `s.includes("command") \|\| s.includes("cohere")` | cohere-color.svg |
| `s.includes("nemotron") \|\| s.includes("nvidia")` | nvidia-color.svg |
| `s.includes("phi-") \|\| s.includes("phi4") \|\| s.includes("microsoft")` | microsoft-color.svg |
| `s.includes("sonar") \|\| s.includes("perplexity")` | perplexity-color.svg |
| `s.includes("kimi") \|\| s.includes("moonshot")` | kimi-color.svg |
| `s.includes("huggingface")` | huggingface-color.svg |
| `s.includes("bedrock") \|\| s.includes("amazon") \|\| s.includes("nova-")` | aws-color.svg |
| `s.includes("glm") \|\| s.includes("zhipu")` | zhipu-color.svg |
| `s.includes("ernie") \|\| s.includes("baidu")` | baidu-color.svg |
| `s.includes("doubao") \|\| s.includes("bytedance")` | bytedance-color.svg |
| `s.includes("minimax")` | minimax-color.svg |
| `s.includes("step-") \|\| s.includes("stepfun")` | stepfun-color.svg |
| `s.includes("yi-") \|\| s.startsWith("01-ai")` | yi-color.svg |
| `s.includes("google/")` | google-color.svg |
| `s.includes("liquid")` | liquid.svg |
| `/^sk-or-v1-/i.test(k)` | openrouter.svg |
| `/^sk-ant-/i.test(k)` | anthropic.svg |
| `/^gsk_/i.test(k)` | groq.svg |
| `/^AIza/i.test(k)` | gemini.svg |
| `/^xai-/i.test(k)` | xai.svg |
| `/^pplx-/i.test(k)` | perplexity.svg |
| `/^csk-/i.test(k)` | cerebras.svg |
| `/^nvapi-/i.test(k)` | nvidia.svg |
| `/^sk-proj-/i.test(k)` | openai.svg |
| `/^sk-[A-Za-z0-9]{32,}$/.test(k)` | deepseek.svg |

Total bundled marks: 53. Fallback (letter in a circle) is used only for user-added custom models with no known family.
