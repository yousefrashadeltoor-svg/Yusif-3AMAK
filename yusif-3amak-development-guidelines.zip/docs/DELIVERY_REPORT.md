# DayFlow v2 upgrade — delivery & audit report (branch `feature/upgrade-v2`)

## Baseline (§0)
Repo `yousefrashadeltoor-svg/Yusif-3AMAK` contains ONE file: `dayflow-specification-volume-two (1).zip` (React 19 + Vite + Tailwind 4 + Zustand UI, Capacitor + Kotlin Android layer). Baseline build **failed**: binary art assets (photos/decor PNGs) were not in the zip → restored with the project's own `scripts/restore-visual-assets.mjs` (licensed sources). Pre-existing: 1 `tsc` error (ModelViewer null) — fixed. 34 unit tests passed at baseline; the Playwright spec was being picked up by Vitest (fixed with `vitest.config.ts`).

## Done and verified here
| § | Result | Evidence |
|---|---|---|
| 1 dates | Root cause: `applyActionsDetailed` only trusted the model's ISO date when `request` was empty (never in chat) → any phrase the regex parser did not know (آخر الشهر, الجمعة بعد الجاية, next …) fell to **today**; one global date for all commands in a message; UTC `toISOString()` date bugs. Fixed: per-clause parsing, model date used when user wording is temporal, new phrases (الأسبوع الجاي, أول/آخر الشهر, بعد شهر, يوم 15, 15 يونيو, 15/06), date-lookup table + UTC offset in the system prompt, confirmation card showing the saved day in words. | `tests/dates-ai.test.ts` (48 cases incl. TZ change, DST, midnight, multi-command) + browser test |
| 2 markdown | react-markdown + remark-gfm + rehype-sanitize + rehype-highlight; copy button, language label, RTL `dir=auto`, streaming-safe, block memoisation, copy as Markdown/text | `tests/markdown.test.tsx`, real Chromium screenshot |
| 3 logos | 53 official marks bundled offline (LobeHub icons, MIT); mono marks use currentColor; letter fallback only for custom models; map in `docs/LOGO_MAP.md` | `tests/logos.test.ts` |
| 5 (web part) | New bottom-nav **Downloads** tab + Home shortcut; link analysis (Range probe, M3U8 parse, oEmbed); in-WebView engines `http-multipart` (parallel Range, IndexedDB parts, byte-exact resume, speed limit) and `hls-segments`; fallback chain with real error reasons and the exact «فشلت الأداة الأولى (X) بسبب …» message; queue/priority/concurrency/Wi-Fi-only/night-only/auto-retry; search/filter/sort; rename/copy/share/open/delete; SHA-256; engine priority UI; share entry points (PWA `share_target`, `dayflow-share` event, `getPendingShare` bridge); clipboard link detection; "must own the content" notices removed | `tests/downloads.test.ts` (13), Playwright |
| 7 about | "Honest limits" block removed; credits list updated | — |

Test totals: Vitest all green (see CI run), Playwright 2/2 in headless Chromium.

## NOT done — stated plainly
* **Native download engines (yt-dlp, NewPipe Extractor, gallery-dl, N_m3u8DL-RE, aria2c, FFmpeg, curl_cffi/QuickJS, cobalt logic, XDM): not integrated, not built, not tested.** This sandbox has no Android SDK/NDK/device, so Kotlin cannot be compiled or run here. The web layer already calls the bridge methods (`analyzeLink`, `startDownload`, `pauseDownload`, `cancelDownload`, `updateEngines`, `openSniffer`, `getPendingShare`) and listens to `dayflow-download` events, but the Kotlin side of those methods **does not exist yet**. In a browser these engines are reported as unavailable with the reason; nothing is simulated. Planned approach: youtubedl-android (yt-dlp + Python + aria2c + FFmpeg modules) in a Foreground Service (`dataSync`), NewPipeExtractor via JitPack as fallback, OkHttp ranged downloader for generic files, WebView `shouldInterceptRequest` sniffer. cobalt is a server project — a local port of its extractors is a large separate task.
* In-app sniffer browser, native notifications with actions, SAF folder picking, MediaStore gallery saving, boot-resume of downloads: need the Android layer (not done). Browser limits: no background downloads when the page is closed; sites without CORS can't be fetched from a web page.
* §6 themes (disable seasonal/time-of-day themes, advanced theme settings, more alarm/widget/notification themes, live previews, decor-only mode, clearer background photo): **not implemented.**
* §4 full audit: static audit only (below); no device testing.
* §9: the 25 features are listed below; none beyond what already exists was implemented (existing: backup export, focus timer, QR scanner/studio, habits, converters). 
* §8 general polish: not done.

## Audit findings (problem → location → severity → fix)
1. Date dropped / today default → store.ts applyActionsDetailed → critical → **fixed**.
2. Multi-command messages shared one date → same → high → **fixed**.
3. UTC date for water/date inputs → AI.tsx, Me.tsx → medium → **fixed**.
4. Build failed without art assets → ambience.ts imports → critical → **fixed** (restore script).
5. `tsc` error ModelViewer.tsx:66 → low → **fixed**.
6. AI/model logos fetched from a CDN at runtime (broke offline) → providers.ts → medium → **fixed**.
7. Markdown shown raw → AI.tsx → high → **fixed**.
8. "Ownership" disclaimer sheet in Media Hub → removed.
9. No `share_target`/shortcuts in manifest → **fixed**; Android SEND filter exists but MainActivity does not forward the URL to the WebView → **open** (needs Kotlin).
10. Android `DownloadForegroundService` only shows an indeterminate notification and downloads nothing → **open**.
11. Service worker caches same-origin only; `sw.js` registration not verified → low → open.
12. API keys in localStorage (plain) → medium → open (encrypt with WebCrypto/Keystore).
13. Alarm engine honours `date`, reschedules on BOOT/TIME_SET/TIMEZONE_CHANGED (read statically, **not run on a device**).

## 25 proposed features (status)
1 encrypted backup — proposed; 2 settings/theme export — proposed; 3 offline voice commands — proposed (needs native STT); 4 prompt templates — proposed; 5 global search — proposed; 6 pomodoro — exists (Focus); 7 smart recurring reminders — proposed; 8 drag-and-drop tasks — kanban exists; 9 biometric lock — needs native; 10 AI daily/weekly summary — proposed; 11 chat export Markdown — proposed; 12 pin/tag chats — proposed; 13 offline OCR — proposed (tesseract.js, large); 14 QR scanner — exists, document scanner proposed; 15 live translation — proposed; 16 local format converter — needs FFmpeg native; 17 compressor — native; 18 trimmer — native; 19 audio extractor — native; 20 built-in player — proposed; 21 night-scheduled downloads — **implemented** (Downloads settings); 22 clipboard link detection — **implemented**; 23 download statistics — partially (total saved); 24 downloads widget — native; 25 App Shortcuts — PWA shortcuts **implemented**, Android static shortcuts/QS tiles need Kotlin.

## Build & run
`npm install && node scripts/restore-visual-assets.mjs && npm run build` → `dist/index.html`. Tests: `npx vitest run`; UI: `npx playwright test` (needs `npx playwright install chromium`). Android: `npx cap sync android && cd android && ./gradlew assembleFullDebug` (unverified here).
