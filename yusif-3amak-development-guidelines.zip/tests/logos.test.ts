import { describe, expect, it } from "vitest";
import { PROVIDERS, modelLogoSlug } from "../src/lib/providers";
import { hasLogo, logoSvg } from "../src/lib/logos";

describe("Section 3 — official logos are bundled for every provider and curated model", () => {
  it("every provider has a local logo", () => {
    const missing = PROVIDERS.filter((p) => !hasLogo(p.logo)).map((p) => p.id);
    expect(missing).toEqual([]);
  });
  it("every curated model resolves (explicit slug or family heuristic) to a local logo", () => {
    const missing: string[] = [];
    for (const p of PROVIDERS) for (const m of p.models) { const slug = m.logo || modelLogoSlug(m.id, p.logo); if (!hasLogo(slug)) missing.push(`${p.id}/${m.id}→${slug}`); }
    expect(missing).toEqual([]);
  });
  it("multi-vendor ids map to the real vendor mark", () => {
    expect(modelLogoSlug("meta-llama/llama-3.3-70b", "openrouter")).toBe("meta-color");
    expect(modelLogoSlug("anthropic/claude-3.5-sonnet", "openrouter")).toBe("claude-color");
    expect(modelLogoSlug("x-ai/grok-4", "openrouter")).toBe("grok");
    expect(modelLogoSlug("microsoft/phi-4", "openrouter")).toBe("microsoft-color");
  });
  it("mono marks use currentColor so they stay visible in dark themes", () => {
    expect(logoSvg("openai")).toContain('fill="currentColor"');
  });
  it("custom unknown models have no mark → letter fallback", () => {
    expect(hasLogo("my-private-model")).toBe(false);
  });
});
