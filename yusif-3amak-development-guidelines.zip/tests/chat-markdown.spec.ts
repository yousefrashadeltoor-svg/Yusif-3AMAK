import { expect, test } from "@playwright/test";

const MD = "## خطة اليوم\n\nده **نص عريض** و *مائل* مع `inline` و [رابط](https://example.com).\n\n- بند أول\n  - بند فرعي\n- [x] تم\n\n| الاسم | القيمة |\n|---|---|\n| أ | 1 |\n\n```ts\nconst answer: number = 42;\n```\n\n<script>window.__xss=1</script>\n\n```dayflow\n{\"actions\":[{\"intent\":\"addTask\",\"title\":\"مكالمة الدكتور\",\"date\":\"2027-05-10\",\"time\":\"17:00\"}]}\n```";

test("AI chat: markdown renders, date comes from the user's words, confirmation card shows the real day", async ({ page }) => {
  await page.clock.install({ time: new Date(2027, 4, 10, 14, 30) });
  await page.addInitScript(() => {
    localStorage.setItem("dayflow-v2", JSON.stringify({ version: 3, state: { lang: "ar", autoTimeTheme: false, apiKeys: [{ id: "k1", provider: "openai", key: "sk-proj-abcdefghijklmnopqrstuvwxyz", label: "t", addedAt: 1 }], activeKeyId: "k1", activeModel: "gpt-4o-mini", companion: { enabled: false, hidden: true, notify: false, bubbles: false, emotion: "idle", sound: false, size: 1, opacity: 1, outfit: "auto" } } }));
  });
  let sentSystem = "";
  await page.route("https://api.openai.com/**", async (route) => {
    const body = JSON.parse(route.request().postData() || "{}");
    sentSystem = body.messages?.[0]?.content || "";
    const chunks = MD.match(/[\s\S]{1,23}/g)!.map((c) => `data: ${JSON.stringify({ choices: [{ delta: { content: c } }] })}\n\n`).join("") + "data: [DONE]\n\n";
    await route.fulfill({ status: 200, contentType: "text/event-stream", body: chunks });
  });
  await page.goto("/#/ai");
  await page.getByRole("textbox", { name: "رسالة" }).fill("ذكرني بمكالمة الدكتور الخميس الجاي الساعة ٥ العصر");
  await page.getByRole("button", { name: "إرسال" }).click();
  await expect(page.locator(".md h2")).toContainText("خطة اليوم");
  await expect(page.locator(".md strong").first()).toHaveText("نص عريض");
  await expect(page.locator(".md table")).toBeVisible();
  await expect(page.locator(".md-code .hljs-keyword").first()).toBeVisible();
  await expect(page.locator(".md-code-bar").first()).toContainText("ts");
  expect(await page.evaluate(() => (window as unknown as { __xss?: number }).__xss)).toBeUndefined();
  expect(sentSystem).toContain("2027-05-10 = Monday");
  expect(sentSystem).toContain("2027-05-11 = Tuesday / الثلاثاء (tomorrow");
  const card = page.getByTestId("confirm-card");
  await expect(card).toHaveAttribute("data-date", "2027-05-13");
  await expect(card).toHaveAttribute("data-time", "17:00");
  await expect(card).toContainText("الخميس");
  await page.screenshot({ path: "/tmp/shot-ai.png" });
  const task = await page.evaluate(() => JSON.parse(localStorage.getItem("dayflow-v2")!).state.tasks[0]);
  expect(task).toMatchObject({ date: "2027-05-13", dueTime: "17:00" });
});

test("Downloads tab renders, analyses a direct link and queues it", async ({ page }) => {
  await page.addInitScript(() => localStorage.setItem("dayflow-v2", JSON.stringify({ version: 3, state: { lang: "ar", autoTimeTheme: false, companion: { enabled: false, hidden: true, notify: false, bubbles: false, emotion: "idle", sound: false, size: 1, opacity: 1, outfit: "auto" } } })));
  await page.route("https://files.example.org/**", (r) => r.fulfill({ status: 206, headers: { "content-range": "bytes 0-0/3000", "content-type": "application/pdf", "access-control-allow-origin": "*", "access-control-expose-headers": "content-range,content-type,accept-ranges", "accept-ranges": "bytes" }, body: "x" }));
  await page.goto("/#/downloads");
  await page.getByLabel("الرابط").fill("بص على ده https://files.example.org/docs/report.pdf شكرا");
  await page.getByLabel("تحليل").click();
  await expect(page.getByText("HTTPS")).toBeVisible();
  await expect(page.getByText("report.pdf").first()).toBeVisible();
  await page.screenshot({ path: "/tmp/shot-dl.png" });
  await page.getByRole("button", { name: "تحميل", exact: true }).click();
  await expect(page.getByText("report.pdf").first()).toBeVisible();
});
