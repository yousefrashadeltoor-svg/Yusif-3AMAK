import { beforeEach, describe, expect, it } from "vitest";
import { dayKey } from "../src/lib/calendar";
import { applyActionsDetailed, nextAlarmTime, useStore } from "../src/lib/store";
import { clauseForAction, hasTemporalHint, parseDateIntent, parseTimeIntent, splitClauses } from "../src/lib/temporal";
import { buildDateContext, describeWhen, localIso } from "../src/lib/dateContext";

const now = new Date(2027, 4, 10, 14, 30); // Monday 10 May 2027
const go = () => {};
beforeEach(() => { useStore.getState().set({ alarms: [], tasks: [], habits: [] }); });

describe("Section 1.3 — deterministic date resolution", () => {
  it.each([
    ["النهاردة", "2027-05-10"], ["اليوم", "2027-05-10"], ["today", "2027-05-10"],
    ["بكرة", "2027-05-11"], ["بكره", "2027-05-11"], ["غدا", "2027-05-11"],
    ["بعد بكرة", "2027-05-12"], ["بعد بكره", "2027-05-12"],
    ["بعد 3 أيام", "2027-05-13"], ["بعد ٣ ايام", "2027-05-13"], ["in 3 days", "2027-05-13"],
    ["الخميس الجاي", "2027-05-13"], ["يوم الخميس اللي جاي", "2027-05-13"], ["next thursday", "2027-05-13"],
    ["الأسبوع الجاي", "2027-05-17"], ["next week", "2027-05-17"], ["بعد أسبوع", "2027-05-17"],
    ["أول الشهر الجاي", "2027-06-01"], ["first of next month", "2027-06-01"],
    ["آخر الشهر", "2027-05-31"], ["الشهر الجاي", "2027-06-10"], ["بعد شهرين", "2027-07-10"],
    ["15 يونيو", "2027-06-15"], ["١٥ يونيو ٢٠٢٨", "2028-06-15"], ["يوم 20", "2027-05-20"], ["يوم 5", "2027-06-05"],
    ["2027-12-25", "2027-12-25"], ["25/12/2027", "2027-12-25"], ["١٥/٠٦/٢٠٢٧", "2027-06-15"],
  ])("%s → %s", (text, expected) => {
    expect(parseDateIntent(text, now)).toMatchObject({ kind: "date", date: expected });
  });

  it("'بعد ساعتين' is a time offset on today", () => {
    expect(parseTimeIntent("بعد ساعتين", now)).toMatchObject({ kind: "time", time: "16:30", date: "2027-05-10", relative: true });
  });

  it("an order issued just before midnight for 'بكرة' lands on the next calendar day", () => {
    const late = new Date(2027, 4, 10, 23, 58);
    expect(parseDateIntent("بكرة", late)).toMatchObject({ date: "2027-05-11" });
    expect(parseTimeIntent("بعد ساعتين", late)).toMatchObject({ date: "2027-05-11", time: "01:58" });
  });

  it("month and year roll-over is correct (Dec 31 → Jan 1, Jan 31 + 1 month clamps)", () => {
    expect(parseDateIntent("بكرة", new Date(2027, 11, 31, 22))).toMatchObject({ date: "2028-01-01" });
    expect(parseDateIntent("الشهر الجاي", new Date(2027, 0, 31))).toMatchObject({ date: "2027-02-28" });
    expect(parseDateIntent("أول الشهر الجاي", new Date(2027, 11, 15))).toMatchObject({ date: "2028-01-01" });
  });

  it("spring-forward DST day does not shift calendar math", () => {
    const d = new Date(2027, 2, 13, 23, 0); // day before US DST change in most zones
    expect(parseDateIntent("بعد بكرة", d)).toMatchObject({ date: "2027-03-15" });
    expect(parseDateIntent("بعد أسبوع", d)).toMatchObject({ date: "2027-03-20" });
  });
});

describe("Section 1.3 — time-zone change", () => {
  const instant = Date.UTC(2027, 4, 10, 22, 30); // 22:30 UTC
  const zones: Array<[string, string, string]> = [["UTC", "2027-05-10", "2027-05-11"], ["Asia/Tokyo", "2027-05-11", "2027-05-12"], ["America/Los_Angeles", "2027-05-10", "2027-05-11"], ["Africa/Cairo", "2027-05-11", "2027-05-12"]];
  it.each(zones)("tomorrow is computed in the device zone (%s)", (tz, today, tomorrow) => {
    const prev = process.env.TZ;
    process.env.TZ = tz;
    try {
      const d = new Date(instant);
      expect(dayKey(d)).toBe(today);
      expect(parseDateIntent("بكرة", d)).toMatchObject({ date: tomorrow });
      expect(buildDateContext(d)).toContain(`${tomorrow} =`);
      expect(localIso(d).startsWith(today)).toBe(true);
    } finally { if (prev === undefined) delete process.env.TZ; else process.env.TZ = prev; }
  });
});

describe("Section 1 — root-cause regression: model's ISO date must not be dropped", () => {
  it("uses the model's date when the user wording is a date phrase the local parser cannot resolve", () => {
    const out = applyActionsDetailed([{ intent: "addTask", title: "اجتماع", date: "2027-05-21", time: "10:00" }], go, "ضيف مهمة اجتماع الجمعة بعد الجاية الساعة ١٠ الصبح", now);
    expect(out.issues).toEqual([]);
    expect(useStore.getState().tasks[0]).toMatchObject({ date: "2027-05-21", dueTime: "10:00" });
    expect(out.records[0]).toMatchObject({ kind: "task", date: "2027-05-21", source: "model" });
  });
  it("text-derived date overrides a wrong model date (model said today)", () => {
    applyActionsDetailed([{ intent: "addTask", title: "دفع الفاتورة", date: "2027-05-10" }], go, "ذكرني بدفع الفاتورة بكرة", now);
    expect(useStore.getState().tasks[0].date).toBe("2027-05-11");
  });
  it("a model date is ignored when the user used no date wording at all", () => {
    applyActionsDetailed([{ intent: "addTask", title: "قراءة", date: "2027-06-01" }], go, "ضيف مهمة قراءة", now);
    expect(useStore.getState().tasks[0].date).toBe("2027-05-10");
  });
  it("schedules an alarm for the model date, and nextAlarmTime points to that day (not today)", () => {
    const out = applyActionsDetailed([{ intent: "addAlarm", date: "2027-05-14", time: "08:00", days: "", label: "فجر" }], go, "صحيني يوم الجمعة الساعة ٨ الصبح", now);
    expect(out.issues).toEqual([]);
    expect(useStore.getState().alarms[0]).toMatchObject({ date: "2027-05-14", time: "08:00", days: [] });
    expect(dayKey(nextAlarmTime(useStore.getState().alarms, now)!.at)).toBe("2027-05-14");
  });
  it("last-day-of-month and first-of-next-month tasks resolve", () => {
    applyActionsDetailed([{ intent: "addTask", title: "تقفيل" }], go, "ضيف مهمة تقفيل آخر الشهر", now);
    applyActionsDetailed([{ intent: "addTask", title: "إيجار" }], go, "ضيف مهمة إيجار أول الشهر الجاي", now);
    expect(useStore.getState().tasks.map((t) => t.date).sort()).toEqual(["2027-05-31", "2027-06-01"]);
  });
});

describe("Section 1.3 — several commands in one message with different dates", () => {
  const request = "ضيف مهمة مكالمة الدكتور بكرة الساعة ٥ العصر وبعدين اعمل منبه الجمعة الجاية الساعة ٧ الصبح وكمان ضيف مهمة تسليم المشروع بعد ٣ أيام";
  it("splits into one clause per command", () => {
    expect(splitClauses(request)).toHaveLength(3);
    expect(clauseForAction(request, "تسليم المشروع", 2, 3)).toContain("بعد ٣ أيام");
  });
  it("each action gets its own date", () => {
    const out = applyActionsDetailed([
      { intent: "addTask", title: "مكالمة الدكتور", date: "2027-05-10", time: "17:00" },
      { intent: "addAlarm", date: "2027-05-14", time: "07:00", days: "", label: "منبه" },
      { intent: "addTask", title: "تسليم المشروع", date: "2027-05-10" },
    ], go, request, now);
    expect(out.issues).toEqual([]);
    const st = useStore.getState();
    expect(st.tasks.find((t) => t.title === "مكالمة الدكتور")).toMatchObject({ date: "2027-05-11", dueTime: "17:00" });
    expect(st.tasks.find((t) => t.title === "تسليم المشروع")?.date).toBe("2027-05-13");
    expect(st.alarms[0]).toMatchObject({ date: "2027-05-14", time: "07:00" });
  });
  it("matches clauses by wording when the model reorders the actions", () => {
    const out = applyActionsDetailed([
      { intent: "addTask", title: "تسليم المشروع" },
      { intent: "addTask", title: "مكالمة الدكتور", time: "17:00" },
    ], go, "ضيف مهمة مكالمة الدكتور بكرة الساعة ٥ العصر وبعدين ضيف مهمة تسليم المشروع بعد ٣ أيام", now);
    expect(out.issues).toEqual([]);
    expect(useStore.getState().tasks.find((t) => t.title === "تسليم المشروع")?.date).toBe("2027-05-13");
    expect(useStore.getState().tasks.find((t) => t.title === "مكالمة الدكتور")?.date).toBe("2027-05-11");
  });
});

describe("AI date context + confirmation text", () => {
  it("system context lists today, tomorrow and 15 days with weekday names and the zone", () => {
    const c = buildDateContext(now);
    expect(c).toContain("2027-05-10 = Monday / الاثنين (today");
    expect(c).toContain("2027-05-11 = Tuesday / الثلاثاء (tomorrow");
    expect(c).toContain("2027-05-24");
    expect(c).toMatch(/UTC[+-]\d\d:\d\d/);
  });
  it("describeWhen renders weekday, day, month, year and 12-hour time", () => {
    expect(describeWhen("2027-05-14", "08:00", "ar")).toContain("الجمعة");
    expect(describeWhen("2027-05-14", "19:00", "en")).toBe("Friday, May 14, 2027 · 7:00 PM");
  });
  it("hasTemporalHint distinguishes date wording from none", () => {
    expect(hasTemporalHint("الجمعة بعد الجاية")).toBe(true);
    expect(hasTemporalHint("ضيف مهمة قراءة")).toBe(false);
  });
});
