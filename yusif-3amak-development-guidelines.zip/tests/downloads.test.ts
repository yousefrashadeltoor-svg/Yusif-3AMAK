import "fake-indexeddb/auto";
import { beforeEach, describe, expect, it, vi } from "vitest";
import { analyzeLink, chainNotice, classifyLink, createItem, explainError, extractUrls, filenameFromHeaders, parseM3u8, pauseItem, planEngines, resumeItem, runItem, useDownloads, hasPart, PART, type Analysis } from "../src/lib/downloads";

const saved: string[] = [];
(globalThis as any).document = { createElement: () => ({ click() { saved.push("click"); }, remove() {} }), body: { appendChild() {} } };

const DATA = new Uint8Array(PART * 2 + 12345).map((_, i) => (i * 7) % 251);
function rangeServer(opts: { ranges?: boolean; failFirst?: number; status?: number } = {}) {
  let calls = 0;
  return vi.fn(async (_url: string, init: RequestInit = {}) => {
    calls++;
    if (opts.status) return new Response("no", { status: opts.status });
    if (opts.failFirst && calls <= opts.failFirst) return new Response("x", { status: 503 });
    const h = new Headers(init.headers); const r = h.get("range")?.match(/bytes=(\d+)-(\d+)/);
    if (r && opts.ranges !== false) { const a = +r[1], b = Math.min(+r[2], DATA.length - 1); return new Response(DATA.slice(a, b + 1), { status: 206, headers: { "content-range": `bytes ${a}-${b}/${DATA.length}`, "content-type": "video/mp4", "content-disposition": 'attachment; filename="clip.mp4"' } }); }
    return new Response(DATA, { status: 200, headers: { "content-length": String(DATA.length) } });
  });
}
const analysis = (over: Partial<Analysis> = {}): Analysis => ({ url: "https://cdn.example.com/clip.mp4", kind: "video", host: "cdn.example.com", site: "generic", secure: true, title: "clip", filename: "clip.mp4", formats: [], engines: ["aria2c", "http-multipart"], native: false, rangeOk: true, ...over });
beforeEach(() => { useDownloads.setState({ items: [] }); saved.length = 0; });

describe("link handling", () => {
  it("extracts the link out of a long share text, ignoring trailing punctuation", () => {
    expect(extractUrls("شوف الفيديو ده 😍 https://youtu.be/abc123?si=xyz. وكمان (https://example.com/a.mp4)!")).toEqual(["https://youtu.be/abc123?si=xyz", "https://example.com/a.mp4"]);
    expect(extractUrls("magnet:?xt=urn:btih:abc&dn=x")).toHaveLength(1);
    expect(extractUrls("no link here")).toEqual([]);
  });
  it("classifies links and plans engines by type (images→gallery-dl, HLS→N_m3u8DL-RE, file→aria2c)", () => {
    expect(classifyLink("https://a.com/x.m3u8").kind).toBe("hls");
    expect(planEngines("image", "x")[0]).toBe("gallerydl");
    expect(planEngines("hls", "generic")[0]).toBe("n_m3u8dl");
    expect(planEngines("file", "generic")[0]).toBe("aria2c");
    expect(planEngines("page", "youtube")[0]).toBe("newpipe");
    expect(planEngines("page", "vimeo", ["gallerydl", "ytdlp", "newpipe", "n_m3u8dl", "aria2c", "hls-segments", "http-multipart"])[0]).toBe("gallerydl");
  });
  it("parses HLS master + media playlists", () => {
    const m = parseM3u8("#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=800000,RESOLUTION=640x360\nlow.m3u8\n#EXT-X-STREAM-INF:BANDWIDTH=2800000,RESOLUTION=1280x720,FRAME-RATE=30\nhi.m3u8", "https://h.com/a/master.m3u8");
    expect(m.variants[0]).toMatchObject({ height: 720, url: "https://h.com/a/hi.m3u8", fps: 30 });
    const s = parseM3u8("#EXTM3U\n#EXTINF:4.0,\nseg0.ts\n#EXTINF:4.0,\nseg1.ts\n#EXT-X-ENDLIST", "https://h.com/a/p.m3u8");
    expect(s.segments).toEqual(["https://h.com/a/seg0.ts", "https://h.com/a/seg1.ts"]); expect(s.duration).toBe(8);
    expect(parseM3u8("#EXT-X-KEY:METHOD=AES-128,URI=\"k\"\n#EXTINF:1,\ns.ts", "https://h.com/p.m3u8").encrypted).toBe(true);
  });
  it("file name from Content-Disposition (RFC 5987) or URL", () => {
    expect(filenameFromHeaders("attachment; filename*=UTF-8''%D9%85%D9%84%D9%81.pdf", "https://x.com/a")).toBe("ملف.pdf");
    expect(filenameFromHeaders(null, "https://x.com/dir/report%20final.zip?x=1")).toBe("report final.zip");
  });
});

describe("real error reasons + fallback notice", () => {
  it("maps real failures to precise causes", () => {
    expect(explainError(new Error("HTTP 403")).code).toBe("blocked");
    expect(explainError(new Error("HTTP 404")).code).toBe("gone");
    expect(explainError(new Error("HTTP 429")).code).toBe("rate");
    expect(explainError(new Error("HTTP 503")).code).toBe("server");
    expect(explainError(new TypeError("Failed to fetch")).code).toBe("cors");
    expect(explainError(Object.assign(new Error("x"), { name: "AbortError" })).code).toBe("timeout");
  });
  it("announces the failed tool, the reason and the next tool", () => {
    const n = chainNotice("ytdlp", explainError(new Error("HTTP 403")), "newpipe", "ar");
    expect(n).toContain("فشلت الأداة الأولى (yt-dlp) بسبب:"); expect(n).toContain("سيتم التحميل بواسطة الأداة (NewPipe Extractor)");
  });
});

describe("http-multipart engine (real Range logic against a mock server)", () => {
  it("downloads with parallel Range parts, byte-exact, with checksum and completion", async () => {
    vi.stubGlobal("fetch", rangeServer());
    const it = createItem(analysis()); useDownloads.getState().add(it);
    await runItem(it.id);
    const done = useDownloads.getState().items[0];
    expect(done.state).toBe("completed"); expect(done.got).toBe(DATA.length); expect(done.parts).toBe(3); expect(done.checksum).toMatch(/^[0-9a-f]{64}$/); expect(saved).toContain("click");
    expect(done.notices.some((n) => n.includes("aria2c"))).toBe(true); // native engine skipped with a real reason, then http-multipart ran
    expect(done.engine).toBe("http-multipart");
  });
  it("resumes after pause without re-downloading finished parts", async () => {
    const srv = rangeServer(); vi.stubGlobal("fetch", srv);
    const it = createItem(analysis({ engines: ["http-multipart"] })); useDownloads.getState().add(it);
    useDownloads.getState().setSettings({ connections: 1 });
    // simulate an interrupted run: part 0 already stored
    const { putPart } = await import("../src/lib/downloads"); await putPart(it.id, 0, new Blob([DATA.slice(0, PART)]));
    await runItem(it.id);
    const requested = srv.mock.calls.map((c) => (c[1]?.headers as Record<string, string>)?.Range).filter(Boolean);
    expect(requested).not.toContain(`bytes=0-${PART - 1}`); expect(await hasPart(it.id, 0)).toBe(true);
    expect(useDownloads.getState().items[0]).toMatchObject({ state: "completed", got: DATA.length });
    useDownloads.getState().setSettings({ connections: 6 });
  });
  it("falls back to a single non-resumable stream when the server has no Range support", async () => {
    vi.stubGlobal("fetch", rangeServer({ ranges: false }));
    const it = createItem(analysis({ engines: ["http-multipart"], rangeOk: false })); useDownloads.getState().add(it);
    await runItem(it.id);
    expect(useDownloads.getState().items[0]).toMatchObject({ state: "completed", resumable: false, got: DATA.length });
  });
  it("fails with the real reason and the exact chain message when every engine fails", async () => {
    vi.stubGlobal("fetch", rangeServer({ status: 403 }));
    useDownloads.getState().setSettings({ autoRetry: 0 });
    const it = createItem(analysis({ engines: ["aria2c", "http-multipart"] })); useDownloads.getState().add(it);
    await runItem(it.id, "ar");
    const f = useDownloads.getState().items[0];
    expect(f.state).toBe("failed"); expect(f.error).toContain("HTTP 403"); expect(f.notices.join("\n")).toContain("aria2c");
  });
  it("pause marks the item paused and stops the controller", async () => {
    vi.stubGlobal("fetch", rangeServer());
    const it = createItem(analysis()); useDownloads.getState().add(it); pauseItem(it.id);
    expect(useDownloads.getState().items[0].state).toBe("paused"); resumeItem(it.id);
    expect(useDownloads.getState().items[0].state).toMatch(/queued|downloading|completed/);
  });
});

describe("analysis", () => {
  it("probes a direct file for size, mime, range support and file name (cached 2nd time)", async () => {
    const srv = rangeServer(); vi.stubGlobal("fetch", srv);
    const a = await analyzeLink("https://files.example.org/some/clip.mp4");
    expect(a).toMatchObject({ kind: "video", size: DATA.length, rangeOk: true, filename: "clip.mp4", secure: true });
    const n = srv.mock.calls.length; const b = await analyzeLink("https://files.example.org/some/clip.mp4");
    expect(b.fromCache).toBe(true); expect(srv.mock.calls.length).toBe(n);
  });
  it("rejects invalid input", async () => { await expect(analyzeLink("not a link")).rejects.toThrow(); });
});
