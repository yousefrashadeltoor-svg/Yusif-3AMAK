import { describe, expect, it } from "vitest";
import { renderToStaticMarkup } from "react-dom/server";
import { Markdown, completeStreaming, markdownToPlain, splitBlocks } from "../src/components/Markdown";

const html = (t: string, streaming = false) => renderToStaticMarkup(<Markdown text={t} streaming={streaming} />);

describe("Markdown renderer (section 2)", () => {
  it("renders headings H1–H6, bold, italic, strikethrough — no raw markers", () => {
    const out = html("# a\n## b\n### c\n#### d\n##### e\n###### f\n\n**bold** *it* ~~del~~");
    for (const h of ["h1", "h2", "h3", "h4", "h5", "h6"]) expect(out).toContain(`<${h}`);
    expect(out).toContain("<strong>bold</strong>"); expect(out).toContain("<em>it</em>"); expect(out).toContain("<del>del</del>");
    expect(out).not.toContain("**"); expect(out).not.toContain("##");
  });
  it("renders nested lists, task lists, quotes, hr, tables", () => {
    const out = html("- a\n  - b\n1. x\n2. y\n\n- [x] done\n- [ ] todo\n\n> quote\n\n---\n\n| h1 | h2 |\n|---|---|\n| 1 | 2 |");
    expect(out).toContain("<ul>"); expect(out).toContain("<ol>"); expect(out).toContain('type="checkbox"'); expect(out).toContain("<blockquote");
    expect(out).toContain("<hr"); expect(out).toContain('class="md-table"'); expect(out).toContain("<th");
  });
  it("code block: language label, copy button, highlight spans, monospace container, LTR", () => {
    const out = html("```ts\nconst a: number = 1;\n```");
    expect(out).toContain("md-code"); expect(out).toContain(">ts<"); expect(out).toContain("md-copy"); expect(out).toContain("hljs-keyword"); expect(out).toContain('dir="ltr"');
  });
  it("inline code and links (safe rel + target)", () => {
    const out = html("`x` and [site](https://example.com)");
    expect(out).toContain("<code>x</code>"); expect(out).toContain('rel="noopener noreferrer nofollow"'); expect(out).toContain('target="_blank"');
  });
  it("sanitises: no script, no event handlers, no javascript: links, no raw iframes", () => {
    const out = html('<script>alert(1)</script><img src=x onerror=alert(1)>[x](javascript:alert(1))<iframe src="https://evil"></iframe>');
    expect(out).not.toMatch(/<script/i); expect(out).not.toMatch(/onerror/i); expect(out).not.toMatch(/href="javascript/i); expect(out).not.toMatch(/<iframe/i);
  });
  it("RTL / mixed Arabic + English + code keep dir=auto blocks", () => {
    const out = html("## عنوان عربي\n\nنص عربي مع `code` و English words\n\n- بند أول\n");
    expect(out).toContain('<h2 dir="auto"'); expect(out).toContain('<p dir="auto"'); expect(out).toContain('<li dir="auto"');
  });
  it("streaming: unclosed fence / bold / inline code / dangling link never leak raw markers", () => {
    expect(completeStreaming("```js\nlet a")).toMatch(/```$/);
    expect(html("هذا **نص عريض", true)).toContain("<strong>");
    expect(html("use `npm ins", true)).toContain("<code>npm ins</code>");
    expect(html("see [docs](https://exa", true)).not.toContain("](");
  });
  it("splitBlocks keeps fenced code (with blank lines) in one block", () => {
    const blocks = splitBlocks("para\n\n```py\na\n\nb\n```\n\nend");
    expect(blocks.some((b) => b.includes("a\n\nb"))).toBe(true);
  });
  it("plain-text export strips syntax", () => {
    expect(markdownToPlain("# T\n**b** `c` [l](https://x.y)")).toBe("T\nb c l (https://x.y)");
  });
});
