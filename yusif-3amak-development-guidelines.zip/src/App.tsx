import { useEffect, useState } from "react";
import { Sun, CalendarDays, AlarmClock, LayoutGrid, User, Plus, ListPlus, StickyNote, BellPlus, MoreHorizontal, Droplet, Timer, Link2, Hourglass, BookHeart, Sparkles, Bot, Download } from "lucide-react";
import { useStore, useT } from "./lib/store";
import { applyTheme, THEMES, withViewTransition } from "./lib/themes";
import { Today } from "./screens/Today";
import { CalendarScreen } from "./screens/CalendarScreen";
import { Alarms } from "./screens/Alarms";
import { Tools } from "./screens/Tools";
import { Me } from "./screens/Me";
import { AI } from "./screens/AI";
import { Downloads } from "./screens/Downloads";
import { initShare } from "./lib/share";
import { Companion } from "./components/Companion";
import { Particles, useDecor } from "./components/Decor";
import { Sheet } from "./components/ui";
import { PERIODS, periodAt } from "./lib/ambience";
import { prayerTimes, CITIES } from "./lib/prayer";
import { QRShareViewer } from "./screens/QRShareViewer";

type Tab = "today" | "calendar" | "alarms" | "tools" | "me" | "ai" | "downloads";
const parseHash = (): { tab: Tab; sub?: string } => {
  const [, tab, sub] = location.hash.replace(/^#/, "").split("/");
  return { tab: (["today", "calendar", "alarms", "tools", "me", "ai", "downloads"].includes(tab) ? tab : "today") as Tab, sub: sub || undefined };
};

export default function App() {
  const s = useStore();
  const t = useT();
  const [route, setRoute] = useState(parseHash);
  const [quick, setQuick] = useState(false);
  const decor = useDecor();

  const [clock, setClock] = useState(() => new Date());
  useEffect(() => { const i = setInterval(() => setClock(new Date()), 60000); return () => clearInterval(i); }, []);
  const pt = prayerTimes(CITIES[s.cityIndex] || CITIES[0], clock);
  const period = periodAt(clock, pt);
  const periodInfo = PERIODS[period];
  const autoId = s.periodThemes[period] || periodInfo.theme;
  const all = [...THEMES, ...s.customThemes];
  const theme = (s.autoTimeTheme ? all.find((x) => x.id === autoId) : null) || all.find((x) => x.id === s.themeId) || THEMES[0];
  useEffect(() => { applyTheme(theme); }, [theme]);
  useEffect(() => { document.documentElement.lang = s.lang; document.documentElement.dir = s.lang === "ar" ? "rtl" : "ltr"; document.title = s.lang === "ar" ? "DAYFLOW — يومك بهدوء" : "DAYFLOW — your day, calmly"; }, [s.lang]);
  useEffect(() => { document.documentElement.classList.toggle("reduce-motion", s.reduceMotion); }, [s.reduceMotion]);
  useEffect(() => { const h = () => setRoute(parseHash()); window.addEventListener("hashchange", h); window.addEventListener("popstate", h); return () => { window.removeEventListener("hashchange", h); window.removeEventListener("popstate", h); }; }, []);

  useEffect(() => initShare(() => { history.pushState(null, "", "#/downloads"); setRoute({ tab: "downloads" }); }), []);

  const go = (tab: string, sub?: string) => {
    const hash = "#/" + tab + (sub ? "/" + sub : "");
    withViewTransition(() => { if (location.hash !== hash) history.pushState(null, "", hash); setRoute({ tab: tab as Tab, sub }); });
    window.scrollTo({ top: 0 });
  };

  const tabs: Array<[Tab, typeof Sun, string]> = [
    ["today", Sun, t("Today", "النهاردة")], ["calendar", CalendarDays, t("Calendar", "التقويم")], ["alarms", AlarmClock, t("Alarms", "المنبهات")], ["tools", LayoutGrid, t("Tools", "أدوات")], ["ai", Sparkles, t("AI", "الذكاء")], ["downloads", Download, t("Download", "التحميل")], ["me", User, t("Me", "أنا")],
  ];
  const sharedMatch = location.hash.match(/^#\/qr-(share|file)\/([^?]+)/);
  const showParticles = s.decorSurfaces.app && s.intensity !== "off" && !s.reduceMotion && (s.intensity !== "subtle" || decor.occasions.length > 0);

  return (
    <div className="relative min-h-full">
      <div className="app-bg" />
      {s.ambientPhoto && <div className="ambient-photo" aria-hidden key={period}>
        <img src={periodInfo.photo} alt="" />
        <span style={{ background: `linear-gradient(180deg, ${periodInfo.tint}, var(--bg) 62%)` }} />
      </div>}
      {showParticles && <div className="pointer-events-none fixed inset-0" data-decor-layer={s.decorLayer} style={{ zIndex: s.decorLayer === "above" ? 25 : 1 }}><Particles family={decor.primary} intensity={s.intensity} /></div>}
      <main className="relative z-[2] mx-auto max-w-2xl px-4 pb-32 pt-2" style={{ viewTransitionName: "main" }}>
        {sharedMatch ? <QRShareViewer kind={sharedMatch[1] === "share" ? "review" : "file"} value={sharedMatch[2]} onBack={() => go("tools", "qr")} /> : route.tab === "today" && <Today go={go} />}
        {route.tab === "calendar" && <CalendarScreen />}
        {route.tab === "alarms" && <Alarms />}
        {route.tab === "tools" && <Tools sub={route.sub} go={go} />}
        {route.tab === "ai" && <AI go={go} />}
        {route.tab === "downloads" && <Downloads go={go} />}
        {route.tab === "me" && <Me sub={route.sub} go={go} />}
      </main>

      <button onClick={() => setQuick(true)} className="btn-primary fixed bottom-[88px] start-1/2 z-40 grid h-14 w-14 -translate-x-1/2 place-items-center rounded-full shadow-lg transition-transform active:scale-90 rtl:translate-x-1/2" style={{ background: "var(--accent)", color: "var(--on-accent)", boxShadow: "0 10px 28px -8px color-mix(in oklch, var(--accent) 70%, transparent)" }} aria-label={t("Create", "اعمل جديد")}>
        <Plus size={26} />
      </button>

      <nav className="tabbar fixed inset-x-0 bottom-0 z-30 pb-[env(safe-area-inset-bottom)]" aria-label={t("Main", "الرئيسية")}>
        <div className="mx-auto flex max-w-2xl">
          {tabs.map(([id, I, label]) => {
            const active = route.tab === id;
            return (
              <button key={id} onClick={() => go(id)} className="flex min-w-0 flex-1 flex-col items-center gap-0.5 pb-2.5 pt-2 text-[10px] font-semibold transition-colors" style={{ color: active ? "var(--accent)" : "var(--muted)" }} aria-current={active ? "page" : undefined}>
                <span className="grid h-7 w-10 place-items-center rounded-full transition-all" style={{ background: active ? "var(--soft)" : "transparent" }}><I size={20} strokeWidth={active ? 2.4 : 1.8} /></span>
                {label}
              </button>
            );
          })}
        </div>
      </nav>

      <Companion onOpenApp={go} />
      <QuickCreate open={quick} onClose={() => setQuick(false)} go={go} />
    </div>
  );
}

function QuickCreate({ open, onClose, go }: { open: boolean; onClose: () => void; go: (tab: string, sub?: string) => void }) {
  const t = useT();
  const s = useStore();
  const [mode, setMode] = useState<null | "task" | "note" | "reminder" | "activity" | "more">(null);
  const [txt, setTxt] = useState(""); const [time, setTime] = useState("18:00");
  const close = () => { setMode(null); setTxt(""); onClose(); };
  const main = [
    ["alarm", AlarmClock, t("Alarm", "منبه")], ["task", ListPlus, t("Task", "مهمة")], ["habit", LayoutGrid, t("Habit", "عادة")],
    ["note", StickyNote, t("Note", "ملاحظة")], ["reminder", BellPlus, t("Reminder", "تذكير")], ["more", MoreHorizontal, t("More…", "المزيد…")],
  ] as const;
  const more = [[Droplet, t("Log 250 ml water", "سجّل ٢٥٠ مل ماية"), () => { s.addWater(250); close(); }], [Sparkles, t("Ask the AI", "اسأل الذكاء"), () => { close(); go("ai"); }], [Bot, t("Create a habit", "اعمل عادة"), () => { close(); go("tools", "habits"); }], [Timer, t("Start focus", "ابدأ التركيز"), () => { close(); go("tools", "focus"); }], [Link2, t("Paste a link", "الصق رابطًا"), () => { close(); go("tools", "media"); }], [Hourglass, t("Countdown", "عد تنازلي"), () => { close(); go("tools", "countdowns"); }], [BookHeart, t("Journal entry", "تدوين يومي"), () => { close(); go("tools", "journal"); }], [LayoutGrid, t("Add a widget", "إضافة ودجت"), () => { close(); go("me", "widgets"); }]] as const;
  const submit = (e: React.FormEvent) => {
    e.preventDefault(); if (!txt.trim()) return;
    if (mode === "task") s.addTask(txt.trim());
    if (mode === "activity") s.addTask(txt.trim(), undefined, false, true, time);
    if (mode === "note") s.addNote(txt.trim());
    if (mode === "reminder") s.addAlarm({ time, days: [], label: txt.trim(), enabled: true, sound: { source: "device", title: t("Default notification (device)", "صوت الإشعار الافتراضي") }, vibrate: true, snooze: 10, gentle: false });
    close();
  };
  return (
    <Sheet open={open} onClose={close} title={t("Create", "اعمل جديد")}>
      {!mode && <div className="grid grid-cols-3 gap-2">{main.map(([id, I, l]) => (
        <button key={id} onClick={() => (id === "alarm" ? (close(), go("alarms")) : id === "habit" ? (close(), go("tools", "habits")) : setMode(id))} className="card flex aspect-square flex-col items-center justify-center gap-2 active:scale-95">
          <span className="grid h-11 w-11 place-items-center rounded-2xl" style={{ background: "var(--soft)", color: "var(--accent)" }}><I size={22} /></span><span className="text-sm font-semibold">{l}</span>
        </button>))}</div>}
      {mode === "more" && <div className="space-y-1">{more.map(([I, l, f], i) => <button key={i} onClick={f} className="flex w-full items-center gap-3 rounded-xl px-2 py-3 text-start hover:bg-[var(--soft)]"><I size={18} className="accent" /><span>{l}</span></button>)}</div>}
      {mode && mode !== "more" && (
        <form onSubmit={submit} className="space-y-3">
          {mode === "note" ? <textarea autoFocus value={txt} onChange={(e) => setTxt(e.target.value)} className="field min-h-28" placeholder={t("Write a note…", "اكتب ملاحظة…")} /> : <input autoFocus value={txt} onChange={(e) => setTxt(e.target.value)} className="field" placeholder={{ task: t("What needs doing?", "ما المطلوب إنجازه؟"), activity: t("Activity name", "اسم النشاط"), reminder: t("Remind me to…", "ذكّرني بـ…") }[mode]} />}
          {(mode === "reminder" || mode === "activity") && <input type="time" value={time} onChange={(e) => setTime(e.target.value)} className="field" />}
          <div className="flex gap-2"><button type="button" className="btn btn-ghost" onClick={() => setMode(null)}>{t("Back", "رجوع")}</button><button className="btn btn-primary flex-1">{t("Save", "حفظ")}</button></div>
        </form>
      )}
    </Sheet>
  );
}
