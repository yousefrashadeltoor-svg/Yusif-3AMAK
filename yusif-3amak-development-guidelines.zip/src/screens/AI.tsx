import { useEffect, useMemo, useRef, useState } from "react";
import { Plus, Send, Square, KeyRound, Trash2, RefreshCw, Search, Check, AlertTriangle, Loader2, Sparkles, ChevronDown, Settings2, MessageSquarePlus, History, ShieldCheck, Cpu, ArrowLeft, BotMessageSquare, Star, Lightbulb, Paperclip, Image as ImageIcon, FileText, X } from "lucide-react";
import { useStore, fmtNum, newId, applyActionsDetailed, type Lang } from "../lib/store";
import { PROVIDERS, TIERS, providerById, detectProvider, LOGO, modelLogoSlug, isChatModelId, type Api, type ModelInfo, type Tier } from "../lib/providers";
import { dayKey } from "../lib/calendar";
import { logoSvg } from "../lib/logos";
import { Markdown, CopyButton, markdownToPlain } from "../components/Markdown";
import { describeWhen } from "../lib/dateContext";
import type { ActionRecord } from "../lib/store";
import { streamChat, verifyKey, parseActions, modelList, keyHint, defaultModelFor, type ApiKeyEntry, type AiMsg, type Conversation, type Attachment } from "../lib/ai";
import { miniBrain } from "../lib/soul";
import { fmtBytes } from "../lib/media";
import { Card, Honest, Sheet, Toggle } from "../components/ui";
import { contextualRequest } from "../lib/temporal";

const MAX_ATTACH_BYTES = 2 * 1024 * 1024; // 2 MB strict limit

/** Official brand mark from local assets (works offline, follows light/dark via currentColor). Letter-in-circle only for unknown/custom models. */
export function Logo({ slug, name, size = 20 }: { src?: string; slug?: string; name: string; size?: number }) {
  const svg = logoSvg(slug);
  if (!svg) return <span aria-hidden className="grid flex-none place-items-center rounded-full font-black" style={{ width: size, height: size, fontSize: Math.max(8, Math.round(size * 0.46)), background: "var(--soft)", color: "var(--accent)", border: "1px solid var(--line)" }}>{(name.trim()[0] || "?").toUpperCase()}</span>;
  return <span aria-hidden className="logo-mark inline-grid flex-none place-items-center" style={{ width: size, height: size, color: "var(--text)", fontSize: size }} dangerouslySetInnerHTML={{ __html: svg }} />;
}

const T = (lang: Lang, en: string, ar: string) => (lang === "ar" ? ar : en);

export function AI({ go }: { go: (tab: string, sub?: string) => void }) {
  const s = useStore();
  const lang = s.lang;
  const t = (en: string, ar: string) => T(lang, en, ar);
  const [keysOpen, setKeysOpen] = useState(false);
  const [modelsOpen, setModelsOpen] = useState(false);
  const [sideOpen, setSideOpen] = useState(false);
  const active = s.apiKeys.find((k) => k.id === s.activeKeyId) || null;
  const provider = active ? providerById(active.provider) : null;
  const models = useMemo(() => (active ? modelList(active.provider, active.liveModels) : []), [active]);
  const safeActiveId = active && s.activeModel && isChatModelId(s.activeModel) ? s.activeModel : (active ? defaultModelFor(active.provider, active.liveModels) : "");
  const activeModel = models.find((m) => m.id === safeActiveId) || models[0] || null;

  useEffect(() => {
    if (active && safeActiveId && s.activeModel !== safeActiveId) s.set({ activeModel: safeActiveId });
  }, [active, safeActiveId]); // eslint-disable-line

  const [convoId, setConvoId] = useState<string>(() => newId());
  const convo = s.convos.find((c) => c.id === convoId);
  const msgs: AiMsg[] = convo?.msgs || [];
  const [input, setInput] = useState("");
  const [attachments, setAttachments] = useState<Attachment[]>([]);
  const [attachErr, setAttachErr] = useState("");
  const [busy, setBusy] = useState(false);
  const [reasoning, setReasoning] = useState("");
  const [streamed, setStreamed] = useState("");
  const [err, setErr] = useState("");
  const [executed, setExecuted] = useState<string[]>([]);
  const abort = useRef<AbortController | null>(null);
  const pendingLocal = useRef("");
  const endRef = useRef<HTMLDivElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const canImage = !!activeModel?.supportsImage;
  const canDoc = !!activeModel?.supportsDoc;
  const canAttach = !!active && (canImage || canDoc);

  const persist = (next: AiMsg[]) => {
    const c: Conversation = { id: convoId, title: c_title(next, t("New chat", "محادثة جديدة")), msgs: next, keyId: active?.id, model: activeModel?.id, at: Date.now() };
    s.saveConvo(c);
  };
  const c_title = (m: AiMsg[], fallback: string) => (m.find((x) => x.role === "user")?.content || fallback).slice(0, 48);

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: "smooth", block: "end" }); }, [msgs.length, streamed, reasoning]);

  const handleAttach = async (file: File) => {
    setAttachErr("");
    if (file.size > MAX_ATTACH_BYTES) {
      setAttachErr(t(`File is ${fmtBytes(file.size)} — max allowed is 2 MB.`, `حجم الملف ${fmtBytes(file.size)} — الحد الأقصى 2 ميجا.`));
      return;
    }
    const isImage = file.type.startsWith("image/");
    if (isImage && !canImage) {
      setAttachErr(t("This model doesn't support images.", "النموذج ده مش بيدعم قراءة الصور."));
      return;
    }
    if (!isImage && !canDoc) {
      setAttachErr(t("This model doesn't support documents.", "النموذج ده مش بيدعم قراءة المستندات."));
      return;
    }
    if (isImage || file.type === "application/pdf") {
      const dataUrl = await new Promise<string>((res, rej) => { const fr = new FileReader(); fr.onload = () => res(fr.result as string); fr.onerror = rej; fr.readAsDataURL(file); });
      setAttachments((a) => [...a, { name: file.name, mime: file.type || "application/octet-stream", size: file.size, isImage, dataUrl }]);
    } else {
      const text = (await file.text()).slice(0, 80000);
      setAttachments((a) => [...a, { name: file.name, mime: file.type || "text/plain", size: file.size, isImage: false, text }]);
    }
  };

  const send = async (text?: string) => {
    const content = (text ?? input).trim();
    if ((!content && !attachments.length) || busy) return;
    setInput(""); setErr(""); setAttachErr(""); setExecuted([]); setReasoning(""); setStreamed("");
    const atts = attachments.slice();
    setAttachments([]);
    const base: AiMsg[] = [...msgs, { role: "user", content: content || t("See attached file", "شوف الملف المرفق"), attachments: atts.length ? atts : undefined, at: Date.now() }];
    persist(base);
    setBusy(true);
    if (!active || !activeModel) {
      const request = contextualRequest(pendingLocal.current, content);
      const local = miniBrain(request, { alarms: s.alarms, tasks: s.tasks, habitsCount: s.habits.length, water: s.water[dayKey(new Date())] || 0 }, lang);
      pendingLocal.current = local.needs?.length ? request : "";
      const outcome = local.actions?.length ? applyActionsDetailed(local.actions, go, request) : { done: [], issues: [], records: [] };
      const reply: AiMsg = { role: "assistant", content: `${local.text}${outcome.issues.length ? `\n\n${t("Not saved", "ما اتحفظش")}: ${outcome.issues.join(" ")}` : ""}`, model: "dayflow-local", at: Date.now(), records: outcome.records.length ? outcome.records : undefined };
      s.saveConvo({ id: convoId, title: c_title(base, "chat"), msgs: [...base, reply], at: Date.now() });
      setExecuted(outcome.done); setBusy(false); return;
    }
    const ctl = new AbortController(); abort.current = ctl;
    let full = "", think = "";
    try {
      await streamChat({ entry: active, model: activeModel.id, messages: base, reasoning: s.aiReasoning }, {
        signal: ctl.signal,
        onReasoning: (d) => { think += d; setReasoning(think); },
        onText: (d) => { full += d; setStreamed(full); },
      });
      const { clean, actions } = parseActions(full);
      const previousUser = msgs.at(-2)?.role === "user" && msgs.at(-1)?.role === "assistant" && /[؟?]/.test(msgs.at(-1)?.content || "") ? msgs.at(-2)?.content : "";
      const request = contextualRequest(previousUser || "", content);
      const outcome = applyActionsDetailed(actions, go, request);
      if (outcome.done.length) setExecuted(outcome.done);
      const message = clean || full || t("(Empty response from model)", "(النموذج رجع رد فاضي)");
      const correction = outcome.issues.length ? `\n\n${t("This action was not saved", "الطلب ده ما اتحفظش")}: ${outcome.issues.join(" ")}` : outcome.done.length ? `\n\n${t("Recorded for", "اتسجّل للميعاد")}: ${outcome.done.join("، ")}` : "";
      const reply: AiMsg = { role: "assistant", content: message + correction, reasoning: think || undefined, model: activeModel.id, at: Date.now(), records: outcome.records.length ? outcome.records : undefined };
      s.saveConvo({ id: convoId, title: c_title(base, "chat"), msgs: [...base, reply], keyId: active.id, model: activeModel.id, at: Date.now() });
    } catch (e) {
      const m = (e as Error).name === "AbortError" ? t("Stopped.", "وقفت.") : (e as Error).message;
      setErr(m);
      if ((e as Error).name !== "AbortError") {
        s.saveConvo({ id: convoId, title: c_title(base, "chat"), msgs: [...base, { role: "assistant", content: t(`Couldn't complete request: ${m}`, `معرفتش أكمل الطلب: ${m}`), model: activeModel.id, err: true, at: Date.now() }], at: Date.now() });
      }
    } finally {
      setBusy(false); setReasoning(""); setStreamed(""); abort.current = null;
    }
  };

  const stop = () => { abort.current?.abort(); };
  const switchToRecommended = () => {
    if (!active) return;
    const rec = defaultModelFor(active.provider, active.liveModels);
    s.set({ activeModel: rec });
    setErr("");
  };

  const suggestions = [t("Plan my day", "نظّملي يومي"), t("Remind me at 6:30", "اعمل منبه ٦:٣٠"), t("What can this app do?", "التطبيق بيعمل إيه؟"), t("Add a habit for reading", "ضيف عادة القراية")];
  const curSlug = activeModel ? (activeModel.logo || modelLogoSlug(activeModel.id, provider?.logo || "openai")) : "openai";
  const acceptAttr = [canImage ? "image/*" : "", canDoc ? ".pdf,.txt,.md,.csv,.json,.xml,.html,.js,.ts,.py" : ""].filter(Boolean).join(",");

  return (
    <div className="ai-shell relative mx-auto min-h-[calc(100dvh-160px)] max-w-3xl pb-2" style={{ marginTop: -8 }}>
      <header className="sticky top-0 z-20 -mx-4 mb-2 flex items-center gap-2 px-3 py-2" style={{ background: "color-mix(in oklch, var(--bg) 88%, transparent)", backdropFilter: "blur(16px)" }}>
        <button onClick={() => setSideOpen(true)} className="grid h-9 w-9 flex-none place-items-center rounded-xl btn-soft" aria-label={t("Chats", "المحادثات")}><History size={17} /></button>
        <button onClick={() => setModelsOpen(true)} className="card flex min-w-0 flex-1 items-center gap-2 px-2.5 py-1.5 text-start">
          <Logo src={LOGO(curSlug)} slug={curSlug} name={provider?.name || "DF"} size={22} />
          <span className="min-w-0 flex-1">
            <span className="flex items-center gap-1 truncate text-[13px] font-bold leading-tight">
              <span className="truncate">{activeModel ? activeModel.name : t("DAYFLOW local engine", "محرك DAYFLOW المحلي")}</span>
              {activeModel?.supportsImage && <ImageIcon size={11} className="flex-none opacity-65" />}
              {activeModel?.supportsDoc && <FileText size={11} className="flex-none opacity-65" />}
            </span>
            <span className="block truncate text-[10px] leading-tight muted">{provider ? provider.name : t("Egyptian engine · offline", "محرك مصري · أوفلاين")}{activeModel?.ctx ? ` · ${fmtNum(Math.round(activeModel.ctx / 1000) + "K", lang)}` : ""}</span>
          </span>
          <ChevronDown size={15} className="muted flex-none" />
        </button>
        <button onClick={() => setKeysOpen(true)} className="grid h-9 w-9 flex-none place-items-center rounded-xl btn-soft" aria-label={t("API keys", "مفاتيح API")}><KeyRound size={16} /></button>
      </header>

      {!msgs.length && !streamed && (
        <div className="fade-in px-1 pt-6">
          <div className="mb-4 flex items-center gap-3">
            <div className="grid h-12 w-12 place-items-center rounded-2xl" style={{ background: "var(--soft)" }}><Sparkles size={22} className="accent" /></div>
            <div><p className="text-lg font-bold leading-tight">{t("What are we doing today?", "هنعمل إيه النهاردة؟")}</p><p className="text-xs muted">{t("Ask anything — in Egyptian Arabic or English.", "اسأل أي حاجة — بالمصري أو الإنجليزي.")}</p></div>
          </div>
          <div className="grid grid-cols-2 gap-2">
            {[
              [Lightbulb, t("Plan my day", "ظبّطلي يومي"), t("Look at my tasks and suggest a calm order.", "شوف مهامي ورتبهملي بهدوء.")],
              [BotMessageSquare, t("Alarms & tasks", "منبهات ومهام"), t("Create, change or explain them.", "اعمل أو عدّل أو اسأل عنهم.")],
              [Star, t("About DAYFLOW", "عن DAYFLOW"), t("Every feature, honestly explained.", "كل ميزة بصراحة.")],
              [Cpu, t("Models & keys", "النماذج والمفاتيح"), t("One key unlocks GPT, Claude, Gemini, Llama…", "مفتاح واحد يفتح GPT وClaude وGemini وLlama…")],
            ].map(([I, title, hint], i) => { const Ic = I as typeof Star; return (
              <button key={i} onClick={() => i === 3 ? setKeysOpen(true) : send(hint as string)} className="card p-3 text-start active:scale-[.99]">
                <Ic size={16} className="accent mb-1.5" /><p className="text-[13px] font-semibold leading-tight">{title as string}</p><p className="mt-0.5 text-[11px] leading-snug muted">{hint as string}</p>
              </button>); })}
          </div>
          <div className="mt-3 flex flex-wrap gap-1.5">{suggestions.map((x) => <button key={x} onClick={() => send(x)} className="chip text-[11px]">{x}</button>)}</div>
          {!active && <div className="mt-4"><Card className="p-3"><p className="mb-1 flex items-center gap-1.5 text-xs font-bold"><KeyRound size={13} className="accent" />{t("Works now, offline", "بيشتغل حالًا، بدون نت")}</p><p className="text-[11px] muted">{t("The local Egyptian engine answers and creates alarms, tasks and habits instantly. Add a key for GPT / Claude / Gemini / Llama.", "المحرك المصري المحلي بيرد ويعمل منبهات ومهام وعادات فورًا. ضيف مفتاح لنماذج GPT / Claude / Gemini / Llama.")}</p></Card></div>}
        </div>
      )}

      <div className="space-y-4 px-0.5">
        {msgs.map((m, i) => <Message key={i} m={m} lang={lang} />)}
        {busy && <div className="space-y-2">
          {reasoning && <div className="rounded-2xl border border-dashed p-3 text-[12px] leading-relaxed" style={{ borderColor: "var(--line)", color: "var(--muted)", background: "color-mix(in oklch, var(--surface) 50%, transparent)" }}><p className="mb-1 flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider"><Sparkles size={11} />{t("Thinking…", "بيفكر…")}</p>{reasoning}</div>}
          {streamed && <div className="rounded-2xl p-3 text-sm" style={{ background: "var(--soft)" }}><Markdown text={streamed} streaming /></div>}
          {!streamed && !reasoning && <div className="flex items-center gap-2 text-xs muted"><Loader2 size={14} className="animate-spin" />{t("Connecting to the provider…", "بيتواصل مع المزوّد…")}</div>}
        </div>}
        {err && <div className="rounded-xl p-3 text-xs space-y-2" style={{ background: "#e5484d14", color: "#c62a2f" }}>
          <p><AlertTriangle size={13} className="inline" /> {err}</p>
          {/terms|orpheus|400|not a chat|unsupported/i.test(err) && active && <button onClick={switchToRecommended} className="btn btn-primary py-1 text-[11px]">{t("Switch to a ready chat model", "بدّل لنموذج محادثة جاهز")}</button>}
        </div>}
        {executed.length > 0 && <div className="flex flex-wrap gap-1.5">{executed.map((x) => { const [kind, ...detail] = x.split(" · "); return <span key={x} className="chip text-[11px]" aria-pressed="true"><Check size={11} />{({ alarm: t("Alarm created", "اتعمل منبه"), task: t("Task added", "اتضافت مهمة"), habit: t("Habit added", "اتضافت عادة"), water: t("Water logged", "اتسجل ماء"), open: t("Opened", "اتفتح"), note: t("Note added", "اتضافت ملاحظة") } as Record<string, string>)[kind] || kind}{detail.length ? ` · ${detail.join(" · ")}` : ""}</span>; })}</div>}
        <div ref={endRef} />
      </div>

      <div className="sticky bottom-[74px] z-20 -mx-2 mt-3 px-2 pt-2" style={{ background: "linear-gradient(180deg, transparent, var(--bg) 30%)" }}>
        {attachments.length > 0 && <div className="mb-1.5 flex flex-wrap gap-1.5">{attachments.map((a, i) => <span key={i} className="chip text-[11px]">{a.isImage ? <ImageIcon size={11} /> : <FileText size={11} />}{a.name} ({fmtBytes(a.size)})<button onClick={() => setAttachments((x) => x.filter((_, j) => j !== i))} aria-label="remove"><X size={11} /></button></span>)}</div>}
        {attachErr && <p className="mb-1 text-[11px] text-red-500">{attachErr}</p>}
        <form onSubmit={(e) => { e.preventDefault(); send(); }} className="card ai-composer flex items-end gap-1.5 p-2">
          <button type="button" onClick={() => { if (canAttach) fileRef.current?.click(); else setAttachErr(active ? t("This model can't read images or documents — pick a model with the 🖼 or 📄 icon.", "النموذج ده مش بيقرأ صور ولا مستندات — اختار نموذج عليه أيقونة 🖼 أو 📄.") : t("Add an API key and pick a vision/document model to attach files.", "ضيف مفتاح API واختار نموذج بيقرأ صور أو ملفات عشان ترفق.")); }}
            className="relative grid h-10 w-10 flex-none place-items-center rounded-2xl transition" style={{ background: canAttach ? "var(--soft)" : "transparent", color: canAttach ? "var(--accent)" : "var(--muted)", opacity: canAttach ? 1 : .55 }}
            aria-label={t("Attach file (max 2 MB)", "إرفاق ملف (أقصى ٢ ميجا)")} title={t("Attach image or document · max 2 MB", "إرفاق صورة أو مستند · أقصى ٢ ميجا")}>
            <Paperclip size={18} />
            {canAttach && <span className="absolute -bottom-0.5 -end-0.5 flex gap-px rounded-full px-1 text-[8px]" style={{ background: "var(--surface)" }}>{canImage && <ImageIcon size={9} />}{canDoc && <FileText size={9} />}</span>}
          </button>
          <input ref={fileRef} type="file" accept={acceptAttr || "*/*"} className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) handleAttach(f); e.target.value = ""; }} />
          <textarea value={input} onChange={(e) => setInput(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); } }} rows={1} className="max-h-32 min-h-9 flex-1 resize-none bg-transparent px-2 py-2 text-sm outline-none" placeholder={t("Ask anything…", "اسأل أي حاجة…")} aria-label={t("Message", "رسالة")} />
          {busy ? <button type="button" onClick={stop} className="grid h-9 w-9 place-items-center rounded-xl" style={{ background: "var(--soft)" }} aria-label={t("Stop", "إيقاف")}><Square size={15} /></button>
            : <button className="grid h-9 w-9 place-items-center rounded-xl" style={{ background: "var(--accent)", color: "var(--on-accent)" }} aria-label={t("Send", "إرسال")}><Send size={16} /></button>}
        </form>
        <p className="mt-1 text-center text-[10px] muted">{active ? t("Your key goes only to your chosen provider. Verify important facts.", "مفتاحك بيتبعت لمزوّدك المختار فقط. راجع المعلومات المهمة.") : t("Local Egyptian engine · instant · offline", "محرك مصري محلي · فوري · بدون نت")}</p>
      </div>

      <KeysSheet open={keysOpen} onClose={() => setKeysOpen(false)} />
      <ModelsSheet open={modelsOpen} onClose={() => setModelsOpen(false)} onAddKey={() => { setModelsOpen(false); setKeysOpen(true); }} />
      <Sheet open={sideOpen} onClose={() => setSideOpen(false)} title={t("Chats", "المحادثات")}>
        <button onClick={() => { pendingLocal.current = ""; setConvoId(newId()); setSideOpen(false); }} className="btn btn-primary mb-3 w-full"><MessageSquarePlus size={16} />{t("New chat", "محادثة جديدة")}</button>
        <div className="space-y-1">{s.convos.map((c) => <div key={c.id} className="flex items-center gap-2">
          <button onClick={() => { pendingLocal.current = ""; setConvoId(c.id); setSideOpen(false); }} className="flex-1 truncate rounded-lg px-2 py-2 text-start text-sm" style={{ background: c.id === convoId ? "var(--soft)" : "transparent" }}>{c.title}</button>
          <button onClick={() => s.deleteConvo(c.id)} className="muted p-1" aria-label={t("Delete", "حذف")}><Trash2 size={14} /></button>
        </div>)}</div>
        {!s.convos.length && <p className="text-sm muted">{t("No saved chats yet.", "مفيش محادثات محفوظة.")}</p>}
        <div className="mt-4"><Row2 icon={<Settings2 size={15} />} label={t("Show model thinking", "اعرض تفكير النموذج")} hint={t("Faint block before the answer, when the model supports it", "بلوك خافت قبل الرد، لو النموذج بيدعمه")} right={<Toggle on={s.aiReasoning} onChange={(v) => s.set({ aiReasoning: v })} label="reasoning" />} /></div>
      </Sheet>
    </div>
  );
}

function Row2({ icon, label, hint, right }: { icon?: React.ReactNode; label: string; hint?: string; right?: React.ReactNode }) {
  return <div className="flex items-center gap-2 rounded-xl p-2" style={{ background: "var(--soft)" }}>{icon}<span className="flex-1"><span className="block text-xs font-semibold">{label}</span>{hint && <span className="block text-[10px] leading-snug muted">{hint}</span>}</span>{right}</div>;
}

const DOW_AR = ["الأحد", "الاثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت"], DOW_EN = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
/** Confirmation card: shows the date the assistant actually saved, in words, so a wrong day is caught immediately. */
function ConfirmCard({ r, lang }: { r: ActionRecord; lang: Lang }) {
  const hour12 = useStore((x) => x.hour12);
  const kind = { alarm: T(lang, "Alarm saved", "اتحفظ منبّه"), task: T(lang, "Task saved", "اتحفظت مهمة"), habit: T(lang, "Habit saved", "اتحفظت عادة") }[r.kind];
  const when = r.date ? describeWhen(r.date, r.time, lang, hour12) : r.days?.length ? `${T(lang, "Every", "كل")} ${r.days.map((d) => (lang === "ar" ? DOW_AR : DOW_EN)[d]).join(lang === "ar" ? "، " : ", ")}${r.time ? " · " + describeWhen(undefined, r.time, lang, hour12) : ""}` : describeWhen(undefined, r.time, lang, hour12);
  return (
    <div className="flex items-center gap-2 rounded-2xl border p-2.5" style={{ borderColor: "var(--line)", background: "var(--soft)" }} data-testid="confirm-card" data-date={r.date || ""} data-time={r.time || ""}>
      <span className="grid h-8 w-8 flex-none place-items-center rounded-xl" style={{ background: "var(--accent)", color: "var(--on-accent)" }}><Check size={15} /></span>
      <span className="min-w-0 flex-1"><span className="block text-[10px] font-bold uppercase tracking-wider muted">{kind}</span><span className="block truncate text-[13px] font-semibold">{r.title}</span><span className="block text-[12px] accent">{when}</span></span>
    </div>
  );
}

function Message({ m, lang }: { m: AiMsg; lang: Lang }) {
  const [open, setOpen] = useState(false);
  const t = (en: string, ar: string) => T(lang, en, ar);
  if (m.role === "user") return (
    <div className="msg-row flex flex-col items-end gap-1">
      {m.attachments?.length ? <div className="flex flex-wrap justify-end gap-1">{m.attachments.map((a, i) => a.isImage && a.dataUrl ? <img key={i} src={a.dataUrl} alt="" className="max-h-36 rounded-xl" /> : <span key={i} className="chip text-[10px]"><FileText size={10} />{a.name}</span>)}</div> : null}
      <div className="max-w-[86%] rounded-2xl rounded-br-md px-3 py-2 text-sm" style={{ background: "var(--accent)", color: "var(--on-accent)" }}>{m.content}</div>
    </div>
  );
  return (
    <div className="fade-in msg-row">
      {m.reasoning && <div className="mb-2 rounded-2xl border border-dashed p-2.5" style={{ borderColor: "var(--line)" }}>
        <button onClick={() => setOpen(!open)} className="flex w-full items-center gap-1 text-[10px] font-bold uppercase tracking-wider muted"><Sparkles size={11} />{t("Thinking", "التفكير")}<ChevronDown size={12} className="ms-auto" style={{ transform: open ? "rotate(180deg)" : "none" }} /></button>
        <p className={`mt-1 whitespace-pre-wrap text-[11.5px] leading-relaxed ${open ? "" : "line-clamp-2"}`} style={{ color: "var(--muted)" }}>{m.reasoning}</p>
      </div>}
      {m.err ? <div className="whitespace-pre-wrap text-[14px] leading-relaxed text-red-500 select-text">{m.content}</div> : <Markdown text={m.content} />}
      {!m.err && m.content && <div className="mt-1 flex gap-1"><CopyButton value={m.content} label={t("Copy Markdown", "نسخ Markdown")} /><CopyButton value={markdownToPlain(m.content)} label={t("Copy text", "نسخ كنص")} /></div>}
      {m.records?.length ? <div className="mt-2 grid gap-1.5">{m.records.map((r, i) => <ConfirmCard key={i} r={r} lang={lang} />)}</div> : null}
      {m.model && <p className="mt-1 text-[10px] muted">{m.model}</p>}
    </div>
  );
}

function KeysSheet({ open, onClose }: { open: boolean; onClose: () => void }) {
  const s = useStore(); const lang = s.lang; const t = (en: string, ar: string) => T(lang, en, ar);
  const [add, setAdd] = useState(false);
  const [provider, setProvider] = useState<Api | null>(null);
  const [key, setKey] = useState("");
  const [base, setBase] = useState("");
  const [label, setLabel] = useState("");
  const [checking, setChecking] = useState(false);
  const [result, setResult] = useState<{ ok: boolean; detail: string } | null>(null);
  const detected = detectProvider(key);
  const actual = detected || provider;

  const save = async () => {
    if (!key.trim() || !actual) return;
    setChecking(true); setResult(null);
    const entry: ApiKeyEntry = { id: newId(), provider: actual, key: key.trim(), label: label || providerById(actual).name, addedAt: Date.now(), baseOverride: base.trim() || undefined };
    const v = await verifyKey(entry);
    if (v.models) { entry.liveModels = v.models; entry.modelsFetchedAt = Date.now(); }
    s.addKey(entry);
    s.set({ activeKeyId: entry.id, activeModel: defaultModelFor(actual, v.models) });
    setResult({ ok: v.ok, detail: v.detail });
    setChecking(false);
    setKey(""); setLabel(""); setBase(""); setProvider(null); setAdd(false);
  };
  const refresh = async (e: ApiKeyEntry) => {
    const v = await verifyKey(e);
    if (v.models) s.updateKey(e.id, { liveModels: v.models, modelsFetchedAt: Date.now() });
    setResult({ ok: v.ok, detail: v.detail });
  };

  return (
    <Sheet open={open} onClose={onClose} title={t("Providers & keys", "المزوّدون والمفاتيح")} wide>
      {result && <div className="mb-3 rounded-xl p-2.5 text-xs" style={{ background: result.ok ? "#2fa36b18" : "#e5484d18" }}>{result.ok ? <Check size={13} className="inline" /> : <AlertTriangle size={13} className="inline" />} {result.detail}</div>}
      {!add && <>
        <button onClick={() => setAdd(true)} className="btn btn-primary mb-3 w-full"><Plus size={16} />{t("Add an API key", "ضيف مفتاح API")}</button>
        <div className="mb-4 space-y-2">
          {s.apiKeys.map((k) => {
            const p = providerById(k.provider);
            const active = s.activeKeyId === k.id;
            return <div key={k.id} className="card flex items-center gap-2 p-2.5">
              <Logo src={LOGO(p.logo)} slug={p.logo} name={p.name} size={26} />
              <button onClick={() => s.set({ activeKeyId: k.id, activeModel: defaultModelFor(k.provider, k.liveModels) })} className="min-w-0 flex-1 text-start">
                <span className="block truncate text-[13px] font-bold">{p.name} <span className="font-normal muted">· {k.label}</span></span>
                <span className="block truncate text-[10px] muted">{keyHint(k.key)} · {p.kind === "anthropic" ? "Anthropic" : p.kind === "gemini" ? "Google" : "OpenAI-compatible"}{k.liveModels?.length ? ` · ${k.liveModels.length} models` : ""}{active ? " · ✓ active" : ""}</span>
              </button>
              <button onClick={() => refresh(k)} className="muted p-1" aria-label="refresh"><RefreshCw size={14} /></button>
              <button onClick={() => s.removeKey(k.id)} className="muted p-1" aria-label="delete"><Trash2 size={14} /></button>
            </div>;
          })}
          {!s.apiKeys.length && <p className="text-sm muted">{t("No key added. Everything still works locally.", "مفيش مفتاح. كل حاجة لسه شغالة محليًا.")}</p>}
        </div>
        <div className="mb-1.5 flex items-center gap-1 text-xs font-bold"><ShieldCheck size={13} className="accent" />{t("Supported providers", "المزوّدون المدعومون")} <span className="muted font-normal">({PROVIDERS.length})</span></div>
        <div className="grid grid-cols-2 gap-1.5 sm:grid-cols-3">{PROVIDERS.map((p) => <div key={p.id} className="card flex items-center gap-1.5 p-1.5"><Logo src={LOGO(p.logo)} slug={p.logo} name={p.name} size={18} /><span className="min-w-0 flex-1 truncate text-[11px] font-medium">{p.name}</span>{p.local && <span className="chip px-1 py-0 text-[8px]">local</span>}</div>)}</div>
        <Honest>{t("Keys stay only in this browser and go directly to your chosen provider. OpenRouter keys (sk-or-v1-) are classified as OpenRouter, never OpenAI.", "المفاتيح بتتخزن في المتصفح بس وتروح للمزوّد المختار مباشرة. مفاتيح OpenRouter بتتعرف كـOpenRouter، مش OpenAI أبدًا.")}</Honest>
      </>}
      {add && <>
        <button onClick={() => { setAdd(false); setResult(null); }} className="mb-2 flex items-center gap-1 text-xs font-semibold accent"><ArrowLeft size={13} />{t("Back", "رجوع")}</button>
        <p className="mb-2 text-xs font-semibold muted">{t("Paste the key — the provider is detected from its real prefix.", "الصق المفتاح — المزوّد بيتعرف من البادئة الحقيقية.")}</p>
        <input value={key} onChange={(e) => setKey(e.target.value)} className="field mb-2 font-mono text-sm" placeholder="sk-or-v1-… / gsk_… / sk-ant-… / AIza…" autoComplete="off" spellCheck={false} />
        {key && (actual ? <div className="mb-2 flex items-center gap-2 rounded-xl p-2" style={{ background: "var(--soft)" }}><Logo src={LOGO(providerById(actual).logo)} slug={providerById(actual).logo} name={providerById(actual).name} size={26} /><div className="flex-1"><p className="text-xs font-bold">{t("Detected", "اتعرّف عليه")}: {providerById(actual).name}</p><p className="text-[10px] muted">{providerById(actual).kind === "anthropic" ? "Anthropic Messages API" : providerById(actual).kind === "gemini" ? "Google Generative Language API" : "OpenAI-compatible API"}</p></div>{detected ? <Check size={15} className="text-green-600" /> : <span className="chip text-[9px]">{t("chosen", "مختار يدويًا")}</span>}</div>
          : <div className="mb-2 rounded-xl p-2 text-[11px] muted" style={{ background: "var(--soft)" }}>{t("Not recognised automatically — pick the provider below.", "مش معروف تلقائيًا — اختار المزوّد تحت.")}</div>)}
        <p className="mb-1.5 text-xs font-semibold muted">{t("Provider", "المزوّد")}</p>
        <div className="mb-2 max-h-44 overflow-y-auto rounded-xl" style={{ border: "1px solid var(--line)" }}>
          {PROVIDERS.map((p) => <button key={p.id} onClick={() => setProvider(p.id)} className="flex w-full items-center gap-2 px-2 py-1.5 text-start" style={{ background: actual === p.id ? "var(--soft)" : "transparent" }}>
            <Logo src={LOGO(p.logo)} slug={p.logo} name={p.name} size={16} /><span className="flex-1 text-[12px]">{p.name}</span><span className="text-[9px] muted">{p.keys}</span>{actual === p.id && <Check size={12} className="accent" />}
          </button>)}
        </div>
        <input value={label} onChange={(e) => setLabel(e.target.value)} className="field mb-2 text-sm" placeholder={t("Label (optional) e.g. my free Groq", "اسم (اختياري) مثل: Groq المجاني")} />
        <details className="mb-2"><summary className="cursor-pointer text-[11px] muted">{t("Advanced: custom base URL", "متقدم: رابط مخصص")}</summary><input value={base} onChange={(e) => setBase(e.target.value)} className="field mt-1 font-mono text-xs" placeholder="https://…/v1" /></details>
        {actual && <div className="mb-2 rounded-xl p-2 text-[11px] leading-relaxed" style={{ background: "var(--soft)" }}>{lang === "ar" ? providerById(actual).noteAr : providerById(actual).noteEn}{providerById(actual).docs && <a href={providerById(actual).docs} target="_blank" rel="noreferrer" className="mt-1 block font-semibold accent">{t("Get a key →", "هات مفتاح ←")} {providerById(actual).docs}</a>}</div>}
        <button onClick={save} disabled={!key.trim() || !actual || checking} className="btn btn-primary w-full disabled:opacity-50">{checking ? <Loader2 size={15} className="animate-spin" /> : <KeyRound size={15} />}{t("Verify & save", "تحقق واحفظ")}</button>
      </>}
    </Sheet>
  );
}

function ModelsSheet({ open, onClose, onAddKey }: { open: boolean; onClose: () => void; onAddKey: () => void }) {
  const s = useStore(); const lang = s.lang; const t = (en: string, ar: string) => T(lang, en, ar);
  const active = s.apiKeys.find((k) => k.id === s.activeKeyId);
  const provider = active ? providerById(active.provider) : null;
  const [q, setQ] = useState(""); const [tier, setTier] = useState<Tier | "all">("all");
  const models = active ? modelList(active.provider, active.liveModels) : [];
  const groups = useMemo(() => {
    const list = models.filter((m) => (tier === "all" || m.tier.includes(tier)) && (!q || m.name.toLowerCase().includes(q.toLowerCase()) || m.id.toLowerCase().includes(q.toLowerCase())));
    const byFamily: Record<string, ModelInfo[]> = {};
    for (const m of list) {
      const fam = m.id.includes("/") ? m.id.split("/")[0] : (provider?.id || "models");
      (byFamily[fam] ||= []).push(m);
    }
    return Object.entries(byFamily);
  }, [models, tier, q, provider]);

  return (
    <Sheet open={open} onClose={onClose} title={t("Choose a model", "اختار نموذج")} wide>
      {!active ? <div className="text-center"><Logo src={LOGO("openai")} slug="openai" name="AI" size={44} /><p className="mt-2 text-sm muted">{t("Add a key to unlock hosted models. The local engine keeps working.", "ضيف مفتاح لفتح النماذج المستضافة. المحرك المحلي شغال.")}</p><button onClick={onAddKey} className="btn btn-primary mt-3"><KeyRound size={15} />{t("Add a key", "ضيف مفتاح")}</button></div> : <>
        <div className="mb-2 flex items-center gap-2 rounded-xl p-2" style={{ background: "var(--soft)" }}><Logo src={LOGO(provider!.logo)} slug={provider!.logo} name={provider!.name} size={26} /><div className="flex-1"><p className="text-xs font-bold">{provider!.name}</p><p className="text-[10px] muted">{models.length} {t("chat models", "نموذج محادثة")}{active.liveModels?.length ? t(" (live)", " (مباشر)") : t(" (curated)", " (منتخبة)")}</p></div><button onClick={onAddKey} className="chip text-[10px]"><KeyRound size={11} />{t("Keys", "المفاتيح")}</button></div>
        {active.liveModels && active.liveModels.some((m) => m.free) && <div className="mb-3 rounded-xl p-2.5" style={{ background: "var(--soft)" }}>
          <p className="mb-1 flex items-center gap-1 text-[11px] font-bold"><Star size={12} className="accent" />{t("Best free models right now", "أحسن النماذج المجانية دلوقتي")}</p>
          <div className="flex flex-wrap gap-1">{active.liveModels.filter((m) => m.free && isChatModelId(m.id)).sort((a, b) => b.ctx - a.ctx).slice(0, 6).map((m) => <button key={m.id} onClick={() => { s.set({ activeModel: m.id }); onClose(); }} className="chip text-[10px]">{m.name.replace(/^[^:]+:\s*/, "").slice(0, 26)} · {Math.round(m.ctx / 1000)}K</button>)}</div>
        </div>}
        <div className="relative mb-2"><Search size={14} className="muted absolute start-2.5 top-1/2 -translate-y-1/2" /><input value={q} onChange={(e) => setQ(e.target.value)} className="field ps-8 py-2 text-sm" placeholder={t("Search models", "ابحث في النماذج")} /></div>
        <div className="scroll-hide mb-3 flex gap-1 overflow-x-auto">{([{ id: "all", en: "All", ar: "الكل" }, ...TIERS.map((x) => ({ id: x.id, en: x.en, ar: x.ar }))] as Array<{ id: string; en: string; ar: string }>).map((x) => <button key={x.id} className="chip text-[10px]" aria-pressed={tier === x.id} onClick={() => setTier(x.id as Tier | "all")}>{lang === "ar" ? x.ar : x.en}</button>)}</div>
        <div className="max-h-[55vh] space-y-4 overflow-y-auto">
          {groups.map(([fam, list]) => <section key={fam}>
            <p className="mb-1 px-1 text-[10px] font-bold uppercase tracking-wider muted">{fam === provider!.id ? provider!.name : fam}</p>
            {list.map((m) => {
              const chosen = s.activeModel === m.id;
              const slug = m.logo || modelLogoSlug(m.id, provider!.logo);
              const lm = active.liveModels?.find((x) => x.id === m.id);
              return <button key={m.id} onClick={() => { s.set({ activeModel: m.id }); onClose(); }} className="card mb-1.5 flex w-full items-center gap-2 p-2 text-start" style={{ outline: chosen ? "2px solid var(--accent)" : "1px solid var(--line)" }}>
                <Logo src={LOGO(slug)} slug={slug} name={m.name} size={24} />
                <span className="min-w-0 flex-1">
                  <span className="flex items-center gap-1 truncate text-[12.5px] font-semibold">
                    <span className="truncate">{m.name}</span>
                    {m.supportsImage && <ImageIcon size={12} className="flex-none text-sky-500" aria-label={t("Reads images", "بيقرأ صور")} />}
                    {m.supportsDoc && <FileText size={12} className="flex-none text-amber-500" aria-label={t("Reads documents", "بيقرأ مستندات")} />}
                  </span>
                  <span className="block truncate text-[10px] muted">{m.ctx ? `${(m.ctx / 1000).toFixed(0)}K ctx` : ""}{m.tier.includes("free") ? " · FREE" : ""}{lm && !lm.free && lm.prompt > 0 ? ` · $${(lm.prompt * 1e6).toFixed(2)}/M in` : ""}{m.recommended ? ` · ⭐ ${lang === "ar" ? m.recommended : "recommended"}` : ""}</span>
                </span>
                <span className="flex flex-none flex-col items-end gap-0.5">{m.tier.slice(0, 2).map((x) => <span key={x} className="rounded px-1 py-0 text-[8px] font-bold" style={{ background: x === "free" ? "#2fa36b22" : x === "premium" ? "#e5484d22" : x === "open" ? "#3e63dd22" : "var(--soft)" }}>{{ free: t("FREE", "مجاني"), cheap: t("$", "رخيص"), premium: t("$$$", "غالي"), open: t("OSS", "مفتوح"), reasoning: t("THINK", "تفكير"), balanced: t("MID", "متوازن"), vision: t("IMG", "صور"), fast: t("FAST", "سريع"), coding: t("CODE", "كود") }[x]}</span>)}{chosen && <Check size={13} className="accent" />}</span>
              </button>;
            })}
          </section>)}
          {!groups.length && <p className="text-center text-sm muted">{t("No model matches this filter.", "مفيش نموذج مطابق.")}</p>}
        </div>
      </>}
    </Sheet>
  );
}
