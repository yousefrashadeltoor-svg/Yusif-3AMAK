// Copies the official brand marks used by DAYFLOW from the MIT-licensed @lobehub/icons-static-svg package
// into src/assets/logos so they ship inside the app and render offline. Also writes docs/LOGO_MAP.md.
import fs from "node:fs";
const dir = "node_modules/@lobehub/icons-static-svg/icons";
const src = fs.readFileSync("src/lib/providers.ts", "utf8");
const slugs = new Set(["openai", "huggingface-color", "aws-color", "bedrock-color", "vertexai-color", "kimi-color", "microsoft-color", "meta", "ollama", "cloudflare-color", "alibaba-color", "stability-color", "replicate", "zai", "github", "vercel"]);
for (const m of src.matchAll(/(?:logo: |return |, \d+, )"([a-z0-9-]+)"/g)) slugs.add(m[1]);
fs.mkdirSync("src/assets/logos", { recursive: true });
const rows = [];
for (const slug of [...slugs].sort()) {
  const f = `${dir}/${slug}.svg`;
  if (!fs.existsSync(f)) { console.warn("missing in package:", slug); continue; }
  fs.copyFileSync(f, `src/assets/logos/${slug}.svg`); rows.push(slug);
}
const providers = [...src.matchAll(/id: "([a-z0-9]+)", name: "([^"]+)", logo: "([a-z0-9-]+)"/g)];
let md = "# Logo map (provider / model family → bundled file)\n\nSource: `@lobehub/icons-static-svg` (MIT) — official brand marks, bundled offline in `src/assets/logos/`. Regenerate with `node scripts/vendor-logos.mjs`.\n\n## Providers\n| Provider | id | File |\n|---|---|---|\n";
for (const [, id, name, logo] of providers) md += `| ${name} | ${id} | src/assets/logos/${logo}.svg |\n`;
md += "\n## Model families (resolved by `modelLogoSlug`)\n| Pattern | File |\n|---|---|\n";
for (const m of src.matchAll(/if \((.+?)\) return "([a-z0-9-]+)";/g)) md += `| \`${m[1].replace(/\|/g, "\\|")}\` | ${m[2]}.svg |\n`;
md += `\nTotal bundled marks: ${rows.length}. Fallback (letter in a circle) is used only for user-added custom models with no known family.\n`;
fs.writeFileSync("docs/LOGO_MAP.md", md);
console.log("bundled", rows.length);
